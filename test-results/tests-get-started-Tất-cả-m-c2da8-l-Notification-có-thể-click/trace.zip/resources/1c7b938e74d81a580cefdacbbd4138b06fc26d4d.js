import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/TransactionCreateContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMachine, useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import TransactionCreateStepOne from "/src/components/TransactionCreateStepOne.tsx";
import TransactionCreateStepTwo from "/src/components/TransactionCreateStepTwo.tsx";
import TransactionCreateStepThree from "/src/components/TransactionCreateStepThree.tsx";
import { createTransactionMachine } from "/src/machines/createTransactionMachine.ts";
import { usersMachine } from "/src/machines/usersMachine.ts";
import __vite__cjsImport10_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const debounce = __vite__cjsImport10_lodash_fp["debounce"];
import { Stepper, Step, StepLabel } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const TransactionCreateContainer = ({ authService, snackbarService }) => {
  _s();
  const [authState] = useActor(authService);
  const [, sendSnackbar] = useActor(snackbarService);
  const [createTransactionState, sendCreateTransaction, createTransactionService] = useMachine(createTransactionMachine);
  window.createTransactionService = createTransactionService;
  const [usersState, sendUsers] = useMachine(usersMachine);
  useEffect(() => {
    sendUsers({ type: "FETCH" });
  }, [sendUsers]);
  const sender = authState?.context?.user;
  const setReceiver = (receiver) => {
    sendCreateTransaction({ type: "SET_USERS", sender, receiver });
  };
  const createTransaction = (payload) => {
    sendCreateTransaction("CREATE", payload);
  };
  const userListSearch = debounce(200, (payload) => sendUsers({ type: "FETCH", ...payload }));
  const showSnackbar = (payload) => sendSnackbar({ type: "SHOW", ...payload });
  let activeStep;
  if (createTransactionState.matches("stepTwo")) {
    activeStep = 1;
  } else if (createTransactionState.matches("stepThree")) {
    activeStep = 3;
  } else {
    activeStep = 0;
  }
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Stepper, { activeStep, children: [
      /* @__PURE__ */ jsxDEV(Step, { children: /* @__PURE__ */ jsxDEV(StepLabel, { children: "Select Contact" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 74,
        columnNumber: 11
      }, this) }, "stepOne", false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Step, { children: /* @__PURE__ */ jsxDEV(StepLabel, { children: "Payment" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 77,
        columnNumber: 11
      }, this) }, "stepTwo", false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Step, { children: /* @__PURE__ */ jsxDEV(StepLabel, { children: "Complete" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 80,
        columnNumber: 11
      }, this) }, "stepThree", false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 79,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
      lineNumber: 72,
      columnNumber: 7
    }, this),
    createTransactionState.matches("stepOne") && /* @__PURE__ */ jsxDEV(
      TransactionCreateStepOne,
      {
        setReceiver,
        users: usersState.context.results,
        userListSearch
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 84,
        columnNumber: 7
      },
      this
    ),
    sender && createTransactionState.matches("stepTwo") && /* @__PURE__ */ jsxDEV(
      TransactionCreateStepTwo,
      {
        receiver: createTransactionState.context.receiver,
        sender,
        createTransaction,
        showSnackbar
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
        lineNumber: 91,
        columnNumber: 7
      },
      this
    ),
    createTransactionState.matches("stepThree") && /* @__PURE__ */ jsxDEV(TransactionCreateStepThree, { createTransactionService }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
      lineNumber: 99,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx",
    lineNumber: 71,
    columnNumber: 5
  }, this);
};
_s(TransactionCreateContainer, "YJ/v9LtUJg5ibWrM/mBaDZLF82o=", false, function() {
  return [useActor, useActor, useMachine, useMachine];
});
_c = TransactionCreateContainer;
export default TransactionCreateContainer;
var _c;
$RefreshReg$(_c, "TransactionCreateContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionCreateContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0VJLG1CQUdNLGNBSE47MkJBdEVKO0FBQWdCQSxNQUFTLGNBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDeEMsU0FBU0MsWUFBWUMsZ0JBQWdCO0FBRXJDLE9BQU9DLDhCQUE4QjtBQUNyQyxPQUFPQyw4QkFBOEI7QUFDckMsT0FBT0MsZ0NBQWdDO0FBQ3ZDLFNBQVNDLGdDQUFnQztBQUN6QyxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0MsZ0JBQWdCO0FBVXpCLFNBQVNDLFNBQVNDLE1BQU1DLGlCQUFpQjtBQWF6QyxNQUFNQyw2QkFBOENBLENBQUMsRUFBRUMsYUFBYUMsZ0JBQWdCLE1BQU07QUFBQUMsS0FBQTtBQUN4RixRQUFNLENBQUNDLFNBQVMsSUFBSWQsU0FBU1csV0FBVztBQUN4QyxRQUFNLEdBQUdJLFlBQVksSUFBSWYsU0FBU1ksZUFBZTtBQUVqRCxRQUFNLENBQUNJLHdCQUF3QkMsdUJBQXVCQyx3QkFBd0IsSUFDNUVuQixXQUFXSyx3QkFBd0I7QUFJckNlLFNBQU9ELDJCQUEyQkE7QUFFbEMsUUFBTSxDQUFDRSxZQUFZQyxTQUFTLElBQUl0QixXQUFXTSxZQUFZO0FBRXZEUCxZQUFVLE1BQU07QUFDZHVCLGNBQVUsRUFBRUMsTUFBTSxRQUFRLENBQUM7QUFBQSxFQUM3QixHQUFHLENBQUNELFNBQVMsQ0FBQztBQUVkLFFBQU1FLFNBQVNULFdBQVdVLFNBQVNDO0FBQ25DLFFBQU1DLGNBQWNBLENBQUNDLGFBQW1CO0FBRXRDViwwQkFBc0IsRUFBRUssTUFBTSxhQUFhQyxRQUFRSSxTQUFTLENBQUM7QUFBQSxFQUMvRDtBQUNBLFFBQU1DLG9CQUFvQkEsQ0FBQ0MsWUFBZ0M7QUFDekRaLDBCQUFzQixVQUFVWSxPQUFPO0FBQUEsRUFDekM7QUFDQSxRQUFNQyxpQkFBaUJ4QixTQUFTLEtBQUssQ0FBQ3VCLFlBQWlCUixVQUFVLEVBQUVDLE1BQU0sU0FBUyxHQUFHTyxRQUFRLENBQUMsQ0FBQztBQUUvRixRQUFNRSxlQUFlQSxDQUFDRixZQUE2QmQsYUFBYSxFQUFFTyxNQUFNLFFBQVEsR0FBR08sUUFBUSxDQUFDO0FBRTVGLE1BQUlHO0FBQ0osTUFBSWhCLHVCQUF1QmlCLFFBQVEsU0FBUyxHQUFHO0FBQzdDRCxpQkFBYTtBQUFBLEVBQ2YsV0FBV2hCLHVCQUF1QmlCLFFBQVEsV0FBVyxHQUFHO0FBQ3RERCxpQkFBYTtBQUFBLEVBQ2YsT0FBTztBQUNMQSxpQkFBYTtBQUFBLEVBQ2Y7QUFFQSxTQUNFLG1DQUNFO0FBQUEsMkJBQUMsV0FBUSxZQUNQO0FBQUEsNkJBQUMsUUFDQyxpQ0FBQyxhQUFVLDhCQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUIsS0FEaEIsV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQ0MsaUNBQUMsYUFBVSx1QkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWtCLEtBRFQsV0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQ0MsaUNBQUMsYUFBVSx3QkFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1CLEtBRFYsYUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQTtBQUFBLElBQ0NoQix1QkFBdUJpQixRQUFRLFNBQVMsS0FDdkM7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQSxPQUFPYixXQUFXSSxRQUFRVTtBQUFBQSxRQUMxQjtBQUFBO0FBQUEsTUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHaUM7QUFBQSxJQUdsQ1gsVUFBVVAsdUJBQXVCaUIsUUFBUSxTQUFTLEtBQ2pEO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxVQUFVakIsdUJBQXVCUSxRQUFRRztBQUFBQSxRQUN6QztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUE7QUFBQSxNQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUk2QjtBQUFBLElBRzlCWCx1QkFBdUJpQixRQUFRLFdBQVcsS0FDekMsdUJBQUMsOEJBQTJCLDRCQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStFO0FBQUEsT0E1Qm5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSjtBQUFFcEIsR0F2RUlILDRCQUEyQztBQUFBLFVBQzNCVixVQUNLQSxVQUd2QkQsWUFNOEJBLFVBQVU7QUFBQTtBQUFBb0MsS0FYdEN6QjtBQXlFTixlQUFlQTtBQUEyQixJQUFBeUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1hY2hpbmUiLCJ1c2VBY3RvciIsIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcE9uZSIsIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcFR3byIsIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcFRocmVlIiwiY3JlYXRlVHJhbnNhY3Rpb25NYWNoaW5lIiwidXNlcnNNYWNoaW5lIiwiZGVib3VuY2UiLCJTdGVwcGVyIiwiU3RlcCIsIlN0ZXBMYWJlbCIsIlRyYW5zYWN0aW9uQ3JlYXRlQ29udGFpbmVyIiwiYXV0aFNlcnZpY2UiLCJzbmFja2JhclNlcnZpY2UiLCJfcyIsImF1dGhTdGF0ZSIsInNlbmRTbmFja2JhciIsImNyZWF0ZVRyYW5zYWN0aW9uU3RhdGUiLCJzZW5kQ3JlYXRlVHJhbnNhY3Rpb24iLCJjcmVhdGVUcmFuc2FjdGlvblNlcnZpY2UiLCJ3aW5kb3ciLCJ1c2Vyc1N0YXRlIiwic2VuZFVzZXJzIiwidHlwZSIsInNlbmRlciIsImNvbnRleHQiLCJ1c2VyIiwic2V0UmVjZWl2ZXIiLCJyZWNlaXZlciIsImNyZWF0ZVRyYW5zYWN0aW9uIiwicGF5bG9hZCIsInVzZXJMaXN0U2VhcmNoIiwic2hvd1NuYWNrYmFyIiwiYWN0aXZlU3RlcCIsIm1hdGNoZXMiLCJyZXN1bHRzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUcmFuc2FjdGlvbkNyZWF0ZUNvbnRhaW5lci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNYWNoaW5lLCB1c2VBY3RvciB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7IFVzZXIsIFRyYW5zYWN0aW9uUGF5bG9hZCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQ3JlYXRlU3RlcE9uZSBmcm9tIFwiLi4vY29tcG9uZW50cy9UcmFuc2FjdGlvbkNyZWF0ZVN0ZXBPbmVcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQ3JlYXRlU3RlcFR3byBmcm9tIFwiLi4vY29tcG9uZW50cy9UcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUd29cIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQ3JlYXRlU3RlcFRocmVlIGZyb20gXCIuLi9jb21wb25lbnRzL1RyYW5zYWN0aW9uQ3JlYXRlU3RlcFRocmVlXCI7XHJcbmltcG9ydCB7IGNyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZSB9IGZyb20gXCIuLi9tYWNoaW5lcy9jcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVcIjtcclxuaW1wb3J0IHsgdXNlcnNNYWNoaW5lIH0gZnJvbSBcIi4uL21hY2hpbmVzL3VzZXJzTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBkZWJvdW5jZSB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHtcclxuICBCYXNlQWN0aW9uT2JqZWN0LFxyXG4gIEludGVycHJldGVyLFxyXG4gIFJlc29sdmVUeXBlZ2VuTWV0YSxcclxuICBTZXJ2aWNlTWFwLFxyXG4gIFR5cGVnZW5EaXNhYmxlZCxcclxufSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVFdmVudHMsIEF1dGhNYWNoaW5lU2NoZW1hIH0gZnJvbSBcIi4uL21hY2hpbmVzL2F1dGhNYWNoaW5lXCI7XHJcbmltcG9ydCB7IFNuYWNrYmFyU2NoZW1hLCBTbmFja2JhckNvbnRleHQsIFNuYWNrYmFyRXZlbnRzIH0gZnJvbSBcIi4uL21hY2hpbmVzL3NuYWNrYmFyTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBTdGVwcGVyLCBTdGVwLCBTdGVwTGFiZWwgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBQcm9wcyB7XHJcbiAgYXV0aFNlcnZpY2U6IEludGVycHJldGVyPEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVTY2hlbWEsIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnksIGFueT47XHJcbiAgc25hY2tiYXJTZXJ2aWNlOiBJbnRlcnByZXRlcjxcclxuICAgIFNuYWNrYmFyQ29udGV4dCxcclxuICAgIFNuYWNrYmFyU2NoZW1hLFxyXG4gICAgU25hY2tiYXJFdmVudHMsXHJcbiAgICBhbnksXHJcbiAgICBSZXNvbHZlVHlwZWdlbk1ldGE8VHlwZWdlbkRpc2FibGVkLCBTbmFja2JhckV2ZW50cywgQmFzZUFjdGlvbk9iamVjdCwgU2VydmljZU1hcD5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbkNyZWF0ZUNvbnRhaW5lcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgYXV0aFNlcnZpY2UsIHNuYWNrYmFyU2VydmljZSB9KSA9PiB7XHJcbiAgY29uc3QgW2F1dGhTdGF0ZV0gPSB1c2VBY3RvcihhdXRoU2VydmljZSk7XHJcbiAgY29uc3QgWywgc2VuZFNuYWNrYmFyXSA9IHVzZUFjdG9yKHNuYWNrYmFyU2VydmljZSk7XHJcblxyXG4gIGNvbnN0IFtjcmVhdGVUcmFuc2FjdGlvblN0YXRlLCBzZW5kQ3JlYXRlVHJhbnNhY3Rpb24sIGNyZWF0ZVRyYW5zYWN0aW9uU2VydmljZV0gPVxyXG4gICAgdXNlTWFjaGluZShjcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmUpO1xyXG5cclxuICAvLyBFeHBvc2UgY3JlYXRlVHJhbnNhY3Rpb25TZXJ2aWNlIG9uIHdpbmRvdyBmb3IgQ3lwcmVzc1xyXG4gIC8vIEB0cy1pZ25vcmVcclxuICB3aW5kb3cuY3JlYXRlVHJhbnNhY3Rpb25TZXJ2aWNlID0gY3JlYXRlVHJhbnNhY3Rpb25TZXJ2aWNlO1xyXG5cclxuICBjb25zdCBbdXNlcnNTdGF0ZSwgc2VuZFVzZXJzXSA9IHVzZU1hY2hpbmUodXNlcnNNYWNoaW5lKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmRVc2Vycyh7IHR5cGU6IFwiRkVUQ0hcIiB9KTtcclxuICB9LCBbc2VuZFVzZXJzXSk7XHJcblxyXG4gIGNvbnN0IHNlbmRlciA9IGF1dGhTdGF0ZT8uY29udGV4dD8udXNlcjtcclxuICBjb25zdCBzZXRSZWNlaXZlciA9IChyZWNlaXZlcjogVXNlcikgPT4ge1xyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgc2VuZENyZWF0ZVRyYW5zYWN0aW9uKHsgdHlwZTogXCJTRVRfVVNFUlNcIiwgc2VuZGVyLCByZWNlaXZlciB9KTtcclxuICB9O1xyXG4gIGNvbnN0IGNyZWF0ZVRyYW5zYWN0aW9uID0gKHBheWxvYWQ6IFRyYW5zYWN0aW9uUGF5bG9hZCkgPT4ge1xyXG4gICAgc2VuZENyZWF0ZVRyYW5zYWN0aW9uKFwiQ1JFQVRFXCIsIHBheWxvYWQpO1xyXG4gIH07XHJcbiAgY29uc3QgdXNlckxpc3RTZWFyY2ggPSBkZWJvdW5jZSgyMDAsIChwYXlsb2FkOiBhbnkpID0+IHNlbmRVc2Vycyh7IHR5cGU6IFwiRkVUQ0hcIiwgLi4ucGF5bG9hZCB9KSk7XHJcblxyXG4gIGNvbnN0IHNob3dTbmFja2JhciA9IChwYXlsb2FkOiBTbmFja2JhckNvbnRleHQpID0+IHNlbmRTbmFja2Jhcih7IHR5cGU6IFwiU0hPV1wiLCAuLi5wYXlsb2FkIH0pO1xyXG5cclxuICBsZXQgYWN0aXZlU3RlcDtcclxuICBpZiAoY3JlYXRlVHJhbnNhY3Rpb25TdGF0ZS5tYXRjaGVzKFwic3RlcFR3b1wiKSkge1xyXG4gICAgYWN0aXZlU3RlcCA9IDE7XHJcbiAgfSBlbHNlIGlmIChjcmVhdGVUcmFuc2FjdGlvblN0YXRlLm1hdGNoZXMoXCJzdGVwVGhyZWVcIikpIHtcclxuICAgIGFjdGl2ZVN0ZXAgPSAzO1xyXG4gIH0gZWxzZSB7XHJcbiAgICBhY3RpdmVTdGVwID0gMDtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8U3RlcHBlciBhY3RpdmVTdGVwPXthY3RpdmVTdGVwfT5cclxuICAgICAgICA8U3RlcCBrZXk9e1wic3RlcE9uZVwifT5cclxuICAgICAgICAgIDxTdGVwTGFiZWw+U2VsZWN0IENvbnRhY3Q8L1N0ZXBMYWJlbD5cclxuICAgICAgICA8L1N0ZXA+XHJcbiAgICAgICAgPFN0ZXAga2V5PXtcInN0ZXBUd29cIn0+XHJcbiAgICAgICAgICA8U3RlcExhYmVsPlBheW1lbnQ8L1N0ZXBMYWJlbD5cclxuICAgICAgICA8L1N0ZXA+XHJcbiAgICAgICAgPFN0ZXAga2V5PXtcInN0ZXBUaHJlZVwifT5cclxuICAgICAgICAgIDxTdGVwTGFiZWw+Q29tcGxldGU8L1N0ZXBMYWJlbD5cclxuICAgICAgICA8L1N0ZXA+XHJcbiAgICAgIDwvU3RlcHBlcj5cclxuICAgICAge2NyZWF0ZVRyYW5zYWN0aW9uU3RhdGUubWF0Y2hlcyhcInN0ZXBPbmVcIikgJiYgKFxyXG4gICAgICAgIDxUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBPbmVcclxuICAgICAgICAgIHNldFJlY2VpdmVyPXtzZXRSZWNlaXZlcn1cclxuICAgICAgICAgIHVzZXJzPXt1c2Vyc1N0YXRlLmNvbnRleHQucmVzdWx0cyF9XHJcbiAgICAgICAgICB1c2VyTGlzdFNlYXJjaD17dXNlckxpc3RTZWFyY2h9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgICAge3NlbmRlciAmJiBjcmVhdGVUcmFuc2FjdGlvblN0YXRlLm1hdGNoZXMoXCJzdGVwVHdvXCIpICYmIChcclxuICAgICAgICA8VHJhbnNhY3Rpb25DcmVhdGVTdGVwVHdvXHJcbiAgICAgICAgICByZWNlaXZlcj17Y3JlYXRlVHJhbnNhY3Rpb25TdGF0ZS5jb250ZXh0LnJlY2VpdmVyfVxyXG4gICAgICAgICAgc2VuZGVyPXtzZW5kZXJ9XHJcbiAgICAgICAgICBjcmVhdGVUcmFuc2FjdGlvbj17Y3JlYXRlVHJhbnNhY3Rpb259XHJcbiAgICAgICAgICBzaG93U25hY2tiYXI9e3Nob3dTbmFja2Jhcn1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7Y3JlYXRlVHJhbnNhY3Rpb25TdGF0ZS5tYXRjaGVzKFwic3RlcFRocmVlXCIpICYmIChcclxuICAgICAgICA8VHJhbnNhY3Rpb25DcmVhdGVTdGVwVGhyZWUgY3JlYXRlVHJhbnNhY3Rpb25TZXJ2aWNlPXtjcmVhdGVUcmFuc2FjdGlvblNlcnZpY2V9IC8+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25DcmVhdGVDb250YWluZXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbnRhaW5lcnMvVHJhbnNhY3Rpb25DcmVhdGVDb250YWluZXIudHN4In0=