import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SvgUndrawReminders697P.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function SvgUndrawReminders697P(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      "data-name": "Layer 1",
      xmlns: "http://www.w3.org/2000/svg",
      width: "959.26162",
      height: "684.45681",
      viewBox: "0 0 959.262 684.457",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M470.463 0L207.361 142.511a66.93 66.93 0 11-117.65 63.726L0 254.83l232.378 429.012 470.463-254.83z",
            fill: "#f2f2f2"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 13,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            d: "M137.144 333.711l189.613 30.182-15.405 96.782-148.135-23.58-5.973 37.528-12.144-40.411-23.361-3.719 15.405-96.782z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 17,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            opacity: 0.2,
            d: "M137.144 333.711l189.613 30.182-15.405 96.782-148.135-23.58-5.973 37.528-12.144-40.411-23.361-3.719 15.405-96.782z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 21,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#f2f2f2",
            d: "M283.886 391.497l-114.558-18.234 1.572-9.876 114.558 18.235zM280.74 411.248l-114.557-18.235 1.572-9.876 114.558 18.235zM277.597 431l-114.558-18.235 1.572-9.876 114.558 18.235z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 25,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            d: "M124.156 472.652l176.225-76.216 38.902 89.948-137.676 59.544 15.084 34.877-31.921-27.595-21.712 9.39-38.902-89.948z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 29,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#f2f2f2",
            d: "M279 442.726l-106.47 46.047-3.969-9.178 106.47-46.047zM286.939 461.084l-106.47 46.047-3.969-9.178 106.47-46.047zM294.875 479.44l-106.47 46.047-3.969-9.178 106.47-46.048z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 33,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            d: "M151.156 296.652l176.225-76.216 38.902 89.948-137.676 59.544 15.084 34.877-31.921-27.595-21.712 9.39-38.902-89.948z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 37,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#f2f2f2",
            d: "M306 266.726l-106.47 46.047-3.969-9.178 106.47-46.047zM313.939 285.084l-106.47 46.047-3.97-9.178 106.47-46.047zM321.876 303.44l-106.47 46.048-3.97-9.179 106.47-46.047z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 41,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M164.592 78.957l704.91 30.124s110.456 351.451 28.116 502.073l-667.757 73.303s140.58-261.078-65.27-605.5z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 45,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "none",
            stroke: "#2f2e41",
            strokeMiterlimit: 10,
            strokeWidth: 2,
            d: "M272.035 242.633l594.455-10.042M288.102 288.823l600.479-12.049M178.866 103.694l696.284 24.484"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 49,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M702.682 463.547c0 1.49-.01 2.98-.05 4.45v.01c-.06 3.64-.2 7.22-.43 10.78q-.36 5.73-.98 11.31c-4.05 36.37-16.27 68.06-33.42 89.72-9.72 12.29-21.03 21.36-33.34 26.24a58.449 58.449 0 01-11.65 3.29 55.128 55.128 0 01-9.37.8c-14.73 0-28.63-5.86-40.87-16.26-23.65-20.05-41.15-56.97-46.58-101.08v-.01c-.92-7.46-1.5-15.11-1.69-22.93q-.09-3.135-.09-6.32c0-80.97 39.95-146.61 89.23-146.61 11.67 0 22.82 3.68 33.04 10.38.3.19.6.39.89.6a86.977 86.977 0 0115.35 13.38 112.596 112.596 0 018.24 10.15 134.249 134.249 0 018.92 14.22c2.24 4.1 4.35 8.42 6.29 12.93v.01q3.03 6.96 5.55 14.5v.01a214.027 214.027 0 019.86 47.41c.73 7.5 1.1 15.19 1.1 23.02z",
            opacity: 0.2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 56,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M219.27 90.501c.765 2.868-.153 6.195-2.047 7.429-1.889 1.23-4.034-.09-4.796-2.946s.146-6.177 2.032-7.42c1.89-1.244 4.046.07 4.81 2.937zM235.312 90.25c.765 2.868-.153 6.195-2.046 7.429-1.89 1.23-4.035-.09-4.797-2.946s.147-6.177 2.033-7.42c1.89-1.244 4.045.07 4.81 2.937zM203.227 90.752c.765 2.868-.153 6.195-2.046 7.429-1.89 1.23-4.035-.09-4.797-2.946s.147-6.177 2.033-7.42c1.89-1.244 4.045.07 4.81 2.937z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 60,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M704.025 379.014l5.191 15.445 5.62.434-5.052-38.503c1.877-24.319-8.275-45.773-32.593-47.65a30.837 30.837 0 00-33.119 28.372l-2.868 37.157a14.896 14.896 0 0013.705 15.998l43.6 3.365z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 64,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M709.506 466.982s4.616 12.528 12.528 14.506 66.597 15.825 66.597 15.825 51.431 1.319 35.606 12.528-41.54 0-41.54 0-75.169-9.23-81.103-19.121a133.286 133.286 0 01-9.891-21.1z",
            fill: "#fbbebe"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 68,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M684.45 411.595s37.584 61.321 32.969 62.64-47.475 15.166-49.453 9.89-1.979-29.671-1.979-29.671z",
            fill: "#ff6584"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 72,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M684.45 411.595s37.584 61.321 32.969 62.64-47.475 15.166-49.453 9.89-1.979-29.671-1.979-29.671z",
            opacity: 0.15
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 76,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M581.192 391.298l-55.787 77.568s-37.096 33.133-23.193 37.112 35.97-28.107 35.97-28.107l64.3-81.199zM695.66 362.8s-16.485 25.057-15.166 30.991c0 0-1.32 3.957.659 6.594s1.319 18.463 1.319 18.463l-6.594 9.23-8.572-28.352-3.956-30.331s8.901-12.199 7.583-18.133 24.726 11.539 24.726 11.539z",
            fill: "#fbbebe"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 80,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M667.802 579.817c-9.72 12.29-21.03 21.36-33.34 26.24a58.449 58.449 0 01-11.65 3.29c2.11-46.81 4.54-88.56 6.25-92.25 3.96-8.57 14.51-11.87 14.51-11.87s1.04 2.79 2.78 7.64c4.51 12.64 13.73 39.28 21.45 66.95z",
            fill: "#ff6584"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 84,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M667.802 579.817c-9.72 12.29-21.03 21.36-33.34 26.24a58.449 58.449 0 01-11.65 3.29c2.11-46.81 4.54-88.56 6.25-92.25 3.96-8.57 14.51-11.87 14.51-11.87s1.04 2.79 2.78 7.64c4.51 12.64 13.73 39.28 21.45 66.95z",
            opacity: 0.15
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 88,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 687.087, cy: 342.36, r: 24.397, fill: "#fbbebe" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
          lineNumber: 92,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M676.542 455.117c-4.56 4.34-7.91 7.54-10.37 9.98-5 4.94-6.34 6.71-6.78 8.48-.66 2.64-3.95 2.64-3.95 2.64l-9.09 36.65-10.04 40.49s-.65 22.5-1.85 52.7a58.449 58.449 0 01-11.65 3.29 55.128 55.128 0 01-9.37.8c-14.73 0-28.63-5.86-40.87-16.26.17-38.62-.22-78.11-.22-78.11s-10.55-17.14 25.72-50.77c0 0 5.72-16.68 11.64-33.43 5.95-16.88 12.1-33.83 12.76-33.83.44 0 3.59-4.03 7.59-9.4 3.51-4.7 7.68-10.44 11.24-15.41 4.59-6.36 8.2-11.45 8.2-11.45s10.83 0 15.47 5.53a8.505 8.505 0 011.68 3.04c1.12 3.65 3.68 12.56 6.25 21.6 3.45 12.17 6.93 24.55 6.93 24.55l1.77-14.88s5.49 7.63 5.49 13.56c0 .32.01.68.02 1.09.29 7.11 2.52 26.66-10.57 39.14z",
            fill: "#ff6584"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 93,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M657.416 366.757l-7.913-5.275s-32.969 19.781-56.047 21.1-22.419 14.506-13.187 23.738 45.497 40.88 46.815 32.968 30.332-72.531 30.332-72.531z",
            fill: "#ff6584"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 97,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M700.883 311.91c-5.303-1.789-18.132-2.74-20.009-2.886a34.531 34.531 0 00-37.086 31.772l-16.692 47.325 25.23 1.947 6.067-17.585 5.262 18.46 12.7.98 1.924-10.7 3.466 11.116 14.147 1.091c-8.745-24.79-12.694-47.077 2.267-59.49 9.3 2.006 17.422.1 19.107-4.896 1.942-5.756-5.393-13.427-16.383-17.134z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 101,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f51b5", d: "M767.262 367.957h192v98h-150v38l-18.345-38h-23.655v-98z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
          lineNumber: 105,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#f2f2f2",
            d: "M921.261 401.957h-116v-10h116zM921.261 421.957h-116v-10h116zM921.261 441.957h-116v-10h116z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 106,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            opacity: 0.2,
            d: "M560.22 142.874l48.306 12.905-12.904 48.306-48.306-12.905z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 110,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "circle",
          {
            cx: 591.037,
            cy: 193.867,
            r: 14.756,
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
            lineNumber: 115,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = SvgUndrawReminders697P;
export default SvgUndrawReminders697P;
var _c;
$RefreshReg$(_c, "SvgUndrawReminders697P");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawReminders697P.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFOUIsU0FBU0EsdUJBQXVCQyxPQUFZO0FBQzFDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLEdBQUlBO0FBQUFBLE1BRUo7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFd0g7QUFBQSxRQUV4SDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUztBQUFBLFlBQ1QsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFd0g7QUFBQSxRQUV4SDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFcUw7QUFBQSxRQUVyTDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFeUg7QUFBQSxRQUV6SDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFK0s7QUFBQSxRQUUvSztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFeUg7QUFBQSxRQUV6SDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFNks7QUFBQSxRQUU3SztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsUUFBTztBQUFBLFlBQ1Asa0JBQWtCO0FBQUEsWUFDbEIsYUFBYTtBQUFBLFlBQ2IsR0FBRTtBQUFBO0FBQUEsVUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFLbUc7QUFBQSxRQUVuRztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsU0FBUztBQUFBO0FBQUEsVUFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZTtBQUFBLFFBRWY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLFNBQVM7QUFBQTtBQUFBLFVBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLFNBQVM7QUFBQTtBQUFBLFVBRlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsWUFBTyxJQUFJLFNBQVMsSUFBSSxRQUFRLEdBQUcsUUFBUSxNQUFLLGFBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMEQ7QUFBQSxRQUMxRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQix1QkFBQyxVQUFLLE1BQUssV0FBVSxHQUFFLDZEQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWdGO0FBQUEsUUFDaEY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLEdBQUU7QUFBQTtBQUFBLFVBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdHO0FBQUEsUUFFaEc7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLFNBQVM7QUFBQSxZQUNULEdBQUU7QUFBQTtBQUFBLFVBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBR2dFO0FBQUEsUUFFaEU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLEdBQUc7QUFBQSxZQUNILE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBUGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBT2lCO0FBQUE7QUFBQTtBQUFBLElBckhuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF1SEE7QUFFSjtBQUFDQyxLQTNIUUY7QUE2SFQsZUFBZUE7QUFBdUIsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlN2Z1VuZHJhd1JlbWluZGVyczY5N1AiLCJwcm9wcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3ZnVW5kcmF3UmVtaW5kZXJzNjk3UC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcblxyXG5mdW5jdGlvbiBTdmdVbmRyYXdSZW1pbmRlcnM2OTdQKHByb3BzOiBhbnkpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2Z1xyXG4gICAgICBkYXRhLW5hbWU9XCJMYXllciAxXCJcclxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgIHdpZHRoPVwiOTU5LjI2MTYyXCJcclxuICAgICAgaGVpZ2h0PVwiNjg0LjQ1NjgxXCJcclxuICAgICAgdmlld0JveD1cIjAgMCA5NTkuMjYyIDY4NC40NTdcIlxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICA+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk00NzAuNDYzIDBMMjA3LjM2MSAxNDIuNTExYTY2LjkzIDY2LjkzIDAgMTEtMTE3LjY1IDYzLjcyNkwwIDI1NC44M2wyMzIuMzc4IDQyOS4wMTIgNDcwLjQ2My0yNTQuODN6XCJcclxuICAgICAgICBmaWxsPVwiI2YyZjJmMlwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiMzZjUxYjVcIlxyXG4gICAgICAgIGQ9XCJNMTM3LjE0NCAzMzMuNzExbDE4OS42MTMgMzAuMTgyLTE1LjQwNSA5Ni43ODItMTQ4LjEzNS0yMy41OC01Ljk3MyAzNy41MjgtMTIuMTQ0LTQwLjQxMS0yMy4zNjEtMy43MTkgMTUuNDA1LTk2Ljc4MnpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIG9wYWNpdHk9ezAuMn1cclxuICAgICAgICBkPVwiTTEzNy4xNDQgMzMzLjcxMWwxODkuNjEzIDMwLjE4Mi0xNS40MDUgOTYuNzgyLTE0OC4xMzUtMjMuNTgtNS45NzMgMzcuNTI4LTEyLjE0NC00MC40MTEtMjMuMzYxLTMuNzE5IDE1LjQwNS05Ni43ODJ6XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsPVwiI2YyZjJmMlwiXHJcbiAgICAgICAgZD1cIk0yODMuODg2IDM5MS40OTdsLTExNC41NTgtMTguMjM0IDEuNTcyLTkuODc2IDExNC41NTggMTguMjM1ek0yODAuNzQgNDExLjI0OGwtMTE0LjU1Ny0xOC4yMzUgMS41NzItOS44NzYgMTE0LjU1OCAxOC4yMzV6TTI3Ny41OTcgNDMxbC0xMTQuNTU4LTE4LjIzNSAxLjU3Mi05Ljg3NiAxMTQuNTU4IDE4LjIzNXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgICBkPVwiTTEyNC4xNTYgNDcyLjY1MmwxNzYuMjI1LTc2LjIxNiAzOC45MDIgODkuOTQ4LTEzNy42NzYgNTkuNTQ0IDE1LjA4NCAzNC44NzctMzEuOTIxLTI3LjU5NS0yMS43MTIgOS4zOS0zOC45MDItODkuOTQ4elwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiNmMmYyZjJcIlxyXG4gICAgICAgIGQ9XCJNMjc5IDQ0Mi43MjZsLTEwNi40NyA0Ni4wNDctMy45NjktOS4xNzggMTA2LjQ3LTQ2LjA0N3pNMjg2LjkzOSA0NjEuMDg0bC0xMDYuNDcgNDYuMDQ3LTMuOTY5LTkuMTc4IDEwNi40Ny00Ni4wNDd6TTI5NC44NzUgNDc5LjQ0bC0xMDYuNDcgNDYuMDQ3LTMuOTY5LTkuMTc4IDEwNi40Ny00Ni4wNDh6XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsPVwiIzNmNTFiNVwiXHJcbiAgICAgICAgZD1cIk0xNTEuMTU2IDI5Ni42NTJsMTc2LjIyNS03Ni4yMTYgMzguOTAyIDg5Ljk0OC0xMzcuNjc2IDU5LjU0NCAxNS4wODQgMzQuODc3LTMxLjkyMS0yNy41OTUtMjEuNzEyIDkuMzktMzguOTAyLTg5Ljk0OHpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjZjJmMmYyXCJcclxuICAgICAgICBkPVwiTTMwNiAyNjYuNzI2bC0xMDYuNDcgNDYuMDQ3LTMuOTY5LTkuMTc4IDEwNi40Ny00Ni4wNDd6TTMxMy45MzkgMjg1LjA4NGwtMTA2LjQ3IDQ2LjA0Ny0zLjk3LTkuMTc4IDEwNi40Ny00Ni4wNDd6TTMyMS44NzYgMzAzLjQ0bC0xMDYuNDcgNDYuMDQ4LTMuOTctOS4xNzkgMTA2LjQ3LTQ2LjA0N3pcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMTY0LjU5MiA3OC45NTdsNzA0LjkxIDMwLjEyNHMxMTAuNDU2IDM1MS40NTEgMjguMTE2IDUwMi4wNzNsLTY2Ny43NTcgNzMuMzAzczE0MC41OC0yNjEuMDc4LTY1LjI3LTYwNS41elwiXHJcbiAgICAgICAgZmlsbD1cIiMzZjNkNTZcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCIjMmYyZTQxXCJcclxuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PXsxMH1cclxuICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgICBkPVwiTTI3Mi4wMzUgMjQyLjYzM2w1OTQuNDU1LTEwLjA0Mk0yODguMTAyIDI4OC44MjNsNjAwLjQ3OS0xMi4wNDlNMTc4Ljg2NiAxMDMuNjk0bDY5Ni4yODQgMjQuNDg0XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTcwMi42ODIgNDYzLjU0N2MwIDEuNDktLjAxIDIuOTgtLjA1IDQuNDV2LjAxYy0uMDYgMy42NC0uMiA3LjIyLS40MyAxMC43OHEtLjM2IDUuNzMtLjk4IDExLjMxYy00LjA1IDM2LjM3LTE2LjI3IDY4LjA2LTMzLjQyIDg5LjcyLTkuNzIgMTIuMjktMjEuMDMgMjEuMzYtMzMuMzQgMjYuMjRhNTguNDQ5IDU4LjQ0OSAwIDAxLTExLjY1IDMuMjkgNTUuMTI4IDU1LjEyOCAwIDAxLTkuMzcuOGMtMTQuNzMgMC0yOC42My01Ljg2LTQwLjg3LTE2LjI2LTIzLjY1LTIwLjA1LTQxLjE1LTU2Ljk3LTQ2LjU4LTEwMS4wOHYtLjAxYy0uOTItNy40Ni0xLjUtMTUuMTEtMS42OS0yMi45M3EtLjA5LTMuMTM1LS4wOS02LjMyYzAtODAuOTcgMzkuOTUtMTQ2LjYxIDg5LjIzLTE0Ni42MSAxMS42NyAwIDIyLjgyIDMuNjggMzMuMDQgMTAuMzguMy4xOS42LjM5Ljg5LjZhODYuOTc3IDg2Ljk3NyAwIDAxMTUuMzUgMTMuMzggMTEyLjU5NiAxMTIuNTk2IDAgMDE4LjI0IDEwLjE1IDEzNC4yNDkgMTM0LjI0OSAwIDAxOC45MiAxNC4yMmMyLjI0IDQuMSA0LjM1IDguNDIgNi4yOSAxMi45M3YuMDFxMy4wMyA2Ljk2IDUuNTUgMTQuNXYuMDFhMjE0LjAyNyAyMTQuMDI3IDAgMDE5Ljg2IDQ3LjQxYy43MyA3LjUgMS4xIDE1LjE5IDEuMSAyMy4wMnpcIlxyXG4gICAgICAgIG9wYWNpdHk9ezAuMn1cclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTIxOS4yNyA5MC41MDFjLjc2NSAyLjg2OC0uMTUzIDYuMTk1LTIuMDQ3IDcuNDI5LTEuODg5IDEuMjMtNC4wMzQtLjA5LTQuNzk2LTIuOTQ2cy4xNDYtNi4xNzcgMi4wMzItNy40MmMxLjg5LTEuMjQ0IDQuMDQ2LjA3IDQuODEgMi45Mzd6TTIzNS4zMTIgOTAuMjVjLjc2NSAyLjg2OC0uMTUzIDYuMTk1LTIuMDQ2IDcuNDI5LTEuODkgMS4yMy00LjAzNS0uMDktNC43OTctMi45NDZzLjE0Ny02LjE3NyAyLjAzMy03LjQyYzEuODktMS4yNDQgNC4wNDUuMDcgNC44MSAyLjkzN3pNMjAzLjIyNyA5MC43NTJjLjc2NSAyLjg2OC0uMTUzIDYuMTk1LTIuMDQ2IDcuNDI5LTEuODkgMS4yMy00LjAzNS0uMDktNC43OTctMi45NDZzLjE0Ny02LjE3NyAyLjAzMy03LjQyYzEuODktMS4yNDQgNC4wNDUuMDcgNC44MSAyLjkzN3pcIlxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTcwNC4wMjUgMzc5LjAxNGw1LjE5MSAxNS40NDUgNS42Mi40MzQtNS4wNTItMzguNTAzYzEuODc3LTI0LjMxOS04LjI3NS00NS43NzMtMzIuNTkzLTQ3LjY1YTMwLjgzNyAzMC44MzcgMCAwMC0zMy4xMTkgMjguMzcybC0yLjg2OCAzNy4xNTdhMTQuODk2IDE0Ljg5NiAwIDAwMTMuNzA1IDE1Ljk5OGw0My42IDMuMzY1elwiXHJcbiAgICAgICAgZmlsbD1cIiMyZjJlNDFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNzA5LjUwNiA0NjYuOTgyczQuNjE2IDEyLjUyOCAxMi41MjggMTQuNTA2IDY2LjU5NyAxNS44MjUgNjYuNTk3IDE1LjgyNSA1MS40MzEgMS4zMTkgMzUuNjA2IDEyLjUyOC00MS41NCAwLTQxLjU0IDAtNzUuMTY5LTkuMjMtODEuMTAzLTE5LjEyMWExMzMuMjg2IDEzMy4yODYgMCAwMS05Ljg5MS0yMS4xelwiXHJcbiAgICAgICAgZmlsbD1cIiNmYmJlYmVcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNjg0LjQ1IDQxMS41OTVzMzcuNTg0IDYxLjMyMSAzMi45NjkgNjIuNjQtNDcuNDc1IDE1LjE2Ni00OS40NTMgOS44OS0xLjk3OS0yOS42NzEtMS45NzktMjkuNjcxelwiXHJcbiAgICAgICAgZmlsbD1cIiNmZjY1ODRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNjg0LjQ1IDQxMS41OTVzMzcuNTg0IDYxLjMyMSAzMi45NjkgNjIuNjQtNDcuNDc1IDE1LjE2Ni00OS40NTMgOS44OS0xLjk3OS0yOS42NzEtMS45NzktMjkuNjcxelwiXHJcbiAgICAgICAgb3BhY2l0eT17MC4xNX1cclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTU4MS4xOTIgMzkxLjI5OGwtNTUuNzg3IDc3LjU2OHMtMzcuMDk2IDMzLjEzMy0yMy4xOTMgMzcuMTEyIDM1Ljk3LTI4LjEwNyAzNS45Ny0yOC4xMDdsNjQuMy04MS4xOTl6TTY5NS42NiAzNjIuOHMtMTYuNDg1IDI1LjA1Ny0xNS4xNjYgMzAuOTkxYzAgMC0xLjMyIDMuOTU3LjY1OSA2LjU5NHMxLjMxOSAxOC40NjMgMS4zMTkgMTguNDYzbC02LjU5NCA5LjIzLTguNTcyLTI4LjM1Mi0zLjk1Ni0zMC4zMzFzOC45MDEtMTIuMTk5IDcuNTgzLTE4LjEzMyAyNC43MjYgMTEuNTM5IDI0LjcyNiAxMS41Mzl6XCJcclxuICAgICAgICBmaWxsPVwiI2ZiYmViZVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk02NjcuODAyIDU3OS44MTdjLTkuNzIgMTIuMjktMjEuMDMgMjEuMzYtMzMuMzQgMjYuMjRhNTguNDQ5IDU4LjQ0OSAwIDAxLTExLjY1IDMuMjljMi4xMS00Ni44MSA0LjU0LTg4LjU2IDYuMjUtOTIuMjUgMy45Ni04LjU3IDE0LjUxLTExLjg3IDE0LjUxLTExLjg3czEuMDQgMi43OSAyLjc4IDcuNjRjNC41MSAxMi42NCAxMy43MyAzOS4yOCAyMS40NSA2Ni45NXpcIlxyXG4gICAgICAgIGZpbGw9XCIjZmY2NTg0XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTY2Ny44MDIgNTc5LjgxN2MtOS43MiAxMi4yOS0yMS4wMyAyMS4zNi0zMy4zNCAyNi4yNGE1OC40NDkgNTguNDQ5IDAgMDEtMTEuNjUgMy4yOWMyLjExLTQ2LjgxIDQuNTQtODguNTYgNi4yNS05Mi4yNSAzLjk2LTguNTcgMTQuNTEtMTEuODcgMTQuNTEtMTEuODdzMS4wNCAyLjc5IDIuNzggNy42NGM0LjUxIDEyLjY0IDEzLjczIDM5LjI4IDIxLjQ1IDY2Ljk1elwiXHJcbiAgICAgICAgb3BhY2l0eT17MC4xNX1cclxuICAgICAgLz5cclxuICAgICAgPGNpcmNsZSBjeD17Njg3LjA4N30gY3k9ezM0Mi4zNn0gcj17MjQuMzk3fSBmaWxsPVwiI2ZiYmViZVwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk02NzYuNTQyIDQ1NS4xMTdjLTQuNTYgNC4zNC03LjkxIDcuNTQtMTAuMzcgOS45OC01IDQuOTQtNi4zNCA2LjcxLTYuNzggOC40OC0uNjYgMi42NC0zLjk1IDIuNjQtMy45NSAyLjY0bC05LjA5IDM2LjY1LTEwLjA0IDQwLjQ5cy0uNjUgMjIuNS0xLjg1IDUyLjdhNTguNDQ5IDU4LjQ0OSAwIDAxLTExLjY1IDMuMjkgNTUuMTI4IDU1LjEyOCAwIDAxLTkuMzcuOGMtMTQuNzMgMC0yOC42My01Ljg2LTQwLjg3LTE2LjI2LjE3LTM4LjYyLS4yMi03OC4xMS0uMjItNzguMTFzLTEwLjU1LTE3LjE0IDI1LjcyLTUwLjc3YzAgMCA1LjcyLTE2LjY4IDExLjY0LTMzLjQzIDUuOTUtMTYuODggMTIuMS0zMy44MyAxMi43Ni0zMy44My40NCAwIDMuNTktNC4wMyA3LjU5LTkuNCAzLjUxLTQuNyA3LjY4LTEwLjQ0IDExLjI0LTE1LjQxIDQuNTktNi4zNiA4LjItMTEuNDUgOC4yLTExLjQ1czEwLjgzIDAgMTUuNDcgNS41M2E4LjUwNSA4LjUwNSAwIDAxMS42OCAzLjA0YzEuMTIgMy42NSAzLjY4IDEyLjU2IDYuMjUgMjEuNiAzLjQ1IDEyLjE3IDYuOTMgMjQuNTUgNi45MyAyNC41NWwxLjc3LTE0Ljg4czUuNDkgNy42MyA1LjQ5IDEzLjU2YzAgLjMyLjAxLjY4LjAyIDEuMDkuMjkgNy4xMSAyLjUyIDI2LjY2LTEwLjU3IDM5LjE0elwiXHJcbiAgICAgICAgZmlsbD1cIiNmZjY1ODRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNjU3LjQxNiAzNjYuNzU3bC03LjkxMy01LjI3NXMtMzIuOTY5IDE5Ljc4MS01Ni4wNDcgMjEuMS0yMi40MTkgMTQuNTA2LTEzLjE4NyAyMy43MzggNDUuNDk3IDQwLjg4IDQ2LjgxNSAzMi45NjggMzAuMzMyLTcyLjUzMSAzMC4zMzItNzIuNTMxelwiXHJcbiAgICAgICAgZmlsbD1cIiNmZjY1ODRcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNzAwLjg4MyAzMTEuOTFjLTUuMzAzLTEuNzg5LTE4LjEzMi0yLjc0LTIwLjAwOS0yLjg4NmEzNC41MzEgMzQuNTMxIDAgMDAtMzcuMDg2IDMxLjc3MmwtMTYuNjkyIDQ3LjMyNSAyNS4yMyAxLjk0NyA2LjA2Ny0xNy41ODUgNS4yNjIgMTguNDYgMTIuNy45OCAxLjkyNC0xMC43IDMuNDY2IDExLjExNiAxNC4xNDcgMS4wOTFjLTguNzQ1LTI0Ljc5LTEyLjY5NC00Ny4wNzcgMi4yNjctNTkuNDkgOS4zIDIuMDA2IDE3LjQyMi4xIDE5LjEwNy00Ljg5NiAxLjk0Mi01Ljc1Ni01LjM5My0xMy40MjctMTYuMzgzLTE3LjEzNHpcIlxyXG4gICAgICAgIGZpbGw9XCIjMmYyZTQxXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGggZmlsbD1cIiMzZjUxYjVcIiBkPVwiTTc2Ny4yNjIgMzY3Ljk1N2gxOTJ2OThoLTE1MHYzOGwtMTguMzQ1LTM4aC0yMy42NTV2LTk4elwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiNmMmYyZjJcIlxyXG4gICAgICAgIGQ9XCJNOTIxLjI2MSA0MDEuOTU3aC0xMTZ2LTEwaDExNnpNOTIxLjI2MSA0MjEuOTU3aC0xMTZ2LTEwaDExNnpNOTIxLjI2MSA0NDEuOTU3aC0xMTZ2LTEwaDExNnpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgICBvcGFjaXR5PXswLjJ9XHJcbiAgICAgICAgZD1cIk01NjAuMjIgMTQyLjg3NGw0OC4zMDYgMTIuOTA1LTEyLjkwNCA0OC4zMDYtNDguMzA2LTEyLjkwNXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8Y2lyY2xlXHJcbiAgICAgICAgY3g9ezU5MS4wMzd9XHJcbiAgICAgICAgY3k9ezE5My44Njd9XHJcbiAgICAgICAgcj17MTQuNzU2fVxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCIjM2YzZDU2XCJcclxuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PXsxMH1cclxuICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN2Z1VuZHJhd1JlbWluZGVyczY5N1A7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvU3ZnVW5kcmF3UmVtaW5kZXJzNjk3UC50c3gifQ==