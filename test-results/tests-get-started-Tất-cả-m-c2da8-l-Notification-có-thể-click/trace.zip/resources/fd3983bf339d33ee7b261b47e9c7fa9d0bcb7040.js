import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=6af76b79"; const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];
import { Router } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import { createTheme, StyledEngineProvider } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { ThemeProvider } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import App from "/src/containers/App.tsx";
import { history } from "/src/utils/historyUtils.ts";
const theme = createTheme({
  palette: {
    secondary: {
      main: "#fff"
    }
  },
  typography: {
    // htmlFontSize: 18.285714285714286,
    fontSize: 14 * 0.875,
    body1: {
      lineHeight: 1.43,
      letterSpacing: "0.01071em"
    }
  },
  components: {
    MuiOutlinedInput: {
      styleOverrides: {
        input: {
          padding: "6px 0 7px"
        }
      }
    },
    MuiInputBase: {
      styleOverrides: {
        input: {
          padding: "6px 0 7px"
        }
      }
    }
    // MuiInput: {
    //   defaultProps: {
    //     inputProps: {
    //       backgroundColor: "green",
    //       height: "300px",
    //     },
    //   },
    // },
  }
});
const root = createRoot(document.getElementById("root"));
root.render(
  /* @__PURE__ */ jsxDEV(Router, { history, children: /* @__PURE__ */ jsxDEV(StyledEngineProvider, { injectFirst: true, children: /* @__PURE__ */ jsxDEV(ThemeProvider, { theme, children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/index.tsx",
    lineNumber: 55,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/index.tsx",
    lineNumber: 54,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/index.tsx",
    lineNumber: 53,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/index.tsx",
    lineNumber: 52,
    columnNumber: 3
  }, this)
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBc0RRO0FBckRSLFNBQVNBLGtCQUFrQjtBQUMzQixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGFBQWFDLDRCQUE0QjtBQUNsRCxTQUFTQyxxQkFBcUI7QUFDOUIsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxlQUFlO0FBRXhCLE1BQU1DLFFBQVFMLFlBQVk7QUFBQSxFQUN4Qk0sU0FBUztBQUFBLElBQ1BDLFdBQVc7QUFBQSxNQUNUQyxNQUFNO0FBQUEsSUFDUjtBQUFBLEVBQ0Y7QUFBQSxFQUNBQyxZQUFZO0FBQUE7QUFBQSxJQUVWQyxVQUFVLEtBQUs7QUFBQSxJQUNmQyxPQUFPO0FBQUEsTUFDTEMsWUFBWTtBQUFBLE1BQ1pDLGVBQWU7QUFBQSxJQUNqQjtBQUFBLEVBQ0Y7QUFBQSxFQUNBQyxZQUFZO0FBQUEsSUFDVkMsa0JBQWtCO0FBQUEsTUFDaEJDLGdCQUFnQjtBQUFBLFFBQ2RDLE9BQU87QUFBQSxVQUNMQyxTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUEsSUFDQUMsY0FBYztBQUFBLE1BQ1pILGdCQUFnQjtBQUFBLFFBQ2RDLE9BQU87QUFBQSxVQUNMQyxTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBU0Y7QUFDRixDQUFDO0FBRUQsTUFBTUUsT0FBT3RCLFdBQVd1QixTQUFTQyxlQUFlLE1BQU0sQ0FBRTtBQUV4REYsS0FBS0c7QUFBQUEsRUFDSCx1QkFBQyxVQUFPLFNBQ04saUNBQUMsd0JBQXFCLGFBQVcsTUFDL0IsaUNBQUMsaUJBQWMsT0FDYixpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQSxLQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUNGIiwibmFtZXMiOlsiY3JlYXRlUm9vdCIsIlJvdXRlciIsImNyZWF0ZVRoZW1lIiwiU3R5bGVkRW5naW5lUHJvdmlkZXIiLCJUaGVtZVByb3ZpZGVyIiwiQXBwIiwiaGlzdG9yeSIsInRoZW1lIiwicGFsZXR0ZSIsInNlY29uZGFyeSIsIm1haW4iLCJ0eXBvZ3JhcGh5IiwiZm9udFNpemUiLCJib2R5MSIsImxpbmVIZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwiY29tcG9uZW50cyIsIk11aU91dGxpbmVkSW5wdXQiLCJzdHlsZU92ZXJyaWRlcyIsImlucHV0IiwicGFkZGluZyIsIk11aUlucHV0QmFzZSIsInJvb3QiLCJkb2N1bWVudCIsImdldEVsZW1lbnRCeUlkIiwicmVuZGVyIl0sInNvdXJjZXMiOlsiaW5kZXgudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XHJcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGNyZWF0ZVRoZW1lLCBTdHlsZWRFbmdpbmVQcm92aWRlciB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IEFwcCBmcm9tIFwiLi9jb250YWluZXJzL0FwcFwiO1xyXG5pbXBvcnQgeyBoaXN0b3J5IH0gZnJvbSBcIi4vdXRpbHMvaGlzdG9yeVV0aWxzXCI7XHJcblxyXG5jb25zdCB0aGVtZSA9IGNyZWF0ZVRoZW1lKHtcclxuICBwYWxldHRlOiB7XHJcbiAgICBzZWNvbmRhcnk6IHtcclxuICAgICAgbWFpbjogXCIjZmZmXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgdHlwb2dyYXBoeToge1xyXG4gICAgLy8gaHRtbEZvbnRTaXplOiAxOC4yODU3MTQyODU3MTQyODYsXHJcbiAgICBmb250U2l6ZTogMTQgKiAwLjg3NSxcclxuICAgIGJvZHkxOiB7XHJcbiAgICAgIGxpbmVIZWlnaHQ6IDEuNDMsXHJcbiAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wMTA3MWVtXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcbiAgY29tcG9uZW50czoge1xyXG4gICAgTXVpT3V0bGluZWRJbnB1dDoge1xyXG4gICAgICBzdHlsZU92ZXJyaWRlczoge1xyXG4gICAgICAgIGlucHV0OiB7XHJcbiAgICAgICAgICBwYWRkaW5nOiBcIjZweCAwIDdweFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICB9LFxyXG4gICAgTXVpSW5wdXRCYXNlOiB7XHJcbiAgICAgIHN0eWxlT3ZlcnJpZGVzOiB7XHJcbiAgICAgICAgaW5wdXQ6IHtcclxuICAgICAgICAgIHBhZGRpbmc6IFwiNnB4IDAgN3B4XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgICAvLyBNdWlJbnB1dDoge1xyXG4gICAgLy8gICBkZWZhdWx0UHJvcHM6IHtcclxuICAgIC8vICAgICBpbnB1dFByb3BzOiB7XHJcbiAgICAvLyAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IFwiZ3JlZW5cIixcclxuICAgIC8vICAgICAgIGhlaWdodDogXCIzMDBweFwiLFxyXG4gICAgLy8gICAgIH0sXHJcbiAgICAvLyAgIH0sXHJcbiAgICAvLyB9LFxyXG4gIH0sXHJcbn0pO1xyXG5cclxuY29uc3Qgcm9vdCA9IGNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoXCJyb290XCIpISk7XHJcblxyXG5yb290LnJlbmRlcihcclxuICA8Um91dGVyIGhpc3Rvcnk9e2hpc3Rvcnl9PlxyXG4gICAgPFN0eWxlZEVuZ2luZVByb3ZpZGVyIGluamVjdEZpcnN0PlxyXG4gICAgICA8VGhlbWVQcm92aWRlciB0aGVtZT17dGhlbWV9PlxyXG4gICAgICAgIDxBcHAgLz5cclxuICAgICAgPC9UaGVtZVByb3ZpZGVyPlxyXG4gICAgPC9TdHlsZWRFbmdpbmVQcm92aWRlcj5cclxuICA8L1JvdXRlcj5cclxuKTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvaW5kZXgudHN4In0=