import { Machine, assign } from "/node_modules/.vite/deps/xstate.js?v=6af76b79";
export var Severities = /* @__PURE__ */ ((Severities2) => {
  Severities2["success"] = "success";
  Severities2["info"] = "info";
  Severities2["warning"] = "warning";
  Severities2["error"] = "error";
  return Severities2;
})(Severities || {});
export const snackbarMachine = Machine(
  {
    id: "snackbar",
    initial: "invisible",
    context: {
      severity: void 0,
      message: void 0
    },
    states: {
      invisible: {
        entry: "resetSnackbar",
        on: { SHOW: "visible" }
      },
      visible: {
        entry: "setSnackbar",
        on: { HIDE: "invisible" },
        after: {
          // after 3 seconds, transition to invisible
          3e3: "invisible"
        }
      }
    }
  },
  {
    actions: {
      setSnackbar: assign((ctx, event) => ({
        severity: event.severity,
        message: event.message
      })),
      resetSnackbar: assign((ctx, event) => ({
        severity: void 0,
        message: void 0
      }))
    }
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNuYWNrYmFyTWFjaGluZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNYWNoaW5lLCBhc3NpZ24gfSBmcm9tIFwieHN0YXRlXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFNuYWNrYmFyU2NoZW1hIHtcclxuICBzdGF0ZXM6IHtcclxuICAgIGludmlzaWJsZToge307XHJcbiAgICB2aXNpYmxlOiB7fTtcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBTbmFja2JhckV2ZW50cyA9IHsgdHlwZTogXCJTSE9XXCIgfSB8IHsgdHlwZTogXCJISURFXCIgfTtcclxuZXhwb3J0IGVudW0gU2V2ZXJpdGllcyB7XHJcbiAgc3VjY2VzcyA9IFwic3VjY2Vzc1wiLFxyXG4gIGluZm8gPSBcImluZm9cIixcclxuICB3YXJuaW5nID0gXCJ3YXJuaW5nXCIsXHJcbiAgZXJyb3IgPSBcImVycm9yXCIsXHJcbn1cclxuZXhwb3J0IGludGVyZmFjZSBTbmFja2JhckNvbnRleHQge1xyXG4gIHNldmVyaXR5PzogU2V2ZXJpdGllcztcclxuICBtZXNzYWdlPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3Qgc25hY2tiYXJNYWNoaW5lID0gTWFjaGluZTxTbmFja2JhckNvbnRleHQsIFNuYWNrYmFyU2NoZW1hLCBTbmFja2JhckV2ZW50cz4oXHJcbiAge1xyXG4gICAgaWQ6IFwic25hY2tiYXJcIixcclxuICAgIGluaXRpYWw6IFwiaW52aXNpYmxlXCIsXHJcbiAgICBjb250ZXh0OiB7XHJcbiAgICAgIHNldmVyaXR5OiB1bmRlZmluZWQsXHJcbiAgICAgIG1lc3NhZ2U6IHVuZGVmaW5lZCxcclxuICAgIH0sXHJcbiAgICBzdGF0ZXM6IHtcclxuICAgICAgaW52aXNpYmxlOiB7XHJcbiAgICAgICAgZW50cnk6IFwicmVzZXRTbmFja2JhclwiLFxyXG4gICAgICAgIG9uOiB7IFNIT1c6IFwidmlzaWJsZVwiIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIHZpc2libGU6IHtcclxuICAgICAgICBlbnRyeTogXCJzZXRTbmFja2JhclwiLFxyXG4gICAgICAgIG9uOiB7IEhJREU6IFwiaW52aXNpYmxlXCIgfSxcclxuICAgICAgICBhZnRlcjoge1xyXG4gICAgICAgICAgLy8gYWZ0ZXIgMyBzZWNvbmRzLCB0cmFuc2l0aW9uIHRvIGludmlzaWJsZVxyXG4gICAgICAgICAgMzAwMDogXCJpbnZpc2libGVcIixcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIGFjdGlvbnM6IHtcclxuICAgICAgc2V0U25hY2tiYXI6IGFzc2lnbigoY3R4LCBldmVudDogYW55KSA9PiAoe1xyXG4gICAgICAgIHNldmVyaXR5OiBldmVudC5zZXZlcml0eSxcclxuICAgICAgICBtZXNzYWdlOiBldmVudC5tZXNzYWdlLFxyXG4gICAgICB9KSksXHJcbiAgICAgIHJlc2V0U25hY2tiYXI6IGFzc2lnbigoY3R4LCBldmVudDogYW55KSA9PiAoe1xyXG4gICAgICAgIHNldmVyaXR5OiB1bmRlZmluZWQsXHJcbiAgICAgICAgbWVzc2FnZTogdW5kZWZpbmVkLFxyXG4gICAgICB9KSksXHJcbiAgICB9LFxyXG4gIH1cclxuKTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVMsY0FBYztBQVV6QixXQUFLLGFBQUwsa0JBQUtBLGdCQUFMO0FBQ0wsRUFBQUEsWUFBQSxhQUFVO0FBQ1YsRUFBQUEsWUFBQSxVQUFPO0FBQ1AsRUFBQUEsWUFBQSxhQUFVO0FBQ1YsRUFBQUEsWUFBQSxXQUFRO0FBSkUsU0FBQUE7QUFBQSxHQUFBO0FBV0wsYUFBTSxrQkFBa0I7QUFBQSxFQUM3QjtBQUFBLElBQ0UsSUFBSTtBQUFBLElBQ0osU0FBUztBQUFBLElBQ1QsU0FBUztBQUFBLE1BQ1AsVUFBVTtBQUFBLE1BQ1YsU0FBUztBQUFBLElBQ1g7QUFBQSxJQUNBLFFBQVE7QUFBQSxNQUNOLFdBQVc7QUFBQSxRQUNULE9BQU87QUFBQSxRQUNQLElBQUksRUFBRSxNQUFNLFVBQVU7QUFBQSxNQUN4QjtBQUFBLE1BQ0EsU0FBUztBQUFBLFFBQ1AsT0FBTztBQUFBLFFBQ1AsSUFBSSxFQUFFLE1BQU0sWUFBWTtBQUFBLFFBQ3hCLE9BQU87QUFBQTtBQUFBLFVBRUwsS0FBTTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUNBO0FBQUEsSUFDRSxTQUFTO0FBQUEsTUFDUCxhQUFhLE9BQU8sQ0FBQyxLQUFLLFdBQWdCO0FBQUEsUUFDeEMsVUFBVSxNQUFNO0FBQUEsUUFDaEIsU0FBUyxNQUFNO0FBQUEsTUFDakIsRUFBRTtBQUFBLE1BQ0YsZUFBZSxPQUFPLENBQUMsS0FBSyxXQUFnQjtBQUFBLFFBQzFDLFVBQVU7QUFBQSxRQUNWLFNBQVM7QUFBQSxNQUNYLEVBQUU7QUFBQSxJQUNKO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbIlNldmVyaXRpZXMiXX0=