import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Paper, Button, ListSubheader, Grid } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Link as RouterLink } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import __vite__cjsImport6_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport6_lodash_fp["isEmpty"];
import SkeletonList from "/src/components/SkeletonList.tsx";
import EmptyList from "/src/components/EmptyList.tsx";
import TransactionInfiniteList from "/src/components/TransactionInfiniteList.tsx";
import TransferMoneyIllustration from "/src/components/SvgUndrawTransferMoneyRywa.tsx";
const PREFIX = "TransactionList";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    paddingLeft: theme.spacing(1)
  }
}));
_c = StyledPaper;
const TransactionList = ({
  header,
  transactions,
  isLoading,
  showCreateButton,
  loadNextPage,
  pagination,
  filterComponent
}) => {
  const showEmptyList = !isLoading && transactions?.length === 0;
  const showSkeleton = isLoading && isEmpty(pagination);
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
    filterComponent,
    /* @__PURE__ */ jsxDEV(ListSubheader, { component: "div", children: header }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    showSkeleton && /* @__PURE__ */ jsxDEV(SkeletonList, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
      lineNumber: 51,
      columnNumber: 24
    }, this),
    transactions.length > 0 && /* @__PURE__ */ jsxDEV(
      TransactionInfiniteList,
      {
        transactions,
        loadNextPage,
        pagination
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
        lineNumber: 53,
        columnNumber: 7
      },
      this
    ),
    showEmptyList && /* @__PURE__ */ jsxDEV(EmptyList, { entity: "Transactions", children: /* @__PURE__ */ jsxDEV(
      Grid,
      {
        container: true,
        direction: "column",
        justifyContent: "center",
        alignItems: "center",
        style: { width: "100%" },
        spacing: 2,
        children: [
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(TransferMoneyIllustration, { style: { height: 200, width: 300, marginBottom: 30 } }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
            lineNumber: 70,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
            lineNumber: 69,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: showCreateButton && /* @__PURE__ */ jsxDEV(
            Button,
            {
              "data-test": "transaction-list-empty-create-transaction-button",
              variant: "contained",
              color: "primary",
              component: RouterLink,
              to: "/transaction/new",
              children: "Create A Transaction"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
              lineNumber: 74,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
            lineNumber: 72,
            columnNumber: 13
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
        lineNumber: 61,
        columnNumber: 11
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx",
    lineNumber: 48,
    columnNumber: 5
  }, this);
};
_c2 = TransactionList;
export default TransactionList;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "TransactionList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURNO0FBakROLE9BQU9BLG9CQUFrQjtBQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDeEMsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxPQUFPQyxRQUFRQyxlQUFlQyxZQUFZO0FBQ25ELFNBQVNDLFFBQVFDLGtCQUFrQjtBQUNuQyxTQUFTQyxlQUFlO0FBRXhCLE9BQU9DLGtCQUFrQjtBQUV6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLDZCQUE2QjtBQUNwQyxPQUFPQywrQkFBK0I7QUFFdEMsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFDbEI7QUFFQSxNQUFNRyxjQUFjZixPQUFPQyxLQUFLLEVBQUUsQ0FBQyxFQUFFZSxNQUFNLE9BQU87QUFBQSxFQUNoRCxDQUFDLEtBQUtILFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdEJHLGFBQWFELE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQzlCO0FBQ0YsRUFBRTtBQUFFQyxLQUpFSjtBQWdCTixNQUFNSyxrQkFBa0RBLENBQUM7QUFBQSxFQUN2REM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osUUFBTUMsZ0JBQWdCLENBQUNMLGFBQWFELGNBQWNPLFdBQVc7QUFDN0QsUUFBTUMsZUFBZVAsYUFBYWhCLFFBQVFtQixVQUFVO0FBRXBELFNBQ0UsdUJBQUMsZUFBWSxXQUFXYixRQUFRQyxPQUM3QmE7QUFBQUE7QUFBQUEsSUFDRCx1QkFBQyxpQkFBYyxXQUFVLE9BQU9OLG9CQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXVDO0FBQUEsSUFDdENTLGdCQUFnQix1QkFBQyxrQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWE7QUFBQSxJQUM3QlIsYUFBYU8sU0FBUyxLQUNyQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFHeUI7QUFBQSxJQUcxQkQsaUJBQ0MsdUJBQUMsYUFBVSxRQUFPLGdCQUNoQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBLFdBQVU7QUFBQSxRQUNWLGdCQUFlO0FBQUEsUUFDZixZQUFXO0FBQUEsUUFDWCxPQUFPLEVBQUVHLE9BQU8sT0FBTztBQUFBLFFBQ3ZCLFNBQVM7QUFBQSxRQUVUO0FBQUEsaUNBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsNkJBQTBCLE9BQU8sRUFBRUMsUUFBUSxLQUFLRCxPQUFPLEtBQUtFLGNBQWMsR0FBRyxLQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFnRixLQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQSx1QkFBQyxRQUFLLE1BQUksTUFDUFQsOEJBQ0M7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLGFBQVU7QUFBQSxjQUNWLFNBQVE7QUFBQSxjQUNSLE9BQU07QUFBQSxjQUNOLFdBQVdsQjtBQUFBQSxjQUNYLElBQUc7QUFBQSxjQUFrQjtBQUFBO0FBQUEsWUFMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBUUEsS0FWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVlBO0FBQUE7QUFBQTtBQUFBLE1BdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQXdCQSxLQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBMEJBO0FBQUEsT0F0Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdDQTtBQUVKO0FBQUU0QixNQXZESWQ7QUF5RE4sZUFBZUE7QUFBZ0IsSUFBQUQsSUFBQWU7QUFBQUMsYUFBQWhCLElBQUE7QUFBQWdCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInN0eWxlZCIsIlBhcGVyIiwiQnV0dG9uIiwiTGlzdFN1YmhlYWRlciIsIkdyaWQiLCJMaW5rIiwiUm91dGVyTGluayIsImlzRW1wdHkiLCJTa2VsZXRvbkxpc3QiLCJFbXB0eUxpc3QiLCJUcmFuc2FjdGlvbkluZmluaXRlTGlzdCIsIlRyYW5zZmVyTW9uZXlJbGx1c3RyYXRpb24iLCJQUkVGSVgiLCJjbGFzc2VzIiwicGFwZXIiLCJTdHlsZWRQYXBlciIsInRoZW1lIiwicGFkZGluZ0xlZnQiLCJzcGFjaW5nIiwiX2MiLCJUcmFuc2FjdGlvbkxpc3QiLCJoZWFkZXIiLCJ0cmFuc2FjdGlvbnMiLCJpc0xvYWRpbmciLCJzaG93Q3JlYXRlQnV0dG9uIiwibG9hZE5leHRQYWdlIiwicGFnaW5hdGlvbiIsImZpbHRlckNvbXBvbmVudCIsInNob3dFbXB0eUxpc3QiLCJsZW5ndGgiLCJzaG93U2tlbGV0b24iLCJ3aWR0aCIsImhlaWdodCIsIm1hcmdpbkJvdHRvbSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgUGFwZXIsIEJ1dHRvbiwgTGlzdFN1YmhlYWRlciwgR3JpZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IExpbmsgYXMgUm91dGVyTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IGlzRW1wdHkgfSBmcm9tIFwibG9kYXNoL2ZwXCI7XHJcblxyXG5pbXBvcnQgU2tlbGV0b25MaXN0IGZyb20gXCIuL1NrZWxldG9uTGlzdFwiO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbSwgVHJhbnNhY3Rpb25QYWdpbmF0aW9uIH0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5pbXBvcnQgRW1wdHlMaXN0IGZyb20gXCIuL0VtcHR5TGlzdFwiO1xyXG5pbXBvcnQgVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3QgZnJvbSBcIi4vVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3RcIjtcclxuaW1wb3J0IFRyYW5zZmVyTW9uZXlJbGx1c3RyYXRpb24gZnJvbSBcIi4vU3ZnVW5kcmF3VHJhbnNmZXJNb25leVJ5d2FcIjtcclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiVHJhbnNhY3Rpb25MaXN0XCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHBhcGVyOiBgJHtQUkVGSVh9LXBhcGVyYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZFBhcGVyID0gc3R5bGVkKFBhcGVyKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMucGFwZXJ9YF06IHtcclxuICAgIHBhZGRpbmdMZWZ0OiB0aGVtZS5zcGFjaW5nKDEpLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25MaXN0UHJvcHMge1xyXG4gIGhlYWRlcjogc3RyaW5nO1xyXG4gIHRyYW5zYWN0aW9uczogVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW1bXTtcclxuICBpc0xvYWRpbmc6IEJvb2xlYW47XHJcbiAgc2hvd0NyZWF0ZUJ1dHRvbj86IEJvb2xlYW47XHJcbiAgbG9hZE5leHRQYWdlOiBGdW5jdGlvbjtcclxuICBwYWdpbmF0aW9uOiBUcmFuc2FjdGlvblBhZ2luYXRpb247XHJcbiAgZmlsdGVyQ29tcG9uZW50OiBSZWFjdE5vZGU7XHJcbn1cclxuXHJcbmNvbnN0IFRyYW5zYWN0aW9uTGlzdDogUmVhY3QuRkM8VHJhbnNhY3Rpb25MaXN0UHJvcHM+ID0gKHtcclxuICBoZWFkZXIsXHJcbiAgdHJhbnNhY3Rpb25zLFxyXG4gIGlzTG9hZGluZyxcclxuICBzaG93Q3JlYXRlQnV0dG9uLFxyXG4gIGxvYWROZXh0UGFnZSxcclxuICBwYWdpbmF0aW9uLFxyXG4gIGZpbHRlckNvbXBvbmVudCxcclxufSkgPT4ge1xyXG4gIGNvbnN0IHNob3dFbXB0eUxpc3QgPSAhaXNMb2FkaW5nICYmIHRyYW5zYWN0aW9ucz8ubGVuZ3RoID09PSAwO1xyXG4gIGNvbnN0IHNob3dTa2VsZXRvbiA9IGlzTG9hZGluZyAmJiBpc0VtcHR5KHBhZ2luYXRpb24pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFN0eWxlZFBhcGVyIGNsYXNzTmFtZT17Y2xhc3Nlcy5wYXBlcn0+XHJcbiAgICAgIHtmaWx0ZXJDb21wb25lbnR9XHJcbiAgICAgIDxMaXN0U3ViaGVhZGVyIGNvbXBvbmVudD1cImRpdlwiPntoZWFkZXJ9PC9MaXN0U3ViaGVhZGVyPlxyXG4gICAgICB7c2hvd1NrZWxldG9uICYmIDxTa2VsZXRvbkxpc3QgLz59XHJcbiAgICAgIHt0cmFuc2FjdGlvbnMubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPFRyYW5zYWN0aW9uSW5maW5pdGVMaXN0XHJcbiAgICAgICAgICB0cmFuc2FjdGlvbnM9e3RyYW5zYWN0aW9uc31cclxuICAgICAgICAgIGxvYWROZXh0UGFnZT17bG9hZE5leHRQYWdlfVxyXG4gICAgICAgICAgcGFnaW5hdGlvbj17cGFnaW5hdGlvbn1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7c2hvd0VtcHR5TGlzdCAmJiAoXHJcbiAgICAgICAgPEVtcHR5TGlzdCBlbnRpdHk9XCJUcmFuc2FjdGlvbnNcIj5cclxuICAgICAgICAgIDxHcmlkXHJcbiAgICAgICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgICAgICBkaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICAgICAgc3BhY2luZz17Mn1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICA8VHJhbnNmZXJNb25leUlsbHVzdHJhdGlvbiBzdHlsZT17eyBoZWlnaHQ6IDIwMCwgd2lkdGg6IDMwMCwgbWFyZ2luQm90dG9tOiAzMCB9fSAvPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAge3Nob3dDcmVhdGVCdXR0b24gJiYgKFxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saXN0LWVtcHR5LWNyZWF0ZS10cmFuc2FjdGlvbi1idXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgY29tcG9uZW50PXtSb3V0ZXJMaW5rfVxyXG4gICAgICAgICAgICAgICAgICB0bz1cIi90cmFuc2FjdGlvbi9uZXdcIlxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBDcmVhdGUgQSBUcmFuc2FjdGlvblxyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvRW1wdHlMaXN0PlxyXG4gICAgICApfVxyXG4gICAgPC9TdHlsZWRQYXBlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25MaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1RyYW5zYWN0aW9uTGlzdC50c3gifQ==