import {
  _setPrototypeOf
} from "/node_modules/.vite/deps/chunk-4FTWOKSW.js?v=6af76b79";

// node_modules/@babel/runtime/helpers/esm/inheritsLoose.js
function _inheritsLoose(t, o) {
  t.prototype = Object.create(o.prototype), t.prototype.constructor = t, _setPrototypeOf(t, o);
}

export {
  _inheritsLoose
};
//# sourceMappingURL=chunk-HZOIS4LS.js.map
