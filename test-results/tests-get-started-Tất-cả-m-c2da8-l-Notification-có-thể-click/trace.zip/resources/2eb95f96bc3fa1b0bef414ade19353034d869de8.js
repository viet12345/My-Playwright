import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionPublicList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPublicList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import TransactionList from "/src/components/TransactionList.tsx";
import { publicTransactionsMachine } from "/src/machines/publicTransactionsMachine.ts";
const TransactionPublicList = ({
  filterComponent,
  dateRangeFilters,
  amountRangeFilters
}) => {
  _s();
  const [current, send, publicTransactionService] = useMachine(publicTransactionsMachine);
  const { pageData, results } = current.context;
  if (window.Cypress) {
    window.publicTransactionService = publicTransactionService;
  }
  useEffect(() => {
    send("FETCH", { ...dateRangeFilters, ...amountRangeFilters });
  }, [send, dateRangeFilters, amountRangeFilters]);
  const loadNextPage = (page) => send("FETCH", { page, ...dateRangeFilters, ...amountRangeFilters });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
    TransactionList,
    {
      filterComponent,
      header: "Public",
      transactions: results,
      isLoading: current.matches("loading"),
      loadNextPage,
      pagination: pageData,
      showCreateButton: true
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPublicList.tsx",
      lineNumber: 41,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPublicList.tsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_s(TransactionPublicList, "e9auPIDKA4IXfoUuuw6/1NjSsvo=", false, function() {
  return [useMachine];
});
_c = TransactionPublicList;
export default TransactionPublicList;
var _c;
$RefreshReg$(_c, "TransactionPublicList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPublicList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPublicList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNJLG1CQUNFLGNBREY7MkJBdkNKO0FBQWdCQSxNQUFXQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsU0FBU0Msa0JBQWtCO0FBTzNCLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxpQ0FBaUM7QUFRMUMsTUFBTUMsd0JBQThEQSxDQUFDO0FBQUEsRUFDbkVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxTQUFTQyxNQUFNQyx3QkFBd0IsSUFBSVYsV0FBV0UseUJBQXlCO0FBQ3RGLFFBQU0sRUFBRVMsVUFBVUMsUUFBUSxJQUFJSixRQUFRSztBQUd0QyxNQUFJQyxPQUFPQyxTQUFTO0FBRWxCRCxXQUFPSiwyQkFBMkJBO0FBQUFBLEVBQ3BDO0FBRUFaLFlBQVUsTUFBTTtBQUNkVyxTQUFLLFNBQVMsRUFBRSxHQUFHSixrQkFBa0IsR0FBR0MsbUJBQW1CLENBQUM7QUFBQSxFQUM5RCxHQUFHLENBQUNHLE1BQU1KLGtCQUFrQkMsa0JBQWtCLENBQUM7QUFFL0MsUUFBTVUsZUFBZUEsQ0FBQ0MsU0FDcEJSLEtBQUssU0FBUyxFQUFFUSxNQUFNLEdBQUdaLGtCQUFrQixHQUFHQyxtQkFBbUIsQ0FBQztBQUVwRSxTQUNFLG1DQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsUUFBTztBQUFBLE1BQ1AsY0FBY007QUFBQUEsTUFDZCxXQUFXSixRQUFRVSxRQUFRLFNBQVM7QUFBQSxNQUNwQztBQUFBLE1BQ0EsWUFBWVA7QUFBQUEsTUFDWixrQkFBZ0I7QUFBQTtBQUFBLElBUGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9rQixLQVJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFFSixHQWxDSUosdUJBQTJEO0FBQUEsVUFLYkgsVUFBVTtBQUFBO0FBQUFtQixLQUx4RGhCO0FBb0NOLGVBQWVBO0FBQXNCLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiUmVhY3ROb2RlIiwidXNlTWFjaGluZSIsIlRyYW5zYWN0aW9uTGlzdCIsInB1YmxpY1RyYW5zYWN0aW9uc01hY2hpbmUiLCJUcmFuc2FjdGlvblB1YmxpY0xpc3QiLCJmaWx0ZXJDb21wb25lbnQiLCJkYXRlUmFuZ2VGaWx0ZXJzIiwiYW1vdW50UmFuZ2VGaWx0ZXJzIiwiX3MiLCJjdXJyZW50Iiwic2VuZCIsInB1YmxpY1RyYW5zYWN0aW9uU2VydmljZSIsInBhZ2VEYXRhIiwicmVzdWx0cyIsImNvbnRleHQiLCJ3aW5kb3ciLCJDeXByZXNzIiwibG9hZE5leHRQYWdlIiwicGFnZSIsIm1hdGNoZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uUHVibGljTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCwgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZU1hY2hpbmUgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIFRyYW5zYWN0aW9uUGFnaW5hdGlvbixcclxuICBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbSxcclxuICBUcmFuc2FjdGlvbkRhdGVSYW5nZVBheWxvYWQsXHJcbiAgVHJhbnNhY3Rpb25BbW91bnRSYW5nZVBheWxvYWQsXHJcbn0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5pbXBvcnQgVHJhbnNhY3Rpb25MaXN0IGZyb20gXCIuL1RyYW5zYWN0aW9uTGlzdFwiO1xyXG5pbXBvcnQgeyBwdWJsaWNUcmFuc2FjdGlvbnNNYWNoaW5lIH0gZnJvbSBcIi4uL21hY2hpbmVzL3B1YmxpY1RyYW5zYWN0aW9uc01hY2hpbmVcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25QdWJsaWNMaXN0UHJvcHMge1xyXG4gIGZpbHRlckNvbXBvbmVudDogUmVhY3ROb2RlO1xyXG4gIGRhdGVSYW5nZUZpbHRlcnM6IFRyYW5zYWN0aW9uRGF0ZVJhbmdlUGF5bG9hZDtcclxuICBhbW91bnRSYW5nZUZpbHRlcnM6IFRyYW5zYWN0aW9uQW1vdW50UmFuZ2VQYXlsb2FkO1xyXG59XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvblB1YmxpY0xpc3Q6IFJlYWN0LkZDPFRyYW5zYWN0aW9uUHVibGljTGlzdFByb3BzPiA9ICh7XHJcbiAgZmlsdGVyQ29tcG9uZW50LFxyXG4gIGRhdGVSYW5nZUZpbHRlcnMsXHJcbiAgYW1vdW50UmFuZ2VGaWx0ZXJzLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW2N1cnJlbnQsIHNlbmQsIHB1YmxpY1RyYW5zYWN0aW9uU2VydmljZV0gPSB1c2VNYWNoaW5lKHB1YmxpY1RyYW5zYWN0aW9uc01hY2hpbmUpO1xyXG4gIGNvbnN0IHsgcGFnZURhdGEsIHJlc3VsdHMgfSA9IGN1cnJlbnQuY29udGV4dDtcclxuXHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIGlmICh3aW5kb3cuQ3lwcmVzcykge1xyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgd2luZG93LnB1YmxpY1RyYW5zYWN0aW9uU2VydmljZSA9IHB1YmxpY1RyYW5zYWN0aW9uU2VydmljZTtcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZW5kKFwiRkVUQ0hcIiwgeyAuLi5kYXRlUmFuZ2VGaWx0ZXJzLCAuLi5hbW91bnRSYW5nZUZpbHRlcnMgfSk7XHJcbiAgfSwgW3NlbmQsIGRhdGVSYW5nZUZpbHRlcnMsIGFtb3VudFJhbmdlRmlsdGVyc10pO1xyXG5cclxuICBjb25zdCBsb2FkTmV4dFBhZ2UgPSAocGFnZTogbnVtYmVyKSA9PlxyXG4gICAgc2VuZChcIkZFVENIXCIsIHsgcGFnZSwgLi4uZGF0ZVJhbmdlRmlsdGVycywgLi4uYW1vdW50UmFuZ2VGaWx0ZXJzIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPFRyYW5zYWN0aW9uTGlzdFxyXG4gICAgICAgIGZpbHRlckNvbXBvbmVudD17ZmlsdGVyQ29tcG9uZW50fVxyXG4gICAgICAgIGhlYWRlcj1cIlB1YmxpY1wiXHJcbiAgICAgICAgdHJhbnNhY3Rpb25zPXtyZXN1bHRzIGFzIFRyYW5zYWN0aW9uUmVzcG9uc2VJdGVtW119XHJcbiAgICAgICAgaXNMb2FkaW5nPXtjdXJyZW50Lm1hdGNoZXMoXCJsb2FkaW5nXCIpfVxyXG4gICAgICAgIGxvYWROZXh0UGFnZT17bG9hZE5leHRQYWdlfVxyXG4gICAgICAgIHBhZ2luYXRpb249e3BhZ2VEYXRhIGFzIFRyYW5zYWN0aW9uUGFnaW5hdGlvbn1cclxuICAgICAgICBzaG93Q3JlYXRlQnV0dG9uXHJcbiAgICAgIC8+XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25QdWJsaWNMaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1RyYW5zYWN0aW9uUHVibGljTGlzdC50c3gifQ==