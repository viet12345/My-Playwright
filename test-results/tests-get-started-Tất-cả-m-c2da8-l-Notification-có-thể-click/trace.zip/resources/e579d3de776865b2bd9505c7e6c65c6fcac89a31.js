import {
  clsx,
  clsx_m_default
} from "/node_modules/.vite/deps/chunk-2TMMHHZA.js?v=6af76b79";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";
export {
  clsx,
  clsx_m_default as default
};
//# sourceMappingURL=clsx.js.map
