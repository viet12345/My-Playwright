import {
  require_react_dom
} from "/node_modules/.vite/deps/chunk-HOONJUPS.js?v=6af76b79";
import {
  require_interopRequireDefault
} from "/node_modules/.vite/deps/chunk-L5I5XQMD.js?v=6af76b79";
import {
  require_prop_types
} from "/node_modules/.vite/deps/chunk-6IJE4OMF.js?v=6af76b79";
import "/node_modules/.vite/deps/chunk-AAY5IJNO.js?v=6af76b79";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=6af76b79";
import {
  __commonJS,
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";

// node_modules/recompose/getDisplayName.js
var require_getDisplayName = __commonJS({
  "node_modules/recompose/getDisplayName.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var getDisplayName = function getDisplayName2(Component5) {
      if (typeof Component5 === "string") {
        return Component5;
      }
      if (!Component5) {
        return void 0;
      }
      return Component5.displayName || Component5.name || "Component";
    };
    exports.default = getDisplayName;
  }
});

// node_modules/recompose/wrapDisplayName.js
var require_wrapDisplayName = __commonJS({
  "node_modules/recompose/wrapDisplayName.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _getDisplayName = require_getDisplayName();
    var _getDisplayName2 = _interopRequireDefault(_getDisplayName);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var wrapDisplayName = function wrapDisplayName2(BaseComponent, hocName) {
      return hocName + "(" + (0, _getDisplayName2.default)(BaseComponent) + ")";
    };
    exports.default = wrapDisplayName;
  }
});

// node_modules/recompose/createHelper.js
var require_createHelper = __commonJS({
  "node_modules/recompose/createHelper.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var createHelper = function createHelper2(func2, helperName) {
      var setDisplayName = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : true;
      var noArgs = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : false;
      if (setDisplayName) {
        var _ret = function() {
          var wrapDisplayName = require_wrapDisplayName().default;
          if (noArgs) {
            return {
              v: function v(BaseComponent) {
                var Component5 = func2(BaseComponent);
                Component5.displayName = wrapDisplayName(BaseComponent, helperName);
                return Component5;
              }
            };
          }
          return {
            v: function v() {
              for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
                args[_key] = arguments[_key];
              }
              return function(BaseComponent) {
                var Component5 = func2.apply(void 0, args)(BaseComponent);
                Component5.displayName = wrapDisplayName(BaseComponent, helperName);
                return Component5;
              };
            }
          };
        }();
        if (typeof _ret === "object")
          return _ret.v;
      }
      return func2;
    };
    exports.default = createHelper;
  }
});

// node_modules/recompose/utils/createEagerElementUtil.js
var require_createEagerElementUtil = __commonJS({
  "node_modules/recompose/utils/createEagerElementUtil.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = require_react();
    var _react2 = _interopRequireDefault(_react);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var createEagerElementUtil = function createEagerElementUtil2(hasKey, isReferentiallyTransparent, type, props, children) {
      if (!hasKey && isReferentiallyTransparent) {
        if (children) {
          return type(_extends10({}, props, { children }));
        }
        return type(props);
      }
      var Component5 = type;
      if (children) {
        return _react2.default.createElement(
          Component5,
          props,
          children
        );
      }
      return _react2.default.createElement(Component5, props);
    };
    exports.default = createEagerElementUtil;
  }
});

// node_modules/recompose/isClassComponent.js
var require_isClassComponent = __commonJS({
  "node_modules/recompose/isClassComponent.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var isClassComponent = function isClassComponent2(Component5) {
      return Boolean(Component5 && Component5.prototype && typeof Component5.prototype.isReactComponent === "object");
    };
    exports.default = isClassComponent;
  }
});

// node_modules/recompose/isReferentiallyTransparentFunctionComponent.js
var require_isReferentiallyTransparentFunctionComponent = __commonJS({
  "node_modules/recompose/isReferentiallyTransparentFunctionComponent.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _isClassComponent = require_isClassComponent();
    var _isClassComponent2 = _interopRequireDefault(_isClassComponent);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var isReferentiallyTransparentFunctionComponent = function isReferentiallyTransparentFunctionComponent2(Component5) {
      return Boolean(typeof Component5 === "function" && !(0, _isClassComponent2.default)(Component5) && !Component5.defaultProps && !Component5.contextTypes && !Component5.propTypes);
    };
    exports.default = isReferentiallyTransparentFunctionComponent;
  }
});

// node_modules/recompose/createEagerFactory.js
var require_createEagerFactory = __commonJS({
  "node_modules/recompose/createEagerFactory.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _createEagerElementUtil = require_createEagerElementUtil();
    var _createEagerElementUtil2 = _interopRequireDefault(_createEagerElementUtil);
    var _isReferentiallyTransparentFunctionComponent = require_isReferentiallyTransparentFunctionComponent();
    var _isReferentiallyTransparentFunctionComponent2 = _interopRequireDefault(_isReferentiallyTransparentFunctionComponent);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var createFactory = function createFactory2(type) {
      var isReferentiallyTransparent = (0, _isReferentiallyTransparentFunctionComponent2.default)(type);
      return function(p, c) {
        return (0, _createEagerElementUtil2.default)(false, isReferentiallyTransparent, type, p, c);
      };
    };
    exports.default = createFactory;
  }
});

// node_modules/recompose/defaultProps.js
var require_defaultProps = __commonJS({
  "node_modules/recompose/defaultProps.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    var _createEagerFactory = require_createEagerFactory();
    var _createEagerFactory2 = _interopRequireDefault(_createEagerFactory);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var defaultProps = function defaultProps2(props) {
      return function(BaseComponent) {
        var factory = (0, _createEagerFactory2.default)(BaseComponent);
        var DefaultProps = function DefaultProps2(ownerProps) {
          return factory(ownerProps);
        };
        DefaultProps.defaultProps = props;
        return DefaultProps;
      };
    };
    exports.default = (0, _createHelper2.default)(defaultProps, "defaultProps");
  }
});

// node_modules/classnames/index.js
var require_classnames = __commonJS({
  "node_modules/classnames/index.js"(exports, module) {
    (function() {
      "use strict";
      var hasOwn = {}.hasOwnProperty;
      function classNames11() {
        var classes = "";
        for (var i = 0; i < arguments.length; i++) {
          var arg = arguments[i];
          if (arg) {
            classes = appendClass(classes, parseValue(arg));
          }
        }
        return classes;
      }
      function parseValue(arg) {
        if (typeof arg === "string" || typeof arg === "number") {
          return arg;
        }
        if (typeof arg !== "object") {
          return "";
        }
        if (Array.isArray(arg)) {
          return classNames11.apply(null, arg);
        }
        if (arg.toString !== Object.prototype.toString && !arg.toString.toString().includes("[native code]")) {
          return arg.toString();
        }
        var classes = "";
        for (var key in arg) {
          if (hasOwn.call(arg, key) && arg[key]) {
            classes = appendClass(classes, key);
          }
        }
        return classes;
      }
      function appendClass(value, newClass) {
        if (!newClass) {
          return value;
        }
        if (value) {
          return value + " " + newClass;
        }
        return value + newClass;
      }
      if (typeof module !== "undefined" && module.exports) {
        classNames11.default = classNames11;
        module.exports = classNames11;
      } else if (typeof define === "function" && typeof define.amd === "object" && define.amd) {
        define("classnames", [], function() {
          return classNames11;
        });
      } else {
        window.classNames = classNames11;
      }
    })();
  }
});

// node_modules/recompose/utils/pick.js
var require_pick = __commonJS({
  "node_modules/recompose/utils/pick.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var pick = function pick2(obj, keys) {
      var result = {};
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (obj.hasOwnProperty(key)) {
          result[key] = obj[key];
        }
      }
      return result;
    };
    exports.default = pick;
  }
});

// node_modules/fbjs/lib/shallowEqual.js
var require_shallowEqual = __commonJS({
  "node_modules/fbjs/lib/shallowEqual.js"(exports, module) {
    "use strict";
    var hasOwnProperty = Object.prototype.hasOwnProperty;
    function is(x, y) {
      if (x === y) {
        return x !== 0 || y !== 0 || 1 / x === 1 / y;
      } else {
        return x !== x && y !== y;
      }
    }
    function shallowEqual(objA, objB) {
      if (is(objA, objB)) {
        return true;
      }
      if (typeof objA !== "object" || objA === null || typeof objB !== "object" || objB === null) {
        return false;
      }
      var keysA = Object.keys(objA);
      var keysB = Object.keys(objB);
      if (keysA.length !== keysB.length) {
        return false;
      }
      for (var i = 0; i < keysA.length; i++) {
        if (!hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) {
          return false;
        }
      }
      return true;
    }
    module.exports = shallowEqual;
  }
});

// node_modules/recompose/shallowEqual.js
var require_shallowEqual2 = __commonJS({
  "node_modules/recompose/shallowEqual.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _shallowEqual = require_shallowEqual();
    var _shallowEqual2 = _interopRequireDefault(_shallowEqual);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    exports.default = _shallowEqual2.default;
  }
});

// node_modules/recompose/withPropsOnChange.js
var require_withPropsOnChange = __commonJS({
  "node_modules/recompose/withPropsOnChange.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = require_react();
    var _pick = require_pick();
    var _pick2 = _interopRequireDefault(_pick);
    var _shallowEqual = require_shallowEqual2();
    var _shallowEqual2 = _interopRequireDefault(_shallowEqual);
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    var _createEagerFactory = require_createEagerFactory();
    var _createEagerFactory2 = _interopRequireDefault(_createEagerFactory);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var withPropsOnChange = function withPropsOnChange2(shouldMapOrKeys, propsMapper) {
      return function(BaseComponent) {
        var factory = (0, _createEagerFactory2.default)(BaseComponent);
        var shouldMap = typeof shouldMapOrKeys === "function" ? shouldMapOrKeys : function(props, nextProps) {
          return !(0, _shallowEqual2.default)((0, _pick2.default)(props, shouldMapOrKeys), (0, _pick2.default)(nextProps, shouldMapOrKeys));
        };
        return function(_Component) {
          _inherits11(_class22, _Component);
          function _class22() {
            var _temp3, _this, _ret;
            _classCallCheck12(this, _class22);
            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
            }
            return _ret = (_temp3 = (_this = _possibleConstructorReturn11(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.computedProps = propsMapper(_this.props), _temp3), _possibleConstructorReturn11(_this, _ret);
          }
          _class22.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
            if (shouldMap(this.props, nextProps)) {
              this.computedProps = propsMapper(nextProps);
            }
          };
          _class22.prototype.render = function render() {
            return factory(_extends10({}, this.props, this.computedProps));
          };
          return _class22;
        }(_react.Component);
      };
    };
    exports.default = (0, _createHelper2.default)(withPropsOnChange, "withPropsOnChange");
  }
});

// node_modules/dom-helpers/util/inDOM.js
var require_inDOM = __commonJS({
  "node_modules/dom-helpers/util/inDOM.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports.default = void 0;
    var _default = !!(typeof window !== "undefined" && window.document && window.document.createElement);
    exports.default = _default;
    module.exports = exports["default"];
  }
});

// node_modules/dom-helpers/util/scrollbarSize.js
var require_scrollbarSize = __commonJS({
  "node_modules/dom-helpers/util/scrollbarSize.js"(exports, module) {
    "use strict";
    var _interopRequireDefault = require_interopRequireDefault();
    exports.__esModule = true;
    exports.default = scrollbarSize2;
    var _inDOM = _interopRequireDefault(require_inDOM());
    var size;
    function scrollbarSize2(recalc) {
      if (!size && size !== 0 || recalc) {
        if (_inDOM.default) {
          var scrollDiv = document.createElement("div");
          scrollDiv.style.position = "absolute";
          scrollDiv.style.top = "-9999px";
          scrollDiv.style.width = "50px";
          scrollDiv.style.height = "50px";
          scrollDiv.style.overflow = "scroll";
          document.body.appendChild(scrollDiv);
          size = scrollDiv.offsetWidth - scrollDiv.clientWidth;
          document.body.removeChild(scrollDiv);
        }
      }
      return size;
    }
    module.exports = exports["default"];
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds/index.js
var require_getTimezoneOffsetInMilliseconds = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/_lib/getTimezoneOffsetInMilliseconds/index.js"(exports, module) {
    var MILLISECONDS_IN_MINUTE = 6e4;
    module.exports = function getTimezoneOffsetInMilliseconds(dirtyDate) {
      var date = new Date(dirtyDate.getTime());
      var baseTimezoneOffset = date.getTimezoneOffset();
      date.setSeconds(0, 0);
      var millisecondsPartOfTimezoneOffset = date.getTime() % MILLISECONDS_IN_MINUTE;
      return baseTimezoneOffset * MILLISECONDS_IN_MINUTE + millisecondsPartOfTimezoneOffset;
    };
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_date/index.js
var require_is_date = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_date/index.js"(exports, module) {
    function isDate(argument) {
      return argument instanceof Date;
    }
    module.exports = isDate;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/parse/index.js
var require_parse = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/parse/index.js"(exports, module) {
    var getTimezoneOffsetInMilliseconds = require_getTimezoneOffsetInMilliseconds();
    var isDate = require_is_date();
    var MILLISECONDS_IN_HOUR = 36e5;
    var MILLISECONDS_IN_MINUTE = 6e4;
    var DEFAULT_ADDITIONAL_DIGITS = 2;
    var parseTokenDateTimeDelimeter = /[T ]/;
    var parseTokenPlainTime = /:/;
    var parseTokenYY = /^(\d{2})$/;
    var parseTokensYYY = [
      /^([+-]\d{2})$/,
      // 0 additional digits
      /^([+-]\d{3})$/,
      // 1 additional digit
      /^([+-]\d{4})$/
      // 2 additional digits
    ];
    var parseTokenYYYY = /^(\d{4})/;
    var parseTokensYYYYY = [
      /^([+-]\d{4})/,
      // 0 additional digits
      /^([+-]\d{5})/,
      // 1 additional digit
      /^([+-]\d{6})/
      // 2 additional digits
    ];
    var parseTokenMM = /^-(\d{2})$/;
    var parseTokenDDD = /^-?(\d{3})$/;
    var parseTokenMMDD = /^-?(\d{2})-?(\d{2})$/;
    var parseTokenWww = /^-?W(\d{2})$/;
    var parseTokenWwwD = /^-?W(\d{2})-?(\d{1})$/;
    var parseTokenHH = /^(\d{2}([.,]\d*)?)$/;
    var parseTokenHHMM = /^(\d{2}):?(\d{2}([.,]\d*)?)$/;
    var parseTokenHHMMSS = /^(\d{2}):?(\d{2}):?(\d{2}([.,]\d*)?)$/;
    var parseTokenTimezone = /([Z+-].*)$/;
    var parseTokenTimezoneZ = /^(Z)$/;
    var parseTokenTimezoneHH = /^([+-])(\d{2})$/;
    var parseTokenTimezoneHHMM = /^([+-])(\d{2}):?(\d{2})$/;
    function parse9(argument, dirtyOptions) {
      if (isDate(argument)) {
        return new Date(argument.getTime());
      } else if (typeof argument !== "string") {
        return new Date(argument);
      }
      var options = dirtyOptions || {};
      var additionalDigits = options.additionalDigits;
      if (additionalDigits == null) {
        additionalDigits = DEFAULT_ADDITIONAL_DIGITS;
      } else {
        additionalDigits = Number(additionalDigits);
      }
      var dateStrings = splitDateString(argument);
      var parseYearResult = parseYear(dateStrings.date, additionalDigits);
      var year = parseYearResult.year;
      var restDateString = parseYearResult.restDateString;
      var date = parseDate(restDateString, year);
      if (date) {
        var timestamp = date.getTime();
        var time = 0;
        var offset;
        if (dateStrings.time) {
          time = parseTime(dateStrings.time);
        }
        if (dateStrings.timezone) {
          offset = parseTimezone(dateStrings.timezone) * MILLISECONDS_IN_MINUTE;
        } else {
          var fullTime = timestamp + time;
          var fullTimeDate = new Date(fullTime);
          offset = getTimezoneOffsetInMilliseconds(fullTimeDate);
          var fullTimeDateNextDay = new Date(fullTime);
          fullTimeDateNextDay.setDate(fullTimeDate.getDate() + 1);
          var offsetDiff = getTimezoneOffsetInMilliseconds(fullTimeDateNextDay) - getTimezoneOffsetInMilliseconds(fullTimeDate);
          if (offsetDiff > 0) {
            offset += offsetDiff;
          }
        }
        return new Date(timestamp + time + offset);
      } else {
        return new Date(argument);
      }
    }
    function splitDateString(dateString) {
      var dateStrings = {};
      var array2 = dateString.split(parseTokenDateTimeDelimeter);
      var timeString;
      if (parseTokenPlainTime.test(array2[0])) {
        dateStrings.date = null;
        timeString = array2[0];
      } else {
        dateStrings.date = array2[0];
        timeString = array2[1];
      }
      if (timeString) {
        var token = parseTokenTimezone.exec(timeString);
        if (token) {
          dateStrings.time = timeString.replace(token[1], "");
          dateStrings.timezone = token[1];
        } else {
          dateStrings.time = timeString;
        }
      }
      return dateStrings;
    }
    function parseYear(dateString, additionalDigits) {
      var parseTokenYYY = parseTokensYYY[additionalDigits];
      var parseTokenYYYYY = parseTokensYYYYY[additionalDigits];
      var token;
      token = parseTokenYYYY.exec(dateString) || parseTokenYYYYY.exec(dateString);
      if (token) {
        var yearString = token[1];
        return {
          year: parseInt(yearString, 10),
          restDateString: dateString.slice(yearString.length)
        };
      }
      token = parseTokenYY.exec(dateString) || parseTokenYYY.exec(dateString);
      if (token) {
        var centuryString = token[1];
        return {
          year: parseInt(centuryString, 10) * 100,
          restDateString: dateString.slice(centuryString.length)
        };
      }
      return {
        year: null
      };
    }
    function parseDate(dateString, year) {
      if (year === null) {
        return null;
      }
      var token;
      var date;
      var month;
      var week;
      if (dateString.length === 0) {
        date = /* @__PURE__ */ new Date(0);
        date.setUTCFullYear(year);
        return date;
      }
      token = parseTokenMM.exec(dateString);
      if (token) {
        date = /* @__PURE__ */ new Date(0);
        month = parseInt(token[1], 10) - 1;
        date.setUTCFullYear(year, month);
        return date;
      }
      token = parseTokenDDD.exec(dateString);
      if (token) {
        date = /* @__PURE__ */ new Date(0);
        var dayOfYear = parseInt(token[1], 10);
        date.setUTCFullYear(year, 0, dayOfYear);
        return date;
      }
      token = parseTokenMMDD.exec(dateString);
      if (token) {
        date = /* @__PURE__ */ new Date(0);
        month = parseInt(token[1], 10) - 1;
        var day = parseInt(token[2], 10);
        date.setUTCFullYear(year, month, day);
        return date;
      }
      token = parseTokenWww.exec(dateString);
      if (token) {
        week = parseInt(token[1], 10) - 1;
        return dayOfISOYear(year, week);
      }
      token = parseTokenWwwD.exec(dateString);
      if (token) {
        week = parseInt(token[1], 10) - 1;
        var dayOfWeek = parseInt(token[2], 10) - 1;
        return dayOfISOYear(year, week, dayOfWeek);
      }
      return null;
    }
    function parseTime(timeString) {
      var token;
      var hours;
      var minutes;
      token = parseTokenHH.exec(timeString);
      if (token) {
        hours = parseFloat(token[1].replace(",", "."));
        return hours % 24 * MILLISECONDS_IN_HOUR;
      }
      token = parseTokenHHMM.exec(timeString);
      if (token) {
        hours = parseInt(token[1], 10);
        minutes = parseFloat(token[2].replace(",", "."));
        return hours % 24 * MILLISECONDS_IN_HOUR + minutes * MILLISECONDS_IN_MINUTE;
      }
      token = parseTokenHHMMSS.exec(timeString);
      if (token) {
        hours = parseInt(token[1], 10);
        minutes = parseInt(token[2], 10);
        var seconds = parseFloat(token[3].replace(",", "."));
        return hours % 24 * MILLISECONDS_IN_HOUR + minutes * MILLISECONDS_IN_MINUTE + seconds * 1e3;
      }
      return null;
    }
    function parseTimezone(timezoneString) {
      var token;
      var absoluteOffset;
      token = parseTokenTimezoneZ.exec(timezoneString);
      if (token) {
        return 0;
      }
      token = parseTokenTimezoneHH.exec(timezoneString);
      if (token) {
        absoluteOffset = parseInt(token[2], 10) * 60;
        return token[1] === "+" ? -absoluteOffset : absoluteOffset;
      }
      token = parseTokenTimezoneHHMM.exec(timezoneString);
      if (token) {
        absoluteOffset = parseInt(token[2], 10) * 60 + parseInt(token[3], 10);
        return token[1] === "+" ? -absoluteOffset : absoluteOffset;
      }
      return 0;
    }
    function dayOfISOYear(isoYear, week, day) {
      week = week || 0;
      day = day || 0;
      var date = /* @__PURE__ */ new Date(0);
      date.setUTCFullYear(isoYear, 0, 4);
      var fourthOfJanuaryDay = date.getUTCDay() || 7;
      var diff = week * 7 + day + 1 - fourthOfJanuaryDay;
      date.setUTCDate(date.getUTCDate() + diff);
      return date;
    }
    module.exports = parse9;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/get_days_in_month/index.js
var require_get_days_in_month = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/get_days_in_month/index.js"(exports, module) {
    var parse9 = require_parse();
    function getDaysInMonth2(dirtyDate) {
      var date = parse9(dirtyDate);
      var year = date.getFullYear();
      var monthIndex = date.getMonth();
      var lastDayOfMonth = /* @__PURE__ */ new Date(0);
      lastDayOfMonth.setFullYear(year, monthIndex + 1, 0);
      lastDayOfMonth.setHours(0, 0, 0, 0);
      return lastDayOfMonth.getDate();
    }
    module.exports = getDaysInMonth2;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/get_day/index.js
var require_get_day = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/get_day/index.js"(exports, module) {
    var parse9 = require_parse();
    function getDay3(dirtyDate) {
      var date = parse9(dirtyDate);
      var day = date.getDay();
      return day;
    }
    module.exports = getDay3;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_after/index.js
var require_is_after = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_after/index.js"(exports, module) {
    var parse9 = require_parse();
    function isAfter4(dirtyDate, dirtyDateToCompare) {
      var date = parse9(dirtyDate);
      var dateToCompare = parse9(dirtyDateToCompare);
      return date.getTime() > dateToCompare.getTime();
    }
    module.exports = isAfter4;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_before/index.js
var require_is_before = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_before/index.js"(exports, module) {
    var parse9 = require_parse();
    function isBefore5(dirtyDate, dirtyDateToCompare) {
      var date = parse9(dirtyDate);
      var dateToCompare = parse9(dirtyDateToCompare);
      return date.getTime() < dateToCompare.getTime();
    }
    module.exports = isBefore5;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_day/index.js
var require_start_of_day = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_day/index.js"(exports, module) {
    var parse9 = require_parse();
    function startOfDay3(dirtyDate) {
      var date = parse9(dirtyDate);
      date.setHours(0, 0, 0, 0);
      return date;
    }
    module.exports = startOfDay3;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_same_day/index.js
var require_is_same_day = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_same_day/index.js"(exports, module) {
    var startOfDay3 = require_start_of_day();
    function isSameDay2(dirtyDateLeft, dirtyDateRight) {
      var dateLeftStartOfDay = startOfDay3(dirtyDateLeft);
      var dateRightStartOfDay = startOfDay3(dirtyDateRight);
      return dateLeftStartOfDay.getTime() === dateRightStartOfDay.getTime();
    }
    module.exports = isSameDay2;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/end_of_day/index.js
var require_end_of_day = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/end_of_day/index.js"(exports, module) {
    var parse9 = require_parse();
    function endOfDay2(dirtyDate) {
      var date = parse9(dirtyDate);
      date.setHours(23, 59, 59, 999);
      return date;
    }
    module.exports = endOfDay2;
  }
});

// node_modules/react-infinite-calendar/es/utils/defaultDisplayOptions.js
var require_defaultDisplayOptions = __commonJS({
  "node_modules/react-infinite-calendar/es/utils/defaultDisplayOptions.js"(exports, module) {
    module.exports = {
      hideYearsOnSelect: true,
      layout: "portrait",
      overscanMonthCount: 2,
      shouldHeaderAnimate: true,
      showHeader: true,
      showMonthsForYears: true,
      showOverlay: true,
      showTodayHelper: true,
      showWeekdays: true,
      todayHelperRowOffset: 4
    };
  }
});

// node_modules/react-infinite-calendar/es/utils/defaultLocale.js
var require_defaultLocale = __commonJS({
  "node_modules/react-infinite-calendar/es/utils/defaultLocale.js"(exports, module) {
    module.exports = {
      blank: "Select a date...",
      headerFormat: "ddd, MMM Do",
      todayLabel: {
        long: "Today"
      },
      weekdays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      weekStartsOn: 0
    };
  }
});

// node_modules/react-infinite-calendar/es/utils/defaultTheme.js
var require_defaultTheme = __commonJS({
  "node_modules/react-infinite-calendar/es/utils/defaultTheme.js"(exports, module) {
    module.exports = {
      accentColor: "#448AFF",
      floatingNav: {
        background: "rgba(56, 87, 138, 0.94)",
        chevron: "#FFA726",
        color: "#FFF"
      },
      headerColor: "#448AFF",
      selectionColor: "#559FFF",
      textColor: {
        active: "#FFF",
        default: "#333"
      },
      todayColor: "#FFA726",
      weekdayColor: "#559FFF"
    };
  }
});

// node_modules/chain-function/index.js
var require_chain_function = __commonJS({
  "node_modules/chain-function/index.js"(exports, module) {
    module.exports = function chain() {
      var len = arguments.length;
      var args = [];
      for (var i = 0; i < len; i++)
        args[i] = arguments[i];
      args = args.filter(function(fn) {
        return fn != null;
      });
      if (args.length === 0)
        return void 0;
      if (args.length === 1)
        return args[0];
      return args.reduce(function(current, next) {
        return function chainedFunction() {
          current.apply(this, arguments);
          next.apply(this, arguments);
        };
      });
    };
  }
});

// node_modules/warning/browser.js
var require_browser = __commonJS({
  "node_modules/warning/browser.js"(exports, module) {
    "use strict";
    var warning = function() {
    };
    if (true) {
      warning = function(condition, format10, args) {
        var len = arguments.length;
        args = new Array(len > 2 ? len - 2 : 0);
        for (var key = 2; key < len; key++) {
          args[key - 2] = arguments[key];
        }
        if (format10 === void 0) {
          throw new Error(
            "`warning(condition, format, ...args)` requires a warning message argument"
          );
        }
        if (format10.length < 10 || /^[s\W]*$/.test(format10)) {
          throw new Error(
            "The warning format should be able to uniquely identify this warning. Please, use a more descriptive format than: " + format10
          );
        }
        if (!condition) {
          var argIndex = 0;
          var message = "Warning: " + format10.replace(/%s/g, function() {
            return args[argIndex++];
          });
          if (typeof console !== "undefined") {
            console.error(message);
          }
          try {
            throw new Error(message);
          } catch (x) {
          }
        }
      };
    }
    module.exports = warning;
  }
});

// node_modules/react-transition-group/utils/ChildMapping.js
var require_ChildMapping = __commonJS({
  "node_modules/react-transition-group/utils/ChildMapping.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.getChildMapping = getChildMapping;
    exports.mergeChildMappings = mergeChildMappings;
    var _react = require_react();
    function getChildMapping(children) {
      if (!children) {
        return children;
      }
      var result = {};
      _react.Children.map(children, function(child) {
        return child;
      }).forEach(function(child) {
        result[child.key] = child;
      });
      return result;
    }
    function mergeChildMappings(prev, next) {
      prev = prev || {};
      next = next || {};
      function getValueForKey(key) {
        if (next.hasOwnProperty(key)) {
          return next[key];
        }
        return prev[key];
      }
      var nextKeysPending = {};
      var pendingKeys = [];
      for (var prevKey in prev) {
        if (next.hasOwnProperty(prevKey)) {
          if (pendingKeys.length) {
            nextKeysPending[prevKey] = pendingKeys;
            pendingKeys = [];
          }
        } else {
          pendingKeys.push(prevKey);
        }
      }
      var i = void 0;
      var childMapping = {};
      for (var nextKey in next) {
        if (nextKeysPending.hasOwnProperty(nextKey)) {
          for (i = 0; i < nextKeysPending[nextKey].length; i++) {
            var pendingNextKey = nextKeysPending[nextKey][i];
            childMapping[nextKeysPending[nextKey][i]] = getValueForKey(pendingNextKey);
          }
        }
        childMapping[nextKey] = getValueForKey(nextKey);
      }
      for (i = 0; i < pendingKeys.length; i++) {
        childMapping[pendingKeys[i]] = getValueForKey(pendingKeys[i]);
      }
      return childMapping;
    }
  }
});

// node_modules/react-transition-group/TransitionGroup.js
var require_TransitionGroup = __commonJS({
  "node_modules/react-transition-group/TransitionGroup.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _chainFunction = require_chain_function();
    var _chainFunction2 = _interopRequireDefault(_chainFunction);
    var _react = require_react();
    var _react2 = _interopRequireDefault(_react);
    var _propTypes = require_prop_types();
    var _propTypes2 = _interopRequireDefault(_propTypes);
    var _warning = require_browser();
    var _warning2 = _interopRequireDefault(_warning);
    var _ChildMapping = require_ChildMapping();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var propTypes = {
      component: _propTypes2.default.any,
      childFactory: _propTypes2.default.func,
      children: _propTypes2.default.node
    };
    var defaultProps = {
      component: "span",
      childFactory: function childFactory(child) {
        return child;
      }
    };
    var TransitionGroup = function(_React$Component) {
      _inherits11(TransitionGroup2, _React$Component);
      function TransitionGroup2(props, context) {
        _classCallCheck12(this, TransitionGroup2);
        var _this = _possibleConstructorReturn11(this, _React$Component.call(this, props, context));
        _this.performAppear = function(key, component) {
          _this.currentlyTransitioningKeys[key] = true;
          if (component.componentWillAppear) {
            component.componentWillAppear(_this._handleDoneAppearing.bind(_this, key, component));
          } else {
            _this._handleDoneAppearing(key, component);
          }
        };
        _this._handleDoneAppearing = function(key, component) {
          if (component.componentDidAppear) {
            component.componentDidAppear();
          }
          delete _this.currentlyTransitioningKeys[key];
          var currentChildMapping = (0, _ChildMapping.getChildMapping)(_this.props.children);
          if (!currentChildMapping || !currentChildMapping.hasOwnProperty(key)) {
            _this.performLeave(key, component);
          }
        };
        _this.performEnter = function(key, component) {
          _this.currentlyTransitioningKeys[key] = true;
          if (component.componentWillEnter) {
            component.componentWillEnter(_this._handleDoneEntering.bind(_this, key, component));
          } else {
            _this._handleDoneEntering(key, component);
          }
        };
        _this._handleDoneEntering = function(key, component) {
          if (component.componentDidEnter) {
            component.componentDidEnter();
          }
          delete _this.currentlyTransitioningKeys[key];
          var currentChildMapping = (0, _ChildMapping.getChildMapping)(_this.props.children);
          if (!currentChildMapping || !currentChildMapping.hasOwnProperty(key)) {
            _this.performLeave(key, component);
          }
        };
        _this.performLeave = function(key, component) {
          _this.currentlyTransitioningKeys[key] = true;
          if (component.componentWillLeave) {
            component.componentWillLeave(_this._handleDoneLeaving.bind(_this, key, component));
          } else {
            _this._handleDoneLeaving(key, component);
          }
        };
        _this._handleDoneLeaving = function(key, component) {
          if (component.componentDidLeave) {
            component.componentDidLeave();
          }
          delete _this.currentlyTransitioningKeys[key];
          var currentChildMapping = (0, _ChildMapping.getChildMapping)(_this.props.children);
          if (currentChildMapping && currentChildMapping.hasOwnProperty(key)) {
            _this.keysToEnter.push(key);
          } else {
            _this.setState(function(state) {
              var newChildren = _extends10({}, state.children);
              delete newChildren[key];
              return { children: newChildren };
            });
          }
        };
        _this.childRefs = /* @__PURE__ */ Object.create(null);
        _this.state = {
          children: (0, _ChildMapping.getChildMapping)(props.children)
        };
        return _this;
      }
      TransitionGroup2.prototype.componentWillMount = function componentWillMount() {
        this.currentlyTransitioningKeys = {};
        this.keysToEnter = [];
        this.keysToLeave = [];
      };
      TransitionGroup2.prototype.componentDidMount = function componentDidMount() {
        var initialChildMapping = this.state.children;
        for (var key in initialChildMapping) {
          if (initialChildMapping[key]) {
            this.performAppear(key, this.childRefs[key]);
          }
        }
      };
      TransitionGroup2.prototype.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
        var nextChildMapping = (0, _ChildMapping.getChildMapping)(nextProps.children);
        var prevChildMapping = this.state.children;
        this.setState({
          children: (0, _ChildMapping.mergeChildMappings)(prevChildMapping, nextChildMapping)
        });
        for (var key in nextChildMapping) {
          var hasPrev = prevChildMapping && prevChildMapping.hasOwnProperty(key);
          if (nextChildMapping[key] && !hasPrev && !this.currentlyTransitioningKeys[key]) {
            this.keysToEnter.push(key);
          }
        }
        for (var _key in prevChildMapping) {
          var hasNext = nextChildMapping && nextChildMapping.hasOwnProperty(_key);
          if (prevChildMapping[_key] && !hasNext && !this.currentlyTransitioningKeys[_key]) {
            this.keysToLeave.push(_key);
          }
        }
      };
      TransitionGroup2.prototype.componentDidUpdate = function componentDidUpdate() {
        var _this2 = this;
        var keysToEnter = this.keysToEnter;
        this.keysToEnter = [];
        keysToEnter.forEach(function(key) {
          return _this2.performEnter(key, _this2.childRefs[key]);
        });
        var keysToLeave = this.keysToLeave;
        this.keysToLeave = [];
        keysToLeave.forEach(function(key) {
          return _this2.performLeave(key, _this2.childRefs[key]);
        });
      };
      TransitionGroup2.prototype.render = function render() {
        var _this3 = this;
        var childrenToRender = [];
        var _loop = function _loop2(key2) {
          var child = _this3.state.children[key2];
          if (child) {
            var isCallbackRef = typeof child.ref !== "string";
            var factoryChild = _this3.props.childFactory(child);
            var ref = function ref2(r) {
              _this3.childRefs[key2] = r;
            };
            true ? (0, _warning2.default)(isCallbackRef, "string refs are not supported on children of TransitionGroup and will be ignored. Please use a callback ref instead: https://facebook.github.io/react/docs/refs-and-the-dom.html#the-ref-callback-attribute") : void 0;
            if (factoryChild === child && isCallbackRef) {
              ref = (0, _chainFunction2.default)(child.ref, ref);
            }
            childrenToRender.push(_react2.default.cloneElement(factoryChild, {
              key: key2,
              ref
            }));
          }
        };
        for (var key in this.state.children) {
          _loop(key);
        }
        var props = _extends10({}, this.props);
        delete props.transitionLeave;
        delete props.transitionName;
        delete props.transitionAppear;
        delete props.transitionEnter;
        delete props.childFactory;
        delete props.transitionLeaveTimeout;
        delete props.transitionEnterTimeout;
        delete props.transitionAppearTimeout;
        delete props.component;
        return _react2.default.createElement(this.props.component, props, childrenToRender);
      };
      return TransitionGroup2;
    }(_react2.default.Component);
    TransitionGroup.displayName = "TransitionGroup";
    TransitionGroup.propTypes = true ? propTypes : {};
    TransitionGroup.defaultProps = defaultProps;
    exports.default = TransitionGroup;
    module.exports = exports["default"];
  }
});

// node_modules/dom-helpers/class/hasClass.js
var require_hasClass = __commonJS({
  "node_modules/dom-helpers/class/hasClass.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    exports.default = hasClass;
    function hasClass(element, className) {
      if (element.classList)
        return !!className && element.classList.contains(className);
      else
        return (" " + (element.className.baseVal || element.className) + " ").indexOf(" " + className + " ") !== -1;
    }
    module.exports = exports["default"];
  }
});

// node_modules/dom-helpers/class/addClass.js
var require_addClass = __commonJS({
  "node_modules/dom-helpers/class/addClass.js"(exports, module) {
    "use strict";
    var _interopRequireDefault = require_interopRequireDefault();
    exports.__esModule = true;
    exports.default = addClass;
    var _hasClass = _interopRequireDefault(require_hasClass());
    function addClass(element, className) {
      if (element.classList)
        element.classList.add(className);
      else if (!(0, _hasClass.default)(element, className))
        if (typeof element.className === "string")
          element.className = element.className + " " + className;
        else
          element.setAttribute("class", (element.className && element.className.baseVal || "") + " " + className);
    }
    module.exports = exports["default"];
  }
});

// node_modules/dom-helpers/class/removeClass.js
var require_removeClass = __commonJS({
  "node_modules/dom-helpers/class/removeClass.js"(exports, module) {
    "use strict";
    function replaceClassName(origClass, classToRemove) {
      return origClass.replace(new RegExp("(^|\\s)" + classToRemove + "(?:\\s|$)", "g"), "$1").replace(/\s+/g, " ").replace(/^\s*|\s*$/g, "");
    }
    module.exports = function removeClass(element, className) {
      if (element.classList)
        element.classList.remove(className);
      else if (typeof element.className === "string")
        element.className = replaceClassName(element.className, className);
      else
        element.setAttribute("class", replaceClassName(element.className && element.className.baseVal || "", className));
    };
  }
});

// node_modules/dom-helpers/util/requestAnimationFrame.js
var require_requestAnimationFrame = __commonJS({
  "node_modules/dom-helpers/util/requestAnimationFrame.js"(exports, module) {
    "use strict";
    var _interopRequireDefault = require_interopRequireDefault();
    exports.__esModule = true;
    exports.default = void 0;
    var _inDOM = _interopRequireDefault(require_inDOM());
    var vendors = ["", "webkit", "moz", "o", "ms"];
    var cancel = "clearTimeout";
    var raf = fallback;
    var compatRaf;
    var getKey = function getKey2(vendor, k) {
      return vendor + (!vendor ? k : k[0].toUpperCase() + k.substr(1)) + "AnimationFrame";
    };
    if (_inDOM.default) {
      vendors.some(function(vendor) {
        var rafKey = getKey(vendor, "request");
        if (rafKey in window) {
          cancel = getKey(vendor, "cancel");
          return raf = function raf2(cb) {
            return window[rafKey](cb);
          };
        }
      });
    }
    var prev = (/* @__PURE__ */ new Date()).getTime();
    function fallback(fn) {
      var curr = (/* @__PURE__ */ new Date()).getTime(), ms = Math.max(0, 16 - (curr - prev)), req = setTimeout(fn, ms);
      prev = curr;
      return req;
    }
    compatRaf = function compatRaf2(cb) {
      return raf(cb);
    };
    compatRaf.cancel = function(id) {
      window[cancel] && typeof window[cancel] === "function" && window[cancel](id);
    };
    var _default = compatRaf;
    exports.default = _default;
    module.exports = exports["default"];
  }
});

// node_modules/dom-helpers/transition/properties.js
var require_properties = __commonJS({
  "node_modules/dom-helpers/transition/properties.js"(exports) {
    "use strict";
    var _interopRequireDefault = require_interopRequireDefault();
    exports.__esModule = true;
    exports.default = exports.animationEnd = exports.animationDelay = exports.animationTiming = exports.animationDuration = exports.animationName = exports.transitionEnd = exports.transitionDuration = exports.transitionDelay = exports.transitionTiming = exports.transitionProperty = exports.transform = void 0;
    var _inDOM = _interopRequireDefault(require_inDOM());
    var transform = "transform";
    exports.transform = transform;
    var prefix;
    var transitionEnd;
    var animationEnd;
    exports.animationEnd = animationEnd;
    exports.transitionEnd = transitionEnd;
    var transitionProperty;
    var transitionDuration;
    var transitionTiming;
    var transitionDelay;
    exports.transitionDelay = transitionDelay;
    exports.transitionTiming = transitionTiming;
    exports.transitionDuration = transitionDuration;
    exports.transitionProperty = transitionProperty;
    var animationName;
    var animationDuration;
    var animationTiming;
    var animationDelay;
    exports.animationDelay = animationDelay;
    exports.animationTiming = animationTiming;
    exports.animationDuration = animationDuration;
    exports.animationName = animationName;
    if (_inDOM.default) {
      _getTransitionPropert = getTransitionProperties();
      prefix = _getTransitionPropert.prefix;
      exports.transitionEnd = transitionEnd = _getTransitionPropert.transitionEnd;
      exports.animationEnd = animationEnd = _getTransitionPropert.animationEnd;
      exports.transform = transform = prefix + "-" + transform;
      exports.transitionProperty = transitionProperty = prefix + "-transition-property";
      exports.transitionDuration = transitionDuration = prefix + "-transition-duration";
      exports.transitionDelay = transitionDelay = prefix + "-transition-delay";
      exports.transitionTiming = transitionTiming = prefix + "-transition-timing-function";
      exports.animationName = animationName = prefix + "-animation-name";
      exports.animationDuration = animationDuration = prefix + "-animation-duration";
      exports.animationTiming = animationTiming = prefix + "-animation-delay";
      exports.animationDelay = animationDelay = prefix + "-animation-timing-function";
    }
    var _getTransitionPropert;
    var _default = {
      transform,
      end: transitionEnd,
      property: transitionProperty,
      timing: transitionTiming,
      delay: transitionDelay,
      duration: transitionDuration
    };
    exports.default = _default;
    function getTransitionProperties() {
      var style = document.createElement("div").style;
      var vendorMap = {
        O: function O(e) {
          return "o" + e.toLowerCase();
        },
        Moz: function Moz(e) {
          return e.toLowerCase();
        },
        Webkit: function Webkit(e) {
          return "webkit" + e;
        },
        ms: function ms(e) {
          return "MS" + e;
        }
      };
      var vendors = Object.keys(vendorMap);
      var transitionEnd2, animationEnd2;
      var prefix2 = "";
      for (var i = 0; i < vendors.length; i++) {
        var vendor = vendors[i];
        if (vendor + "TransitionProperty" in style) {
          prefix2 = "-" + vendor.toLowerCase();
          transitionEnd2 = vendorMap[vendor]("TransitionEnd");
          animationEnd2 = vendorMap[vendor]("AnimationEnd");
          break;
        }
      }
      if (!transitionEnd2 && "transitionProperty" in style)
        transitionEnd2 = "transitionend";
      if (!animationEnd2 && "animationName" in style)
        animationEnd2 = "animationend";
      style = null;
      return {
        animationEnd: animationEnd2,
        transitionEnd: transitionEnd2,
        prefix: prefix2
      };
    }
  }
});

// node_modules/react-transition-group/utils/PropTypes.js
var require_PropTypes = __commonJS({
  "node_modules/react-transition-group/utils/PropTypes.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.nameShape = void 0;
    exports.transitionTimeout = transitionTimeout;
    var _react = require_react();
    var _react2 = _interopRequireDefault(_react);
    var _propTypes = require_prop_types();
    var _propTypes2 = _interopRequireDefault(_propTypes);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function transitionTimeout(transitionType) {
      var timeoutPropName = "transition" + transitionType + "Timeout";
      var enabledPropName = "transition" + transitionType;
      return function(props) {
        if (props[enabledPropName]) {
          if (props[timeoutPropName] == null) {
            return new Error(timeoutPropName + " wasn't supplied to CSSTransitionGroup: this can cause unreliable animations and won't be supported in a future version of React. See https://fb.me/react-animation-transition-group-timeout for more information.");
          } else if (typeof props[timeoutPropName] !== "number") {
            return new Error(timeoutPropName + " must be a number (in milliseconds)");
          }
        }
        return null;
      };
    }
    var nameShape = exports.nameShape = _propTypes2.default.oneOfType([_propTypes2.default.string, _propTypes2.default.shape({
      enter: _propTypes2.default.string,
      leave: _propTypes2.default.string,
      active: _propTypes2.default.string
    }), _propTypes2.default.shape({
      enter: _propTypes2.default.string,
      enterActive: _propTypes2.default.string,
      leave: _propTypes2.default.string,
      leaveActive: _propTypes2.default.string,
      appear: _propTypes2.default.string,
      appearActive: _propTypes2.default.string
    })]);
  }
});

// node_modules/react-transition-group/CSSTransitionGroupChild.js
var require_CSSTransitionGroupChild = __commonJS({
  "node_modules/react-transition-group/CSSTransitionGroupChild.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _addClass = require_addClass();
    var _addClass2 = _interopRequireDefault(_addClass);
    var _removeClass = require_removeClass();
    var _removeClass2 = _interopRequireDefault(_removeClass);
    var _requestAnimationFrame = require_requestAnimationFrame();
    var _requestAnimationFrame2 = _interopRequireDefault(_requestAnimationFrame);
    var _properties = require_properties();
    var _react = require_react();
    var _react2 = _interopRequireDefault(_react);
    var _propTypes = require_prop_types();
    var _propTypes2 = _interopRequireDefault(_propTypes);
    var _reactDom = require_react_dom();
    var _PropTypes = require_PropTypes();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var events = [];
    if (_properties.transitionEnd)
      events.push(_properties.transitionEnd);
    if (_properties.animationEnd)
      events.push(_properties.animationEnd);
    function addEndListener(node, listener) {
      if (events.length) {
        events.forEach(function(e) {
          return node.addEventListener(e, listener, false);
        });
      } else {
        setTimeout(listener, 0);
      }
      return function() {
        if (!events.length)
          return;
        events.forEach(function(e) {
          return node.removeEventListener(e, listener, false);
        });
      };
    }
    var propTypes = {
      children: _propTypes2.default.node,
      name: _PropTypes.nameShape.isRequired,
      // Once we require timeouts to be specified, we can remove the
      // boolean flags (appear etc.) and just accept a number
      // or a bool for the timeout flags (appearTimeout etc.)
      appear: _propTypes2.default.bool,
      enter: _propTypes2.default.bool,
      leave: _propTypes2.default.bool,
      appearTimeout: _propTypes2.default.number,
      enterTimeout: _propTypes2.default.number,
      leaveTimeout: _propTypes2.default.number
    };
    var CSSTransitionGroupChild = function(_React$Component) {
      _inherits11(CSSTransitionGroupChild2, _React$Component);
      function CSSTransitionGroupChild2() {
        var _temp3, _this, _ret;
        _classCallCheck12(this, CSSTransitionGroupChild2);
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        return _ret = (_temp3 = (_this = _possibleConstructorReturn11(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.componentWillAppear = function(done) {
          if (_this.props.appear) {
            _this.transition("appear", done, _this.props.appearTimeout);
          } else {
            done();
          }
        }, _this.componentWillEnter = function(done) {
          if (_this.props.enter) {
            _this.transition("enter", done, _this.props.enterTimeout);
          } else {
            done();
          }
        }, _this.componentWillLeave = function(done) {
          if (_this.props.leave) {
            _this.transition("leave", done, _this.props.leaveTimeout);
          } else {
            done();
          }
        }, _temp3), _possibleConstructorReturn11(_this, _ret);
      }
      CSSTransitionGroupChild2.prototype.componentWillMount = function componentWillMount() {
        this.classNameAndNodeQueue = [];
        this.transitionTimeouts = [];
      };
      CSSTransitionGroupChild2.prototype.componentWillUnmount = function componentWillUnmount() {
        this.unmounted = true;
        if (this.timeout) {
          clearTimeout(this.timeout);
        }
        this.transitionTimeouts.forEach(function(timeout) {
          clearTimeout(timeout);
        });
        this.classNameAndNodeQueue.length = 0;
      };
      CSSTransitionGroupChild2.prototype.transition = function transition2(animationType, finishCallback, timeout) {
        var node = (0, _reactDom.findDOMNode)(this);
        if (!node) {
          if (finishCallback) {
            finishCallback();
          }
          return;
        }
        var className = this.props.name[animationType] || this.props.name + "-" + animationType;
        var activeClassName = this.props.name[animationType + "Active"] || className + "-active";
        var timer = null;
        var removeListeners = void 0;
        (0, _addClass2.default)(node, className);
        this.queueClassAndNode(activeClassName, node);
        var finish = function finish2(e) {
          if (e && e.target !== node) {
            return;
          }
          clearTimeout(timer);
          if (removeListeners)
            removeListeners();
          (0, _removeClass2.default)(node, className);
          (0, _removeClass2.default)(node, activeClassName);
          if (removeListeners)
            removeListeners();
          if (finishCallback) {
            finishCallback();
          }
        };
        if (timeout) {
          timer = setTimeout(finish, timeout);
          this.transitionTimeouts.push(timer);
        } else if (_properties.transitionEnd) {
          removeListeners = addEndListener(node, finish);
        }
      };
      CSSTransitionGroupChild2.prototype.queueClassAndNode = function queueClassAndNode(className, node) {
        var _this2 = this;
        this.classNameAndNodeQueue.push({
          className,
          node
        });
        if (!this.rafHandle) {
          this.rafHandle = (0, _requestAnimationFrame2.default)(function() {
            return _this2.flushClassNameAndNodeQueue();
          });
        }
      };
      CSSTransitionGroupChild2.prototype.flushClassNameAndNodeQueue = function flushClassNameAndNodeQueue() {
        if (!this.unmounted) {
          this.classNameAndNodeQueue.forEach(function(obj) {
            obj.node.scrollTop;
            (0, _addClass2.default)(obj.node, obj.className);
          });
        }
        this.classNameAndNodeQueue.length = 0;
        this.rafHandle = null;
      };
      CSSTransitionGroupChild2.prototype.render = function render() {
        var props = _extends10({}, this.props);
        delete props.name;
        delete props.appear;
        delete props.enter;
        delete props.leave;
        delete props.appearTimeout;
        delete props.enterTimeout;
        delete props.leaveTimeout;
        delete props.children;
        return _react2.default.cloneElement(_react2.default.Children.only(this.props.children), props);
      };
      return CSSTransitionGroupChild2;
    }(_react2.default.Component);
    CSSTransitionGroupChild.displayName = "CSSTransitionGroupChild";
    CSSTransitionGroupChild.propTypes = true ? propTypes : {};
    exports.default = CSSTransitionGroupChild;
    module.exports = exports["default"];
  }
});

// node_modules/react-transition-group/CSSTransitionGroup.js
var require_CSSTransitionGroup = __commonJS({
  "node_modules/react-transition-group/CSSTransitionGroup.js"(exports, module) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = require_react();
    var _react2 = _interopRequireDefault(_react);
    var _propTypes = require_prop_types();
    var _propTypes2 = _interopRequireDefault(_propTypes);
    var _TransitionGroup = require_TransitionGroup();
    var _TransitionGroup2 = _interopRequireDefault(_TransitionGroup);
    var _CSSTransitionGroupChild = require_CSSTransitionGroupChild();
    var _CSSTransitionGroupChild2 = _interopRequireDefault(_CSSTransitionGroupChild);
    var _PropTypes = require_PropTypes();
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var propTypes = {
      transitionName: _PropTypes.nameShape.isRequired,
      transitionAppear: _propTypes2.default.bool,
      transitionEnter: _propTypes2.default.bool,
      transitionLeave: _propTypes2.default.bool,
      transitionAppearTimeout: (0, _PropTypes.transitionTimeout)("Appear"),
      transitionEnterTimeout: (0, _PropTypes.transitionTimeout)("Enter"),
      transitionLeaveTimeout: (0, _PropTypes.transitionTimeout)("Leave")
    };
    var defaultProps = {
      transitionAppear: false,
      transitionEnter: true,
      transitionLeave: true
    };
    var CSSTransitionGroup3 = function(_React$Component) {
      _inherits11(CSSTransitionGroup4, _React$Component);
      function CSSTransitionGroup4() {
        var _temp3, _this, _ret;
        _classCallCheck12(this, CSSTransitionGroup4);
        for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        return _ret = (_temp3 = (_this = _possibleConstructorReturn11(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this._wrapChild = function(child) {
          return _react2.default.createElement(_CSSTransitionGroupChild2.default, {
            name: _this.props.transitionName,
            appear: _this.props.transitionAppear,
            enter: _this.props.transitionEnter,
            leave: _this.props.transitionLeave,
            appearTimeout: _this.props.transitionAppearTimeout,
            enterTimeout: _this.props.transitionEnterTimeout,
            leaveTimeout: _this.props.transitionLeaveTimeout
          }, child);
        }, _temp3), _possibleConstructorReturn11(_this, _ret);
      }
      CSSTransitionGroup4.prototype.render = function render() {
        return _react2.default.createElement(_TransitionGroup2.default, _extends10({}, this.props, { childFactory: this._wrapChild }));
      };
      return CSSTransitionGroup4;
    }(_react2.default.Component);
    CSSTransitionGroup3.displayName = "CSSTransitionGroup";
    CSSTransitionGroup3.propTypes = true ? propTypes : {};
    CSSTransitionGroup3.defaultProps = defaultProps;
    exports.default = CSSTransitionGroup3;
    module.exports = exports["default"];
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_year/index.js
var require_start_of_year = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_year/index.js"(exports, module) {
    var parse9 = require_parse();
    function startOfYear(dirtyDate) {
      var cleanDate = parse9(dirtyDate);
      var date = /* @__PURE__ */ new Date(0);
      date.setFullYear(cleanDate.getFullYear(), 0, 1);
      date.setHours(0, 0, 0, 0);
      return date;
    }
    module.exports = startOfYear;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/difference_in_calendar_days/index.js
var require_difference_in_calendar_days = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/difference_in_calendar_days/index.js"(exports, module) {
    var startOfDay3 = require_start_of_day();
    var MILLISECONDS_IN_MINUTE = 6e4;
    var MILLISECONDS_IN_DAY = 864e5;
    function differenceInCalendarDays(dirtyDateLeft, dirtyDateRight) {
      var startOfDayLeft = startOfDay3(dirtyDateLeft);
      var startOfDayRight = startOfDay3(dirtyDateRight);
      var timestampLeft = startOfDayLeft.getTime() - startOfDayLeft.getTimezoneOffset() * MILLISECONDS_IN_MINUTE;
      var timestampRight = startOfDayRight.getTime() - startOfDayRight.getTimezoneOffset() * MILLISECONDS_IN_MINUTE;
      return Math.round((timestampLeft - timestampRight) / MILLISECONDS_IN_DAY);
    }
    module.exports = differenceInCalendarDays;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/get_day_of_year/index.js
var require_get_day_of_year = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/get_day_of_year/index.js"(exports, module) {
    var parse9 = require_parse();
    var startOfYear = require_start_of_year();
    var differenceInCalendarDays = require_difference_in_calendar_days();
    function getDayOfYear(dirtyDate) {
      var date = parse9(dirtyDate);
      var diff = differenceInCalendarDays(date, startOfYear(date));
      var dayOfYear = diff + 1;
      return dayOfYear;
    }
    module.exports = getDayOfYear;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_week/index.js
var require_start_of_week = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_week/index.js"(exports, module) {
    var parse9 = require_parse();
    function startOfWeek(dirtyDate, dirtyOptions) {
      var weekStartsOn = dirtyOptions ? Number(dirtyOptions.weekStartsOn) || 0 : 0;
      var date = parse9(dirtyDate);
      var day = date.getDay();
      var diff = (day < weekStartsOn ? 7 : 0) + day - weekStartsOn;
      date.setDate(date.getDate() - diff);
      date.setHours(0, 0, 0, 0);
      return date;
    }
    module.exports = startOfWeek;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_iso_week/index.js
var require_start_of_iso_week = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_iso_week/index.js"(exports, module) {
    var startOfWeek = require_start_of_week();
    function startOfISOWeek(dirtyDate) {
      return startOfWeek(dirtyDate, { weekStartsOn: 1 });
    }
    module.exports = startOfISOWeek;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/get_iso_year/index.js
var require_get_iso_year = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/get_iso_year/index.js"(exports, module) {
    var parse9 = require_parse();
    var startOfISOWeek = require_start_of_iso_week();
    function getISOYear(dirtyDate) {
      var date = parse9(dirtyDate);
      var year = date.getFullYear();
      var fourthOfJanuaryOfNextYear = /* @__PURE__ */ new Date(0);
      fourthOfJanuaryOfNextYear.setFullYear(year + 1, 0, 4);
      fourthOfJanuaryOfNextYear.setHours(0, 0, 0, 0);
      var startOfNextYear = startOfISOWeek(fourthOfJanuaryOfNextYear);
      var fourthOfJanuaryOfThisYear = /* @__PURE__ */ new Date(0);
      fourthOfJanuaryOfThisYear.setFullYear(year, 0, 4);
      fourthOfJanuaryOfThisYear.setHours(0, 0, 0, 0);
      var startOfThisYear = startOfISOWeek(fourthOfJanuaryOfThisYear);
      if (date.getTime() >= startOfNextYear.getTime()) {
        return year + 1;
      } else if (date.getTime() >= startOfThisYear.getTime()) {
        return year;
      } else {
        return year - 1;
      }
    }
    module.exports = getISOYear;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_iso_year/index.js
var require_start_of_iso_year = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_iso_year/index.js"(exports, module) {
    var getISOYear = require_get_iso_year();
    var startOfISOWeek = require_start_of_iso_week();
    function startOfISOYear(dirtyDate) {
      var year = getISOYear(dirtyDate);
      var fourthOfJanuary = /* @__PURE__ */ new Date(0);
      fourthOfJanuary.setFullYear(year, 0, 4);
      fourthOfJanuary.setHours(0, 0, 0, 0);
      var date = startOfISOWeek(fourthOfJanuary);
      return date;
    }
    module.exports = startOfISOYear;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/get_iso_week/index.js
var require_get_iso_week = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/get_iso_week/index.js"(exports, module) {
    var parse9 = require_parse();
    var startOfISOWeek = require_start_of_iso_week();
    var startOfISOYear = require_start_of_iso_year();
    var MILLISECONDS_IN_WEEK = 6048e5;
    function getISOWeek(dirtyDate) {
      var date = parse9(dirtyDate);
      var diff = startOfISOWeek(date).getTime() - startOfISOYear(date).getTime();
      return Math.round(diff / MILLISECONDS_IN_WEEK) + 1;
    }
    module.exports = getISOWeek;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_valid/index.js
var require_is_valid = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_valid/index.js"(exports, module) {
    var isDate = require_is_date();
    function isValid(dirtyDate) {
      if (isDate(dirtyDate)) {
        return !isNaN(dirtyDate);
      } else {
        throw new TypeError(toString.call(dirtyDate) + " is not an instance of Date");
      }
    }
    module.exports = isValid;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/build_distance_in_words_locale/index.js
var require_build_distance_in_words_locale = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/build_distance_in_words_locale/index.js"(exports, module) {
    function buildDistanceInWordsLocale() {
      var distanceInWordsLocale = {
        lessThanXSeconds: {
          one: "less than a second",
          other: "less than {{count}} seconds"
        },
        xSeconds: {
          one: "1 second",
          other: "{{count}} seconds"
        },
        halfAMinute: "half a minute",
        lessThanXMinutes: {
          one: "less than a minute",
          other: "less than {{count}} minutes"
        },
        xMinutes: {
          one: "1 minute",
          other: "{{count}} minutes"
        },
        aboutXHours: {
          one: "about 1 hour",
          other: "about {{count}} hours"
        },
        xHours: {
          one: "1 hour",
          other: "{{count}} hours"
        },
        xDays: {
          one: "1 day",
          other: "{{count}} days"
        },
        aboutXMonths: {
          one: "about 1 month",
          other: "about {{count}} months"
        },
        xMonths: {
          one: "1 month",
          other: "{{count}} months"
        },
        aboutXYears: {
          one: "about 1 year",
          other: "about {{count}} years"
        },
        xYears: {
          one: "1 year",
          other: "{{count}} years"
        },
        overXYears: {
          one: "over 1 year",
          other: "over {{count}} years"
        },
        almostXYears: {
          one: "almost 1 year",
          other: "almost {{count}} years"
        }
      };
      function localize(token, count, options) {
        options = options || {};
        var result;
        if (typeof distanceInWordsLocale[token] === "string") {
          result = distanceInWordsLocale[token];
        } else if (count === 1) {
          result = distanceInWordsLocale[token].one;
        } else {
          result = distanceInWordsLocale[token].other.replace("{{count}}", count);
        }
        if (options.addSuffix) {
          if (options.comparison > 0) {
            return "in " + result;
          } else {
            return result + " ago";
          }
        }
        return result;
      }
      return {
        localize
      };
    }
    module.exports = buildDistanceInWordsLocale;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/locale/_lib/build_formatting_tokens_reg_exp/index.js
var require_build_formatting_tokens_reg_exp = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/locale/_lib/build_formatting_tokens_reg_exp/index.js"(exports, module) {
    var commonFormatterKeys = [
      "M",
      "MM",
      "Q",
      "D",
      "DD",
      "DDD",
      "DDDD",
      "d",
      "E",
      "W",
      "WW",
      "YY",
      "YYYY",
      "GG",
      "GGGG",
      "H",
      "HH",
      "h",
      "hh",
      "m",
      "mm",
      "s",
      "ss",
      "S",
      "SS",
      "SSS",
      "Z",
      "ZZ",
      "X",
      "x"
    ];
    function buildFormattingTokensRegExp(formatters) {
      var formatterKeys = [];
      for (var key in formatters) {
        if (formatters.hasOwnProperty(key)) {
          formatterKeys.push(key);
        }
      }
      var formattingTokens = commonFormatterKeys.concat(formatterKeys).sort().reverse();
      var formattingTokensRegExp = new RegExp(
        "(\\[[^\\[]*\\])|(\\\\)?(" + formattingTokens.join("|") + "|.)",
        "g"
      );
      return formattingTokensRegExp;
    }
    module.exports = buildFormattingTokensRegExp;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/build_format_locale/index.js
var require_build_format_locale = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/build_format_locale/index.js"(exports, module) {
    var buildFormattingTokensRegExp = require_build_formatting_tokens_reg_exp();
    function buildFormatLocale() {
      var months3char = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      var monthsFull = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
      var weekdays2char = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];
      var weekdays3char = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      var weekdaysFull = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
      var meridiemUppercase = ["AM", "PM"];
      var meridiemLowercase = ["am", "pm"];
      var meridiemFull = ["a.m.", "p.m."];
      var formatters = {
        // Month: Jan, Feb, ..., Dec
        "MMM": function(date) {
          return months3char[date.getMonth()];
        },
        // Month: January, February, ..., December
        "MMMM": function(date) {
          return monthsFull[date.getMonth()];
        },
        // Day of week: Su, Mo, ..., Sa
        "dd": function(date) {
          return weekdays2char[date.getDay()];
        },
        // Day of week: Sun, Mon, ..., Sat
        "ddd": function(date) {
          return weekdays3char[date.getDay()];
        },
        // Day of week: Sunday, Monday, ..., Saturday
        "dddd": function(date) {
          return weekdaysFull[date.getDay()];
        },
        // AM, PM
        "A": function(date) {
          return date.getHours() / 12 >= 1 ? meridiemUppercase[1] : meridiemUppercase[0];
        },
        // am, pm
        "a": function(date) {
          return date.getHours() / 12 >= 1 ? meridiemLowercase[1] : meridiemLowercase[0];
        },
        // a.m., p.m.
        "aa": function(date) {
          return date.getHours() / 12 >= 1 ? meridiemFull[1] : meridiemFull[0];
        }
      };
      var ordinalFormatters = ["M", "D", "DDD", "d", "Q", "W"];
      ordinalFormatters.forEach(function(formatterToken) {
        formatters[formatterToken + "o"] = function(date, formatters2) {
          return ordinal(formatters2[formatterToken](date));
        };
      });
      return {
        formatters,
        formattingTokensRegExp: buildFormattingTokensRegExp(formatters)
      };
    }
    function ordinal(number2) {
      var rem100 = number2 % 100;
      if (rem100 > 20 || rem100 < 10) {
        switch (rem100 % 10) {
          case 1:
            return number2 + "st";
          case 2:
            return number2 + "nd";
          case 3:
            return number2 + "rd";
        }
      }
      return number2 + "th";
    }
    module.exports = buildFormatLocale;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/index.js
var require_en = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/locale/en/index.js"(exports, module) {
    var buildDistanceInWordsLocale = require_build_distance_in_words_locale();
    var buildFormatLocale = require_build_format_locale();
    module.exports = {
      distanceInWords: buildDistanceInWordsLocale(),
      format: buildFormatLocale()
    };
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/format/index.js
var require_format = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/format/index.js"(exports, module) {
    var getDayOfYear = require_get_day_of_year();
    var getISOWeek = require_get_iso_week();
    var getISOYear = require_get_iso_year();
    var parse9 = require_parse();
    var isValid = require_is_valid();
    var enLocale = require_en();
    function format10(dirtyDate, dirtyFormatStr, dirtyOptions) {
      var formatStr = dirtyFormatStr ? String(dirtyFormatStr) : "YYYY-MM-DDTHH:mm:ss.SSSZ";
      var options = dirtyOptions || {};
      var locale = options.locale;
      var localeFormatters = enLocale.format.formatters;
      var formattingTokensRegExp = enLocale.format.formattingTokensRegExp;
      if (locale && locale.format && locale.format.formatters) {
        localeFormatters = locale.format.formatters;
        if (locale.format.formattingTokensRegExp) {
          formattingTokensRegExp = locale.format.formattingTokensRegExp;
        }
      }
      var date = parse9(dirtyDate);
      if (!isValid(date)) {
        return "Invalid Date";
      }
      var formatFn = buildFormatFn(formatStr, localeFormatters, formattingTokensRegExp);
      return formatFn(date);
    }
    var formatters = {
      // Month: 1, 2, ..., 12
      "M": function(date) {
        return date.getMonth() + 1;
      },
      // Month: 01, 02, ..., 12
      "MM": function(date) {
        return addLeadingZeros(date.getMonth() + 1, 2);
      },
      // Quarter: 1, 2, 3, 4
      "Q": function(date) {
        return Math.ceil((date.getMonth() + 1) / 3);
      },
      // Day of month: 1, 2, ..., 31
      "D": function(date) {
        return date.getDate();
      },
      // Day of month: 01, 02, ..., 31
      "DD": function(date) {
        return addLeadingZeros(date.getDate(), 2);
      },
      // Day of year: 1, 2, ..., 366
      "DDD": function(date) {
        return getDayOfYear(date);
      },
      // Day of year: 001, 002, ..., 366
      "DDDD": function(date) {
        return addLeadingZeros(getDayOfYear(date), 3);
      },
      // Day of week: 0, 1, ..., 6
      "d": function(date) {
        return date.getDay();
      },
      // Day of ISO week: 1, 2, ..., 7
      "E": function(date) {
        return date.getDay() || 7;
      },
      // ISO week: 1, 2, ..., 53
      "W": function(date) {
        return getISOWeek(date);
      },
      // ISO week: 01, 02, ..., 53
      "WW": function(date) {
        return addLeadingZeros(getISOWeek(date), 2);
      },
      // Year: 00, 01, ..., 99
      "YY": function(date) {
        return addLeadingZeros(date.getFullYear(), 4).substr(2);
      },
      // Year: 1900, 1901, ..., 2099
      "YYYY": function(date) {
        return addLeadingZeros(date.getFullYear(), 4);
      },
      // ISO week-numbering year: 00, 01, ..., 99
      "GG": function(date) {
        return String(getISOYear(date)).substr(2);
      },
      // ISO week-numbering year: 1900, 1901, ..., 2099
      "GGGG": function(date) {
        return getISOYear(date);
      },
      // Hour: 0, 1, ... 23
      "H": function(date) {
        return date.getHours();
      },
      // Hour: 00, 01, ..., 23
      "HH": function(date) {
        return addLeadingZeros(date.getHours(), 2);
      },
      // Hour: 1, 2, ..., 12
      "h": function(date) {
        var hours = date.getHours();
        if (hours === 0) {
          return 12;
        } else if (hours > 12) {
          return hours % 12;
        } else {
          return hours;
        }
      },
      // Hour: 01, 02, ..., 12
      "hh": function(date) {
        return addLeadingZeros(formatters["h"](date), 2);
      },
      // Minute: 0, 1, ..., 59
      "m": function(date) {
        return date.getMinutes();
      },
      // Minute: 00, 01, ..., 59
      "mm": function(date) {
        return addLeadingZeros(date.getMinutes(), 2);
      },
      // Second: 0, 1, ..., 59
      "s": function(date) {
        return date.getSeconds();
      },
      // Second: 00, 01, ..., 59
      "ss": function(date) {
        return addLeadingZeros(date.getSeconds(), 2);
      },
      // 1/10 of second: 0, 1, ..., 9
      "S": function(date) {
        return Math.floor(date.getMilliseconds() / 100);
      },
      // 1/100 of second: 00, 01, ..., 99
      "SS": function(date) {
        return addLeadingZeros(Math.floor(date.getMilliseconds() / 10), 2);
      },
      // Millisecond: 000, 001, ..., 999
      "SSS": function(date) {
        return addLeadingZeros(date.getMilliseconds(), 3);
      },
      // Timezone: -01:00, +00:00, ... +12:00
      "Z": function(date) {
        return formatTimezone(date.getTimezoneOffset(), ":");
      },
      // Timezone: -0100, +0000, ... +1200
      "ZZ": function(date) {
        return formatTimezone(date.getTimezoneOffset());
      },
      // Seconds timestamp: 512969520
      "X": function(date) {
        return Math.floor(date.getTime() / 1e3);
      },
      // Milliseconds timestamp: 512969520900
      "x": function(date) {
        return date.getTime();
      }
    };
    function buildFormatFn(formatStr, localeFormatters, formattingTokensRegExp) {
      var array2 = formatStr.match(formattingTokensRegExp);
      var length = array2.length;
      var i;
      var formatter;
      for (i = 0; i < length; i++) {
        formatter = localeFormatters[array2[i]] || formatters[array2[i]];
        if (formatter) {
          array2[i] = formatter;
        } else {
          array2[i] = removeFormattingTokens(array2[i]);
        }
      }
      return function(date) {
        var output = "";
        for (var i2 = 0; i2 < length; i2++) {
          if (array2[i2] instanceof Function) {
            output += array2[i2](date, formatters);
          } else {
            output += array2[i2];
          }
        }
        return output;
      };
    }
    function removeFormattingTokens(input) {
      if (input.match(/\[[\s\S]/)) {
        return input.replace(/^\[|]$/g, "");
      }
      return input.replace(/\\/g, "");
    }
    function formatTimezone(offset, delimeter) {
      delimeter = delimeter || "";
      var sign = offset > 0 ? "-" : "+";
      var absOffset = Math.abs(offset);
      var hours = Math.floor(absOffset / 60);
      var minutes = absOffset % 60;
      return sign + addLeadingZeros(hours, 2) + delimeter + addLeadingZeros(minutes, 2);
    }
    function addLeadingZeros(number2, targetLength) {
      var output = Math.abs(number2).toString();
      while (output.length < targetLength) {
        output = "0" + output;
      }
      return output;
    }
    module.exports = format10;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/start_of_month/index.js
var require_start_of_month = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/start_of_month/index.js"(exports, module) {
    var parse9 = require_parse();
    function startOfMonth2(dirtyDate) {
      var date = parse9(dirtyDate);
      date.setDate(1);
      date.setHours(0, 0, 0, 0);
      return date;
    }
    module.exports = startOfMonth2;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_same_year/index.js
var require_is_same_year = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_same_year/index.js"(exports, module) {
    var parse9 = require_parse();
    function isSameYear2(dirtyDateLeft, dirtyDateRight) {
      var dateLeft = parse9(dirtyDateLeft);
      var dateRight = parse9(dirtyDateRight);
      return dateLeft.getFullYear() === dateRight.getFullYear();
    }
    module.exports = isSameYear2;
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/is_same_month/index.js
var require_is_same_month = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/is_same_month/index.js"(exports, module) {
    var parse9 = require_parse();
    function isSameMonth2(dirtyDateLeft, dirtyDateRight) {
      var dateLeft = parse9(dirtyDateLeft);
      var dateRight = parse9(dirtyDateRight);
      return dateLeft.getFullYear() === dateRight.getFullYear() && dateLeft.getMonth() === dateRight.getMonth();
    }
    module.exports = isSameMonth2;
  }
});

// node_modules/recompose/withState.js
var require_withState = __commonJS({
  "node_modules/recompose/withState.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = require_react();
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    var _createEagerFactory = require_createEagerFactory();
    var _createEagerFactory2 = _interopRequireDefault(_createEagerFactory);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var withState = function withState2(stateName, stateUpdaterName, initialState) {
      return function(BaseComponent) {
        var factory = (0, _createEagerFactory2.default)(BaseComponent);
        return function(_Component) {
          _inherits11(_class22, _Component);
          function _class22() {
            var _temp3, _this, _ret;
            _classCallCheck12(this, _class22);
            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
            }
            return _ret = (_temp3 = (_this = _possibleConstructorReturn11(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.state = {
              stateValue: typeof initialState === "function" ? initialState(_this.props) : initialState
            }, _this.updateStateValue = function(updateFn, callback) {
              return _this.setState(function(_ref) {
                var stateValue = _ref.stateValue;
                return {
                  stateValue: typeof updateFn === "function" ? updateFn(stateValue) : updateFn
                };
              }, callback);
            }, _temp3), _possibleConstructorReturn11(_this, _ret);
          }
          _class22.prototype.render = function render() {
            var _extends22;
            return factory(_extends10({}, this.props, (_extends22 = {}, _extends22[stateName] = this.state.stateValue, _extends22[stateUpdaterName] = this.updateStateValue, _extends22)));
          };
          return _class22;
        }(_react.Component);
      };
    };
    exports.default = (0, _createHelper2.default)(withState, "withState");
  }
});

// node_modules/recompose/mapProps.js
var require_mapProps = __commonJS({
  "node_modules/recompose/mapProps.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    var _createEagerFactory = require_createEagerFactory();
    var _createEagerFactory2 = _interopRequireDefault(_createEagerFactory);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var mapProps = function mapProps2(propsMapper) {
      return function(BaseComponent) {
        var factory = (0, _createEagerFactory2.default)(BaseComponent);
        return function(props) {
          return factory(propsMapper(props));
        };
      };
    };
    exports.default = (0, _createHelper2.default)(mapProps, "mapProps");
  }
});

// node_modules/recompose/withProps.js
var require_withProps = __commonJS({
  "node_modules/recompose/withProps.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    var _mapProps = require_mapProps();
    var _mapProps2 = _interopRequireDefault(_mapProps);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    var withProps = function withProps2(input) {
      return (0, _mapProps2.default)(function(props) {
        return _extends10({}, props, typeof input === "function" ? input(props) : input);
      });
    };
    exports.default = (0, _createHelper2.default)(withProps, "withProps");
  }
});

// node_modules/recompose/compose.js
var require_compose = __commonJS({
  "node_modules/recompose/compose.js"(exports) {
    "use strict";
    exports.__esModule = true;
    exports.default = compose;
    function compose() {
      for (var _len = arguments.length, funcs = Array(_len), _key = 0; _key < _len; _key++) {
        funcs[_key] = arguments[_key];
      }
      if (funcs.length === 0) {
        return function(arg) {
          return arg;
        };
      }
      if (funcs.length === 1) {
        return funcs[0];
      }
      return funcs.reduce(function(a, b) {
        return function() {
          return a(b.apply(void 0, arguments));
        };
      });
    }
  }
});

// node_modules/recompose/withHandlers.js
var require_withHandlers = __commonJS({
  "node_modules/recompose/withHandlers.js"(exports) {
    "use strict";
    exports.__esModule = true;
    var _extends10 = Object.assign || function(target) {
      for (var i = 1; i < arguments.length; i++) {
        var source = arguments[i];
        for (var key in source) {
          if (Object.prototype.hasOwnProperty.call(source, key)) {
            target[key] = source[key];
          }
        }
      }
      return target;
    };
    var _react = require_react();
    var _createEagerFactory = require_createEagerFactory();
    var _createEagerFactory2 = _interopRequireDefault(_createEagerFactory);
    var _createHelper = require_createHelper();
    var _createHelper2 = _interopRequireDefault(_createHelper);
    function _interopRequireDefault(obj) {
      return obj && obj.__esModule ? obj : { default: obj };
    }
    function _classCallCheck12(instance, Constructor) {
      if (!(instance instanceof Constructor)) {
        throw new TypeError("Cannot call a class as a function");
      }
    }
    function _possibleConstructorReturn11(self, call) {
      if (!self) {
        throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
      }
      return call && (typeof call === "object" || typeof call === "function") ? call : self;
    }
    function _inherits11(subClass, superClass) {
      if (typeof superClass !== "function" && superClass !== null) {
        throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
      }
      subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
      if (superClass)
        Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
    }
    var mapValues = function mapValues2(obj, func2) {
      var result = {};
      for (var key in obj) {
        if (obj.hasOwnProperty(key)) {
          result[key] = func2(obj[key], key);
        }
      }
      return result;
    };
    var withHandlers = function withHandlers2(handlers) {
      return function(BaseComponent) {
        var _class4, _temp23, _initialiseProps;
        var factory = (0, _createEagerFactory2.default)(BaseComponent);
        return _temp23 = _class4 = function(_Component) {
          _inherits11(_class5, _Component);
          function _class5() {
            var _temp3, _this, _ret;
            _classCallCheck12(this, _class5);
            for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
            }
            return _ret = (_temp3 = (_this = _possibleConstructorReturn11(this, _Component.call.apply(_Component, [this].concat(args))), _this), _initialiseProps.call(_this), _temp3), _possibleConstructorReturn11(_this, _ret);
          }
          _class5.prototype.componentWillReceiveProps = function componentWillReceiveProps() {
            this.cachedHandlers = {};
          };
          _class5.prototype.render = function render() {
            return factory(_extends10({}, this.props, this.handlers));
          };
          return _class5;
        }(_react.Component), _initialiseProps = function _initialiseProps2() {
          var _this2 = this;
          this.cachedHandlers = {};
          this.handlers = mapValues(typeof handlers === "function" ? handlers(this.props) : handlers, function(createHandler, handlerName) {
            return function() {
              var cachedHandler = _this2.cachedHandlers[handlerName];
              if (cachedHandler) {
                return cachedHandler.apply(void 0, arguments);
              }
              var handler = createHandler(_this2.props);
              _this2.cachedHandlers[handlerName] = handler;
              if (typeof handler !== "function") {
                console.error(
                  // eslint-disable-line no-console
                  "withHandlers(): Expected a map of higher-order functions. Refer to the docs for more info."
                );
              }
              return handler.apply(void 0, arguments);
            };
          });
        }, _temp23;
      };
    };
    exports.default = (0, _createHelper2.default)(withHandlers, "withHandlers");
  }
});

// node_modules/react-infinite-calendar/node_modules/date-fns/add_days/index.js
var require_add_days = __commonJS({
  "node_modules/react-infinite-calendar/node_modules/date-fns/add_days/index.js"(exports, module) {
    var parse9 = require_parse();
    function addDays2(dirtyDate, dirtyAmount) {
      var date = parse9(dirtyDate);
      var amount = Number(dirtyAmount);
      date.setDate(date.getDate() + amount);
      return date;
    }
    module.exports = addDays2;
  }
});

// node_modules/react-infinite-calendar/es/index.js
var import_react14 = __toESM(require_react());

// node_modules/react-infinite-calendar/es/Calendar/index.js
var import_defaultProps = __toESM(require_defaultProps());
var import_react10 = __toESM(require_react());
var import_prop_types7 = __toESM(require_prop_types());
var import_classnames8 = __toESM(require_classnames());

// node_modules/react-infinite-calendar/es/utils/index.js
var import_withPropsOnChange = __toESM(require_withPropsOnChange());
var import_scrollbarSize = __toESM(require_scrollbarSize());
var import_get_days_in_month = __toESM(require_get_days_in_month());
var import_get_day = __toESM(require_get_day());
var import_is_after = __toESM(require_is_after());
var import_is_before = __toESM(require_is_before());
var import_is_same_day = __toESM(require_is_same_day());
var import_end_of_day = __toESM(require_end_of_day());
var import_start_of_day = __toESM(require_start_of_day());

// node_modules/react-infinite-calendar/es/utils/animate.js
function easing(time) {
  return 1 - --time * time * time * time;
}
function getValue(start, end, elapsed, duration) {
  if (elapsed > duration)
    return end;
  return start + (end - start) * easing(elapsed / duration);
}
function animate(_ref) {
  var fromValue = _ref.fromValue, toValue = _ref.toValue, onUpdate = _ref.onUpdate, onComplete = _ref.onComplete, _ref$duration = _ref.duration, duration = _ref$duration === void 0 ? 600 : _ref$duration;
  var startTime = performance.now();
  var tick = function tick2() {
    var elapsed = performance.now() - startTime;
    window.requestAnimationFrame(function() {
      return onUpdate(
        getValue(fromValue, toValue, elapsed, duration),
        // Callback
        elapsed <= duration ? tick2 : onComplete
      );
    });
  };
  tick();
}

// node_modules/react-infinite-calendar/es/utils/index.js
function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
var keyCodes = {
  command: 91,
  control: 17,
  down: 40,
  enter: 13,
  escape: 27,
  left: 37,
  right: 39,
  shift: 16,
  up: 38
};
function getMonth(year, month, weekStartsOn) {
  var rows = [];
  var monthDate = new Date(year, month, 1);
  var daysInMonth = (0, import_get_days_in_month.default)(monthDate);
  var weekEndsOn = getEndOfWeekIndex(weekStartsOn);
  var dow = (0, import_get_day.default)(new Date(year, month, 1));
  var week = 0;
  for (var day = 1; day <= daysInMonth; day++) {
    if (!rows[week]) {
      rows[week] = [];
    }
    rows[week].push(day);
    if (dow === weekEndsOn) {
      week++;
    }
    dow = dow < 6 ? dow + 1 : 0;
  }
  return {
    date: monthDate,
    rows
  };
}
function getWeek(yearStart, date, weekStartsOn) {
  var yearStartDate = typeof yearStart === "number" ? new Date(yearStart, 0, 1) : yearStart;
  return Math.ceil((Math.round((date - yearStartDate) / (60 * 60 * 24 * 1e3)) + yearStartDate.getDay() + 1 - weekStartsOn) / 7);
}
function getWeeksInMonth(month) {
  var year = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : (/* @__PURE__ */ new Date()).getFullYear();
  var weekStartsOn = arguments[2];
  var isLastDisplayedMonth = arguments[3];
  var weekEndsOn = getEndOfWeekIndex(weekStartsOn);
  var firstOfMonth = new Date(year, month, 1);
  var firstWeekNumber = getWeek(year, firstOfMonth, weekStartsOn);
  var lastOfMonth = new Date(year, month + 1, 0);
  var lastWeekNumber = getWeek(year, lastOfMonth, weekStartsOn);
  var rowCount = lastWeekNumber - firstWeekNumber;
  if (lastOfMonth.getDay() === weekEndsOn || isLastDisplayedMonth) {
    rowCount++;
  }
  return rowCount;
}
function getEndOfWeekIndex(weekStartsOn) {
  var weekEndsOn = weekStartsOn === 0 ? 6 : weekStartsOn - 1;
  return weekEndsOn;
}
var ScrollSpeed = function() {
  function ScrollSpeed2() {
    var _this = this;
    _classCallCheck(this, ScrollSpeed2);
    this.clear = function() {
      _this.lastPosition = null;
      _this.delta = 0;
    };
  }
  ScrollSpeed2.prototype.getScrollSpeed = function getScrollSpeed(scrollOffset) {
    if (this.lastPosition != null) {
      this.delta = scrollOffset - this.lastPosition;
    }
    this.lastPosition = scrollOffset;
    clearTimeout(this._timeout);
    this._timeout = setTimeout(this.clear, 50);
    return this.delta;
  };
  return ScrollSpeed2;
}();
var scrollbarSize = (0, import_scrollbarSize.default)();
function emptyFn() {
}
function sanitizeDate(date, _ref) {
  var _ref$disabledDates = _ref.disabledDates, disabledDates = _ref$disabledDates === void 0 ? [] : _ref$disabledDates, _ref$disabledDays = _ref.disabledDays, disabledDays = _ref$disabledDays === void 0 ? [] : _ref$disabledDays, minDate = _ref.minDate, maxDate = _ref.maxDate;
  if (!date || disabledDates.some(function(disabledDate) {
    return (0, import_is_same_day.default)(disabledDate, date);
  }) || disabledDays && disabledDays.indexOf((0, import_get_day.default)(date)) !== -1 || minDate && (0, import_is_before.default)(date, (0, import_start_of_day.default)(minDate)) || maxDate && (0, import_is_after.default)(date, (0, import_end_of_day.default)(maxDate))) {
    return null;
  }
  return date;
}
function getDateString(year, month, date) {
  return year + "-" + ("0" + (month + 1)).slice(-2) + "-" + ("0" + date).slice(-2);
}
function getMonthsForYear(year) {
  var day = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 1;
  return Array.apply(null, Array(12)).map(function(val, index) {
    return new Date(year, index, day);
  });
}
var withImmutableProps = function withImmutableProps2(props) {
  return (0, import_withPropsOnChange.default)(function() {
    return false;
  }, props);
};
function debounce(callback, wait) {
  var _this2 = this;
  var timeout = null;
  var callbackArgs = null;
  var later = function later2() {
    return callback.apply(_this2, callbackArgs);
  };
  return function() {
    callbackArgs = arguments;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}
function range(start, stop) {
  var step = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1;
  var length = Math.max(Math.ceil((stop - start) / step), 0);
  var range2 = Array(length);
  for (var i = 0; i < length; i++, start += step) {
    range2[i] = start;
  }
  return range2;
}

// node_modules/react-infinite-calendar/es/Calendar/index.js
var import_defaultDisplayOptions = __toESM(require_defaultDisplayOptions());
var import_defaultLocale = __toESM(require_defaultLocale());
var import_defaultTheme = __toESM(require_defaultTheme());

// node_modules/react-infinite-calendar/es/Today/index.js
var import_react = __toESM(require_react());
var import_prop_types = __toESM(require_prop_types());
var import_classnames = __toESM(require_classnames());
function _classCallCheck2(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles = {
  "root": "Cal__Today__root",
  "show": "Cal__Today__show",
  "chevron": "Cal__Today__chevron",
  "chevronUp": "Cal__Today__chevronUp",
  "chevronDown": "Cal__Today__chevronDown"
};
var DIRECTION_UP = 1;
var DIRECTION_DOWN = -1;
var CHEVRON = "M256,298.3L256,298.3L256,298.3l174.2-167.2c4.3-4.2,11.4-4.1,15.8,0.2l30.6,29.9c4.4,4.3,4.5,11.3,0.2,15.5L264.1,380.9 c-2.2,2.2-5.2,3.2-8.1,3c-3,0.1-5.9-0.9-8.1-3L35.2,176.7c-4.3-4.2-4.2-11.2,0.2-15.5L66,131.3c4.4-4.3,11.5-4.4,15.8-0.2L256,298.3 z";
var Today = function(_PureComponent) {
  _inherits(Today2, _PureComponent);
  function Today2() {
    var _temp3, _this, _ret;
    _classCallCheck2(this, Today2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp3 = (_this = _possibleConstructorReturn(this, _PureComponent.call.apply(_PureComponent, [this].concat(args))), _this), _this.scrollToToday = function() {
      var scrollToDate = _this.props.scrollToDate;
      scrollToDate(/* @__PURE__ */ new Date(), -40, true);
    }, _temp3), _possibleConstructorReturn(_this, _ret);
  }
  Today2.prototype.render = function render() {
    var _classNames;
    var _props = this.props, todayLabel = _props.todayLabel, show = _props.show, theme = _props.theme;
    return import_react.default.createElement(
      "div",
      {
        className: (0, import_classnames.default)(styles.root, (_classNames = {}, _classNames[styles.show] = show, _classNames[styles.chevronUp] = show === DIRECTION_UP, _classNames[styles.chevronDown] = show === DIRECTION_DOWN, _classNames)),
        style: {
          backgroundColor: theme.floatingNav.background,
          color: theme.floatingNav.color
        },
        onClick: this.scrollToToday,
        ref: "node"
      },
      todayLabel,
      import_react.default.createElement(
        "svg",
        {
          className: styles.chevron,
          x: "0px",
          y: "0px",
          width: "14px",
          height: "14px",
          viewBox: "0 0 512 512"
        },
        import_react.default.createElement("path", {
          fill: theme.floatingNav.chevron || theme.floatingNav.color,
          d: CHEVRON
        })
      )
    );
  };
  return Today2;
}(import_react.PureComponent);
true ? Today.propTypes = {
  scrollToDate: import_prop_types.default.func,
  show: import_prop_types.default.oneOfType([import_prop_types.default.number, import_prop_types.default.bool]),
  theme: import_prop_types.default.object,
  todayLabel: import_prop_types.default.string
} : void 0;

// node_modules/react-infinite-calendar/es/Header/index.js
var import_react3 = __toESM(require_react());
var import_prop_types2 = __toESM(require_prop_types());

// node_modules/react-infinite-calendar/es/Header/defaultSelectionRenderer.js
var import_react2 = __toESM(require_react());
var import_CSSTransitionGroup = __toESM(require_CSSTransitionGroup());
var import_classnames2 = __toESM(require_classnames());
var import_parse = __toESM(require_parse());
var import_format = __toESM(require_format());
var styles2 = {
  "root": "Cal__Header__root",
  "landscape": "Cal__Header__landscape",
  "dateWrapper": "Cal__Header__dateWrapper",
  "day": "Cal__Header__day",
  "wrapper": "Cal__Header__wrapper",
  "blank": "Cal__Header__blank",
  "active": "Cal__Header__active",
  "year": "Cal__Header__year",
  "date": "Cal__Header__date",
  "range": "Cal__Header__range"
};
var animation = {
  "enter": "Cal__Animation__enter",
  "enterActive": "Cal__Animation__enterActive",
  "leave": "Cal__Animation__leave",
  "leaveActive": "Cal__Animation__leaveActive"
};
function defaultSelectionRenderer(value, _ref) {
  var display = _ref.display, key = _ref.key, locale = _ref.locale.locale, dateFormat = _ref.dateFormat, onYearClick = _ref.onYearClick, scrollToDate = _ref.scrollToDate, setDisplay = _ref.setDisplay, shouldAnimate = _ref.shouldAnimate;
  var date = (0, import_parse.default)(value);
  var values = date && [{
    active: display === "years",
    handleClick: function handleClick(e) {
      onYearClick(date, e, key);
      setDisplay("years");
    },
    item: "year",
    title: display === "days" ? "Change year" : null,
    value: date.getFullYear()
  }, {
    active: display === "days",
    handleClick: function handleClick(e) {
      if (display !== "days") {
        setDisplay("days");
      } else if (date) {
        scrollToDate(date, -40, true);
      }
    },
    item: "day",
    title: display === "days" ? "Scroll to " + (0, import_format.default)(date, dateFormat, { locale }) : null,
    value: (0, import_format.default)(date, dateFormat, { locale })
  }];
  return import_react2.default.createElement(
    "div",
    {
      key,
      className: styles2.wrapper,
      "aria-label": (0, import_format.default)(date, dateFormat + " YYYY", { locale })
    },
    values.map(function(_ref2) {
      var _classNames;
      var handleClick = _ref2.handleClick, item = _ref2.item, key2 = _ref2.key, value2 = _ref2.value, active = _ref2.active, title = _ref2.title;
      return import_react2.default.createElement(
        "div",
        {
          key: item,
          className: (0, import_classnames2.default)(styles2.dateWrapper, styles2[item], (_classNames = {}, _classNames[styles2.active] = active, _classNames)),
          title
        },
        import_react2.default.createElement(
          import_CSSTransitionGroup.default,
          {
            transitionName: animation,
            transitionEnterTimeout: 250,
            transitionLeaveTimeout: 250,
            transitionEnter: shouldAnimate,
            transitionLeave: shouldAnimate
          },
          import_react2.default.createElement(
            "span",
            {
              key: item + "-" + value2,
              className: styles2.date,
              "aria-hidden": true,
              onClick: handleClick
            },
            value2
          )
        )
      );
    })
  );
}

// node_modules/react-infinite-calendar/es/Header/index.js
var import_classnames3 = __toESM(require_classnames());
var _class;
var _temp;
function _classCallCheck3(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn2(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits2(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles3 = {
  "root": "Cal__Header__root",
  "landscape": "Cal__Header__landscape",
  "dateWrapper": "Cal__Header__dateWrapper",
  "day": "Cal__Header__day",
  "wrapper": "Cal__Header__wrapper",
  "blank": "Cal__Header__blank",
  "active": "Cal__Header__active",
  "year": "Cal__Header__year",
  "date": "Cal__Header__date",
  "range": "Cal__Header__range"
};
var Header = (_temp = _class = function(_PureComponent) {
  _inherits2(Header2, _PureComponent);
  function Header2() {
    _classCallCheck3(this, Header2);
    return _possibleConstructorReturn2(this, _PureComponent.apply(this, arguments));
  }
  Header2.prototype.render = function render() {
    var _classNames;
    var _props = this.props, layout = _props.layout, blank = _props.locale.blank, selected = _props.selected, renderSelection = _props.renderSelection, theme = _props.theme;
    return import_react3.default.createElement(
      "div",
      {
        className: (0, import_classnames3.default)(styles3.root, (_classNames = {}, _classNames[styles3.landscape] = layout === "landscape", _classNames)),
        style: {
          backgroundColor: theme.headerColor,
          color: theme.textColor.active
        }
      },
      selected && renderSelection(selected, this.props) || import_react3.default.createElement(
        "div",
        { className: (0, import_classnames3.default)(styles3.wrapper, styles3.blank) },
        blank
      )
    );
  };
  return Header2;
}(import_react3.PureComponent), _class.defaultProps = {
  onYearClick: emptyFn,
  renderSelection: defaultSelectionRenderer
}, _temp);
true ? Header.propTypes = {
  dateFormat: import_prop_types2.default.string,
  display: import_prop_types2.default.string,
  layout: import_prop_types2.default.string,
  locale: import_prop_types2.default.object,
  onYearClick: import_prop_types2.default.func,
  selected: import_prop_types2.default.any,
  shouldAnimate: import_prop_types2.default.bool,
  theme: import_prop_types2.default.object
} : void 0;

// node_modules/react-infinite-calendar/es/MonthList/index.js
var import_react6 = __toESM(require_react());
var import_prop_types4 = __toESM(require_prop_types());

// node_modules/react-tiny-virtual-list/build/react-tiny-virtual-list.es.js
var import_react4 = __toESM(require_react());
var import_prop_types3 = __toESM(require_prop_types());
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2)
      if (b2.hasOwnProperty(p))
        d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s)
    if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function") {
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++)
      if (e.indexOf(p[i]) < 0)
        t[p[i]] = s[p[i]];
  }
  return t;
}
var ALIGNMENT;
(function(ALIGNMENT2) {
  ALIGNMENT2["AUTO"] = "auto";
  ALIGNMENT2["START"] = "start";
  ALIGNMENT2["CENTER"] = "center";
  ALIGNMENT2["END"] = "end";
})(ALIGNMENT || (ALIGNMENT = {}));
var DIRECTION;
(function(DIRECTION2) {
  DIRECTION2["HORIZONTAL"] = "horizontal";
  DIRECTION2["VERTICAL"] = "vertical";
})(DIRECTION || (DIRECTION = {}));
var SCROLL_CHANGE_REASON;
(function(SCROLL_CHANGE_REASON2) {
  SCROLL_CHANGE_REASON2["OBSERVED"] = "observed";
  SCROLL_CHANGE_REASON2["REQUESTED"] = "requested";
})(SCROLL_CHANGE_REASON || (SCROLL_CHANGE_REASON = {}));
var scrollProp = (_a = {}, _a[DIRECTION.VERTICAL] = "scrollTop", _a[DIRECTION.HORIZONTAL] = "scrollLeft", _a);
var sizeProp = (_b = {}, _b[DIRECTION.VERTICAL] = "height", _b[DIRECTION.HORIZONTAL] = "width", _b);
var positionProp = (_c = {}, _c[DIRECTION.VERTICAL] = "top", _c[DIRECTION.HORIZONTAL] = "left", _c);
var marginProp = (_d = {}, _d[DIRECTION.VERTICAL] = "marginTop", _d[DIRECTION.HORIZONTAL] = "marginLeft", _d);
var oppositeMarginProp = (_e = {}, _e[DIRECTION.VERTICAL] = "marginBottom", _e[DIRECTION.HORIZONTAL] = "marginRight", _e);
var _a;
var _b;
var _c;
var _d;
var _e;
var SizeAndPositionManager = (
  /** @class */
  function() {
    function SizeAndPositionManager2(_a2) {
      var itemCount = _a2.itemCount, itemSizeGetter = _a2.itemSizeGetter, estimatedItemSize = _a2.estimatedItemSize;
      this.itemSizeGetter = itemSizeGetter;
      this.itemCount = itemCount;
      this.estimatedItemSize = estimatedItemSize;
      this.itemSizeAndPositionData = {};
      this.lastMeasuredIndex = -1;
    }
    SizeAndPositionManager2.prototype.updateConfig = function(_a2) {
      var itemCount = _a2.itemCount, itemSizeGetter = _a2.itemSizeGetter, estimatedItemSize = _a2.estimatedItemSize;
      if (itemCount != null) {
        this.itemCount = itemCount;
      }
      if (estimatedItemSize != null) {
        this.estimatedItemSize = estimatedItemSize;
      }
      if (itemSizeGetter != null) {
        this.itemSizeGetter = itemSizeGetter;
      }
    };
    SizeAndPositionManager2.prototype.getLastMeasuredIndex = function() {
      return this.lastMeasuredIndex;
    };
    SizeAndPositionManager2.prototype.getSizeAndPositionForIndex = function(index) {
      if (index < 0 || index >= this.itemCount) {
        throw Error("Requested index " + index + " is outside of range 0.." + this.itemCount);
      }
      if (index > this.lastMeasuredIndex) {
        var lastMeasuredSizeAndPosition = this.getSizeAndPositionOfLastMeasuredItem();
        var offset = lastMeasuredSizeAndPosition.offset + lastMeasuredSizeAndPosition.size;
        for (var i = this.lastMeasuredIndex + 1; i <= index; i++) {
          var size = this.itemSizeGetter(i);
          if (size == null || isNaN(size)) {
            throw Error("Invalid size returned for index " + i + " of value " + size);
          }
          this.itemSizeAndPositionData[i] = {
            offset,
            size
          };
          offset += size;
        }
        this.lastMeasuredIndex = index;
      }
      return this.itemSizeAndPositionData[index];
    };
    SizeAndPositionManager2.prototype.getSizeAndPositionOfLastMeasuredItem = function() {
      return this.lastMeasuredIndex >= 0 ? this.itemSizeAndPositionData[this.lastMeasuredIndex] : { offset: 0, size: 0 };
    };
    SizeAndPositionManager2.prototype.getTotalSize = function() {
      var lastMeasuredSizeAndPosition = this.getSizeAndPositionOfLastMeasuredItem();
      return lastMeasuredSizeAndPosition.offset + lastMeasuredSizeAndPosition.size + (this.itemCount - this.lastMeasuredIndex - 1) * this.estimatedItemSize;
    };
    SizeAndPositionManager2.prototype.getUpdatedOffsetForIndex = function(_a2) {
      var _b2 = _a2.align, align = _b2 === void 0 ? ALIGNMENT.START : _b2, containerSize = _a2.containerSize, currentOffset = _a2.currentOffset, targetIndex = _a2.targetIndex;
      if (containerSize <= 0) {
        return 0;
      }
      var datum = this.getSizeAndPositionForIndex(targetIndex);
      var maxOffset = datum.offset;
      var minOffset = maxOffset - containerSize + datum.size;
      var idealOffset;
      switch (align) {
        case ALIGNMENT.END:
          idealOffset = minOffset;
          break;
        case ALIGNMENT.CENTER:
          idealOffset = maxOffset - (containerSize - datum.size) / 2;
          break;
        case ALIGNMENT.START:
          idealOffset = maxOffset;
          break;
        default:
          idealOffset = Math.max(minOffset, Math.min(maxOffset, currentOffset));
      }
      var totalSize = this.getTotalSize();
      return Math.max(0, Math.min(totalSize - containerSize, idealOffset));
    };
    SizeAndPositionManager2.prototype.getVisibleRange = function(_a2) {
      var containerSize = _a2.containerSize, offset = _a2.offset, overscanCount = _a2.overscanCount;
      var totalSize = this.getTotalSize();
      if (totalSize === 0) {
        return {};
      }
      var maxOffset = offset + containerSize;
      var start = this.findNearestItem(offset);
      if (typeof start === "undefined") {
        throw Error("Invalid offset " + offset + " specified");
      }
      var datum = this.getSizeAndPositionForIndex(start);
      offset = datum.offset + datum.size;
      var stop = start;
      while (offset < maxOffset && stop < this.itemCount - 1) {
        stop++;
        offset += this.getSizeAndPositionForIndex(stop).size;
      }
      if (overscanCount) {
        start = Math.max(0, start - overscanCount);
        stop = Math.min(stop + overscanCount, this.itemCount - 1);
      }
      return {
        start,
        stop
      };
    };
    SizeAndPositionManager2.prototype.resetItem = function(index) {
      this.lastMeasuredIndex = Math.min(this.lastMeasuredIndex, index - 1);
    };
    SizeAndPositionManager2.prototype.findNearestItem = function(offset) {
      if (isNaN(offset)) {
        throw Error("Invalid offset " + offset + " specified");
      }
      offset = Math.max(0, offset);
      var lastMeasuredSizeAndPosition = this.getSizeAndPositionOfLastMeasuredItem();
      var lastMeasuredIndex = Math.max(0, this.lastMeasuredIndex);
      if (lastMeasuredSizeAndPosition.offset >= offset) {
        return this.binarySearch({
          high: lastMeasuredIndex,
          low: 0,
          offset
        });
      } else {
        return this.exponentialSearch({
          index: lastMeasuredIndex,
          offset
        });
      }
    };
    SizeAndPositionManager2.prototype.binarySearch = function(_a2) {
      var low = _a2.low, high = _a2.high, offset = _a2.offset;
      var middle = 0;
      var currentOffset = 0;
      while (low <= high) {
        middle = low + Math.floor((high - low) / 2);
        currentOffset = this.getSizeAndPositionForIndex(middle).offset;
        if (currentOffset === offset) {
          return middle;
        } else if (currentOffset < offset) {
          low = middle + 1;
        } else if (currentOffset > offset) {
          high = middle - 1;
        }
      }
      if (low > 0) {
        return low - 1;
      }
      return 0;
    };
    SizeAndPositionManager2.prototype.exponentialSearch = function(_a2) {
      var index = _a2.index, offset = _a2.offset;
      var interval = 1;
      while (index < this.itemCount && this.getSizeAndPositionForIndex(index).offset < offset) {
        index += interval;
        interval *= 2;
      }
      return this.binarySearch({
        high: Math.min(index, this.itemCount - 1),
        low: Math.floor(index / 2),
        offset
      });
    };
    return SizeAndPositionManager2;
  }()
);
var STYLE_WRAPPER = {
  overflow: "auto",
  willChange: "transform",
  WebkitOverflowScrolling: "touch"
};
var STYLE_INNER = {
  position: "relative",
  width: "100%",
  minHeight: "100%"
};
var STYLE_ITEM = {
  position: "absolute",
  top: 0,
  left: 0,
  width: "100%"
};
var STYLE_STICKY_ITEM = __assign({}, STYLE_ITEM, { position: "sticky" });
var VirtualList = (
  /** @class */
  function(_super) {
    __extends(VirtualList2, _super);
    function VirtualList2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.itemSizeGetter = function(itemSize) {
        return function(index) {
          return _this.getSize(index, itemSize);
        };
      };
      _this.sizeAndPositionManager = new SizeAndPositionManager({
        itemCount: _this.props.itemCount,
        itemSizeGetter: _this.itemSizeGetter(_this.props.itemSize),
        estimatedItemSize: _this.getEstimatedItemSize()
      });
      _this.state = {
        offset: _this.props.scrollOffset || _this.props.scrollToIndex != null && _this.getOffsetForIndex(_this.props.scrollToIndex) || 0,
        scrollChangeReason: SCROLL_CHANGE_REASON.REQUESTED
      };
      _this.styleCache = {};
      _this.getRef = function(node) {
        _this.rootNode = node;
      };
      _this.handleScroll = function(event) {
        var onScroll = _this.props.onScroll;
        var offset = _this.getNodeOffset();
        if (offset < 0 || _this.state.offset === offset || event.target !== _this.rootNode) {
          return;
        }
        _this.setState({
          offset,
          scrollChangeReason: SCROLL_CHANGE_REASON.OBSERVED
        });
        if (typeof onScroll === "function") {
          onScroll(offset, event);
        }
      };
      return _this;
    }
    VirtualList2.prototype.componentDidMount = function() {
      var _a2 = this.props, scrollOffset = _a2.scrollOffset, scrollToIndex = _a2.scrollToIndex;
      this.rootNode.addEventListener("scroll", this.handleScroll, {
        passive: true
      });
      if (scrollOffset != null) {
        this.scrollTo(scrollOffset);
      } else if (scrollToIndex != null) {
        this.scrollTo(this.getOffsetForIndex(scrollToIndex));
      }
    };
    VirtualList2.prototype.componentWillReceiveProps = function(nextProps) {
      var _a2 = this.props, estimatedItemSize = _a2.estimatedItemSize, itemCount = _a2.itemCount, itemSize = _a2.itemSize, scrollOffset = _a2.scrollOffset, scrollToAlignment = _a2.scrollToAlignment, scrollToIndex = _a2.scrollToIndex;
      var scrollPropsHaveChanged = nextProps.scrollToIndex !== scrollToIndex || nextProps.scrollToAlignment !== scrollToAlignment;
      var itemPropsHaveChanged = nextProps.itemCount !== itemCount || nextProps.itemSize !== itemSize || nextProps.estimatedItemSize !== estimatedItemSize;
      if (nextProps.itemSize !== itemSize) {
        this.sizeAndPositionManager.updateConfig({
          itemSizeGetter: this.itemSizeGetter(nextProps.itemSize)
        });
      }
      if (nextProps.itemCount !== itemCount || nextProps.estimatedItemSize !== estimatedItemSize) {
        this.sizeAndPositionManager.updateConfig({
          itemCount: nextProps.itemCount,
          estimatedItemSize: this.getEstimatedItemSize(nextProps)
        });
      }
      if (itemPropsHaveChanged) {
        this.recomputeSizes();
      }
      if (nextProps.scrollOffset !== scrollOffset) {
        this.setState({
          offset: nextProps.scrollOffset || 0,
          scrollChangeReason: SCROLL_CHANGE_REASON.REQUESTED
        });
      } else if (typeof nextProps.scrollToIndex === "number" && (scrollPropsHaveChanged || itemPropsHaveChanged)) {
        this.setState({
          offset: this.getOffsetForIndex(nextProps.scrollToIndex, nextProps.scrollToAlignment, nextProps.itemCount),
          scrollChangeReason: SCROLL_CHANGE_REASON.REQUESTED
        });
      }
    };
    VirtualList2.prototype.componentDidUpdate = function(_, prevState) {
      var _a2 = this.state, offset = _a2.offset, scrollChangeReason = _a2.scrollChangeReason;
      if (prevState.offset !== offset && scrollChangeReason === SCROLL_CHANGE_REASON.REQUESTED) {
        this.scrollTo(offset);
      }
    };
    VirtualList2.prototype.componentWillUnmount = function() {
      this.rootNode.removeEventListener("scroll", this.handleScroll);
    };
    VirtualList2.prototype.scrollTo = function(value) {
      var _a2 = this.props.scrollDirection, scrollDirection = _a2 === void 0 ? DIRECTION.VERTICAL : _a2;
      this.rootNode[scrollProp[scrollDirection]] = value;
    };
    VirtualList2.prototype.getOffsetForIndex = function(index, scrollToAlignment, itemCount) {
      if (scrollToAlignment === void 0) {
        scrollToAlignment = this.props.scrollToAlignment;
      }
      if (itemCount === void 0) {
        itemCount = this.props.itemCount;
      }
      var _a2 = this.props.scrollDirection, scrollDirection = _a2 === void 0 ? DIRECTION.VERTICAL : _a2;
      if (index < 0 || index >= itemCount) {
        index = 0;
      }
      return this.sizeAndPositionManager.getUpdatedOffsetForIndex({
        align: scrollToAlignment,
        containerSize: this.props[sizeProp[scrollDirection]],
        currentOffset: this.state && this.state.offset || 0,
        targetIndex: index
      });
    };
    VirtualList2.prototype.recomputeSizes = function(startIndex) {
      if (startIndex === void 0) {
        startIndex = 0;
      }
      this.styleCache = {};
      this.sizeAndPositionManager.resetItem(startIndex);
    };
    VirtualList2.prototype.render = function() {
      var _this = this;
      var _a2 = this.props, estimatedItemSize = _a2.estimatedItemSize, height = _a2.height, _b2 = _a2.overscanCount, overscanCount = _b2 === void 0 ? 3 : _b2, renderItem = _a2.renderItem, itemCount = _a2.itemCount, itemSize = _a2.itemSize, onItemsRendered = _a2.onItemsRendered, onScroll = _a2.onScroll, _c2 = _a2.scrollDirection, scrollDirection = _c2 === void 0 ? DIRECTION.VERTICAL : _c2, scrollOffset = _a2.scrollOffset, scrollToIndex = _a2.scrollToIndex, scrollToAlignment = _a2.scrollToAlignment, stickyIndices = _a2.stickyIndices, style = _a2.style, width = _a2.width, props = __rest(_a2, ["estimatedItemSize", "height", "overscanCount", "renderItem", "itemCount", "itemSize", "onItemsRendered", "onScroll", "scrollDirection", "scrollOffset", "scrollToIndex", "scrollToAlignment", "stickyIndices", "style", "width"]);
      var offset = this.state.offset;
      var _d2 = this.sizeAndPositionManager.getVisibleRange({
        containerSize: this.props[sizeProp[scrollDirection]] || 0,
        offset,
        overscanCount
      }), start = _d2.start, stop = _d2.stop;
      var items = [];
      var wrapperStyle = __assign({}, STYLE_WRAPPER, style, { height, width });
      var innerStyle = __assign({}, STYLE_INNER, (_e2 = {}, _e2[sizeProp[scrollDirection]] = this.sizeAndPositionManager.getTotalSize(), _e2));
      if (stickyIndices != null && stickyIndices.length !== 0) {
        stickyIndices.forEach(function(index2) {
          return items.push(renderItem({
            index: index2,
            style: _this.getStyle(index2, true)
          }));
        });
        if (scrollDirection === DIRECTION.HORIZONTAL) {
          innerStyle.display = "flex";
        }
      }
      if (typeof start !== "undefined" && typeof stop !== "undefined") {
        for (var index = start; index <= stop; index++) {
          if (stickyIndices != null && stickyIndices.includes(index)) {
            continue;
          }
          items.push(renderItem({
            index,
            style: this.getStyle(index, false)
          }));
        }
        if (typeof onItemsRendered === "function") {
          onItemsRendered({
            startIndex: start,
            stopIndex: stop
          });
        }
      }
      return (0, import_react4.createElement)("div", __assign({ ref: this.getRef }, props, { style: wrapperStyle }), (0, import_react4.createElement)("div", { style: innerStyle }, items));
      var _e2;
    };
    VirtualList2.prototype.getNodeOffset = function() {
      var _a2 = this.props.scrollDirection, scrollDirection = _a2 === void 0 ? DIRECTION.VERTICAL : _a2;
      return this.rootNode[scrollProp[scrollDirection]];
    };
    VirtualList2.prototype.getEstimatedItemSize = function(props) {
      if (props === void 0) {
        props = this.props;
      }
      return props.estimatedItemSize || typeof props.itemSize === "number" && props.itemSize || 50;
    };
    VirtualList2.prototype.getSize = function(index, itemSize) {
      if (typeof itemSize === "function") {
        return itemSize(index);
      }
      return Array.isArray(itemSize) ? itemSize[index] : itemSize;
    };
    VirtualList2.prototype.getStyle = function(index, sticky) {
      var style = this.styleCache[index];
      if (style) {
        return style;
      }
      var _a2 = this.props.scrollDirection, scrollDirection = _a2 === void 0 ? DIRECTION.VERTICAL : _a2;
      var _b2 = this.sizeAndPositionManager.getSizeAndPositionForIndex(index), size = _b2.size, offset = _b2.offset;
      return this.styleCache[index] = sticky ? __assign({}, STYLE_STICKY_ITEM, (_c2 = {}, _c2[sizeProp[scrollDirection]] = size, _c2[marginProp[scrollDirection]] = offset, _c2[oppositeMarginProp[scrollDirection]] = -(offset + size), _c2.zIndex = 1, _c2)) : __assign({}, STYLE_ITEM, (_d2 = {}, _d2[sizeProp[scrollDirection]] = size, _d2[positionProp[scrollDirection]] = offset, _d2));
      var _c2, _d2;
    };
    VirtualList2.defaultProps = {
      overscanCount: 3,
      scrollDirection: DIRECTION.VERTICAL,
      width: "100%"
    };
    VirtualList2.propTypes = {
      estimatedItemSize: import_prop_types3.number,
      height: (0, import_prop_types3.oneOfType)([import_prop_types3.number, import_prop_types3.string]).isRequired,
      itemCount: import_prop_types3.number.isRequired,
      itemSize: (0, import_prop_types3.oneOfType)([import_prop_types3.number, import_prop_types3.array, import_prop_types3.func]).isRequired,
      onScroll: import_prop_types3.func,
      onItemsRendered: import_prop_types3.func,
      overscanCount: import_prop_types3.number,
      renderItem: import_prop_types3.func.isRequired,
      scrollOffset: import_prop_types3.number,
      scrollToIndex: import_prop_types3.number,
      scrollToAlignment: (0, import_prop_types3.oneOf)([ALIGNMENT.AUTO, ALIGNMENT.START, ALIGNMENT.CENTER, ALIGNMENT.END]),
      scrollDirection: (0, import_prop_types3.oneOf)([DIRECTION.HORIZONTAL, DIRECTION.VERTICAL]),
      stickyIndices: (0, import_prop_types3.arrayOf)(import_prop_types3.number),
      style: import_prop_types3.object,
      width: (0, import_prop_types3.oneOfType)([import_prop_types3.number, import_prop_types3.string])
    };
    return VirtualList2;
  }(import_react4.PureComponent)
);
var react_tiny_virtual_list_es_default = VirtualList;

// node_modules/react-infinite-calendar/es/MonthList/index.js
var import_classnames5 = __toESM(require_classnames());
var import_parse2 = __toESM(require_parse());
var import_start_of_month = __toESM(require_start_of_month());

// node_modules/react-infinite-calendar/es/Month/index.js
var import_react5 = __toESM(require_react());
var import_classnames4 = __toESM(require_classnames());
var import_format2 = __toESM(require_format());
var import_get_day2 = __toESM(require_get_day());
var import_is_same_year = __toESM(require_is_same_year());
var _extends = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck4(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn3(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits3(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles4 = {
  "rows": "Cal__Month__rows",
  "row": "Cal__Month__row",
  "partial": "Cal__Month__partial",
  "label": "Cal__Month__label",
  "partialFirstRow": "Cal__Month__partialFirstRow"
};
var Month = function(_PureComponent) {
  _inherits3(Month2, _PureComponent);
  function Month2() {
    _classCallCheck4(this, Month2);
    return _possibleConstructorReturn3(this, _PureComponent.apply(this, arguments));
  }
  Month2.prototype.renderRows = function renderRows() {
    var _props = this.props, DayComponent = _props.DayComponent, disabledDates = _props.disabledDates, disabledDays = _props.disabledDays, monthDate = _props.monthDate, locale = _props.locale, maxDate = _props.maxDate, minDate = _props.minDate, rowHeight = _props.rowHeight, rows = _props.rows, selected = _props.selected, today = _props.today, theme = _props.theme, passThrough = _props.passThrough;
    var currentYear = today.getFullYear();
    var year = monthDate.getFullYear();
    var month = monthDate.getMonth();
    var monthShort = (0, import_format2.default)(monthDate, "MMM", { locale: locale.locale });
    var monthRows = [];
    var day = 0;
    var isDisabled = false;
    var isToday = false;
    var date = void 0, days = void 0, dow = void 0, row = void 0;
    var _today = (0, import_format2.default)(today, "YYYY-MM-DD");
    var _minDate = (0, import_format2.default)(minDate, "YYYY-MM-DD");
    var _maxDate = (0, import_format2.default)(maxDate, "YYYY-MM-DD");
    for (var i = 0, len = rows.length; i < len; i++) {
      var _classNames;
      row = rows[i];
      days = [];
      dow = (0, import_get_day2.default)(new Date(year, month, row[0]));
      for (var k = 0, _len = row.length; k < _len; k++) {
        day = row[k];
        date = getDateString(year, month, day);
        isToday = date === _today;
        isDisabled = minDate && date < _minDate || maxDate && date > _maxDate || disabledDays && disabledDays.length && disabledDays.indexOf(dow) !== -1 || disabledDates && disabledDates.length && disabledDates.indexOf(date) !== -1;
        days[k] = import_react5.default.createElement(DayComponent, _extends({
          key: "day-" + day,
          currentYear,
          date,
          day,
          selected,
          isDisabled,
          isToday,
          locale,
          month,
          monthShort,
          theme,
          year
        }, passThrough.Day));
        dow += 1;
      }
      monthRows[i] = import_react5.default.createElement(
        "ul",
        {
          key: "Row-" + i,
          className: (0, import_classnames4.default)(styles4.row, (_classNames = {}, _classNames[styles4.partial] = row.length !== 7, _classNames)),
          style: { height: rowHeight },
          role: "row",
          "aria-label": "Week " + (i + 1)
        },
        days
      );
    }
    return monthRows;
  };
  Month2.prototype.render = function render() {
    var _classNames2;
    var _props2 = this.props, locale = _props2.locale.locale, monthDate = _props2.monthDate, today = _props2.today, rows = _props2.rows, rowHeight = _props2.rowHeight, showOverlay = _props2.showOverlay, style = _props2.style, theme = _props2.theme;
    var dateFormat = (0, import_is_same_year.default)(monthDate, today) ? "MMMM" : "MMMM YYYY";
    return import_react5.default.createElement(
      "div",
      { className: styles4.root, style: _extends({}, style, { lineHeight: rowHeight + "px" }) },
      import_react5.default.createElement(
        "div",
        { className: styles4.rows },
        this.renderRows(),
        showOverlay && import_react5.default.createElement(
          "label",
          {
            className: (0, import_classnames4.default)(styles4.label, (_classNames2 = {}, _classNames2[styles4.partialFirstRow] = rows[0].length !== 7, _classNames2)),
            style: { backgroundColor: theme.overlayColor }
          },
          import_react5.default.createElement(
            "span",
            null,
            (0, import_format2.default)(monthDate, dateFormat, { locale })
          )
        )
      )
    );
  };
  return Month2;
}(import_react5.PureComponent);

// node_modules/react-infinite-calendar/es/MonthList/index.js
var _extends2 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck5(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn4(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits4(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles5 = {
  "root": "Cal__MonthList__root",
  "scrolling": "Cal__MonthList__scrolling"
};
var AVERAGE_ROWS_PER_MONTH = 5;
var MonthList = function(_Component) {
  _inherits4(MonthList2, _Component);
  function MonthList2() {
    var _temp3, _this, _ret;
    _classCallCheck5(this, MonthList2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp3 = (_this = _possibleConstructorReturn4(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.state = {
      scrollTop: _this.getDateOffset(_this.props.scrollDate)
    }, _this.cache = {}, _this.memoize = function(param) {
      if (!this.cache[param]) {
        var weekStartsOn = this.props.locale.weekStartsOn;
        var _param$split = param.split(":"), year = _param$split[0], month = _param$split[1];
        var result = getMonth(year, month, weekStartsOn);
        this.cache[param] = result;
      }
      return this.cache[param];
    }, _this.monthHeights = [], _this._getRef = function(instance) {
      _this.VirtualList = instance;
    }, _this.getMonthHeight = function(index) {
      if (!_this.monthHeights[index]) {
        var _this$props = _this.props, weekStartsOn = _this$props.locale.weekStartsOn, months = _this$props.months, rowHeight = _this$props.rowHeight;
        var _months$index = months[index], month = _months$index.month, year = _months$index.year;
        var weeks = getWeeksInMonth(month, year, weekStartsOn, index === months.length - 1);
        var height = weeks * rowHeight;
        _this.monthHeights[index] = height;
      }
      return _this.monthHeights[index];
    }, _this.scrollToDate = function(date) {
      for (var _len2 = arguments.length, rest = Array(_len2 > 2 ? _len2 - 2 : 0), _key2 = 2; _key2 < _len2; _key2++) {
        rest[_key2 - 2] = arguments[_key2];
      }
      var _this2;
      var offset = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : 0;
      var offsetTop = _this.getDateOffset(date);
      (_this2 = _this).scrollTo.apply(_this2, [offsetTop + offset].concat(rest));
    }, _this.scrollTo = function() {
      var scrollTop = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : 0;
      var shouldAnimate = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : false;
      var onScrollEnd = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : emptyFn;
      var onComplete = function onComplete2() {
        return setTimeout(function() {
          _this.scrollEl.style.overflowY = "auto";
          onScrollEnd();
        });
      };
      _this.scrollEl.style.overflowY = "hidden";
      if (shouldAnimate) {
        animate({
          fromValue: _this.scrollEl.scrollTop,
          toValue: scrollTop,
          onUpdate: function onUpdate(scrollTop2, callback) {
            return _this.setState({ scrollTop: scrollTop2 }, callback);
          },
          onComplete
        });
      } else {
        window.requestAnimationFrame(function() {
          _this.scrollEl.scrollTop = scrollTop;
          onComplete();
        });
      }
    }, _this.renderMonth = function(_ref) {
      var index = _ref.index, style = _ref.style;
      var _this$props2 = _this.props, DayComponent = _this$props2.DayComponent, disabledDates = _this$props2.disabledDates, disabledDays = _this$props2.disabledDays, locale = _this$props2.locale, maxDate = _this$props2.maxDate, minDate = _this$props2.minDate, months = _this$props2.months, passThrough = _this$props2.passThrough, rowHeight = _this$props2.rowHeight, selected = _this$props2.selected, showOverlay = _this$props2.showOverlay, theme = _this$props2.theme, today = _this$props2.today;
      var _months$index2 = months[index], month = _months$index2.month, year = _months$index2.year;
      var key = year + ":" + month;
      var _this$memoize = _this.memoize(key), date = _this$memoize.date, rows = _this$memoize.rows;
      return import_react6.default.createElement(Month, _extends2({
        key,
        selected,
        DayComponent,
        monthDate: date,
        disabledDates,
        disabledDays,
        maxDate,
        minDate,
        rows,
        rowHeight,
        isScrolling: false,
        showOverlay,
        today,
        theme,
        style,
        locale,
        passThrough
      }, passThrough.Month));
    }, _temp3), _possibleConstructorReturn4(_this, _ret);
  }
  MonthList2.prototype.componentDidMount = function componentDidMount() {
    this.scrollEl = this.VirtualList.rootNode;
  };
  MonthList2.prototype.componentWillReceiveProps = function componentWillReceiveProps(_ref2) {
    var scrollDate = _ref2.scrollDate;
    if (scrollDate !== this.props.scrollDate) {
      this.setState({
        scrollTop: this.getDateOffset(scrollDate)
      });
    }
  };
  MonthList2.prototype.getDateOffset = function getDateOffset(date) {
    var _props = this.props, min = _props.min, rowHeight = _props.rowHeight, weekStartsOn = _props.locale.weekStartsOn, height = _props.height;
    var weeks = getWeek((0, import_start_of_month.default)(min), (0, import_parse2.default)(date), weekStartsOn);
    return weeks * rowHeight - (height - rowHeight / 2) / 2;
  };
  MonthList2.prototype.render = function render() {
    var _classNames;
    var _props2 = this.props, height = _props2.height, isScrolling = _props2.isScrolling, onScroll = _props2.onScroll, overscanMonthCount = _props2.overscanMonthCount, months = _props2.months, rowHeight = _props2.rowHeight, width = _props2.width;
    var scrollTop = this.state.scrollTop;
    return import_react6.default.createElement(react_tiny_virtual_list_es_default, {
      ref: this._getRef,
      width,
      height,
      itemCount: months.length,
      itemSize: this.getMonthHeight,
      estimatedItemSize: rowHeight * AVERAGE_ROWS_PER_MONTH,
      renderItem: this.renderMonth,
      onScroll,
      scrollOffset: scrollTop,
      className: (0, import_classnames5.default)(styles5.root, (_classNames = {}, _classNames[styles5.scrolling] = isScrolling, _classNames)),
      style: { lineHeight: rowHeight + "px" },
      overscanCount: overscanMonthCount
    });
  };
  return MonthList2;
}(import_react6.Component);
true ? MonthList.propTypes = {
  disabledDates: import_prop_types4.default.arrayOf(import_prop_types4.default.string),
  disabledDays: import_prop_types4.default.arrayOf(import_prop_types4.default.number),
  height: import_prop_types4.default.number,
  isScrolling: import_prop_types4.default.bool,
  locale: import_prop_types4.default.object,
  maxDate: import_prop_types4.default.instanceOf(Date),
  min: import_prop_types4.default.instanceOf(Date),
  minDate: import_prop_types4.default.instanceOf(Date),
  months: import_prop_types4.default.arrayOf(import_prop_types4.default.object),
  onDaySelect: import_prop_types4.default.func,
  onScroll: import_prop_types4.default.func,
  overscanMonthCount: import_prop_types4.default.number,
  rowHeight: import_prop_types4.default.number,
  selectedDate: import_prop_types4.default.instanceOf(Date),
  showOverlay: import_prop_types4.default.bool,
  theme: import_prop_types4.default.object,
  today: import_prop_types4.default.instanceOf(Date),
  width: import_prop_types4.default.oneOfType([import_prop_types4.default.number, import_prop_types4.default.string])
} : void 0;

// node_modules/react-infinite-calendar/es/Weekdays/index.js
var import_react7 = __toESM(require_react());
var import_prop_types5 = __toESM(require_prop_types());
function _classCallCheck6(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn5(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits5(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles6 = {
  "root": "Cal__Weekdays__root",
  "day": "Cal__Weekdays__day"
};
var Weekdays = function(_PureComponent) {
  _inherits5(Weekdays2, _PureComponent);
  function Weekdays2() {
    _classCallCheck6(this, Weekdays2);
    return _possibleConstructorReturn5(this, _PureComponent.apply(this, arguments));
  }
  Weekdays2.prototype.render = function render() {
    var _props = this.props, weekdays = _props.weekdays, weekStartsOn = _props.weekStartsOn, theme = _props.theme;
    var orderedWeekdays = [].concat(weekdays.slice(weekStartsOn, 7), weekdays.slice(0, weekStartsOn));
    return import_react7.default.createElement(
      "ul",
      {
        className: styles6.root,
        style: {
          backgroundColor: theme.weekdayColor,
          color: theme.textColor.active,
          paddingRight: scrollbarSize
        },
        "aria-hidden": true
      },
      orderedWeekdays.map(function(val, index) {
        return import_react7.default.createElement(
          "li",
          { key: "Weekday-" + index, className: styles6.day },
          val
        );
      })
    );
  };
  return Weekdays2;
}(import_react7.PureComponent);
true ? Weekdays.propTypes = {
  locale: import_prop_types5.default.object,
  theme: import_prop_types5.default.object
} : void 0;

// node_modules/react-infinite-calendar/es/Years/index.js
var import_react8 = __toESM(require_react());
var import_prop_types6 = __toESM(require_prop_types());
var import_classnames6 = __toESM(require_classnames());
var import_format3 = __toESM(require_format());
var import_is_after2 = __toESM(require_is_after());
var import_is_before2 = __toESM(require_is_before());
var import_is_same_month = __toESM(require_is_same_month());
var _class2;
var _temp2;
function _classCallCheck7(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn6(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits6(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles7 = {
  "root": "Cal__Years__root",
  "list": "Cal__Years__list",
  "center": "Cal__Years__center",
  "year": "Cal__Years__year",
  "withMonths": "Cal__Years__withMonths",
  "currentMonth": "Cal__Years__currentMonth",
  "selected": "Cal__Years__selected",
  "disabled": "Cal__Years__disabled",
  "active": "Cal__Years__active",
  "currentYear": "Cal__Years__currentYear",
  "first": "Cal__Years__first",
  "last": "Cal__Years__last"
};
var SPACING = 40;
var Years = (_temp2 = _class2 = function(_Component) {
  _inherits6(Years2, _Component);
  function Years2() {
    _classCallCheck7(this, Years2);
    return _possibleConstructorReturn6(this, _Component.apply(this, arguments));
  }
  Years2.prototype.handleClick = function handleClick(date, e) {
    var _props = this.props, hideOnSelect = _props.hideOnSelect, onSelect = _props.onSelect, setDisplay = _props.setDisplay, scrollToDate = _props.scrollToDate;
    onSelect(date, e, function(date2) {
      return scrollToDate(date2);
    });
    if (hideOnSelect) {
      window.requestAnimationFrame(function() {
        return setDisplay("days");
      });
    }
  };
  Years2.prototype.renderMonths = function renderMonths(year) {
    var _this2 = this;
    var _props2 = this.props, locale = _props2.locale.locale, selected = _props2.selected, theme = _props2.theme, today = _props2.today, min = _props2.min, max = _props2.max, minDate = _props2.minDate, maxDate = _props2.maxDate;
    var months = getMonthsForYear(year, selected.getDate());
    return import_react8.default.createElement(
      "ol",
      null,
      months.map(function(date, index) {
        var _classNames;
        var isSelected = (0, import_is_same_month.default)(date, selected);
        var isCurrentMonth = (0, import_is_same_month.default)(date, today);
        var isDisabled = (0, import_is_before2.default)(date, min) || (0, import_is_before2.default)(date, minDate) || (0, import_is_after2.default)(date, max) || (0, import_is_after2.default)(date, maxDate);
        var style = Object.assign({}, isSelected && {
          backgroundColor: typeof theme.selectionColor === "function" ? theme.selectionColor(date) : theme.selectionColor
        }, isCurrentMonth && {
          borderColor: theme.todayColor
        });
        return import_react8.default.createElement(
          "li",
          {
            key: index,
            onClick: function onClick(e) {
              e.stopPropagation();
              if (!isDisabled) {
                _this2.handleClick(date, e);
              }
            },
            className: (0, import_classnames6.default)(styles7.month, (_classNames = {}, _classNames[styles7.selected] = isSelected, _classNames[styles7.currentMonth] = isCurrentMonth, _classNames[styles7.disabled] = isDisabled, _classNames)),
            style,
            title: "Set date to " + (0, import_format3.default)(date, "MMMM Do, YYYY")
          },
          (0, import_format3.default)(date, "MMM", { locale })
        );
      })
    );
  };
  Years2.prototype.render = function render() {
    var _this3 = this;
    var _props3 = this.props, height = _props3.height, selected = _props3.selected, showMonths = _props3.showMonths, theme = _props3.theme, today = _props3.today, width = _props3.width;
    var currentYear = today.getFullYear();
    var years = this.props.years.slice(0, this.props.years.length);
    var selectedYearIndex = years.indexOf(selected.getFullYear());
    var rowHeight = showMonths ? 110 : 50;
    var heights = years.map(function(val, index) {
      return index === 0 || index === years.length - 1 ? rowHeight + SPACING : rowHeight;
    });
    var containerHeight = years.length * rowHeight < height + 50 ? years.length * rowHeight : height + 50;
    return import_react8.default.createElement(
      "div",
      {
        className: styles7.root,
        style: { color: theme.selectionColor, height: height + 50 }
      },
      import_react8.default.createElement(react_tiny_virtual_list_es_default, {
        ref: "List",
        className: styles7.list,
        width,
        height: containerHeight,
        itemCount: years.length,
        estimatedItemSize: rowHeight,
        itemSize: function itemSize(index) {
          return heights[index];
        },
        scrollToIndex: selectedYearIndex !== -1 ? selectedYearIndex : null,
        scrollToAlignment: "center",
        renderItem: function renderItem(_ref) {
          var _classNames2;
          var index = _ref.index, style = _ref.style;
          var year = years[index];
          var isActive = index === selectedYearIndex;
          return import_react8.default.createElement(
            "div",
            {
              key: index,
              className: (0, import_classnames6.default)(styles7.year, (_classNames2 = {}, _classNames2[styles7.active] = !showMonths && isActive, _classNames2[styles7.currentYear] = !showMonths && year === currentYear, _classNames2[styles7.withMonths] = showMonths, _classNames2[styles7.first] = index === 0, _classNames2[styles7.last] = index === years.length - 1, _classNames2)),
              onClick: function onClick() {
                return _this3.handleClick(new Date(selected).setYear(year));
              },
              title: "Set year to " + year,
              "data-year": year,
              style: Object.assign({}, style, {
                color: typeof theme.selectionColor === "function" ? theme.selectionColor(new Date(year, 0, 1)) : theme.selectionColor
              })
            },
            import_react8.default.createElement(
              "label",
              null,
              import_react8.default.createElement(
                "span",
                {
                  style: !showMonths && year === currentYear ? { borderColor: theme.todayColor } : null
                },
                year
              )
            ),
            showMonths && _this3.renderMonths(year)
          );
        }
      })
    );
  };
  return Years2;
}(import_react8.Component), _class2.defaultProps = {
  onSelect: emptyFn,
  showMonths: true
}, _temp2);
true ? Years.propTypes = {
  height: import_prop_types6.default.number,
  hideOnSelect: import_prop_types6.default.bool,
  locale: import_prop_types6.default.object,
  max: import_prop_types6.default.object,
  maxDate: import_prop_types6.default.object,
  min: import_prop_types6.default.object,
  minDate: import_prop_types6.default.object,
  onSelect: import_prop_types6.default.func,
  scrollToDate: import_prop_types6.default.func,
  selectedYear: import_prop_types6.default.number,
  setDisplay: import_prop_types6.default.func,
  theme: import_prop_types6.default.object,
  width: import_prop_types6.default.oneOfType([import_prop_types6.default.number, import_prop_types6.default.string]),
  years: import_prop_types6.default.array
} : void 0;

// node_modules/react-infinite-calendar/es/Day/index.js
var import_react9 = __toESM(require_react());
var import_classnames7 = __toESM(require_classnames());
var import_parse3 = __toESM(require_parse());
var _extends3 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck8(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn7(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits7(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles8 = {
  "root": "Cal__Day__root",
  "enabled": "Cal__Day__enabled",
  "highlighted": "Cal__Day__highlighted",
  "today": "Cal__Day__today",
  "disabled": "Cal__Day__disabled",
  "selected": "Cal__Day__selected",
  "month": "Cal__Day__month",
  "year": "Cal__Day__year",
  "selection": "Cal__Day__selection",
  "day": "Cal__Day__day",
  "range": "Cal__Day__range",
  "start": "Cal__Day__start",
  "end": "Cal__Day__end",
  "betweenRange": "Cal__Day__betweenRange"
};
var Day = function(_PureComponent) {
  _inherits7(Day2, _PureComponent);
  function Day2() {
    var _temp3, _this, _ret;
    _classCallCheck8(this, Day2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp3 = (_this = _possibleConstructorReturn7(this, _PureComponent.call.apply(_PureComponent, [this].concat(args))), _this), _this.handleClick = function() {
      var _this$props = _this.props, date = _this$props.date, isDisabled = _this$props.isDisabled, onClick = _this$props.onClick;
      if (!isDisabled && typeof onClick === "function") {
        onClick((0, import_parse3.default)(date));
      }
    }, _temp3), _possibleConstructorReturn7(_this, _ret);
  }
  Day2.prototype.renderSelection = function renderSelection(selectionColor) {
    var _props = this.props, day = _props.day, date = _props.date, isToday = _props.isToday, todayLabel = _props.locale.todayLabel, monthShort = _props.monthShort, textColor = _props.theme.textColor, selectionStyle = _props.selectionStyle;
    return import_react9.default.createElement(
      "div",
      {
        className: styles8.selection,
        "data-date": date,
        style: _extends3({
          backgroundColor: this.selectionColor,
          color: textColor.active
        }, selectionStyle)
      },
      import_react9.default.createElement(
        "span",
        { className: styles8.month },
        isToday ? todayLabel.short || todayLabel.long : monthShort
      ),
      import_react9.default.createElement(
        "span",
        { className: styles8.day },
        day
      )
    );
  };
  Day2.prototype.render = function render() {
    var _classNames;
    var _props2 = this.props, className = _props2.className, currentYear = _props2.currentYear, date = _props2.date, day = _props2.day, handlers = _props2.handlers, isDisabled = _props2.isDisabled, isHighlighted = _props2.isHighlighted, isToday = _props2.isToday, isSelected = _props2.isSelected, monthShort = _props2.monthShort, _props2$theme = _props2.theme, selectionColor = _props2$theme.selectionColor, todayColor = _props2$theme.todayColor, year = _props2.year;
    var color = void 0;
    if (isSelected) {
      color = this.selectionColor = typeof selectionColor === "function" ? selectionColor(date) : selectionColor;
    } else if (isToday) {
      color = todayColor;
    }
    return import_react9.default.createElement(
      "li",
      _extends3({
        style: color ? { color } : null,
        className: (0, import_classnames7.default)(styles8.root, (_classNames = {}, _classNames[styles8.today] = isToday, _classNames[styles8.highlighted] = isHighlighted, _classNames[styles8.selected] = isSelected, _classNames[styles8.disabled] = isDisabled, _classNames[styles8.enabled] = !isDisabled, _classNames), className),
        onClick: this.handleClick,
        "data-date": date
      }, handlers),
      day === 1 && import_react9.default.createElement(
        "span",
        { className: styles8.month },
        monthShort
      ),
      isToday ? import_react9.default.createElement(
        "span",
        null,
        day
      ) : day,
      day === 1 && currentYear !== year && import_react9.default.createElement(
        "span",
        { className: styles8.year },
        year
      ),
      isSelected && this.renderSelection()
    );
  };
  return Day2;
}(import_react9.PureComponent);

// node_modules/react-infinite-calendar/es/Calendar/index.js
var import_parse4 = __toESM(require_parse());
var import_format4 = __toESM(require_format());
var import_start_of_day2 = __toESM(require_start_of_day());
var _extends4 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _classCallCheck9(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn8(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits8(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles9 = {
  container: {
    "root": "Cal__Container__root",
    "landscape": "Cal__Container__landscape",
    "wrapper": "Cal__Container__wrapper",
    "listWrapper": "Cal__Container__listWrapper"
  },
  day: {
    "root": "Cal__Day__root",
    "enabled": "Cal__Day__enabled",
    "highlighted": "Cal__Day__highlighted",
    "today": "Cal__Day__today",
    "disabled": "Cal__Day__disabled",
    "selected": "Cal__Day__selected",
    "month": "Cal__Day__month",
    "year": "Cal__Day__year",
    "selection": "Cal__Day__selection",
    "day": "Cal__Day__day",
    "range": "Cal__Day__range",
    "start": "Cal__Day__start",
    "end": "Cal__Day__end",
    "betweenRange": "Cal__Day__betweenRange"
  }
};
var withDefaultProps = (0, import_defaultProps.default)({
  autoFocus: true,
  DayComponent: Day,
  display: "days",
  displayOptions: {},
  HeaderComponent: Header,
  height: 500,
  keyboardSupport: true,
  max: new Date(2050, 11, 31),
  maxDate: new Date(2050, 11, 31),
  min: new Date(1980, 0, 1),
  minDate: new Date(1980, 0, 1),
  onHighlightedDateChange: emptyFn,
  onScroll: emptyFn,
  onScrollEnd: emptyFn,
  onSelect: emptyFn,
  passThrough: {},
  rowHeight: 56,
  tabIndex: 1,
  width: 400,
  YearsComponent: Years
});
var Calendar = function(_Component) {
  _inherits8(Calendar2, _Component);
  function Calendar2(props) {
    _classCallCheck9(this, Calendar2);
    var _this = _possibleConstructorReturn8(this, _Component.apply(this, arguments));
    _this._displayOptions = {};
    _this._locale = {};
    _this._theme = {};
    _this.getCurrentOffset = function() {
      return _this.scrollTop;
    };
    _this.getDateOffset = function(date) {
      return _this._MonthList && _this._MonthList.getDateOffset(date);
    };
    _this.scrollTo = function(offset) {
      return _this._MonthList && _this._MonthList.scrollTo(offset);
    };
    _this.scrollToDate = function() {
      var date = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : /* @__PURE__ */ new Date();
      var offset = arguments[1];
      var shouldAnimate = arguments[2];
      var display = _this.props.display;
      return _this._MonthList && _this._MonthList.scrollToDate(date, offset, shouldAnimate && display === "days", function() {
        return _this.setState({ isScrolling: false });
      });
    };
    _this.getScrollSpeed = new ScrollSpeed().getScrollSpeed;
    _this.handleScroll = function(scrollTop, e) {
      var _this$props = _this.props, onScroll = _this$props.onScroll, rowHeight = _this$props.rowHeight;
      var isScrolling = _this.state.isScrolling;
      var _this$getDisplayOptio = _this.getDisplayOptions(), showTodayHelper = _this$getDisplayOptio.showTodayHelper, showOverlay = _this$getDisplayOptio.showOverlay;
      var scrollSpeed = _this.scrollSpeed = Math.abs(_this.getScrollSpeed(scrollTop));
      _this.scrollTop = scrollTop;
      if (showOverlay && scrollSpeed > rowHeight && !isScrolling) {
        _this.setState({
          isScrolling: true
        });
      }
      if (showTodayHelper) {
        _this.updateTodayHelperPosition(scrollSpeed);
      }
      onScroll(scrollTop, e);
      _this.handleScrollEnd();
    };
    _this.handleScrollEnd = debounce(function() {
      var onScrollEnd = _this.props.onScrollEnd;
      var isScrolling = _this.state.isScrolling;
      var _this$getDisplayOptio2 = _this.getDisplayOptions(), showTodayHelper = _this$getDisplayOptio2.showTodayHelper;
      if (isScrolling) {
        _this.setState({ isScrolling: false });
      }
      if (showTodayHelper) {
        _this.updateTodayHelperPosition(0);
      }
      onScrollEnd(_this.scrollTop);
    }, 150);
    _this.updateTodayHelperPosition = function(scrollSpeed) {
      var today = _this.today;
      var scrollTop = _this.scrollTop;
      var showToday = _this.state.showToday;
      var _this$props2 = _this.props, height = _this$props2.height, rowHeight = _this$props2.rowHeight;
      var _this$getDisplayOptio3 = _this.getDisplayOptions(), todayHelperRowOffset = _this$getDisplayOptio3.todayHelperRowOffset;
      var newState = void 0;
      if (!_this._todayOffset) {
        _this._todayOffset = _this.getDateOffset(today);
      }
      if (scrollTop >= _this._todayOffset + (height - rowHeight) / 2 + rowHeight * todayHelperRowOffset) {
        if (showToday !== DIRECTION_UP)
          newState = DIRECTION_UP;
      } else if (scrollTop <= _this._todayOffset - height / 2 - rowHeight * (todayHelperRowOffset + 1)) {
        if (showToday !== DIRECTION_DOWN)
          newState = DIRECTION_DOWN;
      } else if (showToday && scrollSpeed <= 1) {
        newState = false;
      }
      if (scrollTop === 0) {
        newState = false;
      }
      if (newState != null) {
        _this.setState({ showToday: newState });
      }
    };
    _this.setDisplay = function(display) {
      _this.setState({ display });
    };
    _this.updateYears(props);
    _this.state = {
      display: props.display
    };
    return _this;
  }
  Calendar2.prototype.componentDidMount = function componentDidMount() {
    var autoFocus = this.props.autoFocus;
    if (autoFocus) {
      this.node.focus();
    }
  };
  Calendar2.prototype.componentWillUpdate = function componentWillUpdate(nextProps, nextState) {
    var _props = this.props, min = _props.min, minDate = _props.minDate, max = _props.max, maxDate = _props.maxDate;
    if (nextProps.min !== min || nextProps.minDate !== minDate || nextProps.max !== max || nextProps.maxDate !== maxDate) {
      this.updateYears(nextProps);
    }
    if (nextProps.display !== this.props.display) {
      this.setState({ display: nextProps.display });
    }
  };
  Calendar2.prototype.updateYears = function updateYears() {
    var props = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.props;
    this._min = (0, import_parse4.default)(props.min);
    this._max = (0, import_parse4.default)(props.max);
    this._minDate = (0, import_parse4.default)(props.minDate);
    this._maxDate = (0, import_parse4.default)(props.maxDate);
    var min = this._min.getFullYear();
    var minMonth = this._min.getMonth();
    var max = this._max.getFullYear();
    var maxMonth = this._max.getMonth();
    var months = [];
    var year = void 0, month = void 0;
    for (year = min; year <= max; year++) {
      for (month = 0; month < 12; month++) {
        if (year === min && month < minMonth || year === max && month > maxMonth) {
          continue;
        }
        months.push({ month, year });
      }
    }
    this.months = months;
  };
  Calendar2.prototype.getDisabledDates = function getDisabledDates(disabledDates) {
    return disabledDates && disabledDates.map(function(date) {
      return (0, import_format4.default)((0, import_parse4.default)(date), "YYYY-MM-DD");
    });
  };
  Calendar2.prototype.getDisplayOptions = function getDisplayOptions() {
    var displayOptions = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : this.props.displayOptions;
    return Object.assign(this._displayOptions, import_defaultDisplayOptions.default, displayOptions);
  };
  Calendar2.prototype.getLocale = function getLocale() {
    return Object.assign(this._locale, import_defaultLocale.default, this.props.locale);
  };
  Calendar2.prototype.getTheme = function getTheme() {
    return Object.assign(this._theme, import_defaultTheme.default, this.props.theme);
  };
  Calendar2.prototype.render = function render() {
    var _classNames, _this2 = this;
    var _props2 = this.props, className = _props2.className, passThrough = _props2.passThrough, DayComponent = _props2.DayComponent, disabledDays = _props2.disabledDays, displayDate = _props2.displayDate, height = _props2.height, HeaderComponent = _props2.HeaderComponent, rowHeight = _props2.rowHeight, scrollDate = _props2.scrollDate, selected = _props2.selected, tabIndex = _props2.tabIndex, width = _props2.width, YearsComponent = _props2.YearsComponent;
    var _getDisplayOptions = this.getDisplayOptions(), hideYearsOnSelect = _getDisplayOptions.hideYearsOnSelect, layout = _getDisplayOptions.layout, overscanMonthCount = _getDisplayOptions.overscanMonthCount, shouldHeaderAnimate = _getDisplayOptions.shouldHeaderAnimate, showHeader = _getDisplayOptions.showHeader, showMonthsForYears = _getDisplayOptions.showMonthsForYears, showOverlay = _getDisplayOptions.showOverlay, showTodayHelper = _getDisplayOptions.showTodayHelper, showWeekdays = _getDisplayOptions.showWeekdays;
    var _state = this.state, display = _state.display, isScrolling = _state.isScrolling, showToday = _state.showToday;
    var disabledDates = this.getDisabledDates(this.props.disabledDates);
    var locale = this.getLocale();
    var theme = this.getTheme();
    var today = this.today = (0, import_start_of_day2.default)(/* @__PURE__ */ new Date());
    return import_react10.default.createElement(
      "div",
      _extends4({
        tabIndex,
        className: (0, import_classnames8.default)(className, styles9.container.root, (_classNames = {}, _classNames[styles9.container.landscape] = layout === "landscape", _classNames)),
        style: { color: theme.textColor.default, width },
        "aria-label": "Calendar",
        ref: function ref(node) {
          _this2.node = node;
        }
      }, passThrough.rootNode),
      showHeader && import_react10.default.createElement(HeaderComponent, _extends4({
        selected,
        shouldAnimate: Boolean(shouldHeaderAnimate && display !== "years"),
        layout,
        theme,
        locale,
        scrollToDate: this.scrollToDate,
        setDisplay: this.setDisplay,
        dateFormat: locale.headerFormat,
        display,
        displayDate
      }, passThrough.Header)),
      import_react10.default.createElement(
        "div",
        { className: styles9.container.wrapper },
        showWeekdays && import_react10.default.createElement(Weekdays, { weekdays: locale.weekdays, weekStartsOn: locale.weekStartsOn, theme }),
        import_react10.default.createElement(
          "div",
          { className: styles9.container.listWrapper },
          showTodayHelper && import_react10.default.createElement(Today, {
            scrollToDate: this.scrollToDate,
            show: showToday,
            today,
            theme,
            todayLabel: locale.todayLabel.long
          }),
          import_react10.default.createElement(MonthList, {
            ref: function ref(instance) {
              _this2._MonthList = instance;
            },
            DayComponent,
            disabledDates,
            disabledDays,
            height,
            isScrolling,
            locale,
            maxDate: this._maxDate,
            min: this._min,
            minDate: this._minDate,
            months: this.months,
            onScroll: this.handleScroll,
            overscanMonthCount,
            passThrough,
            theme,
            today,
            rowHeight,
            selected,
            scrollDate,
            showOverlay,
            width
          })
        ),
        display === "years" && import_react10.default.createElement(YearsComponent, _extends4({
          ref: function ref(instance) {
            _this2._Years = instance;
          },
          height,
          hideOnSelect: hideYearsOnSelect,
          locale,
          max: this._max,
          maxDate: this._maxDate,
          min: this._min,
          minDate: this._minDate,
          scrollToDate: this.scrollToDate,
          selected,
          setDisplay: this.setDisplay,
          showMonths: showMonthsForYears,
          theme,
          today,
          width,
          years: range(this._min.getFullYear(), this._max.getFullYear() + 1)
        }, passThrough.Years))
      )
    );
  };
  return Calendar2;
}(import_react10.Component);
true ? Calendar.propTypes = {
  autoFocus: import_prop_types7.default.bool,
  className: import_prop_types7.default.string,
  DayComponent: import_prop_types7.default.func,
  disabledDates: import_prop_types7.default.arrayOf(import_prop_types7.default.instanceOf(Date)),
  disabledDays: import_prop_types7.default.arrayOf(import_prop_types7.default.number),
  display: import_prop_types7.default.oneOf(["years", "days"]),
  displayOptions: import_prop_types7.default.shape({
    hideYearsOnSelect: import_prop_types7.default.bool,
    layout: import_prop_types7.default.oneOf(["portrait", "landscape"]),
    overscanMonthCount: import_prop_types7.default.number,
    shouldHeaderAnimate: import_prop_types7.default.bool,
    showHeader: import_prop_types7.default.bool,
    showMonthsForYears: import_prop_types7.default.bool,
    showOverlay: import_prop_types7.default.bool,
    showTodayHelper: import_prop_types7.default.bool,
    showWeekdays: import_prop_types7.default.bool,
    todayHelperRowOffset: import_prop_types7.default.number
  }),
  height: import_prop_types7.default.number,
  keyboardSupport: import_prop_types7.default.bool,
  locale: import_prop_types7.default.shape({
    blank: import_prop_types7.default.string,
    headerFormat: import_prop_types7.default.string,
    todayLabel: import_prop_types7.default.shape({
      long: import_prop_types7.default.string,
      short: import_prop_types7.default.string
    }),
    weekdays: import_prop_types7.default.arrayOf(import_prop_types7.default.string),
    weekStartsOn: import_prop_types7.default.oneOf([0, 1, 2, 3, 4, 5, 6])
  }),
  max: import_prop_types7.default.instanceOf(Date),
  maxDate: import_prop_types7.default.instanceOf(Date),
  min: import_prop_types7.default.instanceOf(Date),
  minDate: import_prop_types7.default.instanceOf(Date),
  onScroll: import_prop_types7.default.func,
  onScrollEnd: import_prop_types7.default.func,
  onSelect: import_prop_types7.default.func,
  rowHeight: import_prop_types7.default.number,
  tabIndex: import_prop_types7.default.number,
  theme: import_prop_types7.default.shape({
    floatingNav: import_prop_types7.default.shape({
      background: import_prop_types7.default.string,
      chevron: import_prop_types7.default.string,
      color: import_prop_types7.default.string
    }),
    headerColor: import_prop_types7.default.string,
    selectionColor: import_prop_types7.default.oneOfType([import_prop_types7.default.string, import_prop_types7.default.func]),
    textColor: import_prop_types7.default.shape({
      active: import_prop_types7.default.string,
      default: import_prop_types7.default.string
    }),
    todayColor: import_prop_types7.default.string,
    weekdayColor: import_prop_types7.default.string
  }),
  width: import_prop_types7.default.oneOfType([import_prop_types7.default.string, import_prop_types7.default.number]),
  YearsComponent: import_prop_types7.default.func
} : void 0;

// node_modules/react-infinite-calendar/es/Calendar/withDateSelection.js
var import_withState = __toESM(require_withState());
var import_withPropsOnChange2 = __toESM(require_withPropsOnChange());
var import_withProps = __toESM(require_withProps());
var import_compose = __toESM(require_compose());
var import_format5 = __toESM(require_format());
var import_parse5 = __toESM(require_parse());
function _objectWithoutProperties(obj, keys) {
  var target = {};
  for (var i in obj) {
    if (keys.indexOf(i) >= 0)
      continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i))
      continue;
    target[i] = obj[i];
  }
  return target;
}
var enhanceDay = (0, import_withPropsOnChange2.default)(["selected"], function(props) {
  return {
    isSelected: props.selected === props.date
  };
});
var enhanceYear = (0, import_withPropsOnChange2.default)(["selected"], function(_ref) {
  var selected = _ref.selected;
  return {
    selected: (0, import_parse5.default)(selected)
  };
});
var withDateSelection = (0, import_compose.default)(withDefaultProps, withImmutableProps(function(_ref2) {
  var DayComponent = _ref2.DayComponent, onSelect = _ref2.onSelect, setScrollDate = _ref2.setScrollDate, YearsComponent = _ref2.YearsComponent;
  return {
    DayComponent: enhanceDay(DayComponent),
    YearsComponent: enhanceYear(YearsComponent)
  };
}), (0, import_withState.default)("scrollDate", "setScrollDate", function(props) {
  return props.selected || /* @__PURE__ */ new Date();
}), (0, import_withProps.default)(function(_ref3) {
  var _onSelect = _ref3.onSelect, setScrollDate = _ref3.setScrollDate, props = _objectWithoutProperties(_ref3, ["onSelect", "setScrollDate"]);
  var selected = sanitizeDate(props.selected, props);
  return {
    passThrough: {
      Day: {
        onClick: _onSelect
      },
      Years: {
        onSelect: function onSelect(year) {
          return handleYearSelect(year, { onSelect: _onSelect, selected, setScrollDate });
        }
      }
    },
    selected: selected && (0, import_format5.default)(selected, "YYYY-MM-DD")
  };
}));
function handleYearSelect(date, _ref4) {
  var setScrollDate = _ref4.setScrollDate, selected = _ref4.selected, onSelect = _ref4.onSelect;
  var newDate = (0, import_parse5.default)(date);
  onSelect(newDate);
  setScrollDate(newDate);
}

// node_modules/react-infinite-calendar/es/Calendar/withKeyboardSupport.js
var import_withState2 = __toESM(require_withState());
var import_withProps2 = __toESM(require_withProps());
var import_withHandlers = __toESM(require_withHandlers());
var import_compose2 = __toESM(require_compose());
var import_add_days = __toESM(require_add_days());
var import_format6 = __toESM(require_format());
var import_is_after3 = __toESM(require_is_after());
var import_is_before3 = __toESM(require_is_before());
var _extends5 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var enhanceDay2 = (0, import_withProps2.default)(function(props) {
  return {
    isHighlighted: props.highlightedDate === props.date
  };
});
var withKeyboardSupport = (0, import_compose2.default)((0, import_withState2.default)("highlightedDate", "setHighlight"), withImmutableProps(function(_ref) {
  var DayComponent = _ref.DayComponent;
  return {
    DayComponent: enhanceDay2(DayComponent)
  };
}), (0, import_withHandlers.default)({
  onKeyDown: function onKeyDown(props) {
    return function(e) {
      return handleKeyDown(e, props);
    };
  }
}), (0, import_withProps2.default)(function(_ref2) {
  var highlightedDate = _ref2.highlightedDate, onKeyDown2 = _ref2.onKeyDown, onSelect = _ref2.onSelect, passThrough = _ref2.passThrough, setHighlight = _ref2.setHighlight;
  return {
    passThrough: _extends5({}, passThrough, {
      Day: _extends5({}, passThrough.Day, {
        highlightedDate: (0, import_format6.default)(highlightedDate, "YYYY-MM-DD"),
        onClick: function onClick(date) {
          setHighlight(null);
          passThrough.Day.onClick(date);
        }
      }),
      rootNode: { onKeyDown: onKeyDown2 }
    })
  };
}));
function handleKeyDown(e, props) {
  var minDate = props.minDate, maxDate = props.maxDate, onClick = props.passThrough.Day.onClick, setScrollDate = props.setScrollDate, setHighlight = props.setHighlight;
  var highlightedDate = getInitialDate(props);
  var delta = 0;
  if ([keyCodes.left, keyCodes.up, keyCodes.right, keyCodes.down].indexOf(e.keyCode) > -1 && typeof e.preventDefault === "function") {
    e.preventDefault();
  }
  switch (e.keyCode) {
    case keyCodes.enter:
      onClick && onClick(highlightedDate);
      return;
    case keyCodes.left:
      delta = -1;
      break;
    case keyCodes.right:
      delta = 1;
      break;
    case keyCodes.down:
      delta = 7;
      break;
    case keyCodes.up:
      delta = -7;
      break;
    default:
      delta = 0;
  }
  if (delta) {
    var newHighlightedDate = (0, import_add_days.default)(highlightedDate, delta);
    if ((0, import_is_before3.default)(newHighlightedDate, minDate)) {
      newHighlightedDate = new Date(minDate);
    } else if ((0, import_is_after3.default)(newHighlightedDate, maxDate)) {
      newHighlightedDate = new Date(maxDate);
    }
    setScrollDate(newHighlightedDate);
    setHighlight(newHighlightedDate);
  }
}
function getInitialDate(_ref3) {
  var highlightedDate = _ref3.highlightedDate, selected = _ref3.selected, displayDate = _ref3.displayDate;
  return highlightedDate || selected.start || displayDate || selected || /* @__PURE__ */ new Date();
}

// node_modules/react-infinite-calendar/es/Calendar/withMultipleDates.js
var import_withState3 = __toESM(require_withState());
var import_withPropsOnChange3 = __toESM(require_withPropsOnChange());
var import_withProps3 = __toESM(require_withProps());
var import_compose3 = __toESM(require_compose());

// node_modules/react-infinite-calendar/es/Header/withMultipleDates.js
var import_react12 = __toESM(require_react());

// node_modules/react-infinite-calendar/es/Header/Slider/index.js
var import_react11 = __toESM(require_react());
var import_CSSTransitionGroup2 = __toESM(require_CSSTransitionGroup());
var import_classnames9 = __toESM(require_classnames());
function _classCallCheck10(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn9(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits9(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var styles10 = {
  "root": "Cal__Slider__root",
  "slide": "Cal__Slider__slide",
  "wrapper": "Cal__Slider__wrapper",
  "arrow": "Cal__Slider__arrow",
  "arrowRight": "Cal__Slider__arrowRight",
  "arrowLeft": "Cal__Slider__arrowLeft"
};
var transition = {
  "enter": "Cal__transition__enter",
  "enterActive": "Cal__transition__enterActive",
  "leave": "Cal__transition__leave",
  "leaveActive": "Cal__transition__leaveActive"
};
var DIRECTIONS = {
  LEFT: 0,
  RIGHT: 1
};
var Arrow = function Arrow2(_ref) {
  var _classNames;
  var direction = _ref.direction, _onClick = _ref.onClick;
  return import_react11.default.createElement(
    "div",
    {
      className: (0, import_classnames9.default)(styles10.arrow, (_classNames = {}, _classNames[styles10.arrowLeft] = direction === DIRECTIONS.LEFT, _classNames[styles10.arrowRight] = direction === DIRECTIONS.RIGHT, _classNames)),
      onClick: function onClick() {
        return _onClick(direction);
      }
    },
    import_react11.default.createElement(
      "svg",
      {
        x: "0px",
        y: "0px",
        viewBox: "0 0 26 46"
      },
      import_react11.default.createElement("path", { d: "M31.232233,34.767767 C32.2085438,35.7440777 33.7914562,35.7440777 34.767767,34.767767 C35.7440777,33.7914562 35.7440777,32.2085438 34.767767,31.232233 L14.767767,11.232233 C13.7914562,10.2559223 12.2085438,10.2559223 11.232233,11.232233 L-8.767767,31.232233 C-9.7440777,32.2085438 -9.7440777,33.7914562 -8.767767,34.767767 C-7.7914562,35.7440777 -6.2085438,35.7440777 -5.232233,34.767767 L12.9997921,16.5357418 L31.232233,34.767767 Z", id: "Shape", fill: "#FFF", transform: "translate(13.000000, 23.000000) rotate(90.000000) translate(-13.000000, -23.000000) " })
    )
  );
};
var Slider = function(_PureComponent) {
  _inherits9(Slider2, _PureComponent);
  function Slider2() {
    var _temp3, _this, _ret;
    _classCallCheck10(this, Slider2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp3 = (_this = _possibleConstructorReturn9(this, _PureComponent.call.apply(_PureComponent, [this].concat(args))), _this), _this.handleClick = function(direction) {
      var _this$props = _this.props, children = _this$props.children, index = _this$props.index, onChange = _this$props.onChange;
      switch (direction) {
        case DIRECTIONS.LEFT:
          index = Math.max(0, index - 1);
          break;
        case DIRECTIONS.RIGHT:
          index = Math.min(index + 1, children.length);
          break;
        default:
          return;
      }
      onChange(index);
    }, _temp3), _possibleConstructorReturn9(_this, _ret);
  }
  Slider2.prototype.render = function render() {
    var _props = this.props, children = _props.children, index = _props.index;
    return import_react11.default.createElement(
      "div",
      { className: styles10.root },
      index !== 0 && import_react11.default.createElement(Arrow, { onClick: this.handleClick, direction: DIRECTIONS.LEFT }),
      import_react11.default.createElement(
        import_CSSTransitionGroup2.default,
        {
          className: styles10.wrapper,
          component: "div",
          style: {
            transform: "translate3d(-" + 100 * index + "%, 0, 0)"
          },
          transitionName: transition,
          transitionEnterTimeout: 300,
          transitionLeaveTimeout: 300
        },
        import_react11.Children.map(children, function(child, i) {
          return import_react11.default.createElement(
            "div",
            {
              key: i,
              className: styles10.slide,
              style: { transform: "translateX(" + 100 * i + "%)" }
            },
            child
          );
        })
      ),
      index !== children.length - 1 && import_react11.default.createElement(Arrow, { onClick: this.handleClick, direction: DIRECTIONS.RIGHT })
    );
  };
  return Slider2;
}(import_react11.PureComponent);

// node_modules/react-infinite-calendar/es/Header/withMultipleDates.js
var import_parse6 = __toESM(require_parse());
var import_format7 = __toESM(require_format());
var _extends6 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _objectWithoutProperties2(obj, keys) {
  var target = {};
  for (var i in obj) {
    if (keys.indexOf(i) >= 0)
      continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i))
      continue;
    target[i] = obj[i];
  }
  return target;
}
var withMultipleDates_default = withImmutableProps(function(_ref) {
  var renderSelection = _ref.renderSelection, setDisplayDate = _ref.setDisplayDate;
  return {
    renderSelection: function renderSelection2(values, _ref2) {
      var scrollToDate = _ref2.scrollToDate, displayDate = _ref2.displayDate, props = _objectWithoutProperties2(_ref2, ["scrollToDate", "displayDate"]);
      if (!values.length) {
        return null;
      }
      var dates = values.sort();
      var index = values.indexOf((0, import_format7.default)((0, import_parse6.default)(displayDate), "YYYY-MM-DD"));
      return import_react12.default.createElement(
        Slider,
        {
          index: index !== -1 ? index : dates.length - 1,
          onChange: function onChange(index2) {
            return setDisplayDate(dates[index2], function() {
              return setTimeout(function() {
                return scrollToDate(dates[index2], 0, true);
              }, 50);
            });
          }
        },
        dates.map(function(value) {
          return defaultSelectionRenderer(value, _extends6({}, props, {
            key: index,
            scrollToDate,
            shouldAnimate: false
          }));
        })
      );
    }
  };
});

// node_modules/react-infinite-calendar/es/Calendar/withMultipleDates.js
var import_format8 = __toESM(require_format());
var import_parse7 = __toESM(require_parse());
function _objectWithoutProperties3(obj, keys) {
  var target = {};
  for (var i in obj) {
    if (keys.indexOf(i) >= 0)
      continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i))
      continue;
    target[i] = obj[i];
  }
  return target;
}
var enhanceDay3 = (0, import_withPropsOnChange3.default)(["selected"], function(props) {
  return {
    isSelected: props.selected.indexOf(props.date) !== -1
  };
});
var enhanceYears = (0, import_withProps3.default)(function(_ref) {
  var displayDate = _ref.displayDate;
  return {
    selected: displayDate ? (0, import_parse7.default)(displayDate) : null
  };
});
var withMultipleDates = (0, import_compose3.default)(withDefaultProps, (0, import_withState3.default)("scrollDate", "setScrollDate", getInitialDate2), (0, import_withState3.default)("displayDate", "setDisplayDate", getInitialDate2), withImmutableProps(function(_ref2) {
  var DayComponent = _ref2.DayComponent, HeaderComponent = _ref2.HeaderComponent, YearsComponent = _ref2.YearsComponent;
  return {
    DayComponent: enhanceDay3(DayComponent),
    HeaderComponent: withMultipleDates_default(HeaderComponent),
    YearsComponent: enhanceYears(YearsComponent)
  };
}), (0, import_withProps3.default)(function(_ref3) {
  var displayDate = _ref3.displayDate, onSelect = _ref3.onSelect, setDisplayDate = _ref3.setDisplayDate, scrollToDate = _ref3.scrollToDate, props = _objectWithoutProperties3(_ref3, ["displayDate", "onSelect", "setDisplayDate", "scrollToDate"]);
  return {
    passThrough: {
      Day: {
        onClick: function onClick(date) {
          return handleSelect(date, { onSelect, setDisplayDate });
        }
      },
      Header: {
        setDisplayDate
      },
      Years: {
        displayDate,
        onSelect: function onSelect2(year, e, callback) {
          return handleYearSelect2(year, callback);
        },
        selected: displayDate
      }
    },
    selected: props.selected.filter(function(date) {
      return sanitizeDate(date, props);
    }).map(function(date) {
      return (0, import_format8.default)(date, "YYYY-MM-DD");
    })
  };
}));
function handleSelect(date, _ref4) {
  var onSelect = _ref4.onSelect, setDisplayDate = _ref4.setDisplayDate;
  onSelect(date);
  setDisplayDate(date);
}
function handleYearSelect2(date, callback) {
  callback((0, import_parse7.default)(date));
}
function getInitialDate2(_ref5) {
  var selected = _ref5.selected;
  return selected.length ? selected[0] : /* @__PURE__ */ new Date();
}
function defaultMultipleDateInterpolation(date, selected) {
  var selectedMap = selected.map(function(date2) {
    return (0, import_format8.default)(date2, "YYYY-MM-DD");
  });
  var index = selectedMap.indexOf((0, import_format8.default)(date, "YYYY-MM-DD"));
  return index === -1 ? [].concat(selected, [date]) : [].concat(selected.slice(0, index), selected.slice(index + 1));
}

// node_modules/react-infinite-calendar/es/Calendar/withRange.js
var import_withState4 = __toESM(require_withState());
var import_withPropsOnChange4 = __toESM(require_withPropsOnChange());
var import_withProps4 = __toESM(require_withProps());
var import_compose4 = __toESM(require_compose());
var import_classnames10 = __toESM(require_classnames());
var import_is_before4 = __toESM(require_is_before());

// node_modules/react-infinite-calendar/es/Header/withRange.js
var import_react13 = __toESM(require_react());
var _extends7 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var styles11 = {
  "root": "Cal__Header__root",
  "landscape": "Cal__Header__landscape",
  "dateWrapper": "Cal__Header__dateWrapper",
  "day": "Cal__Header__day",
  "wrapper": "Cal__Header__wrapper",
  "blank": "Cal__Header__blank",
  "active": "Cal__Header__active",
  "year": "Cal__Header__year",
  "date": "Cal__Header__date",
  "range": "Cal__Header__range"
};
var withRange_default = withImmutableProps(function(_ref) {
  var renderSelection = _ref.renderSelection;
  return {
    renderSelection: function renderSelection2(values, props) {
      if (!values || !values.start && !values.end) {
        return null;
      }
      if (values.start === values.end) {
        return defaultSelectionRenderer(values.start, props);
      }
      var dateFormat = props.locale && props.locale.headerFormat || "MMM Do";
      return import_react13.default.createElement(
        "div",
        { className: styles11.range, style: { color: props.theme.headerColor } },
        defaultSelectionRenderer(values.start, _extends7({}, props, { dateFormat, key: "start", shouldAnimate: false })),
        defaultSelectionRenderer(values.end, _extends7({}, props, { dateFormat, key: "end", shouldAnimate: false }))
      );
    }
  };
});

// node_modules/react-infinite-calendar/es/Calendar/withRange.js
var import_format9 = __toESM(require_format());
var import_parse8 = __toESM(require_parse());
var _extends8 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
function _objectWithoutProperties4(obj, keys) {
  var target = {};
  for (var i in obj) {
    if (keys.indexOf(i) >= 0)
      continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i))
      continue;
    target[i] = obj[i];
  }
  return target;
}
var styles12 = {
  "root": "Cal__Day__root",
  "enabled": "Cal__Day__enabled",
  "highlighted": "Cal__Day__highlighted",
  "today": "Cal__Day__today",
  "disabled": "Cal__Day__disabled",
  "selected": "Cal__Day__selected",
  "month": "Cal__Day__month",
  "year": "Cal__Day__year",
  "selection": "Cal__Day__selection",
  "day": "Cal__Day__day",
  "range": "Cal__Day__range",
  "start": "Cal__Day__start",
  "end": "Cal__Day__end",
  "betweenRange": "Cal__Day__betweenRange"
};
var isTouchDevice = false;
var EVENT_TYPE = {
  END: 3,
  HOVER: 2,
  START: 1
};
var enhanceDay4 = (0, import_withPropsOnChange4.default)(["selected"], function(_ref) {
  var _classNames;
  var date = _ref.date, selected = _ref.selected, theme = _ref.theme;
  var isSelected = date >= selected.start && date <= selected.end;
  var isStart = date === selected.start;
  var isEnd = date === selected.end;
  var isRange = !(isStart && isEnd);
  var style = isRange && (isStart && { backgroundColor: theme.accentColor } || isEnd && { borderColor: theme.accentColor });
  return {
    className: isSelected && isRange && (0, import_classnames10.default)(styles12.range, (_classNames = {}, _classNames[styles12.start] = isStart, _classNames[styles12.betweenRange] = !isStart && !isEnd, _classNames[styles12.end] = isEnd, _classNames)),
    isSelected,
    selectionStyle: style
  };
});
var withRange = (0, import_compose4.default)(withDefaultProps, (0, import_withState4.default)("scrollDate", "setScrollDate", getInitialDate3), (0, import_withState4.default)("displayKey", "setDisplayKey", getInitialDate3), (0, import_withState4.default)("selectionStart", "setSelectionStart", null), withImmutableProps(function(_ref2) {
  var DayComponent = _ref2.DayComponent, HeaderComponent = _ref2.HeaderComponent, YearsComponent = _ref2.YearsComponent;
  return {
    DayComponent: enhanceDay4(DayComponent),
    HeaderComponent: withRange_default(HeaderComponent)
  };
}), (0, import_withProps4.default)(function(_ref3) {
  var displayKey = _ref3.displayKey, passThrough = _ref3.passThrough, selected = _ref3.selected, setDisplayKey = _ref3.setDisplayKey, props = _objectWithoutProperties4(_ref3, ["displayKey", "passThrough", "selected", "setDisplayKey"]);
  return {
    /* eslint-disable sort-keys */
    passThrough: _extends8({}, passThrough, {
      Day: {
        onClick: function onClick(date) {
          return handleSelect2(date, _extends8({ selected }, props));
        },
        handlers: {
          onMouseOver: !isTouchDevice && props.selectionStart ? function(e) {
            return handleMouseOver(e, _extends8({ selected }, props));
          } : null
        }
      },
      Years: {
        selected: selected && selected[displayKey],
        onSelect: function onSelect(date) {
          return handleYearSelect3(date, _extends8({ displayKey, selected }, props));
        }
      },
      Header: {
        onYearClick: function onYearClick(date, e, key) {
          return setDisplayKey(key || "start");
        }
      }
    }),
    selected: {
      start: selected && (0, import_format9.default)(selected.start, "YYYY-MM-DD"),
      end: selected && (0, import_format9.default)(selected.end, "YYYY-MM-DD")
    }
  };
}));
function getSortedSelection(_ref4) {
  var start = _ref4.start, end = _ref4.end;
  return (0, import_is_before4.default)(start, end) ? { start, end } : { start: end, end: start };
}
function handleSelect2(date, _ref5) {
  var onSelect = _ref5.onSelect, selected = _ref5.selected, selectionStart = _ref5.selectionStart, setSelectionStart = _ref5.setSelectionStart;
  if (selectionStart) {
    onSelect(_extends8({
      eventType: EVENT_TYPE.END
    }, getSortedSelection({
      start: selectionStart,
      end: date
    })));
    setSelectionStart(null);
  } else {
    onSelect({ eventType: EVENT_TYPE.START, start: date, end: date });
    setSelectionStart(date);
  }
}
function handleMouseOver(e, _ref6) {
  var onSelect = _ref6.onSelect, selectionStart = _ref6.selectionStart;
  var dateStr = e.target.getAttribute("data-date");
  var date = dateStr && (0, import_parse8.default)(dateStr);
  if (!date) {
    return;
  }
  onSelect(_extends8({
    eventType: EVENT_TYPE.HOVER
  }, getSortedSelection({
    start: selectionStart,
    end: date
  })));
}
function handleYearSelect3(date, _ref7) {
  var _Object$assign;
  var displayKey = _ref7.displayKey, onSelect = _ref7.onSelect, selected = _ref7.selected, setScrollDate = _ref7.setScrollDate;
  setScrollDate(date);
  onSelect(getSortedSelection(Object.assign({}, selected, (_Object$assign = {}, _Object$assign[displayKey] = (0, import_parse8.default)(date), _Object$assign))));
}
function getInitialDate3(_ref8) {
  var selected = _ref8.selected;
  return selected && selected.start || /* @__PURE__ */ new Date();
}
if (typeof window !== "undefined") {
  window.addEventListener("touchstart", function onTouch() {
    isTouchDevice = true;
    window.removeEventListener("touchstart", onTouch, false);
  });
}

// node_modules/react-infinite-calendar/es/index.js
var _extends9 = Object.assign || function(target) {
  for (var i = 1; i < arguments.length; i++) {
    var source = arguments[i];
    for (var key in source) {
      if (Object.prototype.hasOwnProperty.call(source, key)) {
        target[key] = source[key];
      }
    }
  }
  return target;
};
var _class3;
var _temp22;
function _objectWithoutProperties5(obj, keys) {
  var target = {};
  for (var i in obj) {
    if (keys.indexOf(i) >= 0)
      continue;
    if (!Object.prototype.hasOwnProperty.call(obj, i))
      continue;
    target[i] = obj[i];
  }
  return target;
}
function _classCallCheck11(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}
function _possibleConstructorReturn10(self, call) {
  if (!self) {
    throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  }
  return call && (typeof call === "object" || typeof call === "function") ? call : self;
}
function _inherits10(subClass, superClass) {
  if (typeof superClass !== "function" && superClass !== null) {
    throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
  }
  subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } });
  if (superClass)
    Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
}
var DefaultCalendar = (_temp22 = _class3 = function(_Component) {
  _inherits10(DefaultCalendar2, _Component);
  function DefaultCalendar2() {
    var _temp3, _this, _ret;
    _classCallCheck11(this, DefaultCalendar2);
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    return _ret = (_temp3 = (_this = _possibleConstructorReturn10(this, _Component.call.apply(_Component, [this].concat(args))), _this), _this.state = {
      selected: typeof _this.props.selected !== "undefined" ? _this.props.selected : /* @__PURE__ */ new Date()
    }, _this.handleSelect = function(selected) {
      var _this$props = _this.props, onSelect = _this$props.onSelect, interpolateSelection2 = _this$props.interpolateSelection;
      if (typeof onSelect === "function") {
        onSelect(selected);
      }
      _this.setState({ selected: interpolateSelection2(selected, _this.state.selected) });
    }, _temp3), _possibleConstructorReturn10(_this, _ret);
  }
  DefaultCalendar2.prototype.componentWillReceiveProps = function componentWillReceiveProps(_ref) {
    var selected = _ref.selected;
    if (selected !== this.props.selected) {
      this.setState({ selected });
    }
  };
  DefaultCalendar2.prototype.render = function render() {
    var _props = this.props, Component5 = _props.Component, interpolateSelection2 = _props.interpolateSelection, props = _objectWithoutProperties5(_props, ["Component", "interpolateSelection"]);
    return import_react14.default.createElement(Component5, _extends9({}, props, {
      onSelect: this.handleSelect,
      selected: this.state.selected
    }));
  };
  return DefaultCalendar2;
}(import_react14.Component), _class3.defaultProps = {
  Component: withDateSelection(Calendar),
  interpolateSelection: function interpolateSelection(selected) {
    return selected;
  }
}, _temp22);
export {
  Calendar,
  EVENT_TYPE,
  DefaultCalendar as default,
  defaultMultipleDateInterpolation,
  withDateSelection,
  withKeyboardSupport,
  withMultipleDates,
  withRange
};
/*! Bundled license information:

classnames/index.js:
  (*!
  	Copyright (c) 2018 Jed Watson.
  	Licensed under the MIT License (MIT), see
  	http://jedwatson.github.io/classnames
  *)

react-tiny-virtual-list/build/react-tiny-virtual-list.es.js:
  (*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0
  
  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.
  
  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** *)
*/
//# sourceMappingURL=react-infinite-calendar.js.map
