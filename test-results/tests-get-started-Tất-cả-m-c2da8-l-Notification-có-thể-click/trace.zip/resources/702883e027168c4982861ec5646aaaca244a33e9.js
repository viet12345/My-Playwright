import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SvgUndrawPersonalFinanceTqcd.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function SvgUndrawPersonalFinanceTqcd(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      "data-name": "Layer 1",
      xmlns: "http://www.w3.org/2000/svg",
      width: "784.39764",
      height: "733.6066",
      viewBox: "0 0 784.398 733.607",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M624.745 521.218s97.04 5.017 74.437 35.565-81.994-17.92-81.994-17.92z",
            fill: "#ffb8b8"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 13,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M445.916 230.251l19.752 4.938s11.522 34.567 19.752 65.84 24.69 125.097 24.69 125.097l127.61 89.433-15.22 34.048-170-67-37.859-148.657z",
            fill: "#575a89"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 17,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { opacity: 0.2, d: "M464.5 291.607l-7.362 154.165 15.362 45.835-45-33 37-167z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 21,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M491.18 565.214s21.399 57.61 24.69 97.114 6.585 70.779 6.585 70.779H422.048l-19.752-29.629v29.629H285.43s-32.92-106.99-19.752-120.159 138.264-69.132 138.264-69.132z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 22,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M101.5 731.607h581v2h-581z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 26,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 365.261, cy: 105.155, r: 62.548, fill: "#ffb8b8" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M317.527 131.491l-4.938 72.424 62.548 83.947 31.274-79.009s-27.982-18.106-11.522-55.964z",
            fill: "#ffb8b8"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 28,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M500.23 579.203c0 14.82-41.15 37.86-41.15 37.86v8.23l-16.46 8.23-36.21-72.42-9.87 79s-72.43 11.53-95.47 0c-23.05-11.52-34.57-6.58-67.49-18.1s13.17-166.25 13.17-166.25l-32.92-238.67 71.92-35.96 3.79-1.9 9.89-1.82 15.16-2.8 50.67 34.25 4.08 21.4 2.51 13.17 13.16-14.82 9.94-32.69 70.72 39.28-19.75 158.01s54.31 171.19 54.31 186z",
            fill: "#575a89"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 32,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M258.27 630.231s75.717 60.902 39.505 72.424-55.964-62.548-55.964-62.548z",
            fill: "#ffb8b8"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 36,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M230.289 220.375l-16.46-3.292s-24.69 13.168-26.337 39.505-23.044 210.688-23.044 210.688l69.133 186 55.964-21.399L235.227 457.4l41.15-151.432z",
            fill: "#575a89"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 40,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 372.5, cy: 264.607, r: 6, fill: "#2f2e41" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 44,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 372.5, cy: 303.607, r: 6, fill: "#2f2e41" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 45,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 406.5, cy: 560.607, r: 6, fill: "#2f2e41" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 46,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M312.452 41.077l-11.562-4.629s24.176-26.616 57.812-24.302l-9.46-10.415s23.125-9.258 44.147 15.044c11.051 12.775 23.838 27.791 31.808 44.707h12.383l-5.168 11.38L450.5 84.24l-18.566-2.044a63.589 63.589 0 01.504 18.874 24.421 24.421 0 01-8.943 15.976s-14.34-29.68-14.34-34.31V94.31s-11.562-10.415-11.562-17.358l-6.306 8.1h-42.045l6.307-10.414-24.176 3.471 9.46-12.73-37.431 52.566s-21.432-59.509 9.05-76.867z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 47,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 684.398, cy: 383.545, r: 100, fill: "#3f3d56" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 51,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 684.398, cy: 383.545, r: 86, opacity: 0.1 }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 52,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M680.277 434.293v-12.517c-6.328-.124-12.873-2.355-16.691-5.453l2.618-8.303a26.681 26.681 0 0015.71 5.328c7.745 0 12.981-5.08 12.981-12.145 0-6.816-4.254-11.03-12.327-14.748-11.128-4.957-18-10.658-18-21.44 0-10.286 6.436-18.094 16.473-19.953v-12.517h6.763v12.022a26.543 26.543 0 0114.182 4.337l-2.727 8.18a24.107 24.107 0 00-13.746-4.214c-8.4 0-11.564 5.7-11.564 10.658 0 6.444 4.037 9.666 13.528 14.128 11.236 5.205 16.91 11.65 16.91 22.68 0 9.79-6 18.961-17.237 21.067v12.89z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 53,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { opacity: 0.2, d: "M250.005 504.87L290 629.803l-32-130-7.995 5.067z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 57,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M46.093 260.803H20.707a4.178 4.178 0 01-4.174-4.173v-36.493a4.178 4.178 0 014.174-4.174h25.386a4.178 4.178 0 014.174 4.174v36.493a4.178 4.178 0 01-4.174 4.173zm-25.386-42.84a2.176 2.176 0 00-2.174 2.174v36.493a2.176 2.176 0 002.174 2.173h25.386a2.176 2.176 0 002.174-2.173v-36.493a2.176 2.176 0 00-2.174-2.174zM92.463 260.803H69.537a5.41 5.41 0 01-5.404-5.404V181.7a5.41 5.41 0 015.404-5.404h22.926a5.41 5.41 0 015.404 5.404v73.7a5.41 5.41 0 01-5.404 5.403zm-22.926-82.507a3.408 3.408 0 00-3.404 3.404v73.7a3.408 3.408 0 003.404 3.403h22.926a3.408 3.408 0 003.404-3.404V181.7a3.408 3.408 0 00-3.404-3.404zM139.178 260.803h-21.156a6.296 6.296 0 01-6.289-6.289V146.092a6.296 6.296 0 016.29-6.289h21.155a6.296 6.296 0 016.289 6.29v108.421a6.296 6.296 0 01-6.29 6.29zm-21.156-119a4.294 4.294 0 00-4.289 4.29v108.421a4.294 4.294 0 004.29 4.29h21.155a4.294 4.294 0 004.289-4.29V146.092a4.294 4.294 0 00-4.29-4.289z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 58,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            d: "M23.88 222.913h19.04v30.94H23.88zM71.48 183.643h19.04v70.21H71.48zM119.08 147.15h19.04v106.703h-19.04z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 62,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M723 145.803H590a1 1 0 01-1-1v-135a1 1 0 012 0v134h132a1 1 0 010 2zM159 274.803H1a1 1 0 01-1-1v-157a1 1 0 012 0v156h157a1 1 0 010 2z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 66,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M635.898 133.27h-25.386a4.178 4.178 0 01-4.174-4.173V92.604a4.178 4.178 0 014.174-4.173h25.386a4.178 4.178 0 014.173 4.173v36.493a4.178 4.178 0 01-4.173 4.174zm-25.386-42.84a2.176 2.176 0 00-2.174 2.174v36.493a2.176 2.176 0 002.174 2.174h25.386a2.176 2.176 0 002.173-2.174V92.604a2.176 2.176 0 00-2.173-2.173zM687.888 133.27H664.52a5.19 5.19 0 01-5.183-5.184v-66.1a5.19 5.19 0 015.183-5.183h23.367a5.19 5.19 0 015.183 5.184v66.1a5.19 5.19 0 01-5.183 5.184zM664.52 58.804a3.187 3.187 0 00-3.183 3.184v66.1a3.187 3.187 0 003.183 3.184h23.367a3.187 3.187 0 003.183-3.185v-66.1a3.187 3.187 0 00-3.183-3.183z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 70,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f51b5",
            d: "M613.228 95.727h19.04v30.94h-19.04zM666.685 65.105h19.04v59.864h-19.04z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
            lineNumber: 74,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 623, cy: 68.803, r: 9, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 78,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 676, cy: 34.803, r: 9, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
          lineNumber: 79,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = SvgUndrawPersonalFinanceTqcd;
export default SvgUndrawPersonalFinanceTqcd;
var _c;
$RefreshReg$(_c, "SvgUndrawPersonalFinanceTqcd");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawPersonalFinanceTqcd.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFOUIsU0FBU0EsNkJBQTZCQyxPQUFZO0FBQ2hELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLEdBQUlBO0FBQUFBLE1BRUo7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQix1QkFBQyxVQUFLLFNBQVMsS0FBSyxHQUFFLCtEQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSxnQ0FBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFtRDtBQUFBLFFBQ25ELHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsWUFBTyxJQUFJLE9BQU8sSUFBSSxTQUFTLEdBQUcsR0FBRyxNQUFLLGFBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0Q7QUFBQSxRQUNwRCx1QkFBQyxZQUFPLElBQUksT0FBTyxJQUFJLFNBQVMsR0FBRyxHQUFHLE1BQUssYUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvRDtBQUFBLFFBQ3BELHVCQUFDLFlBQU8sSUFBSSxPQUFPLElBQUksU0FBUyxHQUFHLEdBQUcsTUFBSyxhQUEzQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW9EO0FBQUEsUUFDcEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsWUFBTyxJQUFJLFNBQVMsSUFBSSxTQUFTLEdBQUcsS0FBSyxNQUFLLGFBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Q7QUFBQSxRQUN4RCx1QkFBQyxZQUFPLElBQUksU0FBUyxJQUFJLFNBQVMsR0FBRyxJQUFJLFNBQVMsT0FBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFzRDtBQUFBLFFBQ3REO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCLHVCQUFDLFVBQUssU0FBUyxLQUFLLEdBQUUsc0RBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFNEc7QUFBQSxRQUU1RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFNkU7QUFBQSxRQUU3RSx1QkFBQyxZQUFPLElBQUksS0FBSyxJQUFJLFFBQVEsR0FBRyxHQUFHLE1BQUssYUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRDtBQUFBLFFBQ2pELHVCQUFDLFlBQU8sSUFBSSxLQUFLLElBQUksUUFBUSxHQUFHLEdBQUcsTUFBSyxhQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlEO0FBQUE7QUFBQTtBQUFBLElBMUVuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUEyRUE7QUFFSjtBQUFDQyxLQS9FUUY7QUFpRlQsZUFBZUE7QUFBNkIsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlN2Z1VuZHJhd1BlcnNvbmFsRmluYW5jZVRxY2QiLCJwcm9wcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3ZnVW5kcmF3UGVyc29uYWxGaW5hbmNlVHFjZC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICogYXMgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcblxyXG5mdW5jdGlvbiBTdmdVbmRyYXdQZXJzb25hbEZpbmFuY2VUcWNkKHByb3BzOiBhbnkpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2Z1xyXG4gICAgICBkYXRhLW5hbWU9XCJMYXllciAxXCJcclxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgIHdpZHRoPVwiNzg0LjM5NzY0XCJcclxuICAgICAgaGVpZ2h0PVwiNzMzLjYwNjZcIlxyXG4gICAgICB2aWV3Qm94PVwiMCAwIDc4NC4zOTggNzMzLjYwN1wiXHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgID5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTYyNC43NDUgNTIxLjIxOHM5Ny4wNCA1LjAxNyA3NC40MzcgMzUuNTY1LTgxLjk5NC0xNy45Mi04MS45OTQtMTcuOTJ6XCJcclxuICAgICAgICBmaWxsPVwiI2ZmYjhiOFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk00NDUuOTE2IDIzMC4yNTFsMTkuNzUyIDQuOTM4czExLjUyMiAzNC41NjcgMTkuNzUyIDY1Ljg0IDI0LjY5IDEyNS4wOTcgMjQuNjkgMTI1LjA5N2wxMjcuNjEgODkuNDMzLTE1LjIyIDM0LjA0OC0xNzAtNjctMzcuODU5LTE0OC42NTd6XCJcclxuICAgICAgICBmaWxsPVwiIzU3NWE4OVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoIG9wYWNpdHk9ezAuMn0gZD1cIk00NjQuNSAyOTEuNjA3bC03LjM2MiAxNTQuMTY1IDE1LjM2MiA0NS44MzUtNDUtMzMgMzctMTY3elwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk00OTEuMTggNTY1LjIxNHMyMS4zOTkgNTcuNjEgMjQuNjkgOTcuMTE0IDYuNTg1IDcwLjc3OSA2LjU4NSA3MC43NzlINDIyLjA0OGwtMTkuNzUyLTI5LjYyOXYyOS42MjlIMjg1LjQzcy0zMi45Mi0xMDYuOTktMTkuNzUyLTEyMC4xNTkgMTM4LjI2NC02OS4xMzIgMTM4LjI2NC02OS4xMzJ6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoIGZpbGw9XCIjM2YzZDU2XCIgZD1cIk0xMDEuNSA3MzEuNjA3aDU4MXYyaC01ODF6XCIgLz5cclxuICAgICAgPGNpcmNsZSBjeD17MzY1LjI2MX0gY3k9ezEwNS4xNTV9IHI9ezYyLjU0OH0gZmlsbD1cIiNmZmI4YjhcIiAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMzE3LjUyNyAxMzEuNDkxbC00LjkzOCA3Mi40MjQgNjIuNTQ4IDgzLjk0NyAzMS4yNzQtNzkuMDA5cy0yNy45ODItMTguMTA2LTExLjUyMi01NS45NjR6XCJcclxuICAgICAgICBmaWxsPVwiI2ZmYjhiOFwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01MDAuMjMgNTc5LjIwM2MwIDE0LjgyLTQxLjE1IDM3Ljg2LTQxLjE1IDM3Ljg2djguMjNsLTE2LjQ2IDguMjMtMzYuMjEtNzIuNDItOS44NyA3OXMtNzIuNDMgMTEuNTMtOTUuNDcgMGMtMjMuMDUtMTEuNTItMzQuNTctNi41OC02Ny40OS0xOC4xczEzLjE3LTE2Ni4yNSAxMy4xNy0xNjYuMjVsLTMyLjkyLTIzOC42NyA3MS45Mi0zNS45NiAzLjc5LTEuOSA5Ljg5LTEuODIgMTUuMTYtMi44IDUwLjY3IDM0LjI1IDQuMDggMjEuNCAyLjUxIDEzLjE3IDEzLjE2LTE0LjgyIDkuOTQtMzIuNjkgNzAuNzIgMzkuMjgtMTkuNzUgMTU4LjAxczU0LjMxIDE3MS4xOSA1NC4zMSAxODZ6XCJcclxuICAgICAgICBmaWxsPVwiIzU3NWE4OVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0yNTguMjcgNjMwLjIzMXM3NS43MTcgNjAuOTAyIDM5LjUwNSA3Mi40MjQtNTUuOTY0LTYyLjU0OC01NS45NjQtNjIuNTQ4elwiXHJcbiAgICAgICAgZmlsbD1cIiNmZmI4YjhcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMjMwLjI4OSAyMjAuMzc1bC0xNi40Ni0zLjI5MnMtMjQuNjkgMTMuMTY4LTI2LjMzNyAzOS41MDUtMjMuMDQ0IDIxMC42ODgtMjMuMDQ0IDIxMC42ODhsNjkuMTMzIDE4NiA1NS45NjQtMjEuMzk5TDIzNS4yMjcgNDU3LjRsNDEuMTUtMTUxLjQzMnpcIlxyXG4gICAgICAgIGZpbGw9XCIjNTc1YTg5XCJcclxuICAgICAgLz5cclxuICAgICAgPGNpcmNsZSBjeD17MzcyLjV9IGN5PXsyNjQuNjA3fSByPXs2fSBmaWxsPVwiIzJmMmU0MVwiIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezM3Mi41fSBjeT17MzAzLjYwN30gcj17Nn0gZmlsbD1cIiMyZjJlNDFcIiAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PXs0MDYuNX0gY3k9ezU2MC42MDd9IHI9ezZ9IGZpbGw9XCIjMmYyZTQxXCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTMxMi40NTIgNDEuMDc3bC0xMS41NjItNC42MjlzMjQuMTc2LTI2LjYxNiA1Ny44MTItMjQuMzAybC05LjQ2LTEwLjQxNXMyMy4xMjUtOS4yNTggNDQuMTQ3IDE1LjA0NGMxMS4wNTEgMTIuNzc1IDIzLjgzOCAyNy43OTEgMzEuODA4IDQ0LjcwN2gxMi4zODNsLTUuMTY4IDExLjM4TDQ1MC41IDg0LjI0bC0xOC41NjYtMi4wNDRhNjMuNTg5IDYzLjU4OSAwIDAxLjUwNCAxOC44NzQgMjQuNDIxIDI0LjQyMSAwIDAxLTguOTQzIDE1Ljk3NnMtMTQuMzQtMjkuNjgtMTQuMzQtMzQuMzFWOTQuMzFzLTExLjU2Mi0xMC40MTUtMTEuNTYyLTE3LjM1OGwtNi4zMDYgOC4xaC00Mi4wNDVsNi4zMDctMTAuNDE0LTI0LjE3NiAzLjQ3MSA5LjQ2LTEyLjczLTM3LjQzMSA1Mi41NjZzLTIxLjQzMi01OS41MDkgOS4wNS03Ni44Njd6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezY4NC4zOTh9IGN5PXszODMuNTQ1fSByPXsxMDB9IGZpbGw9XCIjM2YzZDU2XCIgLz5cclxuICAgICAgPGNpcmNsZSBjeD17Njg0LjM5OH0gY3k9ezM4My41NDV9IHI9ezg2fSBvcGFjaXR5PXswLjF9IC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk02ODAuMjc3IDQzNC4yOTN2LTEyLjUxN2MtNi4zMjgtLjEyNC0xMi44NzMtMi4zNTUtMTYuNjkxLTUuNDUzbDIuNjE4LTguMzAzYTI2LjY4MSAyNi42ODEgMCAwMDE1LjcxIDUuMzI4YzcuNzQ1IDAgMTIuOTgxLTUuMDggMTIuOTgxLTEyLjE0NSAwLTYuODE2LTQuMjU0LTExLjAzLTEyLjMyNy0xNC43NDgtMTEuMTI4LTQuOTU3LTE4LTEwLjY1OC0xOC0yMS40NCAwLTEwLjI4NiA2LjQzNi0xOC4wOTQgMTYuNDczLTE5Ljk1M3YtMTIuNTE3aDYuNzYzdjEyLjAyMmEyNi41NDMgMjYuNTQzIDAgMDExNC4xODIgNC4zMzdsLTIuNzI3IDguMThhMjQuMTA3IDI0LjEwNyAwIDAwLTEzLjc0Ni00LjIxNGMtOC40IDAtMTEuNTY0IDUuNy0xMS41NjQgMTAuNjU4IDAgNi40NDQgNC4wMzcgOS42NjYgMTMuNTI4IDE0LjEyOCAxMS4yMzYgNS4yMDUgMTYuOTEgMTEuNjUgMTYuOTEgMjIuNjggMCA5Ljc5LTYgMTguOTYxLTE3LjIzNyAyMS4wNjd2MTIuODl6XCJcclxuICAgICAgICBmaWxsPVwiIzNmNTFiNVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoIG9wYWNpdHk9ezAuMn0gZD1cIk0yNTAuMDA1IDUwNC44N0wyOTAgNjI5LjgwM2wtMzItMTMwLTcuOTk1IDUuMDY3elwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk00Ni4wOTMgMjYwLjgwM0gyMC43MDdhNC4xNzggNC4xNzggMCAwMS00LjE3NC00LjE3M3YtMzYuNDkzYTQuMTc4IDQuMTc4IDAgMDE0LjE3NC00LjE3NGgyNS4zODZhNC4xNzggNC4xNzggMCAwMTQuMTc0IDQuMTc0djM2LjQ5M2E0LjE3OCA0LjE3OCAwIDAxLTQuMTc0IDQuMTczem0tMjUuMzg2LTQyLjg0YTIuMTc2IDIuMTc2IDAgMDAtMi4xNzQgMi4xNzR2MzYuNDkzYTIuMTc2IDIuMTc2IDAgMDAyLjE3NCAyLjE3M2gyNS4zODZhMi4xNzYgMi4xNzYgMCAwMDIuMTc0LTIuMTczdi0zNi40OTNhMi4xNzYgMi4xNzYgMCAwMC0yLjE3NC0yLjE3NHpNOTIuNDYzIDI2MC44MDNINjkuNTM3YTUuNDEgNS40MSAwIDAxLTUuNDA0LTUuNDA0VjE4MS43YTUuNDEgNS40MSAwIDAxNS40MDQtNS40MDRoMjIuOTI2YTUuNDEgNS40MSAwIDAxNS40MDQgNS40MDR2NzMuN2E1LjQxIDUuNDEgMCAwMS01LjQwNCA1LjQwM3ptLTIyLjkyNi04Mi41MDdhMy40MDggMy40MDggMCAwMC0zLjQwNCAzLjQwNHY3My43YTMuNDA4IDMuNDA4IDAgMDAzLjQwNCAzLjQwM2gyMi45MjZhMy40MDggMy40MDggMCAwMDMuNDA0LTMuNDA0VjE4MS43YTMuNDA4IDMuNDA4IDAgMDAtMy40MDQtMy40MDR6TTEzOS4xNzggMjYwLjgwM2gtMjEuMTU2YTYuMjk2IDYuMjk2IDAgMDEtNi4yODktNi4yODlWMTQ2LjA5MmE2LjI5NiA2LjI5NiAwIDAxNi4yOS02LjI4OWgyMS4xNTVhNi4yOTYgNi4yOTYgMCAwMTYuMjg5IDYuMjl2MTA4LjQyMWE2LjI5NiA2LjI5NiAwIDAxLTYuMjkgNi4yOXptLTIxLjE1Ni0xMTlhNC4yOTQgNC4yOTQgMCAwMC00LjI4OSA0LjI5djEwOC40MjFhNC4yOTQgNC4yOTQgMCAwMDQuMjkgNC4yOWgyMS4xNTVhNC4yOTQgNC4yOTQgMCAwMDQuMjg5LTQuMjlWMTQ2LjA5MmE0LjI5NCA0LjI5NCAwIDAwLTQuMjktNC4yODl6XCJcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiMzZjUxYjVcIlxyXG4gICAgICAgIGQ9XCJNMjMuODggMjIyLjkxM2gxOS4wNHYzMC45NEgyMy44OHpNNzEuNDggMTgzLjY0M2gxOS4wNHY3MC4yMUg3MS40OHpNMTE5LjA4IDE0Ny4xNWgxOS4wNHYxMDYuNzAzaC0xOS4wNHpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNzIzIDE0NS44MDNINTkwYTEgMSAwIDAxLTEtMXYtMTM1YTEgMSAwIDAxMiAwdjEzNGgxMzJhMSAxIDAgMDEwIDJ6TTE1OSAyNzQuODAzSDFhMSAxIDAgMDEtMS0xdi0xNTdhMSAxIDAgMDEyIDB2MTU2aDE1N2ExIDEgMCAwMTAgMnpcIlxyXG4gICAgICAgIGZpbGw9XCIjM2YzZDU2XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTYzNS44OTggMTMzLjI3aC0yNS4zODZhNC4xNzggNC4xNzggMCAwMS00LjE3NC00LjE3M1Y5Mi42MDRhNC4xNzggNC4xNzggMCAwMTQuMTc0LTQuMTczaDI1LjM4NmE0LjE3OCA0LjE3OCAwIDAxNC4xNzMgNC4xNzN2MzYuNDkzYTQuMTc4IDQuMTc4IDAgMDEtNC4xNzMgNC4xNzR6bS0yNS4zODYtNDIuODRhMi4xNzYgMi4xNzYgMCAwMC0yLjE3NCAyLjE3NHYzNi40OTNhMi4xNzYgMi4xNzYgMCAwMDIuMTc0IDIuMTc0aDI1LjM4NmEyLjE3NiAyLjE3NiAwIDAwMi4xNzMtMi4xNzRWOTIuNjA0YTIuMTc2IDIuMTc2IDAgMDAtMi4xNzMtMi4xNzN6TTY4Ny44ODggMTMzLjI3SDY2NC41MmE1LjE5IDUuMTkgMCAwMS01LjE4My01LjE4NHYtNjYuMWE1LjE5IDUuMTkgMCAwMTUuMTgzLTUuMTgzaDIzLjM2N2E1LjE5IDUuMTkgMCAwMTUuMTgzIDUuMTg0djY2LjFhNS4xOSA1LjE5IDAgMDEtNS4xODMgNS4xODR6TTY2NC41MiA1OC44MDRhMy4xODcgMy4xODcgMCAwMC0zLjE4MyAzLjE4NHY2Ni4xYTMuMTg3IDMuMTg3IDAgMDAzLjE4MyAzLjE4NGgyMy4zNjdhMy4xODcgMy4xODcgMCAwMDMuMTgzLTMuMTg1di02Ni4xYTMuMTg3IDMuMTg3IDAgMDAtMy4xODMtMy4xODN6XCJcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiMzZjUxYjVcIlxyXG4gICAgICAgIGQ9XCJNNjEzLjIyOCA5NS43MjdoMTkuMDR2MzAuOTRoLTE5LjA0ek02NjYuNjg1IDY1LjEwNWgxOS4wNHY1OS44NjRoLTE5LjA0elwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezYyM30gY3k9ezY4LjgwM30gcj17OX0gZmlsbD1cIiMzZjUxYjVcIiAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PXs2NzZ9IGN5PXszNC44MDN9IHI9ezl9IGZpbGw9XCIjM2Y1MWI1XCIgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN2Z1VuZHJhd1BlcnNvbmFsRmluYW5jZVRxY2Q7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvU3ZnVW5kcmF3UGVyc29uYWxGaW5hbmNlVHFjZC50c3gifQ==