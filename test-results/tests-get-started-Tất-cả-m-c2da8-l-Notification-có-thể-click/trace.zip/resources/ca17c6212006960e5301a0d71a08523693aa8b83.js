import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommentList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { List } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import CommentListItem from "/src/components/CommentListItem.tsx";
const CommentsList = ({ comments }) => {
  return /* @__PURE__ */ jsxDEV(List, { "data-test": "comments-list", children: comments && comments.map((comment) => /* @__PURE__ */ jsxDEV(CommentListItem, { comment }, comment.id, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentList.tsx",
    lineNumber: 15,
    columnNumber: 42
  }, this)) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentList.tsx",
    lineNumber: 13,
    columnNumber: 5
  }, this);
};
_c = CommentsList;
export default CommentsList;
var _c;
$RefreshReg$(_c, "CommentsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYzJDO0FBZDNDLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsWUFBWTtBQUVyQixPQUFPQyxxQkFBcUI7QUFPNUIsTUFBTUMsZUFBNENBLENBQUMsRUFBRUMsU0FBUyxNQUFNO0FBQ2xFLFNBQ0UsdUJBQUMsUUFBSyxhQUFVLGlCQUNiQSxzQkFDQ0EsU0FBU0MsSUFBSSxDQUFDQyxZQUFxQix1QkFBQyxtQkFBaUMsV0FBWkEsUUFBUUMsSUFBOUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFtRCxDQUFHLEtBRjdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUVDLEtBUElMO0FBU04sZUFBZUE7QUFBYSxJQUFBSztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaXN0IiwiQ29tbWVudExpc3RJdGVtIiwiQ29tbWVudHNMaXN0IiwiY29tbWVudHMiLCJtYXAiLCJjb21tZW50IiwiaWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkNvbW1lbnRMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpc3QgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IENvbW1lbnRMaXN0SXRlbSBmcm9tIFwiLi9Db21tZW50TGlzdEl0ZW1cIjtcclxuaW1wb3J0IHsgQ29tbWVudCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWVudHNMaXN0UHJvcHMge1xyXG4gIGNvbW1lbnRzOiBDb21tZW50W107XHJcbn1cclxuXHJcbmNvbnN0IENvbW1lbnRzTGlzdDogUmVhY3QuRkM8Q29tbWVudHNMaXN0UHJvcHM+ID0gKHsgY29tbWVudHMgfSkgPT4ge1xyXG4gIHJldHVybiAoXHJcbiAgICA8TGlzdCBkYXRhLXRlc3Q9XCJjb21tZW50cy1saXN0XCI+XHJcbiAgICAgIHtjb21tZW50cyAmJlxyXG4gICAgICAgIGNvbW1lbnRzLm1hcCgoY29tbWVudDogQ29tbWVudCkgPT4gPENvbW1lbnRMaXN0SXRlbSBrZXk9e2NvbW1lbnQuaWR9IGNvbW1lbnQ9e2NvbW1lbnR9IC8+KX1cclxuICAgIDwvTGlzdD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29tbWVudHNMaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL0NvbW1lbnRMaXN0LnRzeCJ9