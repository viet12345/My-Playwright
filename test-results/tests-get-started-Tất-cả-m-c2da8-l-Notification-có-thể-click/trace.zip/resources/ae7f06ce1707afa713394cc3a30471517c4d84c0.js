import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionNavTabs.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { Tabs, Tab } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Link, useRouteMatch } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
export default function TransactionNavTabs() {
  _s();
  const match = useRouteMatch();
  const navUrls = {
    "/": 0,
    "/public": 0,
    "/contacts": 1,
    "/personal": 2
  };
  const [value, setValue] = React.useState(navUrls[match.url]);
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };
  return /* @__PURE__ */ jsxDEV(
    Tabs,
    {
      value,
      onChange: handleChange,
      indicatorColor: "secondary",
      textColor: "inherit",
      centered: true,
      "data-test": "nav-transaction-tabs",
      children: [
        /* @__PURE__ */ jsxDEV(Tab, { label: "Everyone", component: Link, to: "/", "data-test": "nav-public-tab" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx",
          lineNumber: 32,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Tab, { label: "Friends", component: Link, to: "/contacts", "data-test": "nav-contacts-tab" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx",
          lineNumber: 33,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Tab, { label: "Mine", component: Link, to: "/personal", "data-test": "nav-personal-tab" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx",
          lineNumber: 34,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx",
      lineNumber: 24,
      columnNumber: 5
    },
    this
  );
}
_s(TransactionNavTabs, "YoLp8WOxgiHEJrxlIYWCnlpLmuk=", false, function() {
  return [useRouteMatch];
});
_c = TransactionNavTabs;
var _c;
$RefreshReg$(_c, "TransactionNavTabs");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionNavTabs.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0JNOzJCQS9CTjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNBLE1BQU1DLFdBQVc7QUFDMUIsU0FBU0MsTUFBTUMscUJBQXFCO0FBRXBDLHdCQUF3QkMscUJBQXFCO0FBQUFDLEtBQUE7QUFDM0MsUUFBTUMsUUFBUUgsY0FBYztBQUc1QixRQUFNSSxVQUFlO0FBQUEsSUFDbkIsS0FBSztBQUFBLElBQ0wsV0FBVztBQUFBLElBQ1gsYUFBYTtBQUFBLElBQ2IsYUFBYTtBQUFBLEVBQ2Y7QUFHQSxRQUFNLENBQUNDLE9BQU9DLFFBQVEsSUFBSUMsTUFBTUMsU0FBU0osUUFBUUQsTUFBTU0sR0FBRyxDQUFDO0FBRTNELFFBQU1DLGVBQWVBLENBQUNDLE9BQWlDQyxhQUFxQjtBQUMxRU4sYUFBU00sUUFBUTtBQUFBLEVBQ25CO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBLFVBQVVGO0FBQUFBLE1BQ1YsZ0JBQWU7QUFBQSxNQUNmLFdBQVU7QUFBQSxNQUNWO0FBQUEsTUFDQSxhQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLE9BQUksT0FBTSxZQUFXLFdBQVdYLE1BQU0sSUFBRyxLQUFJLGFBQVUsb0JBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0U7QUFBQSxRQUN4RSx1QkFBQyxPQUFJLE9BQU0sV0FBVSxXQUFXQSxNQUFNLElBQUcsYUFBWSxhQUFVLHNCQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakYsdUJBQUMsT0FBSSxPQUFNLFFBQU8sV0FBV0EsTUFBTSxJQUFHLGFBQVksYUFBVSxzQkFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE4RTtBQUFBO0FBQUE7QUFBQSxJQVZoRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXQTtBQUVKO0FBQUNHLEdBaEN1QkQsb0JBQWtCO0FBQUEsVUFDMUJELGFBQWE7QUFBQTtBQUFBYSxLQURMWjtBQUFrQixJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiVGFicyIsIlRhYiIsIkxpbmsiLCJ1c2VSb3V0ZU1hdGNoIiwiVHJhbnNhY3Rpb25OYXZUYWJzIiwiX3MiLCJtYXRjaCIsIm5hdlVybHMiLCJ2YWx1ZSIsInNldFZhbHVlIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsInVybCIsImhhbmRsZUNoYW5nZSIsImV2ZW50IiwibmV3VmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uTmF2VGFicy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBUYWJzLCBUYWIgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBMaW5rLCB1c2VSb3V0ZU1hdGNoIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRyYW5zYWN0aW9uTmF2VGFicygpIHtcclxuICBjb25zdCBtYXRjaCA9IHVzZVJvdXRlTWF0Y2goKTtcclxuXHJcbiAgLy8gUm91dGUgTG9va3VwIGZvciB0YWJzXHJcbiAgY29uc3QgbmF2VXJsczogYW55ID0ge1xyXG4gICAgXCIvXCI6IDAsXHJcbiAgICBcIi9wdWJsaWNcIjogMCxcclxuICAgIFwiL2NvbnRhY3RzXCI6IDEsXHJcbiAgICBcIi9wZXJzb25hbFwiOiAyLFxyXG4gIH07XHJcblxyXG4gIC8vIFNldCBzZWxlY3RlZCB0YWIgYmFzZWQgb24gdXJsXHJcbiAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZShuYXZVcmxzW21hdGNoLnVybF0pO1xyXG5cclxuICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQ6IFJlYWN0LlN5bnRoZXRpY0V2ZW50PHt9PiwgbmV3VmFsdWU6IG51bWJlcikgPT4ge1xyXG4gICAgc2V0VmFsdWUobmV3VmFsdWUpO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8VGFic1xyXG4gICAgICB2YWx1ZT17dmFsdWV9XHJcbiAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2V9XHJcbiAgICAgIGluZGljYXRvckNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgdGV4dENvbG9yPVwiaW5oZXJpdFwiXHJcbiAgICAgIGNlbnRlcmVkXHJcbiAgICAgIGRhdGEtdGVzdD1cIm5hdi10cmFuc2FjdGlvbi10YWJzXCJcclxuICAgID5cclxuICAgICAgPFRhYiBsYWJlbD1cIkV2ZXJ5b25lXCIgY29tcG9uZW50PXtMaW5rfSB0bz1cIi9cIiBkYXRhLXRlc3Q9XCJuYXYtcHVibGljLXRhYlwiIC8+XHJcbiAgICAgIDxUYWIgbGFiZWw9XCJGcmllbmRzXCIgY29tcG9uZW50PXtMaW5rfSB0bz1cIi9jb250YWN0c1wiIGRhdGEtdGVzdD1cIm5hdi1jb250YWN0cy10YWJcIiAvPlxyXG4gICAgICA8VGFiIGxhYmVsPVwiTWluZVwiIGNvbXBvbmVudD17TGlua30gdG89XCIvcGVyc29uYWxcIiBkYXRhLXRlc3Q9XCJuYXYtcGVyc29uYWwtdGFiXCIgLz5cclxuICAgIDwvVGFicz5cclxuICApO1xyXG59XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25OYXZUYWJzLnRzeCJ9