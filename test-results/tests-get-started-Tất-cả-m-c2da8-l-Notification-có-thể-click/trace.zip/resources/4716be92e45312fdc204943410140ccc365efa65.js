import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport0_lodash_fp["isEmpty"]; const omit = __vite__cjsImport0_lodash_fp["omit"];
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const personalTransactionsMachine = dataMachine("personalTransactions").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.get(`http://localhost:${backendPort}/transactions`, {
        params: !isEmpty(payload) ? payload : void 0
      });
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInBlcnNvbmFsVHJhbnNhY3Rpb25zTWFjaGluZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpc0VtcHR5LCBvbWl0IH0gZnJvbSBcImxvZGFzaC9mcFwiO1xyXG5pbXBvcnQgeyBkYXRhTWFjaGluZSB9IGZyb20gXCIuL2RhdGFNYWNoaW5lXCI7XHJcbmltcG9ydCB7IGh0dHBDbGllbnQgfSBmcm9tIFwiLi4vdXRpbHMvYXN5bmNVdGlsc1wiO1xyXG5pbXBvcnQgeyBiYWNrZW5kUG9ydCB9IGZyb20gXCIuLi91dGlscy9wb3J0VXRpbHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBwZXJzb25hbFRyYW5zYWN0aW9uc01hY2hpbmUgPSBkYXRhTWFjaGluZShcInBlcnNvbmFsVHJhbnNhY3Rpb25zXCIpLndpdGhDb25maWcoe1xyXG4gIHNlcnZpY2VzOiB7XHJcbiAgICBmZXRjaERhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQuZ2V0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L3RyYW5zYWN0aW9uc2AsIHtcclxuICAgICAgICBwYXJhbXM6ICFpc0VtcHR5KHBheWxvYWQpID8gcGF5bG9hZCA6IHVuZGVmaW5lZCxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiByZXNwLmRhdGE7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsU0FBUyxZQUFZO0FBQzlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBRXJCLGFBQU0sOEJBQThCLFlBQVksc0JBQXNCLEVBQUUsV0FBVztBQUFBLEVBQ3hGLFVBQVU7QUFBQSxJQUNSLFdBQVcsT0FBTyxLQUFLLFVBQWU7QUFDcEMsWUFBTSxVQUFVLEtBQUssUUFBUSxLQUFLO0FBQ2xDLFlBQU0sT0FBTyxNQUFNLFdBQVcsSUFBSSxvQkFBb0IsV0FBVyxpQkFBaUI7QUFBQSxRQUNoRixRQUFRLENBQUMsUUFBUSxPQUFPLElBQUksVUFBVTtBQUFBLE1BQ3hDLENBQUM7QUFDRCxhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNGLENBQUM7IiwibmFtZXMiOltdfQ==