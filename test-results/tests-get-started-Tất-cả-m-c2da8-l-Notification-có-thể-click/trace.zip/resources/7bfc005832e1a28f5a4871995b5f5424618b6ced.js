import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserListSearchForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useRef = __vite__cjsImport3_react["useRef"];
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { TextField } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const PREFIX = "UserListSearchForm";
const classes = {
  paper: `${PREFIX}-paper`,
  form: `${PREFIX}-form`
};
const Root = styled("div")(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.form}`]: {
    width: "100%",
    // Fix IE 11 issue.
    marginTop: theme.spacing(1)
  }
}));
_c = Root;
const UserListSearchForm = ({ userListSearch }) => {
  _s();
  const inputEl = useRef(null);
  return /* @__PURE__ */ jsxDEV(Root, { children: /* @__PURE__ */ jsxDEV("form", { className: classes.form, children: /* @__PURE__ */ jsxDEV(
    TextField,
    {
      variant: "outlined",
      margin: "dense",
      fullWidth: true,
      name: "q",
      type: "text",
      placeholder: "Search...",
      id: "user-list-search-input",
      inputRef: inputEl,
      inputProps: { "data-test": "user-list-search-input" },
      onFocus: () => {
        if (null !== inputEl.current) {
          inputEl.current.value = "";
          inputEl.current.focus();
        }
      },
      onChange: ({ target: { value: q } }) => {
        userListSearch({ q });
      }
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx",
      lineNumber: 36,
      columnNumber: 9
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx",
    lineNumber: 35,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx",
    lineNumber: 34,
    columnNumber: 5
  }, this);
};
_s(UserListSearchForm, "ym51OZLSyFi7C9y0aD9taJOK1dY=");
_c2 = UserListSearchForm;
export default UserListSearchForm;
var _c, _c2;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "UserListSearchForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListSearchForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNROzJCQW5DUjtBQUFnQkEsTUFBTSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3JDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsaUJBQWlCO0FBRTFCLE1BQU1DLFNBQVM7QUFFZixNQUFNQyxVQUFVO0FBQUEsRUFDZEMsT0FBTyxHQUFHRixNQUFNO0FBQUEsRUFDaEJHLE1BQU0sR0FBR0gsTUFBTTtBQUNqQjtBQUVBLE1BQU1JLE9BQU9OLE9BQU8sS0FBSyxFQUFFLENBQUMsRUFBRU8sTUFBTSxPQUFPO0FBQUEsRUFDekMsQ0FBQyxNQUFNSixRQUFRQyxLQUFLLEVBQUUsR0FBRztBQUFBLElBQ3ZCSSxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxJQUMxQkMsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsRUFDZDtBQUFBLEVBRUEsQ0FBQyxNQUFNVCxRQUFRRSxJQUFJLEVBQUUsR0FBRztBQUFBLElBQ3RCUSxPQUFPO0FBQUE7QUFBQSxJQUNQTCxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUM1QjtBQUNGLEVBQUU7QUFBRUssS0FaRVI7QUFrQk4sTUFBTVMscUJBQXdEQSxDQUFDLEVBQUVDLGVBQWUsTUFBTTtBQUFBQyxLQUFBO0FBQ3BGLFFBQU1DLFVBQVVuQixPQUF5QixJQUFJO0FBRTdDLFNBQ0UsdUJBQUMsUUFDQyxpQ0FBQyxVQUFLLFdBQVdJLFFBQVFFLE1BQ3ZCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxTQUFRO0FBQUEsTUFDUixRQUFPO0FBQUEsTUFDUDtBQUFBLE1BQ0EsTUFBSztBQUFBLE1BQ0wsTUFBSztBQUFBLE1BQ0wsYUFBWTtBQUFBLE1BQ1osSUFBRztBQUFBLE1BQ0gsVUFBVWE7QUFBQUEsTUFDVixZQUFZLEVBQUUsYUFBYSx5QkFBeUI7QUFBQSxNQUNwRCxTQUFTLE1BQU07QUFDYixZQUFJLFNBQVNBLFFBQVFDLFNBQVM7QUFDNUJELGtCQUFRQyxRQUFRQyxRQUFRO0FBQ3hCRixrQkFBUUMsUUFBUUUsTUFBTTtBQUFBLFFBQ3hCO0FBQUEsTUFDRjtBQUFBLE1BQ0EsVUFBVSxDQUFDLEVBQUVDLFFBQVEsRUFBRUYsT0FBT0csRUFBRSxFQUFFLE1BQU07QUFDdENQLHVCQUFlLEVBQUVPLEVBQUUsQ0FBQztBQUFBLE1BQ3RCO0FBQUE7QUFBQSxJQWxCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFrQkksS0FuQk47QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBRU4sR0E3QklGLG9CQUFxRDtBQUFBUyxNQUFyRFQ7QUErQk4sZUFBZUE7QUFBbUIsSUFBQUQsSUFBQVU7QUFBQUMsYUFBQVgsSUFBQTtBQUFBVyxhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlUmVmIiwic3R5bGVkIiwiVGV4dEZpZWxkIiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwiZm9ybSIsIlJvb3QiLCJ0aGVtZSIsIm1hcmdpblRvcCIsInNwYWNpbmciLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJ3aWR0aCIsIl9jIiwiVXNlckxpc3RTZWFyY2hGb3JtIiwidXNlckxpc3RTZWFyY2giLCJfcyIsImlucHV0RWwiLCJjdXJyZW50IiwidmFsdWUiLCJmb2N1cyIsInRhcmdldCIsInEiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJVc2VyTGlzdFNlYXJjaEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VSZWYgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlVzZXJMaXN0U2VhcmNoRm9ybVwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwYXBlcjogYCR7UFJFRklYfS1wYXBlcmAsXHJcbiAgZm9ybTogYCR7UFJFRklYfS1mb3JtYCxcclxufTtcclxuXHJcbmNvbnN0IFJvb3QgPSBzdHlsZWQoXCJkaXZcIikoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYgLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDgpLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5mb3JtfWBdOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsIC8vIEZpeCBJRSAxMSBpc3N1ZS5cclxuICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZygxKSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFVzZXJMaXN0U2VhcmNoRm9ybVByb3BzIHtcclxuICB1c2VyTGlzdFNlYXJjaDogRnVuY3Rpb247XHJcbn1cclxuXHJcbmNvbnN0IFVzZXJMaXN0U2VhcmNoRm9ybTogUmVhY3QuRkM8VXNlckxpc3RTZWFyY2hGb3JtUHJvcHM+ID0gKHsgdXNlckxpc3RTZWFyY2ggfSkgPT4ge1xyXG4gIGNvbnN0IGlucHV0RWwgPSB1c2VSZWY8SFRNTElucHV0RWxlbWVudD4obnVsbCk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Um9vdD5cclxuICAgICAgPGZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19PlxyXG4gICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgIG5hbWU9XCJxXCJcclxuICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VhcmNoLi4uXCJcclxuICAgICAgICAgIGlkPVwidXNlci1saXN0LXNlYXJjaC1pbnB1dFwiXHJcbiAgICAgICAgICBpbnB1dFJlZj17aW5wdXRFbH1cclxuICAgICAgICAgIGlucHV0UHJvcHM9e3sgXCJkYXRhLXRlc3RcIjogXCJ1c2VyLWxpc3Qtc2VhcmNoLWlucHV0XCIgfX1cclxuICAgICAgICAgIG9uRm9jdXM9eygpID0+IHtcclxuICAgICAgICAgICAgaWYgKG51bGwgIT09IGlucHV0RWwuY3VycmVudCkge1xyXG4gICAgICAgICAgICAgIGlucHV0RWwuY3VycmVudC52YWx1ZSA9IFwiXCI7XHJcbiAgICAgICAgICAgICAgaW5wdXRFbC5jdXJyZW50LmZvY3VzKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICBvbkNoYW5nZT17KHsgdGFyZ2V0OiB7IHZhbHVlOiBxIH0gfSkgPT4ge1xyXG4gICAgICAgICAgICB1c2VyTGlzdFNlYXJjaCh7IHEgfSk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvUm9vdD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlckxpc3RTZWFyY2hGb3JtO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1VzZXJMaXN0U2VhcmNoRm9ybS50c3gifQ==