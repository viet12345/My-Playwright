import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport0_lodash_fp["isEmpty"]; const omit = __vite__cjsImport0_lodash_fp["omit"];
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const usersMachine = dataMachine("users").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const payload = omit("type", event);
      let route = isEmpty(payload) ? "users" : "users/search";
      const resp = await httpClient.get(`http://localhost:${backendPort}/${route}`, {
        params: !isEmpty(payload) ? payload : void 0
      });
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInVzZXJzTWFjaGluZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpc0VtcHR5LCBvbWl0IH0gZnJvbSBcImxvZGFzaC9mcFwiO1xyXG5pbXBvcnQgeyBkYXRhTWFjaGluZSB9IGZyb20gXCIuL2RhdGFNYWNoaW5lXCI7XHJcbmltcG9ydCB7IGh0dHBDbGllbnQgfSBmcm9tIFwiLi4vdXRpbHMvYXN5bmNVdGlsc1wiO1xyXG5pbXBvcnQgeyBiYWNrZW5kUG9ydCB9IGZyb20gXCIuLi91dGlscy9wb3J0VXRpbHNcIjtcclxuXHJcbmV4cG9ydCBjb25zdCB1c2Vyc01hY2hpbmUgPSBkYXRhTWFjaGluZShcInVzZXJzXCIpLndpdGhDb25maWcoe1xyXG4gIHNlcnZpY2VzOiB7XHJcbiAgICBmZXRjaERhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgbGV0IHJvdXRlID0gaXNFbXB0eShwYXlsb2FkKSA/IFwidXNlcnNcIiA6IFwidXNlcnMvc2VhcmNoXCI7XHJcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBodHRwQ2xpZW50LmdldChgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS8ke3JvdXRlfWAsIHtcclxuICAgICAgICBwYXJhbXM6ICFpc0VtcHR5KHBheWxvYWQpID8gcGF5bG9hZCA6IHVuZGVmaW5lZCxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiByZXNwLmRhdGE7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsU0FBUyxZQUFZO0FBQzlCLFNBQVMsbUJBQW1CO0FBQzVCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsbUJBQW1CO0FBRXJCLGFBQU0sZUFBZSxZQUFZLE9BQU8sRUFBRSxXQUFXO0FBQUEsRUFDMUQsVUFBVTtBQUFBLElBQ1IsV0FBVyxPQUFPLEtBQUssVUFBZTtBQUNwQyxZQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsVUFBSSxRQUFRLFFBQVEsT0FBTyxJQUFJLFVBQVU7QUFDekMsWUFBTSxPQUFPLE1BQU0sV0FBVyxJQUFJLG9CQUFvQixXQUFXLElBQUksS0FBSyxJQUFJO0FBQUEsUUFDNUUsUUFBUSxDQUFDLFFBQVEsT0FBTyxJQUFJLFVBQVU7QUFBQSxNQUN4QyxDQUFDO0FBQ0QsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=