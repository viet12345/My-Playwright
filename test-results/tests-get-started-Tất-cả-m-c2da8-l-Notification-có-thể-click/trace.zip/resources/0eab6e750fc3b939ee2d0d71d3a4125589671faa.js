import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport0_lodash_fp["isEmpty"]; const omit = __vite__cjsImport0_lodash_fp["omit"];
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const notificationsMachine = dataMachine("notifications").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.get(`http://localhost:${backendPort}/notifications`, {
        params: !isEmpty(payload) && event.type === "FETCH" ? payload : void 0
      });
      return resp.data;
    },
    updateData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.patch(
        `http://localhost:${backendPort}/notifications/${payload.id}`,
        payload
      );
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vdGlmaWNhdGlvbnNNYWNoaW5lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGlzRW1wdHksIG9taXQgfSBmcm9tIFwibG9kYXNoL2ZwXCI7XHJcbmltcG9ydCB7IGRhdGFNYWNoaW5lIH0gZnJvbSBcIi4vZGF0YU1hY2hpbmVcIjtcclxuaW1wb3J0IHsgaHR0cENsaWVudCB9IGZyb20gXCIuLi91dGlscy9hc3luY1V0aWxzXCI7XHJcbmltcG9ydCB7IGJhY2tlbmRQb3J0IH0gZnJvbSBcIi4uL3V0aWxzL3BvcnRVdGlsc1wiO1xyXG5cclxuZXhwb3J0IGNvbnN0IG5vdGlmaWNhdGlvbnNNYWNoaW5lID0gZGF0YU1hY2hpbmUoXCJub3RpZmljYXRpb25zXCIpLndpdGhDb25maWcoe1xyXG4gIHNlcnZpY2VzOiB7XHJcbiAgICBmZXRjaERhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQuZ2V0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L25vdGlmaWNhdGlvbnNgLCB7XHJcbiAgICAgICAgcGFyYW1zOiAhaXNFbXB0eShwYXlsb2FkKSAmJiBldmVudC50eXBlID09PSBcIkZFVENIXCIgPyBwYXlsb2FkIDogdW5kZWZpbmVkLFxyXG4gICAgICB9KTtcclxuICAgICAgcmV0dXJuIHJlc3AuZGF0YTtcclxuICAgIH0sXHJcbiAgICB1cGRhdGVEYXRhOiBhc3luYyAoY3R4LCBldmVudDogYW55KSA9PiB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSBvbWl0KFwidHlwZVwiLCBldmVudCk7XHJcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBodHRwQ2xpZW50LnBhdGNoKFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L25vdGlmaWNhdGlvbnMvJHtwYXlsb2FkLmlkfWAsXHJcbiAgICAgICAgcGF5bG9hZFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgfSxcclxuICB9LFxyXG59KTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVMsWUFBWTtBQUM5QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUVyQixhQUFNLHVCQUF1QixZQUFZLGVBQWUsRUFBRSxXQUFXO0FBQUEsRUFDMUUsVUFBVTtBQUFBLElBQ1IsV0FBVyxPQUFPLEtBQUssVUFBZTtBQUNwQyxZQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsWUFBTSxPQUFPLE1BQU0sV0FBVyxJQUFJLG9CQUFvQixXQUFXLGtCQUFrQjtBQUFBLFFBQ2pGLFFBQVEsQ0FBQyxRQUFRLE9BQU8sS0FBSyxNQUFNLFNBQVMsVUFBVSxVQUFVO0FBQUEsTUFDbEUsQ0FBQztBQUNELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFBQSxJQUNBLFlBQVksT0FBTyxLQUFLLFVBQWU7QUFDckMsWUFBTSxVQUFVLEtBQUssUUFBUSxLQUFLO0FBQ2xDLFlBQU0sT0FBTyxNQUFNLFdBQVc7QUFBQSxRQUM1QixvQkFBb0IsV0FBVyxrQkFBa0IsUUFBUSxFQUFFO0FBQUEsUUFDM0Q7QUFBQSxNQUNGO0FBQ0EsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=