import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/TransactionsContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Switch, Route } from "/node_modules/.vite/deps/react-router.js?v=6af76b79";
import TransactionListFilters from "/src/components/TransactionListFilters.tsx";
import TransactionContactsList from "/src/components/TransactionContactsList.tsx";
import { transactionFiltersMachine } from "/src/machines/transactionFiltersMachine.ts";
import { getDateQueryFields, getAmountQueryFields } from "/src/utils/transactionUtils.ts";
import TransactionPersonalList from "/src/components/TransactionPersonalList.tsx";
import TransactionPublicList from "/src/components/TransactionPublicList.tsx";
const TransactionsContainer = () => {
  _s();
  const [currentFilters, sendFilterEvent] = useMachine(transactionFiltersMachine);
  const hasDateRangeFilter = currentFilters.matches({ dateRange: "filter" });
  const hasAmountRangeFilter = currentFilters.matches({
    amountRange: "filter"
  });
  const dateRangeFilters = hasDateRangeFilter && getDateQueryFields(currentFilters.context);
  const amountRangeFilters = hasAmountRangeFilter && getAmountQueryFields(currentFilters.context);
  const Filters = /* @__PURE__ */ jsxDEV(
    TransactionListFilters,
    {
      dateRangeFilters,
      amountRangeFilters,
      sendFilterEvent
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
      lineNumber: 24,
      columnNumber: 3
    },
    this
  );
  return /* @__PURE__ */ jsxDEV(Switch, { children: [
    /* @__PURE__ */ jsxDEV(Route, { exact: true, path: "/contacts", children: /* @__PURE__ */ jsxDEV(
      TransactionContactsList,
      {
        filterComponent: Filters,
        dateRangeFilters,
        amountRangeFilters
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
        lineNumber: 34,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { exact: true, path: "/personal", children: /* @__PURE__ */ jsxDEV(
      TransactionPersonalList,
      {
        filterComponent: Filters,
        dateRangeFilters,
        amountRangeFilters
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
        lineNumber: 41,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Route, { exact: true, path: "/(public)?", children: /* @__PURE__ */ jsxDEV(
      TransactionPublicList,
      {
        filterComponent: Filters,
        dateRangeFilters,
        amountRangeFilters
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
        lineNumber: 48,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx",
    lineNumber: 32,
    columnNumber: 5
  }, this);
};
_s(TransactionsContainer, "Vn/L35wZhKC21RkmqnVX0UDebzQ=", false, function() {
  return [useMachine];
});
_c = TransactionsContainer;
export default TransactionsContainer;
var _c;
$RefreshReg$(_c, "TransactionsContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionsContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUJJOzJCQXZCSjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxrQkFBa0I7QUFDM0IsU0FBU0MsUUFBUUMsYUFBYTtBQUU5QixPQUFPQyw0QkFBNEI7QUFDbkMsT0FBT0MsNkJBQTZCO0FBQ3BDLFNBQVNDLGlDQUFpQztBQUMxQyxTQUFTQyxvQkFBb0JDLDRCQUE0QjtBQUN6RCxPQUFPQyw2QkFBNkI7QUFDcEMsT0FBT0MsMkJBQTJCO0FBRWxDLE1BQU1DLHdCQUFrQ0EsTUFBTTtBQUFBQyxLQUFBO0FBQzVDLFFBQU0sQ0FBQ0MsZ0JBQWdCQyxlQUFlLElBQUliLFdBQVdLLHlCQUF5QjtBQUU5RSxRQUFNUyxxQkFBcUJGLGVBQWVHLFFBQVEsRUFBRUMsV0FBVyxTQUFTLENBQUM7QUFDekUsUUFBTUMsdUJBQXVCTCxlQUFlRyxRQUFRO0FBQUEsSUFDbERHLGFBQWE7QUFBQSxFQUNmLENBQUM7QUFFRCxRQUFNQyxtQkFBbUJMLHNCQUFzQlIsbUJBQW1CTSxlQUFlUSxPQUFPO0FBQ3hGLFFBQU1DLHFCQUFxQkosd0JBQXdCVixxQkFBcUJLLGVBQWVRLE9BQU87QUFFOUYsUUFBTUUsVUFDSjtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBO0FBQUEsSUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFHbUM7QUFJckMsU0FDRSx1QkFBQyxVQUNDO0FBQUEsMkJBQUMsU0FBTSxPQUFLLE1BQUMsTUFBSyxhQUNoQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsaUJBQWlCQTtBQUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzBFLEtBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxPQUFLLE1BQUMsTUFBSyxhQUNoQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsaUJBQWlCQTtBQUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzBFLEtBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBQ0EsdUJBQUMsU0FBTSxPQUFLLE1BQUMsTUFBSyxjQUNoQjtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsaUJBQWlCQTtBQUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQTtBQUFBLE1BSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRzBFLEtBSjVFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BckJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQkE7QUFFSjtBQUFFWCxHQTVDSUQsdUJBQStCO0FBQUEsVUFDT1YsVUFBVTtBQUFBO0FBQUF1QixLQURoRGI7QUE4Q04sZUFBZUE7QUFBc0IsSUFBQWE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZU1hY2hpbmUiLCJTd2l0Y2giLCJSb3V0ZSIsIlRyYW5zYWN0aW9uTGlzdEZpbHRlcnMiLCJUcmFuc2FjdGlvbkNvbnRhY3RzTGlzdCIsInRyYW5zYWN0aW9uRmlsdGVyc01hY2hpbmUiLCJnZXREYXRlUXVlcnlGaWVsZHMiLCJnZXRBbW91bnRRdWVyeUZpZWxkcyIsIlRyYW5zYWN0aW9uUGVyc29uYWxMaXN0IiwiVHJhbnNhY3Rpb25QdWJsaWNMaXN0IiwiVHJhbnNhY3Rpb25zQ29udGFpbmVyIiwiX3MiLCJjdXJyZW50RmlsdGVycyIsInNlbmRGaWx0ZXJFdmVudCIsImhhc0RhdGVSYW5nZUZpbHRlciIsIm1hdGNoZXMiLCJkYXRlUmFuZ2UiLCJoYXNBbW91bnRSYW5nZUZpbHRlciIsImFtb3VudFJhbmdlIiwiZGF0ZVJhbmdlRmlsdGVycyIsImNvbnRleHQiLCJhbW91bnRSYW5nZUZpbHRlcnMiLCJGaWx0ZXJzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUcmFuc2FjdGlvbnNDb250YWluZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTWFjaGluZSB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7IFN3aXRjaCwgUm91dGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7IFRyYW5zYWN0aW9uRGF0ZVJhbmdlUGF5bG9hZCwgVHJhbnNhY3Rpb25BbW91bnRSYW5nZVBheWxvYWQgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvbkxpc3RGaWx0ZXJzIGZyb20gXCIuLi9jb21wb25lbnRzL1RyYW5zYWN0aW9uTGlzdEZpbHRlcnNcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQ29udGFjdHNMaXN0IGZyb20gXCIuLi9jb21wb25lbnRzL1RyYW5zYWN0aW9uQ29udGFjdHNMaXN0XCI7XHJcbmltcG9ydCB7IHRyYW5zYWN0aW9uRmlsdGVyc01hY2hpbmUgfSBmcm9tIFwiLi4vbWFjaGluZXMvdHJhbnNhY3Rpb25GaWx0ZXJzTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBnZXREYXRlUXVlcnlGaWVsZHMsIGdldEFtb3VudFF1ZXJ5RmllbGRzIH0gZnJvbSBcIi4uL3V0aWxzL3RyYW5zYWN0aW9uVXRpbHNcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uUGVyc29uYWxMaXN0IGZyb20gXCIuLi9jb21wb25lbnRzL1RyYW5zYWN0aW9uUGVyc29uYWxMaXN0XCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvblB1YmxpY0xpc3QgZnJvbSBcIi4uL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25QdWJsaWNMaXN0XCI7XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbnNDb250YWluZXI6IFJlYWN0LkZDID0gKCkgPT4ge1xyXG4gIGNvbnN0IFtjdXJyZW50RmlsdGVycywgc2VuZEZpbHRlckV2ZW50XSA9IHVzZU1hY2hpbmUodHJhbnNhY3Rpb25GaWx0ZXJzTWFjaGluZSk7XHJcblxyXG4gIGNvbnN0IGhhc0RhdGVSYW5nZUZpbHRlciA9IGN1cnJlbnRGaWx0ZXJzLm1hdGNoZXMoeyBkYXRlUmFuZ2U6IFwiZmlsdGVyXCIgfSk7XHJcbiAgY29uc3QgaGFzQW1vdW50UmFuZ2VGaWx0ZXIgPSBjdXJyZW50RmlsdGVycy5tYXRjaGVzKHtcclxuICAgIGFtb3VudFJhbmdlOiBcImZpbHRlclwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBkYXRlUmFuZ2VGaWx0ZXJzID0gaGFzRGF0ZVJhbmdlRmlsdGVyICYmIGdldERhdGVRdWVyeUZpZWxkcyhjdXJyZW50RmlsdGVycy5jb250ZXh0KTtcclxuICBjb25zdCBhbW91bnRSYW5nZUZpbHRlcnMgPSBoYXNBbW91bnRSYW5nZUZpbHRlciAmJiBnZXRBbW91bnRRdWVyeUZpZWxkcyhjdXJyZW50RmlsdGVycy5jb250ZXh0KTtcclxuXHJcbiAgY29uc3QgRmlsdGVycyA9IChcclxuICAgIDxUcmFuc2FjdGlvbkxpc3RGaWx0ZXJzXHJcbiAgICAgIGRhdGVSYW5nZUZpbHRlcnM9e2RhdGVSYW5nZUZpbHRlcnMgYXMgVHJhbnNhY3Rpb25EYXRlUmFuZ2VQYXlsb2FkfVxyXG4gICAgICBhbW91bnRSYW5nZUZpbHRlcnM9e2Ftb3VudFJhbmdlRmlsdGVycyBhcyBUcmFuc2FjdGlvbkFtb3VudFJhbmdlUGF5bG9hZH1cclxuICAgICAgc2VuZEZpbHRlckV2ZW50PXtzZW5kRmlsdGVyRXZlbnR9XHJcbiAgICAvPlxyXG4gICk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3dpdGNoPlxyXG4gICAgICA8Um91dGUgZXhhY3QgcGF0aD1cIi9jb250YWN0c1wiPlxyXG4gICAgICAgIDxUcmFuc2FjdGlvbkNvbnRhY3RzTGlzdFxyXG4gICAgICAgICAgZmlsdGVyQ29tcG9uZW50PXtGaWx0ZXJzfVxyXG4gICAgICAgICAgZGF0ZVJhbmdlRmlsdGVycz17ZGF0ZVJhbmdlRmlsdGVycyBhcyBUcmFuc2FjdGlvbkRhdGVSYW5nZVBheWxvYWR9XHJcbiAgICAgICAgICBhbW91bnRSYW5nZUZpbHRlcnM9e2Ftb3VudFJhbmdlRmlsdGVycyBhcyBUcmFuc2FjdGlvbkFtb3VudFJhbmdlUGF5bG9hZH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1JvdXRlPlxyXG4gICAgICA8Um91dGUgZXhhY3QgcGF0aD1cIi9wZXJzb25hbFwiPlxyXG4gICAgICAgIDxUcmFuc2FjdGlvblBlcnNvbmFsTGlzdFxyXG4gICAgICAgICAgZmlsdGVyQ29tcG9uZW50PXtGaWx0ZXJzfVxyXG4gICAgICAgICAgZGF0ZVJhbmdlRmlsdGVycz17ZGF0ZVJhbmdlRmlsdGVycyBhcyBUcmFuc2FjdGlvbkRhdGVSYW5nZVBheWxvYWR9XHJcbiAgICAgICAgICBhbW91bnRSYW5nZUZpbHRlcnM9e2Ftb3VudFJhbmdlRmlsdGVycyBhcyBUcmFuc2FjdGlvbkFtb3VudFJhbmdlUGF5bG9hZH1cclxuICAgICAgICAvPlxyXG4gICAgICA8L1JvdXRlPlxyXG4gICAgICA8Um91dGUgZXhhY3QgcGF0aD1cIi8ocHVibGljKT9cIj5cclxuICAgICAgICA8VHJhbnNhY3Rpb25QdWJsaWNMaXN0XHJcbiAgICAgICAgICBmaWx0ZXJDb21wb25lbnQ9e0ZpbHRlcnN9XHJcbiAgICAgICAgICBkYXRlUmFuZ2VGaWx0ZXJzPXtkYXRlUmFuZ2VGaWx0ZXJzIGFzIFRyYW5zYWN0aW9uRGF0ZVJhbmdlUGF5bG9hZH1cclxuICAgICAgICAgIGFtb3VudFJhbmdlRmlsdGVycz17YW1vdW50UmFuZ2VGaWx0ZXJzIGFzIFRyYW5zYWN0aW9uQW1vdW50UmFuZ2VQYXlsb2FkfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvUm91dGU+XHJcbiAgICA8L1N3aXRjaD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25zQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL1RyYW5zYWN0aW9uc0NvbnRhaW5lci50c3gifQ==