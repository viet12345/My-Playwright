import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SkeletonList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Skeleton } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const PREFIX = "ListSkeleton";
const classes = {
  root: `${PREFIX}-root`
};
const Root = styled("div")(({ theme }) => ({
  [`&.${classes.root}`]: {
    minHeight: "100vh",
    marginLeft: theme.spacing(2),
    marginRight: theme.spacing(2),
    width: "95%"
  }
}));
_c = Root;
const ListSkeleton = () => {
  return /* @__PURE__ */ jsxDEV(Root, { className: classes.root, "data-test": "list-skeleton", children: [
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 22,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 24,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 25,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 26,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 27,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 28,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 30,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 31,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 32,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 33,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 41,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 43,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 44,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 45,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 46,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 47,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 48,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 49,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 52,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 53,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 54,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 56,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 58,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 59,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 60,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 61,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 63,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: false }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 64,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Skeleton, { animation: "wave" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
      lineNumber: 65,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx",
    lineNumber: 21,
    columnNumber: 5
  }, this);
};
_c2 = ListSkeleton;
export default ListSkeleton;
var _c, _c2;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "ListSkeleton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SkeletonList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNO0FBckJOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxnQkFBZ0I7QUFDekIsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxNQUFNLEdBQUdGLE1BQU07QUFDakI7QUFFQSxNQUFNRyxPQUFPTCxPQUFPLEtBQUssRUFBRSxDQUFDLEVBQUVNLE1BQU0sT0FBTztBQUFBLEVBQ3pDLENBQUMsS0FBS0gsUUFBUUMsSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUNyQkcsV0FBVztBQUFBLElBQ1hDLFlBQVlGLE1BQU1HLFFBQVEsQ0FBQztBQUFBLElBQzNCQyxhQUFhSixNQUFNRyxRQUFRLENBQUM7QUFBQSxJQUM1QkUsT0FBTztBQUFBLEVBQ1Q7QUFDRixFQUFFO0FBQUVDLEtBUEVQO0FBU04sTUFBTVEsZUFBZUEsTUFBTTtBQUN6QixTQUNFLHVCQUFDLFFBQUssV0FBV1YsUUFBUUMsTUFBTSxhQUFVLGlCQUN2QztBQUFBLDJCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsWUFBUyxXQUFXLFNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxJQUMzQix1QkFBQyxZQUFTLFdBQVUsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQzFCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFlBQVMsV0FBVyxTQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsSUFDM0IsdUJBQUMsWUFBUyxXQUFVLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxJQUMxQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxZQUFTLFdBQVcsU0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLElBQzNCLHVCQUFDLFlBQVMsV0FBVSxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsSUFDMUIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsWUFBUyxXQUFXLFNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxJQUMzQix1QkFBQyxZQUFTLFdBQVUsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQzFCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFlBQVMsV0FBVyxTQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsSUFDM0IsdUJBQUMsWUFBUyxXQUFVLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxJQUMxQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxZQUFTLFdBQVcsU0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLElBQzNCLHVCQUFDLFlBQVMsV0FBVSxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsSUFDMUIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxjQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsWUFBUyxXQUFXLFNBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxJQUMzQix1QkFBQyxZQUFTLFdBQVUsVUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQjtBQUFBLElBQzFCLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsY0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFlBQVMsV0FBVyxTQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJCO0FBQUEsSUFDM0IsdUJBQUMsWUFBUyxXQUFVLFVBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEI7QUFBQSxJQUMxQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQUEsSUFDVCx1QkFBQyxZQUFTLFdBQVcsU0FBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEyQjtBQUFBLElBQzNCLHVCQUFDLFlBQVMsV0FBVSxVQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsT0E1QzVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2Q0E7QUFFSjtBQUFFVSxNQWpESUQ7QUFtRE4sZUFBZUE7QUFBYSxJQUFBRCxJQUFBRTtBQUFBQyxhQUFBSCxJQUFBO0FBQUFHLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInN0eWxlZCIsIlNrZWxldG9uIiwiUFJFRklYIiwiY2xhc3NlcyIsInJvb3QiLCJSb290IiwidGhlbWUiLCJtaW5IZWlnaHQiLCJtYXJnaW5MZWZ0Iiwic3BhY2luZyIsIm1hcmdpblJpZ2h0Iiwid2lkdGgiLCJfYyIsIkxpc3RTa2VsZXRvbiIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNrZWxldG9uTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgU2tlbGV0b24gfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5jb25zdCBQUkVGSVggPSBcIkxpc3RTa2VsZXRvblwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICByb290OiBgJHtQUkVGSVh9LXJvb3RgLFxyXG59O1xyXG5cclxuY29uc3QgUm9vdCA9IHN0eWxlZChcImRpdlwiKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMucm9vdH1gXToge1xyXG4gICAgbWluSGVpZ2h0OiBcIjEwMHZoXCIsXHJcbiAgICBtYXJnaW5MZWZ0OiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gICAgbWFyZ2luUmlnaHQ6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgICB3aWR0aDogXCI5NSVcIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5jb25zdCBMaXN0U2tlbGV0b24gPSAoKSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxSb290IGNsYXNzTmFtZT17Y2xhc3Nlcy5yb290fSBkYXRhLXRlc3Q9XCJsaXN0LXNrZWxldG9uXCI+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgICAgPGJyIC8+XHJcbiAgICAgIDxiciAvPlxyXG4gICAgICA8U2tlbGV0b24gLz5cclxuICAgICAgPFNrZWxldG9uIGFuaW1hdGlvbj17ZmFsc2V9IC8+XHJcbiAgICAgIDxTa2VsZXRvbiBhbmltYXRpb249XCJ3YXZlXCIgLz5cclxuICAgIDwvUm9vdD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGlzdFNrZWxldG9uO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1NrZWxldG9uTGlzdC50c3gifQ==