import {
  __commonJS
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";

// browser-external:net
var require_net = __commonJS({
  "browser-external:net"(exports, module) {
    module.exports = Object.create(new Proxy({}, {
      get(_, key) {
        if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") {
          console.warn(`Module "net" has been externalized for browser compatibility. Cannot access "net.${key}" in client code. See http://vitejs.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
        }
      }
    }));
  }
});

// browser-external:os
var require_os = __commonJS({
  "browser-external:os"(exports, module) {
    module.exports = Object.create(new Proxy({}, {
      get(_, key) {
        if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") {
          console.warn(`Module "os" has been externalized for browser compatibility. Cannot access "os.${key}" in client code. See http://vitejs.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
        }
      }
    }));
  }
});

// browser-external:fs
var require_fs = __commonJS({
  "browser-external:fs"(exports, module) {
    module.exports = Object.create(new Proxy({}, {
      get(_, key) {
        if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") {
          console.warn(`Module "fs" has been externalized for browser compatibility. Cannot access "fs.${key}" in client code. See http://vitejs.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
        }
      }
    }));
  }
});

// browser-external:child_process
var require_child_process = __commonJS({
  "browser-external:child_process"(exports, module) {
    module.exports = Object.create(new Proxy({}, {
      get(_, key) {
        if (key !== "__esModule" && key !== "__proto__" && key !== "constructor" && key !== "splice") {
          console.warn(`Module "child_process" has been externalized for browser compatibility. Cannot access "child_process.${key}" in client code. See http://vitejs.dev/guide/troubleshooting.html#module-externalized-for-browser-compatibility for more details.`);
        }
      }
    }));
  }
});

// node_modules/address/lib/address.js
var require_address = __commonJS({
  "node_modules/address/lib/address.js"(exports, module) {
    "use strict";
    var os = require_os();
    var fs = require_fs();
    var child = require_child_process();
    var DEFAULT_RESOLV_FILE = "/etc/resolv.conf";
    function getInterfaceName() {
      var val = "eth";
      var platform = os.platform();
      if (platform === "darwin") {
        val = "en";
      } else if (platform === "win32") {
        val = null;
      }
      return val;
    }
    function getIfconfigCMD() {
      if (os.platform() === "win32") {
        return "ipconfig/all";
      }
      return "/sbin/ifconfig";
    }
    function matchName(actualFamily, expectedFamily) {
      if (expectedFamily === "IPv4") {
        return actualFamily === "IPv4" || actualFamily === 4;
      }
      if (expectedFamily === "IPv6") {
        return actualFamily === "IPv6" || actualFamily === 6;
      }
      return actualFamily === expectedFamily;
    }
    function address(interfaceName, callback) {
      if (typeof interfaceName === "function") {
        callback = interfaceName;
        interfaceName = null;
      }
      var addr = {
        ip: address.ip(interfaceName),
        ipv6: address.ipv6(interfaceName),
        mac: null
      };
      address.mac(interfaceName, function(err, mac) {
        if (mac) {
          addr.mac = mac;
        }
        callback(err, addr);
      });
    }
    address.interface = function(family, name) {
      var interfaces = os.networkInterfaces();
      var noName = !name;
      name = name || getInterfaceName();
      family = family || "IPv4";
      for (var i = -1; i < 8; i++) {
        var interfaceName = name + (i >= 0 ? i : "");
        var items = interfaces[interfaceName];
        if (items) {
          for (var j = 0; j < items.length; j++) {
            var item = items[j];
            if (matchName(item.family, family)) {
              return item;
            }
          }
        }
      }
      if (noName) {
        for (var k in interfaces) {
          var items = interfaces[k];
          for (var i = 0; i < items.length; i++) {
            var item = items[i];
            if (matchName(item.family, family) && !item.address.startsWith("127.")) {
              return item;
            }
          }
        }
      }
      return;
    };
    address.ip = function(interfaceName) {
      var item = address.interface("IPv4", interfaceName);
      return item && item.address;
    };
    address.ipv6 = function(interfaceName) {
      var item = address.interface("IPv6", interfaceName);
      return item && item.address;
    };
    var MAC_OSX_START_LINE = /^(\w+)\:\s+flags=/;
    var MAC_LINUX_START_LINE = /^(\w+)\s{2,}link encap:\w+/i;
    var MAC_RE = address.MAC_RE = /(?:ether|HWaddr)\s+((?:[a-z0-9]{2}\:){5}[a-z0-9]{2})/i;
    var MAC_IP_RE = address.MAC_IP_RE = /inet\s(?:addr\:)?(\d+\.\d+\.\d+\.\d+)/;
    function getMAC(content, interfaceName, matchIP) {
      var lines = content.split("\n");
      for (var i = 0; i < lines.length; i++) {
        var line = lines[i].trimRight();
        var m = MAC_OSX_START_LINE.exec(line) || MAC_LINUX_START_LINE.exec(line);
        if (!m) {
          continue;
        }
        var name = m[1];
        if (name.indexOf(interfaceName) !== 0) {
          continue;
        }
        var ip = null;
        var mac = null;
        var match = MAC_RE.exec(line);
        if (match) {
          mac = match[1];
        }
        i++;
        while (true) {
          line = lines[i];
          if (!line || MAC_OSX_START_LINE.exec(line) || MAC_LINUX_START_LINE.exec(line)) {
            i--;
            break;
          }
          if (!mac) {
            match = MAC_RE.exec(line);
            if (match) {
              mac = match[1];
            }
          }
          if (!ip) {
            match = MAC_IP_RE.exec(line);
            if (match) {
              ip = match[1];
            }
          }
          i++;
        }
        if (ip === matchIP) {
          return mac;
        }
      }
    }
    address.mac = function(interfaceName, callback) {
      if (typeof interfaceName === "function") {
        callback = interfaceName;
        interfaceName = null;
      }
      interfaceName = interfaceName || getInterfaceName();
      var item = address.interface("IPv4", interfaceName);
      if (!item) {
        return callback();
      }
      if (!process.env.CI && (item.mac === "ff:00:00:00:00:00" || item.mac === "00:00:00:00:00:00")) {
        item.mac = "";
      }
      if (item.mac) {
        return callback(null, item.mac);
      }
      child.exec(getIfconfigCMD(), { timeout: 5e3 }, function(err, stdout, stderr) {
        if (err || !stdout) {
          return callback(err);
        }
        var mac = getMAC(stdout || "", interfaceName, item.address);
        callback(null, mac);
      });
    };
    var DNS_SERVER_RE = /^nameserver\s+(\d+\.\d+\.\d+\.\d+)$/i;
    address.dns = function(filepath, callback) {
      if (typeof filepath === "function") {
        callback = filepath;
        filepath = null;
      }
      filepath = filepath || DEFAULT_RESOLV_FILE;
      fs.readFile(filepath, "utf8", function(err, content) {
        if (err) {
          return callback(err);
        }
        var servers = [];
        content = content || "";
        var lines = content.split("\n");
        for (var i = 0; i < lines.length; i++) {
          var line = lines[i].trim();
          var m = DNS_SERVER_RE.exec(line);
          if (m) {
            servers.push(m[1]);
          }
        }
        callback(null, servers);
      });
    };
    module.exports = address;
  }
});

// node_modules/ms/index.js
var require_ms = __commonJS({
  "node_modules/ms/index.js"(exports, module) {
    var s = 1e3;
    var m = s * 60;
    var h = m * 60;
    var d = h * 24;
    var w = d * 7;
    var y = d * 365.25;
    module.exports = function(val, options) {
      options = options || {};
      var type = typeof val;
      if (type === "string" && val.length > 0) {
        return parse(val);
      } else if (type === "number" && isFinite(val)) {
        return options.long ? fmtLong(val) : fmtShort(val);
      }
      throw new Error(
        "val is not a non-empty string or a valid number. val=" + JSON.stringify(val)
      );
    };
    function parse(str) {
      str = String(str);
      if (str.length > 100) {
        return;
      }
      var match = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
        str
      );
      if (!match) {
        return;
      }
      var n = parseFloat(match[1]);
      var type = (match[2] || "ms").toLowerCase();
      switch (type) {
        case "years":
        case "year":
        case "yrs":
        case "yr":
        case "y":
          return n * y;
        case "weeks":
        case "week":
        case "w":
          return n * w;
        case "days":
        case "day":
        case "d":
          return n * d;
        case "hours":
        case "hour":
        case "hrs":
        case "hr":
        case "h":
          return n * h;
        case "minutes":
        case "minute":
        case "mins":
        case "min":
        case "m":
          return n * m;
        case "seconds":
        case "second":
        case "secs":
        case "sec":
        case "s":
          return n * s;
        case "milliseconds":
        case "millisecond":
        case "msecs":
        case "msec":
        case "ms":
          return n;
        default:
          return void 0;
      }
    }
    function fmtShort(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return Math.round(ms / d) + "d";
      }
      if (msAbs >= h) {
        return Math.round(ms / h) + "h";
      }
      if (msAbs >= m) {
        return Math.round(ms / m) + "m";
      }
      if (msAbs >= s) {
        return Math.round(ms / s) + "s";
      }
      return ms + "ms";
    }
    function fmtLong(ms) {
      var msAbs = Math.abs(ms);
      if (msAbs >= d) {
        return plural(ms, msAbs, d, "day");
      }
      if (msAbs >= h) {
        return plural(ms, msAbs, h, "hour");
      }
      if (msAbs >= m) {
        return plural(ms, msAbs, m, "minute");
      }
      if (msAbs >= s) {
        return plural(ms, msAbs, s, "second");
      }
      return ms + " ms";
    }
    function plural(ms, msAbs, n, name) {
      var isPlural = msAbs >= n * 1.5;
      return Math.round(ms / n) + " " + name + (isPlural ? "s" : "");
    }
  }
});

// node_modules/debug/src/common.js
var require_common = __commonJS({
  "node_modules/debug/src/common.js"(exports, module) {
    function setup(env) {
      createDebug.debug = createDebug;
      createDebug.default = createDebug;
      createDebug.coerce = coerce;
      createDebug.disable = disable;
      createDebug.enable = enable;
      createDebug.enabled = enabled;
      createDebug.humanize = require_ms();
      createDebug.destroy = destroy;
      Object.keys(env).forEach((key) => {
        createDebug[key] = env[key];
      });
      createDebug.names = [];
      createDebug.skips = [];
      createDebug.formatters = {};
      function selectColor(namespace) {
        let hash = 0;
        for (let i = 0; i < namespace.length; i++) {
          hash = (hash << 5) - hash + namespace.charCodeAt(i);
          hash |= 0;
        }
        return createDebug.colors[Math.abs(hash) % createDebug.colors.length];
      }
      createDebug.selectColor = selectColor;
      function createDebug(namespace) {
        let prevTime;
        let enableOverride = null;
        let namespacesCache;
        let enabledCache;
        function debug(...args) {
          if (!debug.enabled) {
            return;
          }
          const self = debug;
          const curr = Number(/* @__PURE__ */ new Date());
          const ms = curr - (prevTime || curr);
          self.diff = ms;
          self.prev = prevTime;
          self.curr = curr;
          prevTime = curr;
          args[0] = createDebug.coerce(args[0]);
          if (typeof args[0] !== "string") {
            args.unshift("%O");
          }
          let index = 0;
          args[0] = args[0].replace(/%([a-zA-Z%])/g, (match, format) => {
            if (match === "%%") {
              return "%";
            }
            index++;
            const formatter = createDebug.formatters[format];
            if (typeof formatter === "function") {
              const val = args[index];
              match = formatter.call(self, val);
              args.splice(index, 1);
              index--;
            }
            return match;
          });
          createDebug.formatArgs.call(self, args);
          const logFn = self.log || createDebug.log;
          logFn.apply(self, args);
        }
        debug.namespace = namespace;
        debug.useColors = createDebug.useColors();
        debug.color = createDebug.selectColor(namespace);
        debug.extend = extend;
        debug.destroy = createDebug.destroy;
        Object.defineProperty(debug, "enabled", {
          enumerable: true,
          configurable: false,
          get: () => {
            if (enableOverride !== null) {
              return enableOverride;
            }
            if (namespacesCache !== createDebug.namespaces) {
              namespacesCache = createDebug.namespaces;
              enabledCache = createDebug.enabled(namespace);
            }
            return enabledCache;
          },
          set: (v) => {
            enableOverride = v;
          }
        });
        if (typeof createDebug.init === "function") {
          createDebug.init(debug);
        }
        return debug;
      }
      function extend(namespace, delimiter) {
        const newDebug = createDebug(this.namespace + (typeof delimiter === "undefined" ? ":" : delimiter) + namespace);
        newDebug.log = this.log;
        return newDebug;
      }
      function enable(namespaces) {
        createDebug.save(namespaces);
        createDebug.namespaces = namespaces;
        createDebug.names = [];
        createDebug.skips = [];
        const split = (typeof namespaces === "string" ? namespaces : "").trim().replace(" ", ",").split(",").filter(Boolean);
        for (const ns of split) {
          if (ns[0] === "-") {
            createDebug.skips.push(ns.slice(1));
          } else {
            createDebug.names.push(ns);
          }
        }
      }
      function matchesTemplate(search, template) {
        let searchIndex = 0;
        let templateIndex = 0;
        let starIndex = -1;
        let matchIndex = 0;
        while (searchIndex < search.length) {
          if (templateIndex < template.length && (template[templateIndex] === search[searchIndex] || template[templateIndex] === "*")) {
            if (template[templateIndex] === "*") {
              starIndex = templateIndex;
              matchIndex = searchIndex;
              templateIndex++;
            } else {
              searchIndex++;
              templateIndex++;
            }
          } else if (starIndex !== -1) {
            templateIndex = starIndex + 1;
            matchIndex++;
            searchIndex = matchIndex;
          } else {
            return false;
          }
        }
        while (templateIndex < template.length && template[templateIndex] === "*") {
          templateIndex++;
        }
        return templateIndex === template.length;
      }
      function disable() {
        const namespaces = [
          ...createDebug.names,
          ...createDebug.skips.map((namespace) => "-" + namespace)
        ].join(",");
        createDebug.enable("");
        return namespaces;
      }
      function enabled(name) {
        for (const skip of createDebug.skips) {
          if (matchesTemplate(name, skip)) {
            return false;
          }
        }
        for (const ns of createDebug.names) {
          if (matchesTemplate(name, ns)) {
            return true;
          }
        }
        return false;
      }
      function coerce(val) {
        if (val instanceof Error) {
          return val.stack || val.message;
        }
        return val;
      }
      function destroy() {
        console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
      }
      createDebug.enable(createDebug.load());
      return createDebug;
    }
    module.exports = setup;
  }
});

// node_modules/debug/src/browser.js
var require_browser = __commonJS({
  "node_modules/debug/src/browser.js"(exports, module) {
    exports.formatArgs = formatArgs;
    exports.save = save;
    exports.load = load;
    exports.useColors = useColors;
    exports.storage = localstorage();
    exports.destroy = (() => {
      let warned = false;
      return () => {
        if (!warned) {
          warned = true;
          console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
        }
      };
    })();
    exports.colors = [
      "#0000CC",
      "#0000FF",
      "#0033CC",
      "#0033FF",
      "#0066CC",
      "#0066FF",
      "#0099CC",
      "#0099FF",
      "#00CC00",
      "#00CC33",
      "#00CC66",
      "#00CC99",
      "#00CCCC",
      "#00CCFF",
      "#3300CC",
      "#3300FF",
      "#3333CC",
      "#3333FF",
      "#3366CC",
      "#3366FF",
      "#3399CC",
      "#3399FF",
      "#33CC00",
      "#33CC33",
      "#33CC66",
      "#33CC99",
      "#33CCCC",
      "#33CCFF",
      "#6600CC",
      "#6600FF",
      "#6633CC",
      "#6633FF",
      "#66CC00",
      "#66CC33",
      "#9900CC",
      "#9900FF",
      "#9933CC",
      "#9933FF",
      "#99CC00",
      "#99CC33",
      "#CC0000",
      "#CC0033",
      "#CC0066",
      "#CC0099",
      "#CC00CC",
      "#CC00FF",
      "#CC3300",
      "#CC3333",
      "#CC3366",
      "#CC3399",
      "#CC33CC",
      "#CC33FF",
      "#CC6600",
      "#CC6633",
      "#CC9900",
      "#CC9933",
      "#CCCC00",
      "#CCCC33",
      "#FF0000",
      "#FF0033",
      "#FF0066",
      "#FF0099",
      "#FF00CC",
      "#FF00FF",
      "#FF3300",
      "#FF3333",
      "#FF3366",
      "#FF3399",
      "#FF33CC",
      "#FF33FF",
      "#FF6600",
      "#FF6633",
      "#FF9900",
      "#FF9933",
      "#FFCC00",
      "#FFCC33"
    ];
    function useColors() {
      if (typeof window !== "undefined" && window.process && (window.process.type === "renderer" || window.process.__nwjs)) {
        return true;
      }
      if (typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/)) {
        return false;
      }
      let m;
      return typeof document !== "undefined" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || // Is firebug? http://stackoverflow.com/a/398120/376773
      typeof window !== "undefined" && window.console && (window.console.firebug || window.console.exception && window.console.table) || // Is firefox >= v31?
      // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
      typeof navigator !== "undefined" && navigator.userAgent && (m = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(m[1], 10) >= 31 || // Double check webkit in userAgent just in case we are in a worker
      typeof navigator !== "undefined" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
    }
    function formatArgs(args) {
      args[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + args[0] + (this.useColors ? "%c " : " ") + "+" + module.exports.humanize(this.diff);
      if (!this.useColors) {
        return;
      }
      const c = "color: " + this.color;
      args.splice(1, 0, c, "color: inherit");
      let index = 0;
      let lastC = 0;
      args[0].replace(/%[a-zA-Z%]/g, (match) => {
        if (match === "%%") {
          return;
        }
        index++;
        if (match === "%c") {
          lastC = index;
        }
      });
      args.splice(lastC, 0, c);
    }
    exports.log = console.debug || console.log || (() => {
    });
    function save(namespaces) {
      try {
        if (namespaces) {
          exports.storage.setItem("debug", namespaces);
        } else {
          exports.storage.removeItem("debug");
        }
      } catch (error) {
      }
    }
    function load() {
      let r;
      try {
        r = exports.storage.getItem("debug");
      } catch (error) {
      }
      if (!r && typeof process !== "undefined" && "env" in process) {
        r = process.env.DEBUG;
      }
      return r;
    }
    function localstorage() {
      try {
        return localStorage;
      } catch (error) {
      }
    }
    module.exports = require_common()(exports);
    var { formatters } = module.exports;
    formatters.j = function(v) {
      try {
        return JSON.stringify(v);
      } catch (error) {
        return "[UnexpectedJSONParseError]: " + error.message;
      }
    };
  }
});

// node_modules/detect-port/lib/detect-port.js
var require_detect_port = __commonJS({
  "node_modules/detect-port/lib/detect-port.js"(exports, module) {
    "use strict";
    var net = require_net();
    var address = require_address();
    var debug = require_browser()("detect-port");
    module.exports = (port, callback) => {
      let hostname = "";
      if (typeof port === "object" && port) {
        hostname = port.hostname;
        callback = port.callback;
        port = port.port;
      } else {
        if (typeof port === "function") {
          callback = port;
          port = null;
        }
      }
      port = parseInt(port) || 0;
      let maxPort = port + 10;
      if (maxPort > 65535) {
        maxPort = 65535;
      }
      debug("detect free port between [%s, %s)", port, maxPort);
      if (typeof callback === "function") {
        return tryListen(port, maxPort, hostname, callback);
      }
      return new Promise((resolve) => {
        tryListen(port, maxPort, hostname, (_, realPort) => {
          resolve(realPort);
        });
      });
    };
    function tryListen(port, maxPort, hostname, callback) {
      function handleError() {
        port++;
        if (port >= maxPort) {
          debug("port: %s >= maxPort: %s, give up and use random port", port, maxPort);
          port = 0;
          maxPort = 0;
        }
        tryListen(port, maxPort, hostname, callback);
      }
      if (hostname) {
        listen(port, hostname, (err, realPort) => {
          if (err) {
            if (err.code === "EADDRNOTAVAIL") {
              return callback(new Error("the ip that is not unknown on the machine"));
            }
            return handleError();
          }
          callback(null, realPort);
        });
      } else {
        listen(port, null, (err, realPort) => {
          if (port === 0) {
            return callback(err, realPort);
          }
          if (err) {
            return handleError(err);
          }
          listen(port, "0.0.0.0", (err2) => {
            if (err2) {
              return handleError(err2);
            }
            listen(port, "localhost", (err3) => {
              if (err3 && err3.code !== "EADDRNOTAVAIL") {
                return handleError(err3);
              }
              listen(port, address.ip(), (err4, realPort2) => {
                if (err4) {
                  return handleError(err4);
                }
                callback(null, realPort2);
              });
            });
          });
        });
      }
    }
    function listen(port, hostname, callback) {
      const server = new net.Server();
      server.on("error", (err) => {
        debug("listen %s:%s error: %s", hostname, port, err);
        server.close();
        if (err.code === "ENOTFOUND") {
          debug("ignore dns ENOTFOUND error, get free %s:%s", hostname, port);
          return callback(null, port);
        }
        return callback(err);
      });
      server.listen(port, hostname, () => {
        port = server.address().port;
        server.close();
        debug("get free %s:%s", hostname, port);
        return callback(null, port);
      });
    }
  }
});

// node_modules/detect-port/lib/wait-port.js
var require_wait_port = __commonJS({
  "node_modules/detect-port/lib/wait-port.js"(exports, module) {
    "use strict";
    var debug = require_browser()("wait-port");
    var detect = require_detect_port();
    var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
    async function waitPort(port, options = {}) {
      const { retryInterval = 1e3, retries = Infinity } = options;
      let count = 1;
      async function loop() {
        debug("retries", retries, "count", count);
        if (count > retries) {
          const err = new Error("retries exceeded");
          err.retries = retries;
          err.count = count;
          throw err;
        }
        count++;
        const freePort = await detect(port);
        if (freePort === port) {
          await sleep(retryInterval);
          return loop();
        }
        return true;
      }
      return await loop();
    }
    module.exports = waitPort;
  }
});

// node_modules/detect-port/index.js
var require_detect_port2 = __commonJS({
  "node_modules/detect-port/index.js"(exports, module) {
    module.exports = require_detect_port();
    module.exports.waitPort = require_wait_port();
  }
});
export default require_detect_port2();
//# sourceMappingURL=detect-port.js.map
