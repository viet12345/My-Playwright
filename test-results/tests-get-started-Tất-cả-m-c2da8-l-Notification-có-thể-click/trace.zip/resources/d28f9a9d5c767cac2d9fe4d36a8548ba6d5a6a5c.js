import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionAmount.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionAmount.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { isRequestTransaction, formatAmount } from "/src/utils/transactionUtils.ts";
const PREFIX = "TransactionAmount";
const classes = {
  amountPositive: `${PREFIX}-amountPositive`,
  amountNegative: `${PREFIX}-amountNegative`
};
const StyledTypography = styled(Typography)(({ theme }) => ({
  [`&.${classes.amountPositive}`]: {
    fontSize: 24,
    [theme.breakpoints.down("md")]: {
      fontSize: theme.typography.body1.fontSize
    },
    color: "#4CAF50"
  },
  [`&.${classes.amountNegative}`]: {
    fontSize: 24,
    [theme.breakpoints.down("md")]: {
      fontSize: theme.typography.body1.fontSize
    },
    color: "red"
  }
}));
const TransactionAmount = ({ transaction }) => {
  return /* @__PURE__ */ jsxDEV(
    StyledTypography,
    {
      "data-test": `transaction-amount-${transaction.id}`,
      className: isRequestTransaction(transaction) ? classes.amountPositive : classes.amountNegative,
      display: "inline",
      component: "span",
      color: "primary",
      children: [
        isRequestTransaction(transaction) ? "+" : "-",
        transaction.amount && formatAmount(transaction.amount)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionAmount.tsx",
      lineNumber: 36,
      columnNumber: 5
    },
    this
  );
};
_c = TransactionAmount;
export default TransactionAmount;
var _c;
$RefreshReg$(_c, "TransactionAmount");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionAmount.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionAmount.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUNJO0FBbkNKLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxrQkFBa0I7QUFFM0IsU0FBU0Msc0JBQXNCQyxvQkFBb0I7QUFFbkQsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxnQkFBZ0IsR0FBR0YsTUFBTTtBQUFBLEVBQ3pCRyxnQkFBZ0IsR0FBR0gsTUFBTTtBQUMzQjtBQUVBLE1BQU1JLG1CQUFtQlIsT0FBT0MsVUFBVSxFQUFFLENBQUMsRUFBRVEsTUFBTSxPQUFPO0FBQUEsRUFDMUQsQ0FBQyxLQUFLSixRQUFRQyxjQUFjLEVBQUUsR0FBRztBQUFBLElBQy9CSSxVQUFVO0FBQUEsSUFDVixDQUFDRCxNQUFNRSxZQUFZQyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFDOUJGLFVBQVVELE1BQU1JLFdBQVdDLE1BQU1KO0FBQUFBLElBQ25DO0FBQUEsSUFDQUssT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLENBQUMsS0FBS1YsUUFBUUUsY0FBYyxFQUFFLEdBQUc7QUFBQSxJQUMvQkcsVUFBVTtBQUFBLElBQ1YsQ0FBQ0QsTUFBTUUsWUFBWUMsS0FBSyxJQUFJLENBQUMsR0FBRztBQUFBLE1BQzlCRixVQUFVRCxNQUFNSSxXQUFXQyxNQUFNSjtBQUFBQSxJQUNuQztBQUFBLElBQ0FLLE9BQU87QUFBQSxFQUNUO0FBQ0YsRUFBRTtBQUVGLE1BQU1DLG9CQUVEQSxDQUFDLEVBQUVDLFlBQVksTUFBTTtBQUN4QixTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxhQUFXLHNCQUFzQkEsWUFBWUMsRUFBRTtBQUFBLE1BQy9DLFdBQ0VoQixxQkFBcUJlLFdBQVcsSUFBSVosUUFBUUMsaUJBQWlCRCxRQUFRRTtBQUFBQSxNQUV2RSxTQUFRO0FBQUEsTUFDUixXQUFVO0FBQUEsTUFDVixPQUFNO0FBQUEsTUFFTEw7QUFBQUEsNkJBQXFCZSxXQUFXLElBQUksTUFBTTtBQUFBLFFBQzFDQSxZQUFZRSxVQUFVaEIsYUFBYWMsWUFBWUUsTUFBTTtBQUFBO0FBQUE7QUFBQSxJQVZ4RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFXQTtBQUVKO0FBQUVDLEtBakJJSjtBQW1CTixlQUFlQTtBQUFrQixJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJzdHlsZWQiLCJUeXBvZ3JhcGh5IiwiaXNSZXF1ZXN0VHJhbnNhY3Rpb24iLCJmb3JtYXRBbW91bnQiLCJQUkVGSVgiLCJjbGFzc2VzIiwiYW1vdW50UG9zaXRpdmUiLCJhbW91bnROZWdhdGl2ZSIsIlN0eWxlZFR5cG9ncmFwaHkiLCJ0aGVtZSIsImZvbnRTaXplIiwiYnJlYWtwb2ludHMiLCJkb3duIiwidHlwb2dyYXBoeSIsImJvZHkxIiwiY29sb3IiLCJUcmFuc2FjdGlvbkFtb3VudCIsInRyYW5zYWN0aW9uIiwiaWQiLCJhbW91bnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uQW1vdW50LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBUeXBvZ3JhcGh5IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW0gfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCB7IGlzUmVxdWVzdFRyYW5zYWN0aW9uLCBmb3JtYXRBbW91bnQgfSBmcm9tIFwiLi4vdXRpbHMvdHJhbnNhY3Rpb25VdGlsc1wiO1xyXG5cclxuY29uc3QgUFJFRklYID0gXCJUcmFuc2FjdGlvbkFtb3VudFwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBhbW91bnRQb3NpdGl2ZTogYCR7UFJFRklYfS1hbW91bnRQb3NpdGl2ZWAsXHJcbiAgYW1vdW50TmVnYXRpdmU6IGAke1BSRUZJWH0tYW1vdW50TmVnYXRpdmVgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkVHlwb2dyYXBoeSA9IHN0eWxlZChUeXBvZ3JhcGh5KSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMuYW1vdW50UG9zaXRpdmV9YF06IHtcclxuICAgIGZvbnRTaXplOiAyNCxcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKFwibWRcIildOiB7XHJcbiAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmJvZHkxLmZvbnRTaXplLFxyXG4gICAgfSxcclxuICAgIGNvbG9yOiBcIiM0Q0FGNTBcIixcclxuICB9LFxyXG5cclxuICBbYCYuJHtjbGFzc2VzLmFtb3VudE5lZ2F0aXZlfWBdOiB7XHJcbiAgICBmb250U2l6ZTogMjQsXHJcbiAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bihcIm1kXCIpXToge1xyXG4gICAgICBmb250U2l6ZTogdGhlbWUudHlwb2dyYXBoeS5ib2R5MS5mb250U2l6ZSxcclxuICAgIH0sXHJcbiAgICBjb2xvcjogXCJyZWRcIixcclxuICB9LFxyXG59KSkgYXMgdHlwZW9mIFR5cG9ncmFwaHk7XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbkFtb3VudDogUmVhY3QuRkM8e1xyXG4gIHRyYW5zYWN0aW9uOiBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbTtcclxufT4gPSAoeyB0cmFuc2FjdGlvbiB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRUeXBvZ3JhcGh5XHJcbiAgICAgIGRhdGEtdGVzdD17YHRyYW5zYWN0aW9uLWFtb3VudC0ke3RyYW5zYWN0aW9uLmlkfWB9XHJcbiAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgaXNSZXF1ZXN0VHJhbnNhY3Rpb24odHJhbnNhY3Rpb24pID8gY2xhc3Nlcy5hbW91bnRQb3NpdGl2ZSA6IGNsYXNzZXMuYW1vdW50TmVnYXRpdmVcclxuICAgICAgfVxyXG4gICAgICBkaXNwbGF5PVwiaW5saW5lXCJcclxuICAgICAgY29tcG9uZW50PVwic3BhblwiXHJcbiAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICA+XHJcbiAgICAgIHtpc1JlcXVlc3RUcmFuc2FjdGlvbih0cmFuc2FjdGlvbikgPyBcIitcIiA6IFwiLVwifVxyXG4gICAgICB7dHJhbnNhY3Rpb24uYW1vdW50ICYmIGZvcm1hdEFtb3VudCh0cmFuc2FjdGlvbi5hbW91bnQpfVxyXG4gICAgPC9TdHlsZWRUeXBvZ3JhcGh5PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvbkFtb3VudDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvbkFtb3VudC50c3gifQ==