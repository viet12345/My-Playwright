import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NavDrawer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import __vite__cjsImport4_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const head = __vite__cjsImport4_lodash_fp["head"];
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import clsx from "/node_modules/.vite/deps/clsx.js?v=6af76b79";
import {
  useMediaQuery,
  useTheme,
  Drawer,
  List,
  Divider,
  ListItem,
  ListItemIcon,
  ListItemText,
  Grid,
  Avatar,
  Typography
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Link as RouterLink } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import {
  Home as HomeIcon,
  Person as PersonIcon,
  ExitToApp as LogoutIcon,
  Notifications as NotificationsIcon,
  AccountBalance as AccountBalanceIcon
} from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import { formatAmount } from "/src/utils/transactionUtils.ts";
const PREFIX = "NavDrawer";
const classes = {
  toolbar: `${PREFIX}-toolbar`,
  toolbarIcon: `${PREFIX}-toolbarIcon`,
  drawerPaper: `${PREFIX}-drawerPaper`,
  drawerPaperClose: `${PREFIX}-drawerPaperClose`,
  userProfile: `${PREFIX}-userProfile`,
  userProfileHidden: `${PREFIX}-userProfileHidden`,
  avatar: `${PREFIX}-avatar`,
  accountBalance: `${PREFIX}-accountBalance`,
  amount: `${PREFIX}-amount`,
  accountBalanceHidden: `${PREFIX}-accountBalanceHidden`,
  cypressLogo: `${PREFIX}-cypressLogo`
};
const StyledDrawer = styled(Drawer)(({ theme }) => ({
  [`& .${classes.toolbar}`]: {
    paddingRight: 24
    // keep right padding when drawer closed
  },
  [`& .${classes.toolbarIcon}`]: {
    display: "flex",
    alignItems: "center",
    justifyContent: "flex-end",
    padding: "0 8px",
    ...theme.mixins.toolbar
  },
  [`& .${classes.drawerPaper}`]: {
    position: "relative",
    whiteSpace: "nowrap",
    width: drawerWidth,
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  [`& .${classes.drawerPaperClose}`]: {
    marginTop: 50,
    overflowX: "hidden",
    transition: theme.transitions.create("width", {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    }),
    width: theme.spacing(7),
    [theme.breakpoints.up("sm")]: {
      width: theme.spacing(9)
    }
  },
  [`& .${classes.userProfile}`]: {
    padding: theme.spacing(2)
  },
  [`& .${classes.userProfileHidden}`]: {
    display: "none"
  },
  [`& .${classes.avatar}`]: {
    marginRight: theme.spacing(2)
  },
  [`& .${classes.accountBalance}`]: {
    marginLeft: theme.spacing(2)
  },
  [`& .${classes.amount}`]: {
    fontWeight: "bold"
  },
  [`& .${classes.accountBalanceHidden}`]: {
    display: "none"
  },
  [`& .${classes.cypressLogo}`]: {
    width: "40%"
  }
}));
_c = StyledDrawer;
const drawerWidth = 240;
export const mainListItems = (toggleDrawer, showTemporaryDrawer) => /* @__PURE__ */ jsxDEV("div", { children: [
  /* @__PURE__ */ jsxDEV(
    ListItem,
    {
      button: true,
      onClick: () => showTemporaryDrawer && toggleDrawer(),
      component: RouterLink,
      to: "/",
      "data-test": "sidenav-home",
      children: [
        /* @__PURE__ */ jsxDEV(ListItemIcon, { children: /* @__PURE__ */ jsxDEV(HomeIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 129,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 128,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ListItemText, { primary: "Home" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 131,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
      lineNumber: 120,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV(
    ListItem,
    {
      button: true,
      onClick: () => showTemporaryDrawer && toggleDrawer(),
      component: RouterLink,
      to: "/user/settings",
      "data-test": "sidenav-user-settings",
      children: [
        /* @__PURE__ */ jsxDEV(ListItemIcon, { children: /* @__PURE__ */ jsxDEV(PersonIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 142,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 141,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ListItemText, { primary: "My Account" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 144,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
      lineNumber: 133,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV(
    ListItem,
    {
      button: true,
      onClick: () => showTemporaryDrawer && toggleDrawer(),
      component: RouterLink,
      to: "/bankaccounts",
      "data-test": "sidenav-bankaccounts",
      children: [
        /* @__PURE__ */ jsxDEV(ListItemIcon, { children: /* @__PURE__ */ jsxDEV(AccountBalanceIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 155,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 154,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ListItemText, { primary: "Bank Accounts" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 157,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
      lineNumber: 146,
      columnNumber: 5
    },
    this
  ),
  /* @__PURE__ */ jsxDEV(
    ListItem,
    {
      button: true,
      onClick: () => showTemporaryDrawer && toggleDrawer(),
      component: RouterLink,
      to: "/notifications",
      "data-test": "sidenav-notifications",
      children: [
        /* @__PURE__ */ jsxDEV(ListItemIcon, { children: /* @__PURE__ */ jsxDEV(NotificationsIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 168,
          columnNumber: 9
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 167,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(ListItemText, { primary: "Notifications" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
          lineNumber: 170,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
      lineNumber: 159,
      columnNumber: 5
    },
    this
  )
] }, void 0, true, {
  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
  lineNumber: 119,
  columnNumber: 1
}, this);
export const secondaryListItems = (signOutPending) => /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(ListItem, { button: true, onClick: () => signOutPending(), "data-test": "sidenav-signout", children: [
  /* @__PURE__ */ jsxDEV(ListItemIcon, { children: /* @__PURE__ */ jsxDEV(LogoutIcon, {}, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
    lineNumber: 179,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
    lineNumber: 178,
    columnNumber: 7
  }, this),
  /* @__PURE__ */ jsxDEV(ListItemText, { primary: "Logout" }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
    lineNumber: 181,
    columnNumber: 7
  }, this)
] }, void 0, true, {
  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
  lineNumber: 177,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
  lineNumber: 176,
  columnNumber: 1
}, this);
const NavDrawer = ({
  toggleDrawer,
  closeMobileDrawer,
  drawerOpen,
  authService
}) => {
  _s();
  const theme = useTheme();
  const [authState, sendAuth] = useActor(authService);
  const showTemporaryDrawer = useMediaQuery(theme.breakpoints.only("xs"));
  const currentUser = authState?.context?.user;
  const signOut = () => sendAuth("LOGOUT");
  return /* @__PURE__ */ jsxDEV(
    StyledDrawer,
    {
      "data-test": "sidenav",
      variant: showTemporaryDrawer ? "temporary" : "persistent",
      classes: {
        paper: clsx(classes.drawerPaper, !drawerOpen && classes.drawerPaperClose)
      },
      open: drawerOpen,
      ModalProps: {
        onBackdropClick: () => closeMobileDrawer(),
        closeAfterTransition: showTemporaryDrawer
      },
      children: [
        /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            className: drawerOpen ? classes.userProfile : classes.userProfileHidden,
            children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: currentUser && /* @__PURE__ */ jsxDEV(
                Avatar,
                {
                  className: classes.avatar,
                  alt: `${currentUser.firstName} ${currentUser.lastName}`,
                  src: currentUser.avatar
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                  lineNumber: 228,
                  columnNumber: 11
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 226,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: currentUser && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(
                  Typography,
                  {
                    variant: "subtitle1",
                    color: "textPrimary",
                    "data-test": "sidenav-user-full-name",
                    children: [
                      currentUser.firstName,
                      " ",
                      head(currentUser.lastName)
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                    lineNumber: 238,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Typography,
                  {
                    variant: "subtitle2",
                    color: "inherit",
                    gutterBottom: true,
                    "data-test": "sidenav-username",
                    children: [
                      "@",
                      currentUser.username
                    ]
                  },
                  void 0,
                  true,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                    lineNumber: 245,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 237,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 235,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, style: { width: "30%" } }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 256,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
            lineNumber: 219,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            className: drawerOpen ? classes.userProfile : classes.userProfileHidden,
            children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: currentUser && /* @__PURE__ */ jsxDEV(Fragment, { children: [
                /* @__PURE__ */ jsxDEV(
                  Typography,
                  {
                    variant: "h6",
                    color: "textPrimary",
                    className: classes.amount,
                    "data-test": "sidenav-user-balance",
                    children: currentUser.balance ? formatAmount(currentUser.balance) : formatAmount(0)
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                    lineNumber: 268,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(Typography, { variant: "subtitle2", color: "inherit", gutterBottom: true, children: "Account Balance" }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                  lineNumber: 276,
                  columnNumber: 15
                }, this)
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 267,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 265,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Divider, {}, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 283,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 282,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(List, { children: mainListItems(toggleDrawer, showTemporaryDrawer) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 286,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 285,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Divider, {}, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 289,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 288,
                columnNumber: 9
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(List, { children: secondaryListItems(signOut) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 292,
                columnNumber: 11
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
                lineNumber: 291,
                columnNumber: 9
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
            lineNumber: 258,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx",
      lineNumber: 207,
      columnNumber: 5
    },
    this
  );
};
_s(NavDrawer, "FQovIVouWzN798Ir4Z3tAy8mBMw=", false, function() {
  return [useTheme, useActor, useMediaQuery];
});
_c2 = NavDrawer;
export default NavDrawer;
var _c, _c2;
$RefreshReg$(_c, "StyledDrawer");
$RefreshReg$(_c2, "NavDrawer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavDrawer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0lRLFNBNEdJLFVBNUdKOzJCQWhJUjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLFlBQVk7QUFFckIsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFVBQVU7QUFDakI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsU0FBU0MsUUFBUUMsa0JBQWtCO0FBQ25DO0FBQUEsRUFDRUMsUUFBUUM7QUFBQUEsRUFDUkMsVUFBVUM7QUFBQUEsRUFDVkMsYUFBYUM7QUFBQUEsRUFDYkMsaUJBQWlCQztBQUFBQSxFQUNqQkMsa0JBQWtCQztBQUFBQSxPQUNiO0FBRVAsU0FBU0Msb0JBQW9CO0FBRzdCLE1BQU1DLFNBQVM7QUFFZixNQUFNQyxVQUFVO0FBQUEsRUFDZEMsU0FBUyxHQUFHRixNQUFNO0FBQUEsRUFDbEJHLGFBQWEsR0FBR0gsTUFBTTtBQUFBLEVBQ3RCSSxhQUFhLEdBQUdKLE1BQU07QUFBQSxFQUN0Qkssa0JBQWtCLEdBQUdMLE1BQU07QUFBQSxFQUMzQk0sYUFBYSxHQUFHTixNQUFNO0FBQUEsRUFDdEJPLG1CQUFtQixHQUFHUCxNQUFNO0FBQUEsRUFDNUJRLFFBQVEsR0FBR1IsTUFBTTtBQUFBLEVBQ2pCUyxnQkFBZ0IsR0FBR1QsTUFBTTtBQUFBLEVBQ3pCVSxRQUFRLEdBQUdWLE1BQU07QUFBQSxFQUNqQlcsc0JBQXNCLEdBQUdYLE1BQU07QUFBQSxFQUMvQlksYUFBYSxHQUFHWixNQUFNO0FBQ3hCO0FBRUEsTUFBTWEsZUFBZXpDLE9BQU9NLE1BQU0sRUFBRSxDQUFDLEVBQUVvQyxNQUFNLE9BQU87QUFBQSxFQUNsRCxDQUFDLE1BQU1iLFFBQVFDLE9BQU8sRUFBRSxHQUFHO0FBQUEsSUFDekJhLGNBQWM7QUFBQTtBQUFBLEVBQ2hCO0FBQUEsRUFFQSxDQUFDLE1BQU1kLFFBQVFFLFdBQVcsRUFBRSxHQUFHO0FBQUEsSUFDN0JhLFNBQVM7QUFBQSxJQUNUQyxZQUFZO0FBQUEsSUFDWkMsZ0JBQWdCO0FBQUEsSUFDaEJDLFNBQVM7QUFBQSxJQUNULEdBQUdMLE1BQU1NLE9BQU9sQjtBQUFBQSxFQUNsQjtBQUFBLEVBRUEsQ0FBQyxNQUFNRCxRQUFRRyxXQUFXLEVBQUUsR0FBRztBQUFBLElBQzdCaUIsVUFBVTtBQUFBLElBQ1ZDLFlBQVk7QUFBQSxJQUNaQyxPQUFPQztBQUFBQSxJQUNQQyxZQUFZWCxNQUFNWSxZQUFZQyxPQUFPLFNBQVM7QUFBQSxNQUM1Q0MsUUFBUWQsTUFBTVksWUFBWUUsT0FBT0M7QUFBQUEsTUFDakNDLFVBQVVoQixNQUFNWSxZQUFZSSxTQUFTQztBQUFBQSxJQUN2QyxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsQ0FBQyxNQUFNOUIsUUFBUUksZ0JBQWdCLEVBQUUsR0FBRztBQUFBLElBQ2xDMkIsV0FBVztBQUFBLElBQ1hDLFdBQVc7QUFBQSxJQUNYUixZQUFZWCxNQUFNWSxZQUFZQyxPQUFPLFNBQVM7QUFBQSxNQUM1Q0MsUUFBUWQsTUFBTVksWUFBWUUsT0FBT0M7QUFBQUEsTUFDakNDLFVBQVVoQixNQUFNWSxZQUFZSSxTQUFTSTtBQUFBQSxJQUN2QyxDQUFDO0FBQUEsSUFDRFgsT0FBT1QsTUFBTXFCLFFBQVEsQ0FBQztBQUFBLElBQ3RCLENBQUNyQixNQUFNc0IsWUFBWUMsR0FBRyxJQUFJLENBQUMsR0FBRztBQUFBLE1BQzVCZCxPQUFPVCxNQUFNcUIsUUFBUSxDQUFDO0FBQUEsSUFDeEI7QUFBQSxFQUNGO0FBQUEsRUFFQSxDQUFDLE1BQU1sQyxRQUFRSyxXQUFXLEVBQUUsR0FBRztBQUFBLElBQzdCYSxTQUFTTCxNQUFNcUIsUUFBUSxDQUFDO0FBQUEsRUFDMUI7QUFBQSxFQUVBLENBQUMsTUFBTWxDLFFBQVFNLGlCQUFpQixFQUFFLEdBQUc7QUFBQSxJQUNuQ1MsU0FBUztBQUFBLEVBQ1g7QUFBQSxFQUVBLENBQUMsTUFBTWYsUUFBUU8sTUFBTSxFQUFFLEdBQUc7QUFBQSxJQUN4QjhCLGFBQWF4QixNQUFNcUIsUUFBUSxDQUFDO0FBQUEsRUFDOUI7QUFBQSxFQUVBLENBQUMsTUFBTWxDLFFBQVFRLGNBQWMsRUFBRSxHQUFHO0FBQUEsSUFDaEM4QixZQUFZekIsTUFBTXFCLFFBQVEsQ0FBQztBQUFBLEVBQzdCO0FBQUEsRUFFQSxDQUFDLE1BQU1sQyxRQUFRUyxNQUFNLEVBQUUsR0FBRztBQUFBLElBQ3hCOEIsWUFBWTtBQUFBLEVBQ2Q7QUFBQSxFQUVBLENBQUMsTUFBTXZDLFFBQVFVLG9CQUFvQixFQUFFLEdBQUc7QUFBQSxJQUN0Q0ssU0FBUztBQUFBLEVBQ1g7QUFBQSxFQUVBLENBQUMsTUFBTWYsUUFBUVcsV0FBVyxFQUFFLEdBQUc7QUFBQSxJQUM3QlcsT0FBTztBQUFBLEVBQ1Q7QUFDRixFQUFFO0FBQUVrQixLQS9ERTVCO0FBaUVOLE1BQU1XLGNBQWM7QUFFYixhQUFNa0IsZ0JBQWdCQSxDQUMzQkMsY0FDQUMsd0JBRUEsdUJBQUMsU0FDQztBQUFBO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BRUEsU0FBUyxNQUFNQSx1QkFBdUJELGFBQWE7QUFBQSxNQUNuRCxXQUFXdkQ7QUFBQUEsTUFDWCxJQUFHO0FBQUEsTUFDSCxhQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLGdCQUNDLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxnQkFBYSxTQUFRLFVBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQTtBQUFBO0FBQUEsSUFYOUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUE7QUFBQSxFQUNBO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BRUEsU0FBUyxNQUFNd0QsdUJBQXVCRCxhQUFhO0FBQUEsTUFDbkQsV0FBV3ZEO0FBQUFBLE1BQ1gsSUFBRztBQUFBLE1BQ0gsYUFBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxnQkFDQyxpQ0FBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVcsS0FEYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLGdCQUFhLFNBQVEsZ0JBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0M7QUFBQTtBQUFBO0FBQUEsSUFYcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUE7QUFBQSxFQUNBO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BRUEsU0FBUyxNQUFNd0QsdUJBQXVCRCxhQUFhO0FBQUEsTUFDbkQsV0FBV3ZEO0FBQUFBLE1BQ1gsSUFBRztBQUFBLE1BQ0gsYUFBVTtBQUFBLE1BRVY7QUFBQSwrQkFBQyxnQkFDQyxpQ0FBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsZ0JBQWEsU0FBUSxtQkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFxQztBQUFBO0FBQUE7QUFBQSxJQVh2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFZQTtBQUFBLEVBQ0E7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFFQSxTQUFTLE1BQU13RCx1QkFBdUJELGFBQWE7QUFBQSxNQUNuRCxXQUFXdkQ7QUFBQUEsTUFDWCxJQUFHO0FBQUEsTUFDSCxhQUFVO0FBQUEsTUFFVjtBQUFBLCtCQUFDLGdCQUNDLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxnQkFBYSxTQUFRLG1CQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXFDO0FBQUE7QUFBQTtBQUFBLElBWHZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVlBO0FBQUEsS0FwREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxPQXFEQTtBQUdLLGFBQU15RCxxQkFBcUJBLENBQUNDLG1CQUNqQyx1QkFBQyxTQUNDLGlDQUFDLFlBQVMsUUFBTSxNQUFDLFNBQVMsTUFBTUEsZUFBZSxHQUFHLGFBQVUsbUJBQzFEO0FBQUEseUJBQUMsZ0JBQ0MsaUNBQUMsZ0JBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFXLEtBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBQUEsRUFDQSx1QkFBQyxnQkFBYSxTQUFRLFlBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBOEI7QUFBQSxLQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBLE9BS0EsS0FORjtBQUFBO0FBQUE7QUFBQTtBQUFBLE9BT0E7QUFVRixNQUFNQyxZQUE2QkEsQ0FBQztBQUFBLEVBQ2xDSjtBQUFBQSxFQUNBSztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU1yQyxRQUFRckMsU0FBUztBQUN2QixRQUFNLENBQUMyRSxXQUFXQyxRQUFRLElBQUkvRSxTQUFTNEUsV0FBVztBQUNsRCxRQUFNTixzQkFBc0JwRSxjQUFjc0MsTUFBTXNCLFlBQVlrQixLQUFLLElBQUksQ0FBQztBQUV0RSxRQUFNQyxjQUFjSCxXQUFXSSxTQUFTQztBQUN4QyxRQUFNQyxVQUFVQSxNQUFNTCxTQUFTLFFBQVE7QUFFdkMsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsYUFBVTtBQUFBLE1BQ1YsU0FBU1Qsc0JBQXNCLGNBQWM7QUFBQSxNQUM3QyxTQUFTO0FBQUEsUUFDUGUsT0FBT3BGLEtBQUswQixRQUFRRyxhQUFhLENBQUM2QyxjQUFjaEQsUUFBUUksZ0JBQWdCO0FBQUEsTUFDMUU7QUFBQSxNQUNBLE1BQU00QztBQUFBQSxNQUNOLFlBQVk7QUFBQSxRQUNWVyxpQkFBaUJBLE1BQU1aLGtCQUFrQjtBQUFBLFFBQ3pDYSxzQkFBc0JqQjtBQUFBQSxNQUN4QjtBQUFBLE1BRUE7QUFBQTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0M7QUFBQSxZQUNBLFdBQVU7QUFBQSxZQUNWLGdCQUFlO0FBQUEsWUFDZixZQUFXO0FBQUEsWUFDWCxXQUFXSyxhQUFhaEQsUUFBUUssY0FBY0wsUUFBUU07QUFBQUEsWUFFdEQ7QUFBQSxxQ0FBQyxRQUFLLE1BQUksTUFDUGdELHlCQUNDO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFdBQVd0RCxRQUFRTztBQUFBQSxrQkFDbkIsS0FBSyxHQUFHK0MsWUFBWU8sU0FBUyxJQUFJUCxZQUFZUSxRQUFRO0FBQUEsa0JBQ3JELEtBQUtSLFlBQVkvQztBQUFBQTtBQUFBQSxnQkFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBRzBCLEtBTDlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNQK0MseUJBQ0MsbUNBQ0U7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsT0FBTTtBQUFBLG9CQUNOLGFBQVU7QUFBQSxvQkFFVEE7QUFBQUEsa0NBQVlPO0FBQUFBLHNCQUFVO0FBQUEsc0JBQUV6RixLQUFLa0YsWUFBWVEsUUFBUTtBQUFBO0FBQUE7QUFBQSxrQkFMcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU1BO0FBQUEsZ0JBQ0E7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsU0FBUTtBQUFBLG9CQUNSLE9BQU07QUFBQSxvQkFDTjtBQUFBLG9CQUNBLGFBQVU7QUFBQSxvQkFBa0I7QUFBQTtBQUFBLHNCQUUxQlIsWUFBWVM7QUFBQUE7QUFBQUE7QUFBQUEsa0JBTmhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFPQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZ0JBLEtBbEJKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBb0JBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLE1BQUksTUFBQyxPQUFPLEVBQUV6QyxPQUFPLE1BQU0sS0FBakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBb0M7QUFBQTtBQUFBO0FBQUEsVUFyQ3RDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQXNDQTtBQUFBLFFBQ0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixnQkFBZTtBQUFBLFlBQ2YsWUFBVztBQUFBLFlBQ1gsV0FBVzBCLGFBQWFoRCxRQUFRSyxjQUFjTCxRQUFRTTtBQUFBQSxZQUV0RDtBQUFBLHFDQUFDLFFBQUssTUFBSSxNQUNQZ0QseUJBQ0MsbUNBQ0U7QUFBQTtBQUFBLGtCQUFDO0FBQUE7QUFBQSxvQkFDQyxTQUFRO0FBQUEsb0JBQ1IsT0FBTTtBQUFBLG9CQUNOLFdBQVd0RCxRQUFRUztBQUFBQSxvQkFDbkIsYUFBVTtBQUFBLG9CQUVUNkMsc0JBQVlVLFVBQVVsRSxhQUFhd0QsWUFBWVUsT0FBTyxJQUFJbEUsYUFBYSxDQUFDO0FBQUE7QUFBQSxrQkFOM0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQU9BO0FBQUEsZ0JBQ0EsdUJBQUMsY0FBVyxTQUFRLGFBQVksT0FBTSxXQUFVLGNBQVksTUFBQywrQkFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFFQTtBQUFBLG1CQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWUEsS0FkSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWdCQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsUUFBTTJDLHdCQUFjQyxjQUFjQyxtQkFBbUIsS0FBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBd0QsS0FEMUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsYUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFRLEtBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsUUFBTUMsNkJBQW1CYSxPQUFPLEtBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQW1DLEtBRHJDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQTtBQUFBO0FBQUEsVUFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBb0NBO0FBQUE7QUFBQTtBQUFBLElBdkZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXdGQTtBQUVKO0FBQUVQLEdBeEdJSixXQUEwQjtBQUFBLFVBTWhCdEUsVUFDZ0JILFVBQ0ZFLGFBQWE7QUFBQTtBQUFBMEYsTUFSckNuQjtBQTBHTixlQUFlQTtBQUFVLElBQUFOLElBQUF5QjtBQUFBQyxhQUFBMUIsSUFBQTtBQUFBMEIsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlZCIsImhlYWQiLCJ1c2VBY3RvciIsImNsc3giLCJ1c2VNZWRpYVF1ZXJ5IiwidXNlVGhlbWUiLCJEcmF3ZXIiLCJMaXN0IiwiRGl2aWRlciIsIkxpc3RJdGVtIiwiTGlzdEl0ZW1JY29uIiwiTGlzdEl0ZW1UZXh0IiwiR3JpZCIsIkF2YXRhciIsIlR5cG9ncmFwaHkiLCJMaW5rIiwiUm91dGVyTGluayIsIkhvbWUiLCJIb21lSWNvbiIsIlBlcnNvbiIsIlBlcnNvbkljb24iLCJFeGl0VG9BcHAiLCJMb2dvdXRJY29uIiwiTm90aWZpY2F0aW9ucyIsIk5vdGlmaWNhdGlvbnNJY29uIiwiQWNjb3VudEJhbGFuY2UiLCJBY2NvdW50QmFsYW5jZUljb24iLCJmb3JtYXRBbW91bnQiLCJQUkVGSVgiLCJjbGFzc2VzIiwidG9vbGJhciIsInRvb2xiYXJJY29uIiwiZHJhd2VyUGFwZXIiLCJkcmF3ZXJQYXBlckNsb3NlIiwidXNlclByb2ZpbGUiLCJ1c2VyUHJvZmlsZUhpZGRlbiIsImF2YXRhciIsImFjY291bnRCYWxhbmNlIiwiYW1vdW50IiwiYWNjb3VudEJhbGFuY2VIaWRkZW4iLCJjeXByZXNzTG9nbyIsIlN0eWxlZERyYXdlciIsInRoZW1lIiwicGFkZGluZ1JpZ2h0IiwiZGlzcGxheSIsImFsaWduSXRlbXMiLCJqdXN0aWZ5Q29udGVudCIsInBhZGRpbmciLCJtaXhpbnMiLCJwb3NpdGlvbiIsIndoaXRlU3BhY2UiLCJ3aWR0aCIsImRyYXdlcldpZHRoIiwidHJhbnNpdGlvbiIsInRyYW5zaXRpb25zIiwiY3JlYXRlIiwiZWFzaW5nIiwic2hhcnAiLCJkdXJhdGlvbiIsImVudGVyaW5nU2NyZWVuIiwibWFyZ2luVG9wIiwib3ZlcmZsb3dYIiwibGVhdmluZ1NjcmVlbiIsInNwYWNpbmciLCJicmVha3BvaW50cyIsInVwIiwibWFyZ2luUmlnaHQiLCJtYXJnaW5MZWZ0IiwiZm9udFdlaWdodCIsIl9jIiwibWFpbkxpc3RJdGVtcyIsInRvZ2dsZURyYXdlciIsInNob3dUZW1wb3JhcnlEcmF3ZXIiLCJzZWNvbmRhcnlMaXN0SXRlbXMiLCJzaWduT3V0UGVuZGluZyIsIk5hdkRyYXdlciIsImNsb3NlTW9iaWxlRHJhd2VyIiwiZHJhd2VyT3BlbiIsImF1dGhTZXJ2aWNlIiwiX3MiLCJhdXRoU3RhdGUiLCJzZW5kQXV0aCIsIm9ubHkiLCJjdXJyZW50VXNlciIsImNvbnRleHQiLCJ1c2VyIiwic2lnbk91dCIsInBhcGVyIiwib25CYWNrZHJvcENsaWNrIiwiY2xvc2VBZnRlclRyYW5zaXRpb24iLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsInVzZXJuYW1lIiwiYmFsYW5jZSIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5hdkRyYXdlci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgaGVhZCB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHsgSW50ZXJwcmV0ZXIgfSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IHVzZUFjdG9yIH0gZnJvbSBcIkB4c3RhdGUvcmVhY3RcIjtcclxuaW1wb3J0IGNsc3ggZnJvbSBcImNsc3hcIjtcclxuaW1wb3J0IHtcclxuICB1c2VNZWRpYVF1ZXJ5LFxyXG4gIHVzZVRoZW1lLFxyXG4gIERyYXdlcixcclxuICBMaXN0LFxyXG4gIERpdmlkZXIsXHJcbiAgTGlzdEl0ZW0sXHJcbiAgTGlzdEl0ZW1JY29uLFxyXG4gIExpc3RJdGVtVGV4dCxcclxuICBHcmlkLFxyXG4gIEF2YXRhcixcclxuICBUeXBvZ3JhcGh5LFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IExpbmsgYXMgUm91dGVyTGluayB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7XHJcbiAgSG9tZSBhcyBIb21lSWNvbixcclxuICBQZXJzb24gYXMgUGVyc29uSWNvbixcclxuICBFeGl0VG9BcHAgYXMgTG9nb3V0SWNvbixcclxuICBOb3RpZmljYXRpb25zIGFzIE5vdGlmaWNhdGlvbnNJY29uLFxyXG4gIEFjY291bnRCYWxhbmNlIGFzIEFjY291bnRCYWxhbmNlSWNvbixcclxufSBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IHsgZm9ybWF0QW1vdW50IH0gZnJvbSBcIi4uL3V0aWxzL3RyYW5zYWN0aW9uVXRpbHNcIjtcclxuaW1wb3J0IHsgQXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZUV2ZW50cyB9IGZyb20gXCIuLi9tYWNoaW5lcy9hdXRoTWFjaGluZVwiO1xyXG5cclxuY29uc3QgUFJFRklYID0gXCJOYXZEcmF3ZXJcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgdG9vbGJhcjogYCR7UFJFRklYfS10b29sYmFyYCxcclxuICB0b29sYmFySWNvbjogYCR7UFJFRklYfS10b29sYmFySWNvbmAsXHJcbiAgZHJhd2VyUGFwZXI6IGAke1BSRUZJWH0tZHJhd2VyUGFwZXJgLFxyXG4gIGRyYXdlclBhcGVyQ2xvc2U6IGAke1BSRUZJWH0tZHJhd2VyUGFwZXJDbG9zZWAsXHJcbiAgdXNlclByb2ZpbGU6IGAke1BSRUZJWH0tdXNlclByb2ZpbGVgLFxyXG4gIHVzZXJQcm9maWxlSGlkZGVuOiBgJHtQUkVGSVh9LXVzZXJQcm9maWxlSGlkZGVuYCxcclxuICBhdmF0YXI6IGAke1BSRUZJWH0tYXZhdGFyYCxcclxuICBhY2NvdW50QmFsYW5jZTogYCR7UFJFRklYfS1hY2NvdW50QmFsYW5jZWAsXHJcbiAgYW1vdW50OiBgJHtQUkVGSVh9LWFtb3VudGAsXHJcbiAgYWNjb3VudEJhbGFuY2VIaWRkZW46IGAke1BSRUZJWH0tYWNjb3VudEJhbGFuY2VIaWRkZW5gLFxyXG4gIGN5cHJlc3NMb2dvOiBgJHtQUkVGSVh9LWN5cHJlc3NMb2dvYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZERyYXdlciA9IHN0eWxlZChEcmF3ZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmIC4ke2NsYXNzZXMudG9vbGJhcn1gXToge1xyXG4gICAgcGFkZGluZ1JpZ2h0OiAyNCwgLy8ga2VlcCByaWdodCBwYWRkaW5nIHdoZW4gZHJhd2VyIGNsb3NlZFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnRvb2xiYXJJY29ufWBdOiB7XHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgICBqdXN0aWZ5Q29udGVudDogXCJmbGV4LWVuZFwiLFxyXG4gICAgcGFkZGluZzogXCIwIDhweFwiLFxyXG4gICAgLi4udGhlbWUubWl4aW5zLnRvb2xiYXIsXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuZHJhd2VyUGFwZXJ9YF06IHtcclxuICAgIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsXHJcbiAgICB3aGl0ZVNwYWNlOiBcIm5vd3JhcFwiLFxyXG4gICAgd2lkdGg6IGRyYXdlcldpZHRoLFxyXG4gICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKFwid2lkdGhcIiwge1xyXG4gICAgICBlYXNpbmc6IHRoZW1lLnRyYW5zaXRpb25zLmVhc2luZy5zaGFycCxcclxuICAgICAgZHVyYXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmR1cmF0aW9uLmVudGVyaW5nU2NyZWVuLFxyXG4gICAgfSksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuZHJhd2VyUGFwZXJDbG9zZX1gXToge1xyXG4gICAgbWFyZ2luVG9wOiA1MCxcclxuICAgIG92ZXJmbG93WDogXCJoaWRkZW5cIixcclxuICAgIHRyYW5zaXRpb246IHRoZW1lLnRyYW5zaXRpb25zLmNyZWF0ZShcIndpZHRoXCIsIHtcclxuICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbiAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5sZWF2aW5nU2NyZWVuLFxyXG4gICAgfSksXHJcbiAgICB3aWR0aDogdGhlbWUuc3BhY2luZyg3KSxcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy51cChcInNtXCIpXToge1xyXG4gICAgICB3aWR0aDogdGhlbWUuc3BhY2luZyg5KSxcclxuICAgIH0sXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMudXNlclByb2ZpbGV9YF06IHtcclxuICAgIHBhZGRpbmc6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMudXNlclByb2ZpbGVIaWRkZW59YF06IHtcclxuICAgIGRpc3BsYXk6IFwibm9uZVwiLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmF2YXRhcn1gXToge1xyXG4gICAgbWFyZ2luUmlnaHQ6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuYWNjb3VudEJhbGFuY2V9YF06IHtcclxuICAgIG1hcmdpbkxlZnQ6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuYW1vdW50fWBdOiB7XHJcbiAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5hY2NvdW50QmFsYW5jZUhpZGRlbn1gXToge1xyXG4gICAgZGlzcGxheTogXCJub25lXCIsXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuY3lwcmVzc0xvZ299YF06IHtcclxuICAgIHdpZHRoOiBcIjQwJVwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IGRyYXdlcldpZHRoID0gMjQwO1xyXG5cclxuZXhwb3J0IGNvbnN0IG1haW5MaXN0SXRlbXMgPSAoXHJcbiAgdG9nZ2xlRHJhd2VyOiAoKGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50PEhUTUxBbmNob3JFbGVtZW50LCBNb3VzZUV2ZW50PikgPT4gdm9pZCkgfCB1bmRlZmluZWQsXHJcbiAgc2hvd1RlbXBvcmFyeURyYXdlcjogQm9vbGVhblxyXG4pID0+IChcclxuICA8ZGl2PlxyXG4gICAgPExpc3RJdGVtXHJcbiAgICAgIGJ1dHRvblxyXG4gICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgIG9uQ2xpY2s9eygpID0+IHNob3dUZW1wb3JhcnlEcmF3ZXIgJiYgdG9nZ2xlRHJhd2VyKCl9XHJcbiAgICAgIGNvbXBvbmVudD17Um91dGVyTGlua31cclxuICAgICAgdG89XCIvXCJcclxuICAgICAgZGF0YS10ZXN0PVwic2lkZW5hdi1ob21lXCJcclxuICAgID5cclxuICAgICAgPExpc3RJdGVtSWNvbj5cclxuICAgICAgICA8SG9tZUljb24gLz5cclxuICAgICAgPC9MaXN0SXRlbUljb24+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT1cIkhvbWVcIiAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICAgIDxMaXN0SXRlbVxyXG4gICAgICBidXR0b25cclxuICAgICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiBzaG93VGVtcG9yYXJ5RHJhd2VyICYmIHRvZ2dsZURyYXdlcigpfVxyXG4gICAgICBjb21wb25lbnQ9e1JvdXRlckxpbmt9XHJcbiAgICAgIHRvPVwiL3VzZXIvc2V0dGluZ3NcIlxyXG4gICAgICBkYXRhLXRlc3Q9XCJzaWRlbmF2LXVzZXItc2V0dGluZ3NcIlxyXG4gICAgPlxyXG4gICAgICA8TGlzdEl0ZW1JY29uPlxyXG4gICAgICAgIDxQZXJzb25JY29uIC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJNeSBBY2NvdW50XCIgLz5cclxuICAgIDwvTGlzdEl0ZW0+XHJcbiAgICA8TGlzdEl0ZW1cclxuICAgICAgYnV0dG9uXHJcbiAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgb25DbGljaz17KCkgPT4gc2hvd1RlbXBvcmFyeURyYXdlciAmJiB0b2dnbGVEcmF3ZXIoKX1cclxuICAgICAgY29tcG9uZW50PXtSb3V0ZXJMaW5rfVxyXG4gICAgICB0bz1cIi9iYW5rYWNjb3VudHNcIlxyXG4gICAgICBkYXRhLXRlc3Q9XCJzaWRlbmF2LWJhbmthY2NvdW50c1wiXHJcbiAgICA+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPEFjY291bnRCYWxhbmNlSWNvbiAvPlxyXG4gICAgICA8L0xpc3RJdGVtSWNvbj5cclxuICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PVwiQmFuayBBY2NvdW50c1wiIC8+XHJcbiAgICA8L0xpc3RJdGVtPlxyXG4gICAgPExpc3RJdGVtXHJcbiAgICAgIGJ1dHRvblxyXG4gICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgIG9uQ2xpY2s9eygpID0+IHNob3dUZW1wb3JhcnlEcmF3ZXIgJiYgdG9nZ2xlRHJhd2VyKCl9XHJcbiAgICAgIGNvbXBvbmVudD17Um91dGVyTGlua31cclxuICAgICAgdG89XCIvbm90aWZpY2F0aW9uc1wiXHJcbiAgICAgIGRhdGEtdGVzdD1cInNpZGVuYXYtbm90aWZpY2F0aW9uc1wiXHJcbiAgICA+XHJcbiAgICAgIDxMaXN0SXRlbUljb24+XHJcbiAgICAgICAgPE5vdGlmaWNhdGlvbnNJY29uIC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJOb3RpZmljYXRpb25zXCIgLz5cclxuICAgIDwvTGlzdEl0ZW0+XHJcbiAgPC9kaXY+XHJcbik7XHJcblxyXG5leHBvcnQgY29uc3Qgc2Vjb25kYXJ5TGlzdEl0ZW1zID0gKHNpZ25PdXRQZW5kaW5nOiBGdW5jdGlvbikgPT4gKFxyXG4gIDxkaXY+XHJcbiAgICA8TGlzdEl0ZW0gYnV0dG9uIG9uQ2xpY2s9eygpID0+IHNpZ25PdXRQZW5kaW5nKCl9IGRhdGEtdGVzdD1cInNpZGVuYXYtc2lnbm91dFwiPlxyXG4gICAgICA8TGlzdEl0ZW1JY29uPlxyXG4gICAgICAgIDxMb2dvdXRJY29uIC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1JY29uPlxyXG4gICAgICA8TGlzdEl0ZW1UZXh0IHByaW1hcnk9XCJMb2dvdXRcIiAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICA8L2Rpdj5cclxuKTtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgY2xvc2VNb2JpbGVEcmF3ZXI6ICgpID0+IHZvaWQ7XHJcbiAgdG9nZ2xlRHJhd2VyOiAoKSA9PiB2b2lkO1xyXG4gIGRyYXdlck9wZW46IGJvb2xlYW47XHJcbiAgYXV0aFNlcnZpY2U6IEludGVycHJldGVyPEF1dGhNYWNoaW5lQ29udGV4dCwgYW55LCBBdXRoTWFjaGluZUV2ZW50cywgYW55PjtcclxufVxyXG5cclxuY29uc3QgTmF2RHJhd2VyOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xyXG4gIHRvZ2dsZURyYXdlcixcclxuICBjbG9zZU1vYmlsZURyYXdlcixcclxuICBkcmF3ZXJPcGVuLFxyXG4gIGF1dGhTZXJ2aWNlLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpO1xyXG4gIGNvbnN0IFthdXRoU3RhdGUsIHNlbmRBdXRoXSA9IHVzZUFjdG9yKGF1dGhTZXJ2aWNlKTtcclxuICBjb25zdCBzaG93VGVtcG9yYXJ5RHJhd2VyID0gdXNlTWVkaWFRdWVyeSh0aGVtZS5icmVha3BvaW50cy5vbmx5KFwieHNcIikpO1xyXG5cclxuICBjb25zdCBjdXJyZW50VXNlciA9IGF1dGhTdGF0ZT8uY29udGV4dD8udXNlcjtcclxuICBjb25zdCBzaWduT3V0ID0gKCkgPT4gc2VuZEF1dGgoXCJMT0dPVVRcIik7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkRHJhd2VyXHJcbiAgICAgIGRhdGEtdGVzdD1cInNpZGVuYXZcIlxyXG4gICAgICB2YXJpYW50PXtzaG93VGVtcG9yYXJ5RHJhd2VyID8gXCJ0ZW1wb3JhcnlcIiA6IFwicGVyc2lzdGVudFwifVxyXG4gICAgICBjbGFzc2VzPXt7XHJcbiAgICAgICAgcGFwZXI6IGNsc3goY2xhc3Nlcy5kcmF3ZXJQYXBlciwgIWRyYXdlck9wZW4gJiYgY2xhc3Nlcy5kcmF3ZXJQYXBlckNsb3NlKSxcclxuICAgICAgfX1cclxuICAgICAgb3Blbj17ZHJhd2VyT3Blbn1cclxuICAgICAgTW9kYWxQcm9wcz17e1xyXG4gICAgICAgIG9uQmFja2Ryb3BDbGljazogKCkgPT4gY2xvc2VNb2JpbGVEcmF3ZXIoKSxcclxuICAgICAgICBjbG9zZUFmdGVyVHJhbnNpdGlvbjogc2hvd1RlbXBvcmFyeURyYXdlcixcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgPEdyaWRcclxuICAgICAgICBjb250YWluZXJcclxuICAgICAgICBkaXJlY3Rpb249XCJyb3dcIlxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgY2xhc3NOYW1lPXtkcmF3ZXJPcGVuID8gY2xhc3Nlcy51c2VyUHJvZmlsZSA6IGNsYXNzZXMudXNlclByb2ZpbGVIaWRkZW59XHJcbiAgICAgID5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAge2N1cnJlbnRVc2VyICYmIChcclxuICAgICAgICAgICAgPEF2YXRhclxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5hdmF0YXJ9XHJcbiAgICAgICAgICAgICAgYWx0PXtgJHtjdXJyZW50VXNlci5maXJzdE5hbWV9ICR7Y3VycmVudFVzZXIubGFzdE5hbWV9YH1cclxuICAgICAgICAgICAgICBzcmM9e2N1cnJlbnRVc2VyLmF2YXRhcn1cclxuICAgICAgICAgICAgLz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwic3VidGl0bGUxXCJcclxuICAgICAgICAgICAgICAgIGNvbG9yPVwidGV4dFByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lkZW5hdi11c2VyLWZ1bGwtbmFtZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge2N1cnJlbnRVc2VyLmZpcnN0TmFtZX0ge2hlYWQoY3VycmVudFVzZXIubGFzdE5hbWUpfVxyXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cInN1YnRpdGxlMlwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgICAgICAgZ3V0dGVyQm90dG9tXHJcbiAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJzaWRlbmF2LXVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBAe2N1cnJlbnRVc2VyLnVzZXJuYW1lfVxyXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtIHN0eWxlPXt7IHdpZHRoOiBcIjMwJVwiIH19PjwvR3JpZD5cclxuICAgICAgPC9HcmlkPlxyXG4gICAgICA8R3JpZFxyXG4gICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgIGRpcmVjdGlvbj1cInJvd1wiXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICBjbGFzc05hbWU9e2RyYXdlck9wZW4gPyBjbGFzc2VzLnVzZXJQcm9maWxlIDogY2xhc3Nlcy51c2VyUHJvZmlsZUhpZGRlbn1cclxuICAgICAgPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiaDZcIlxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJ0ZXh0UHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuYW1vdW50fVxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lkZW5hdi11c2VyLWJhbGFuY2VcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIHtjdXJyZW50VXNlci5iYWxhbmNlID8gZm9ybWF0QW1vdW50KGN1cnJlbnRVc2VyLmJhbGFuY2UpIDogZm9ybWF0QW1vdW50KDApfVxyXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwic3VidGl0bGUyXCIgY29sb3I9XCJpbmhlcml0XCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAgICAgICAgQWNjb3VudCBCYWxhbmNlXHJcbiAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICA8RGl2aWRlciAvPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPExpc3Q+e21haW5MaXN0SXRlbXModG9nZ2xlRHJhd2VyLCBzaG93VGVtcG9yYXJ5RHJhd2VyKX08L0xpc3Q+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICA8RGl2aWRlciAvPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPExpc3Q+e3NlY29uZGFyeUxpc3RJdGVtcyhzaWduT3V0KX08L0xpc3Q+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L1N0eWxlZERyYXdlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTmF2RHJhd2VyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL05hdkRyYXdlci50c3gifQ==