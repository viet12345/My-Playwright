import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const omit = __vite__cjsImport0_lodash_fp["omit"];
import { Machine, assign } from "/node_modules/.vite/deps/xstate.js?v=6af76b79";
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { authService } from "/src/machines/authMachine.ts";
import { backendPort } from "/src/utils/portUtils.ts";
const transactionDataMachine = dataMachine("transactionData").withConfig({
  services: {
    createData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.post(`http://localhost:${backendPort}/transactions`, payload);
      authService.send("REFRESH");
      return resp.data;
    }
  }
});
export const createTransactionMachine = Machine(
  {
    id: "createTransaction",
    initial: "stepOne",
    states: {
      stepOne: {
        entry: "clearContext",
        on: {
          SET_USERS: "stepTwo"
        }
      },
      stepTwo: {
        entry: "setSenderAndReceiver",
        invoke: {
          id: "transactionDataMachine",
          src: transactionDataMachine,
          autoForward: true
        },
        on: {
          CREATE: "stepThree"
        }
      },
      stepThree: {
        entry: "setTransactionDetails",
        on: {
          RESET: "stepOne"
        }
      }
    }
  },
  {
    actions: {
      setSenderAndReceiver: assign((ctx, event) => ({
        sender: event.sender,
        receiver: event.receiver
      })),
      setTransactionDetails: assign((ctx, event) => ({
        transactionDetails: event
      })),
      clearContext: assign((ctx, event) => ({}))
    }
  }
);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBvbWl0IH0gZnJvbSBcImxvZGFzaC9mcFwiO1xyXG5pbXBvcnQgeyBNYWNoaW5lLCBhc3NpZ24gfSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IGRhdGFNYWNoaW5lIH0gZnJvbSBcIi4vZGF0YU1hY2hpbmVcIjtcclxuaW1wb3J0IHsgaHR0cENsaWVudCB9IGZyb20gXCIuLi91dGlscy9hc3luY1V0aWxzXCI7XHJcbmltcG9ydCB7IFVzZXIsIFRyYW5zYWN0aW9uQ3JlYXRlUGF5bG9hZCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IHsgYXV0aFNlcnZpY2UgfSBmcm9tIFwiLi9hdXRoTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBiYWNrZW5kUG9ydCB9IGZyb20gXCIuLi91dGlscy9wb3J0VXRpbHNcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ3JlYXRlVHJhbnNhY3Rpb25NYWNoaW5lU2NoZW1hIHtcclxuICBzdGF0ZXM6IHtcclxuICAgIHN0ZXBPbmU6IHt9O1xyXG4gICAgc3RlcFR3bzoge307XHJcbiAgICBzdGVwVGhyZWU6IHt9O1xyXG4gIH07XHJcbn1cclxuXHJcbmNvbnN0IHRyYW5zYWN0aW9uRGF0YU1hY2hpbmUgPSBkYXRhTWFjaGluZShcInRyYW5zYWN0aW9uRGF0YVwiKS53aXRoQ29uZmlnKHtcclxuICBzZXJ2aWNlczoge1xyXG4gICAgY3JlYXRlRGF0YTogYXN5bmMgKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0gb21pdChcInR5cGVcIiwgZXZlbnQpO1xyXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgaHR0cENsaWVudC5wb3N0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L3RyYW5zYWN0aW9uc2AsIHBheWxvYWQpO1xyXG4gICAgICBhdXRoU2VydmljZS5zZW5kKFwiUkVGUkVTSFwiKTtcclxuICAgICAgcmV0dXJuIHJlc3AuZGF0YTtcclxuICAgIH0sXHJcbiAgfSxcclxufSk7XHJcblxyXG5leHBvcnQgdHlwZSBDcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVFdmVudHMgPVxyXG4gIHwgeyB0eXBlOiBcIlNFVF9VU0VSU1wiIH1cclxuICB8IHsgdHlwZTogXCJDUkVBVEVcIiB9XHJcbiAgfCB7IHR5cGU6IFwiUkVTRVRcIiB9O1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBDcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVDb250ZXh0IHtcclxuICBzZW5kZXI6IFVzZXI7XHJcbiAgcmVjZWl2ZXI6IFVzZXI7XHJcbiAgdHJhbnNhY3Rpb25EZXRhaWxzOiBUcmFuc2FjdGlvbkNyZWF0ZVBheWxvYWQ7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBjcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmUgPSBNYWNoaW5lPFxyXG4gIENyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZUNvbnRleHQsXHJcbiAgQ3JlYXRlVHJhbnNhY3Rpb25NYWNoaW5lU2NoZW1hLFxyXG4gIENyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZUV2ZW50c1xyXG4+KFxyXG4gIHtcclxuICAgIGlkOiBcImNyZWF0ZVRyYW5zYWN0aW9uXCIsXHJcbiAgICBpbml0aWFsOiBcInN0ZXBPbmVcIixcclxuICAgIHN0YXRlczoge1xyXG4gICAgICBzdGVwT25lOiB7XHJcbiAgICAgICAgZW50cnk6IFwiY2xlYXJDb250ZXh0XCIsXHJcbiAgICAgICAgb246IHtcclxuICAgICAgICAgIFNFVF9VU0VSUzogXCJzdGVwVHdvXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgc3RlcFR3bzoge1xyXG4gICAgICAgIGVudHJ5OiBcInNldFNlbmRlckFuZFJlY2VpdmVyXCIsXHJcbiAgICAgICAgaW52b2tlOiB7XHJcbiAgICAgICAgICBpZDogXCJ0cmFuc2FjdGlvbkRhdGFNYWNoaW5lXCIsXHJcbiAgICAgICAgICBzcmM6IHRyYW5zYWN0aW9uRGF0YU1hY2hpbmUsXHJcbiAgICAgICAgICBhdXRvRm9yd2FyZDogdHJ1ZSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uOiB7XHJcbiAgICAgICAgICBDUkVBVEU6IFwic3RlcFRocmVlXCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgc3RlcFRocmVlOiB7XHJcbiAgICAgICAgZW50cnk6IFwic2V0VHJhbnNhY3Rpb25EZXRhaWxzXCIsXHJcbiAgICAgICAgb246IHtcclxuICAgICAgICAgIFJFU0VUOiBcInN0ZXBPbmVcIixcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICB9LFxyXG4gIHtcclxuICAgIGFjdGlvbnM6IHtcclxuICAgICAgc2V0U2VuZGVyQW5kUmVjZWl2ZXI6IGFzc2lnbigoY3R4LCBldmVudDogYW55KSA9PiAoe1xyXG4gICAgICAgIHNlbmRlcjogZXZlbnQuc2VuZGVyLFxyXG4gICAgICAgIHJlY2VpdmVyOiBldmVudC5yZWNlaXZlcixcclxuICAgICAgfSkpLFxyXG4gICAgICBzZXRUcmFuc2FjdGlvbkRldGFpbHM6IGFzc2lnbigoY3R4LCBldmVudDogYW55KSA9PiAoe1xyXG4gICAgICAgIHRyYW5zYWN0aW9uRGV0YWlsczogZXZlbnQsXHJcbiAgICAgIH0pKSxcclxuICAgICAgY2xlYXJDb250ZXh0OiBhc3NpZ24oKGN0eCwgZXZlbnQ6IGFueSkgPT4gKHt9KSksXHJcbiAgICB9LFxyXG4gIH1cclxuKTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFlBQVk7QUFDckIsU0FBUyxTQUFTLGNBQWM7QUFDaEMsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxrQkFBa0I7QUFFM0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxtQkFBbUI7QUFVNUIsTUFBTSx5QkFBeUIsWUFBWSxpQkFBaUIsRUFBRSxXQUFXO0FBQUEsRUFDdkUsVUFBVTtBQUFBLElBQ1IsWUFBWSxPQUFPLEtBQUssVUFBZTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsWUFBTSxPQUFPLE1BQU0sV0FBVyxLQUFLLG9CQUFvQixXQUFXLGlCQUFpQixPQUFPO0FBQzFGLGtCQUFZLEtBQUssU0FBUztBQUMxQixhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNGLENBQUM7QUFhTSxhQUFNLDJCQUEyQjtBQUFBLEVBS3RDO0FBQUEsSUFDRSxJQUFJO0FBQUEsSUFDSixTQUFTO0FBQUEsSUFDVCxRQUFRO0FBQUEsTUFDTixTQUFTO0FBQUEsUUFDUCxPQUFPO0FBQUEsUUFDUCxJQUFJO0FBQUEsVUFDRixXQUFXO0FBQUEsUUFDYjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLE9BQU87QUFBQSxRQUNQLFFBQVE7QUFBQSxVQUNOLElBQUk7QUFBQSxVQUNKLEtBQUs7QUFBQSxVQUNMLGFBQWE7QUFBQSxRQUNmO0FBQUEsUUFDQSxJQUFJO0FBQUEsVUFDRixRQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFdBQVc7QUFBQSxRQUNULE9BQU87QUFBQSxRQUNQLElBQUk7QUFBQSxVQUNGLE9BQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0UsU0FBUztBQUFBLE1BQ1Asc0JBQXNCLE9BQU8sQ0FBQyxLQUFLLFdBQWdCO0FBQUEsUUFDakQsUUFBUSxNQUFNO0FBQUEsUUFDZCxVQUFVLE1BQU07QUFBQSxNQUNsQixFQUFFO0FBQUEsTUFDRix1QkFBdUIsT0FBTyxDQUFDLEtBQUssV0FBZ0I7QUFBQSxRQUNsRCxvQkFBb0I7QUFBQSxNQUN0QixFQUFFO0FBQUEsTUFDRixjQUFjLE9BQU8sQ0FBQyxLQUFLLFdBQWdCLENBQUMsRUFBRTtBQUFBLElBQ2hEO0FBQUEsRUFDRjtBQUNGOyIsIm5hbWVzIjpbXX0=