import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/UserSettingsContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Paper, Typography, Grid } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import UserSettingsForm from "/src/components/UserSettingsForm.tsx";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import PersonalSettingsIllustration from "/src/components/SvgUndrawPersonalSettingsKihd.tsx";
const PREFIX = "UserSettingsContainer";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  }
}));
_c = StyledPaper;
const UserSettingsContainer = ({ authService }) => {
  _s();
  const [authState, sendAuth] = useActor(authService);
  const currentUser = authState?.context?.user;
  const updateUser = (payload) => sendAuth({ type: "UPDATE", ...payload });
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: "User Settings" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      Grid,
      {
        container: true,
        spacing: 2,
        direction: "row",
        justifyContent: "flex-start",
        alignItems: "flex-start",
        children: [
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(PersonalSettingsIllustration, { style: { height: 200, width: 300 } }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
            lineNumber: 48,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
            lineNumber: 47,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Grid, { item: true, style: { width: "50%" }, children: currentUser && /* @__PURE__ */ jsxDEV(UserSettingsForm, { userProfile: currentUser, updateUser }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
            lineNumber: 51,
            columnNumber: 27
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
            lineNumber: 50,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
        lineNumber: 40,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_s(UserSettingsContainer, "pUJtIQi1VqUJ66yHLq7JmkgZGZg=", false, function() {
  return [useActor];
});
_c2 = UserSettingsContainer;
export default UserSettingsContainer;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "UserSettingsContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserSettingsContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NNOzJCQXBDTjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLE9BQU9DLFlBQVlDLFlBQVk7QUFDeEMsT0FBT0Msc0JBQXNCO0FBRzdCLFNBQVNDLGdCQUFnQjtBQUN6QixPQUFPQyxrQ0FBa0M7QUFFekMsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFDbEI7QUFFQSxNQUFNRyxjQUFjVixPQUFPQyxLQUFLLEVBQUUsQ0FBQyxFQUFFVSxNQUFNLE9BQU87QUFBQSxFQUNoRCxDQUFDLEtBQUtILFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdEJHLFNBQVNELE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQ3hCQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLGVBQWU7QUFBQSxFQUNqQjtBQUNGLEVBQUU7QUFBRUMsS0FQRVA7QUFhTixNQUFNUSx3QkFBeUNBLENBQUMsRUFBRUMsWUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDbEUsUUFBTSxDQUFDQyxXQUFXQyxRQUFRLElBQUlqQixTQUFTYyxXQUFXO0FBRWxELFFBQU1JLGNBQWNGLFdBQVdHLFNBQVNDO0FBQ3hDLFFBQU1DLGFBQWFBLENBQUNDLFlBQWlCTCxTQUFTLEVBQUVNLE1BQU0sVUFBVSxHQUFHRCxRQUFRLENBQUM7QUFFNUUsU0FDRSx1QkFBQyxlQUFZLFdBQVduQixRQUFRQyxPQUM5QjtBQUFBLDJCQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxPQUFNLFdBQVUsY0FBWSxNQUFDLDZCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsU0FBUztBQUFBLFFBQ1QsV0FBVTtBQUFBLFFBQ1YsZ0JBQWU7QUFBQSxRQUNmLFlBQVc7QUFBQSxRQUVYO0FBQUEsaUNBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsZ0NBQTZCLE9BQU8sRUFBRW9CLFFBQVEsS0FBS0MsT0FBTyxJQUFJLEtBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFLEtBRG5FO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxVQUNBLHVCQUFDLFFBQUssTUFBSSxNQUFDLE9BQU8sRUFBRUEsT0FBTyxNQUFNLEdBQzlCUCx5QkFBZSx1QkFBQyxvQkFBaUIsYUFBYUEsYUFBYSxjQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRSxLQURyRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQTtBQUFBLE1BWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBYUE7QUFBQSxPQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBa0JBO0FBRUo7QUFBRUgsR0EzQklGLHVCQUFzQztBQUFBLFVBQ1piLFFBQVE7QUFBQTtBQUFBMEIsTUFEbENiO0FBNEJOLGVBQWVBO0FBQXNCLElBQUFELElBQUFjO0FBQUFDLGFBQUFmLElBQUE7QUFBQWUsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlZCIsIlBhcGVyIiwiVHlwb2dyYXBoeSIsIkdyaWQiLCJVc2VyU2V0dGluZ3NGb3JtIiwidXNlQWN0b3IiLCJQZXJzb25hbFNldHRpbmdzSWxsdXN0cmF0aW9uIiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwiU3R5bGVkUGFwZXIiLCJ0aGVtZSIsInBhZGRpbmciLCJzcGFjaW5nIiwiZGlzcGxheSIsIm92ZXJmbG93IiwiZmxleERpcmVjdGlvbiIsIl9jIiwiVXNlclNldHRpbmdzQ29udGFpbmVyIiwiYXV0aFNlcnZpY2UiLCJfcyIsImF1dGhTdGF0ZSIsInNlbmRBdXRoIiwiY3VycmVudFVzZXIiLCJjb250ZXh0IiwidXNlciIsInVwZGF0ZVVzZXIiLCJwYXlsb2FkIiwidHlwZSIsImhlaWdodCIsIndpZHRoIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlclNldHRpbmdzQ29udGFpbmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBQYXBlciwgVHlwb2dyYXBoeSwgR3JpZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCBVc2VyU2V0dGluZ3NGb3JtIGZyb20gXCIuLi9jb21wb25lbnRzL1VzZXJTZXR0aW5nc0Zvcm1cIjtcclxuaW1wb3J0IHsgSW50ZXJwcmV0ZXIgfSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVFdmVudHMgfSBmcm9tIFwiLi4vbWFjaGluZXMvYXV0aE1hY2hpbmVcIjtcclxuaW1wb3J0IHsgdXNlQWN0b3IgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQgUGVyc29uYWxTZXR0aW5nc0lsbHVzdHJhdGlvbiBmcm9tIFwiLi4vY29tcG9uZW50cy9TdmdVbmRyYXdQZXJzb25hbFNldHRpbmdzS2loZFwiO1xyXG5cclxuY29uc3QgUFJFRklYID0gXCJVc2VyU2V0dGluZ3NDb250YWluZXJcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgcGFwZXI6IGAke1BSRUZJWH0tcGFwZXJgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkUGFwZXIgPSBzdHlsZWQoUGFwZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFByb3BzIHtcclxuICBhdXRoU2VydmljZTogSW50ZXJwcmV0ZXI8QXV0aE1hY2hpbmVDb250ZXh0LCBhbnksIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnk+O1xyXG59XHJcblxyXG5jb25zdCBVc2VyU2V0dGluZ3NDb250YWluZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGF1dGhTZXJ2aWNlIH0pID0+IHtcclxuICBjb25zdCBbYXV0aFN0YXRlLCBzZW5kQXV0aF0gPSB1c2VBY3RvcihhdXRoU2VydmljZSk7XHJcblxyXG4gIGNvbnN0IGN1cnJlbnRVc2VyID0gYXV0aFN0YXRlPy5jb250ZXh0Py51c2VyO1xyXG4gIGNvbnN0IHVwZGF0ZVVzZXIgPSAocGF5bG9hZDogYW55KSA9PiBzZW5kQXV0aCh7IHR5cGU6IFwiVVBEQVRFXCIsIC4uLnBheWxvYWQgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkUGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfT5cclxuICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIiBjb2xvcj1cInByaW1hcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgVXNlciBTZXR0aW5nc1xyXG4gICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgIDxHcmlkXHJcbiAgICAgICAgY29udGFpbmVyXHJcbiAgICAgICAgc3BhY2luZz17Mn1cclxuICAgICAgICBkaXJlY3Rpb249XCJyb3dcIlxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICA+XHJcbiAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgIDxQZXJzb25hbFNldHRpbmdzSWxsdXN0cmF0aW9uIHN0eWxlPXt7IGhlaWdodDogMjAwLCB3aWR0aDogMzAwIH19IC8+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0gc3R5bGU9e3sgd2lkdGg6IFwiNTAlXCIgfX0+XHJcbiAgICAgICAgICB7Y3VycmVudFVzZXIgJiYgPFVzZXJTZXR0aW5nc0Zvcm0gdXNlclByb2ZpbGU9e2N1cnJlbnRVc2VyfSB1cGRhdGVVc2VyPXt1cGRhdGVVc2VyfSAvPn1cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvU3R5bGVkUGFwZXI+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgVXNlclNldHRpbmdzQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL1VzZXJTZXR0aW5nc0NvbnRhaW5lci50c3gifQ==