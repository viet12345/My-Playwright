import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { List } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import NotificationListItem from "/src/components/NotificationListItem.tsx";
import EmptyList from "/src/components/EmptyList.tsx";
import RemindersIllustration from "/src/components/SvgUndrawReminders697P.tsx";
const NotificationsList = ({
  notifications,
  updateNotification
}) => {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: notifications?.length > 0 ? /* @__PURE__ */ jsxDEV(List, { "data-test": "notifications-list", children: notifications.map(
    (notification) => /* @__PURE__ */ jsxDEV(
      NotificationListItem,
      {
        notification,
        updateNotification
      },
      notification.id,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx",
        lineNumber: 23,
        columnNumber: 9
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx",
    lineNumber: 21,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV(EmptyList, { entity: "Notifications", children: /* @__PURE__ */ jsxDEV(RemindersIllustration, { style: { height: 200, width: 250, marginBottom: 30 } }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx",
    lineNumber: 32,
    columnNumber: 11
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx",
    lineNumber: 31,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx",
    lineNumber: 19,
    columnNumber: 5
  }, this);
};
_c = NotificationsList;
export default NotificationsList;
var _c;
$RefreshReg$(_c, "NotificationsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JJLG1CQUlRLGNBSlI7QUFsQkosT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxZQUFZO0FBRXJCLE9BQU9DLDBCQUEwQjtBQUVqQyxPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLDJCQUEyQjtBQU9sQyxNQUFNQyxvQkFBc0RBLENBQUM7QUFBQSxFQUMzREM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osU0FDRSxtQ0FDR0QseUJBQWVFLFNBQVMsSUFDdkIsdUJBQUMsUUFBSyxhQUFVLHNCQUNiRix3QkFBY0c7QUFBQUEsSUFBSSxDQUFDQyxpQkFDbEI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFGS0EsYUFBYUM7QUFBQUEsTUFEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUd5QztBQUFBLEVBRTFDLEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLElBRUEsdUJBQUMsYUFBVSxRQUFPLGlCQUNoQixpQ0FBQyx5QkFBc0IsT0FBTyxFQUFFQyxRQUFRLEtBQUtDLE9BQU8sS0FBS0MsY0FBYyxHQUFHLEtBQTFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBNEUsS0FEOUU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBLEtBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUVDLEtBdkJJVjtBQXlCTixlQUFlQTtBQUFrQixJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaXN0IiwiTm90aWZpY2F0aW9uTGlzdEl0ZW0iLCJFbXB0eUxpc3QiLCJSZW1pbmRlcnNJbGx1c3RyYXRpb24iLCJOb3RpZmljYXRpb25zTGlzdCIsIm5vdGlmaWNhdGlvbnMiLCJ1cGRhdGVOb3RpZmljYXRpb24iLCJsZW5ndGgiLCJtYXAiLCJub3RpZmljYXRpb24iLCJpZCIsImhlaWdodCIsIndpZHRoIiwibWFyZ2luQm90dG9tIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25MaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpc3QgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IE5vdGlmaWNhdGlvbkxpc3RJdGVtIGZyb20gXCIuL05vdGlmaWNhdGlvbkxpc3RJdGVtXCI7XHJcbmltcG9ydCB7IE5vdGlmaWNhdGlvblJlc3BvbnNlSXRlbSB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IEVtcHR5TGlzdCBmcm9tIFwiLi9FbXB0eUxpc3RcIjtcclxuaW1wb3J0IFJlbWluZGVyc0lsbHVzdHJhdGlvbiBmcm9tIFwiLi9TdmdVbmRyYXdSZW1pbmRlcnM2OTdQXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5vdGlmaWNhdGlvbnNMaXN0UHJvcHMge1xyXG4gIG5vdGlmaWNhdGlvbnM6IE5vdGlmaWNhdGlvblJlc3BvbnNlSXRlbVtdO1xyXG4gIHVwZGF0ZU5vdGlmaWNhdGlvbjogRnVuY3Rpb247XHJcbn1cclxuXHJcbmNvbnN0IE5vdGlmaWNhdGlvbnNMaXN0OiBSZWFjdC5GQzxOb3RpZmljYXRpb25zTGlzdFByb3BzPiA9ICh7XHJcbiAgbm90aWZpY2F0aW9ucyxcclxuICB1cGRhdGVOb3RpZmljYXRpb24sXHJcbn0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge25vdGlmaWNhdGlvbnM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgPExpc3QgZGF0YS10ZXN0PVwibm90aWZpY2F0aW9ucy1saXN0XCI+XHJcbiAgICAgICAgICB7bm90aWZpY2F0aW9ucy5tYXAoKG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uUmVzcG9uc2VJdGVtKSA9PiAoXHJcbiAgICAgICAgICAgIDxOb3RpZmljYXRpb25MaXN0SXRlbVxyXG4gICAgICAgICAgICAgIGtleT17bm90aWZpY2F0aW9uLmlkfVxyXG4gICAgICAgICAgICAgIG5vdGlmaWNhdGlvbj17bm90aWZpY2F0aW9ufVxyXG4gICAgICAgICAgICAgIHVwZGF0ZU5vdGlmaWNhdGlvbj17dXBkYXRlTm90aWZpY2F0aW9ufVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9MaXN0PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxFbXB0eUxpc3QgZW50aXR5PVwiTm90aWZpY2F0aW9uc1wiPlxyXG4gICAgICAgICAgPFJlbWluZGVyc0lsbHVzdHJhdGlvbiBzdHlsZT17eyBoZWlnaHQ6IDIwMCwgd2lkdGg6IDI1MCwgbWFyZ2luQm90dG9tOiAzMCB9fSAvPlxyXG4gICAgICAgIDwvRW1wdHlMaXN0PlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE5vdGlmaWNhdGlvbnNMaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbkxpc3QudHN4In0=