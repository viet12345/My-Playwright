import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionTitle.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { isRequestTransaction, isAcceptedRequestTransaction } from "/src/utils/transactionUtils.ts";
const PREFIX = "TransactionTitle";
const classes = {
  title: `${PREFIX}-title`,
  titleAction: `${PREFIX}-titleAction`,
  titleName: `${PREFIX}-titleName`
};
const StyledTypography = styled(Typography)(({ theme }) => ({
  [`&.${classes.title}`]: {
    fontSize: 18,
    [theme.breakpoints.down("md")]: {
      fontSize: theme.typography.fontSize
    }
  },
  [`& .${classes.titleAction}`]: {
    fontSize: 18,
    [theme.breakpoints.down("md")]: {
      fontSize: theme.typography.fontSize
    }
  },
  [`& .${classes.titleName}`]: {
    fontSize: 18,
    [theme.breakpoints.down("md")]: {
      fontSize: theme.typography.fontSize
    },
    color: "#1A202C"
  }
}));
_c = StyledTypography;
const TransactionTitle = ({ transaction }) => {
  return /* @__PURE__ */ jsxDEV(StyledTypography, { color: "textSecondary", className: classes.title, gutterBottom: true, children: [
    /* @__PURE__ */ jsxDEV(
      Typography,
      {
        "data-test": `transaction-sender-${transaction.id}`,
        className: classes.titleName,
        display: "inline",
        component: "span",
        children: transaction.senderName
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx",
        lineNumber: 44,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Typography,
      {
        "data-test": `transaction-action-${transaction.id}`,
        display: "inline",
        className: classes.titleAction,
        component: "span",
        children: isRequestTransaction(transaction) ? isAcceptedRequestTransaction(transaction) ? " charged " : " requested " : " paid "
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx",
        lineNumber: 52,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Typography,
      {
        "data-test": `transaction-receiver-${transaction.id}`,
        className: classes.titleName,
        display: "inline",
        component: "span",
        children: transaction.receiverName
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx",
        lineNumber: 64,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx",
    lineNumber: 43,
    columnNumber: 5
  }, this);
};
_c2 = TransactionTitle;
export default TransactionTitle;
var _c, _c2;
$RefreshReg$(_c, "StyledTypography");
$RefreshReg$(_c2, "TransactionTitle");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionTitle.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkNNO0FBM0NOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxrQkFBa0I7QUFFM0IsU0FBU0Msc0JBQXNCQyxvQ0FBb0M7QUFFbkUsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFBQSxFQUNoQkcsYUFBYSxHQUFHSCxNQUFNO0FBQUEsRUFDdEJJLFdBQVcsR0FBR0osTUFBTTtBQUN0QjtBQUVBLE1BQU1LLG1CQUFtQlQsT0FBT0MsVUFBVSxFQUFFLENBQUMsRUFBRVMsTUFBTSxPQUFPO0FBQUEsRUFDMUQsQ0FBQyxLQUFLTCxRQUFRQyxLQUFLLEVBQUUsR0FBRztBQUFBLElBQ3RCSyxVQUFVO0FBQUEsSUFDVixDQUFDRCxNQUFNRSxZQUFZQyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFDOUJGLFVBQVVELE1BQU1JLFdBQVdIO0FBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUFBLEVBRUEsQ0FBQyxNQUFNTixRQUFRRSxXQUFXLEVBQUUsR0FBRztBQUFBLElBQzdCSSxVQUFVO0FBQUEsSUFDVixDQUFDRCxNQUFNRSxZQUFZQyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFDOUJGLFVBQVVELE1BQU1JLFdBQVdIO0FBQUFBLElBQzdCO0FBQUEsRUFDRjtBQUFBLEVBRUEsQ0FBQyxNQUFNTixRQUFRRyxTQUFTLEVBQUUsR0FBRztBQUFBLElBQzNCRyxVQUFVO0FBQUEsSUFDVixDQUFDRCxNQUFNRSxZQUFZQyxLQUFLLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFDOUJGLFVBQVVELE1BQU1JLFdBQVdIO0FBQUFBLElBQzdCO0FBQUEsSUFDQUksT0FBTztBQUFBLEVBQ1Q7QUFDRixFQUFFO0FBQUVDLEtBdEJFUDtBQXdCTixNQUFNUSxtQkFFREEsQ0FBQyxFQUFFQyxZQUFZLE1BQU07QUFDeEIsU0FDRSx1QkFBQyxvQkFBaUIsT0FBTSxpQkFBZ0IsV0FBV2IsUUFBUUMsT0FBTyxjQUFZLE1BQzVFO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGFBQVcsc0JBQXNCWSxZQUFZQyxFQUFFO0FBQUEsUUFDL0MsV0FBV2QsUUFBUUc7QUFBQUEsUUFDbkIsU0FBUTtBQUFBLFFBQ1IsV0FBVTtBQUFBLFFBRVRVLHNCQUFZRTtBQUFBQTtBQUFBQSxNQU5mO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsYUFBVyxzQkFBc0JGLFlBQVlDLEVBQUU7QUFBQSxRQUMvQyxTQUFRO0FBQUEsUUFDUixXQUFXZCxRQUFRRTtBQUFBQSxRQUNuQixXQUFVO0FBQUEsUUFFVEwsK0JBQXFCZ0IsV0FBVyxJQUM3QmYsNkJBQTZCZSxXQUFXLElBQ3RDLGNBQ0EsZ0JBQ0Y7QUFBQTtBQUFBLE1BVk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBV0E7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxhQUFXLHdCQUF3QkEsWUFBWUMsRUFBRTtBQUFBLFFBQ2pELFdBQVdkLFFBQVFHO0FBQUFBLFFBQ25CLFNBQVE7QUFBQSxRQUNSLFdBQVU7QUFBQSxRQUVUVSxzQkFBWUc7QUFBQUE7QUFBQUEsTUFOZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFPQTtBQUFBLE9BNUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2QkE7QUFFSjtBQUFFQyxNQW5DSUw7QUFxQ04sZUFBZUE7QUFBaUIsSUFBQUQsSUFBQU07QUFBQUMsYUFBQVAsSUFBQTtBQUFBTyxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJzdHlsZWQiLCJUeXBvZ3JhcGh5IiwiaXNSZXF1ZXN0VHJhbnNhY3Rpb24iLCJpc0FjY2VwdGVkUmVxdWVzdFRyYW5zYWN0aW9uIiwiUFJFRklYIiwiY2xhc3NlcyIsInRpdGxlIiwidGl0bGVBY3Rpb24iLCJ0aXRsZU5hbWUiLCJTdHlsZWRUeXBvZ3JhcGh5IiwidGhlbWUiLCJmb250U2l6ZSIsImJyZWFrcG9pbnRzIiwiZG93biIsInR5cG9ncmFwaHkiLCJjb2xvciIsIl9jIiwiVHJhbnNhY3Rpb25UaXRsZSIsInRyYW5zYWN0aW9uIiwiaWQiLCJzZW5kZXJOYW1lIiwicmVjZWl2ZXJOYW1lIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVHJhbnNhY3Rpb25UaXRsZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgVHlwb2dyYXBoeSB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IFRyYW5zYWN0aW9uUmVzcG9uc2VJdGVtIH0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5pbXBvcnQgeyBpc1JlcXVlc3RUcmFuc2FjdGlvbiwgaXNBY2NlcHRlZFJlcXVlc3RUcmFuc2FjdGlvbiB9IGZyb20gXCIuLi91dGlscy90cmFuc2FjdGlvblV0aWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uVGl0bGVcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgdGl0bGU6IGAke1BSRUZJWH0tdGl0bGVgLFxyXG4gIHRpdGxlQWN0aW9uOiBgJHtQUkVGSVh9LXRpdGxlQWN0aW9uYCxcclxuICB0aXRsZU5hbWU6IGAke1BSRUZJWH0tdGl0bGVOYW1lYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZFR5cG9ncmFwaHkgPSBzdHlsZWQoVHlwb2dyYXBoeSkoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYuJHtjbGFzc2VzLnRpdGxlfWBdOiB7XHJcbiAgICBmb250U2l6ZTogMTgsXHJcbiAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bihcIm1kXCIpXToge1xyXG4gICAgICBmb250U2l6ZTogdGhlbWUudHlwb2dyYXBoeS5mb250U2l6ZSxcclxuICAgIH0sXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMudGl0bGVBY3Rpb259YF06IHtcclxuICAgIGZvbnRTaXplOiAxOCxcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKFwibWRcIildOiB7XHJcbiAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmZvbnRTaXplLFxyXG4gICAgfSxcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy50aXRsZU5hbWV9YF06IHtcclxuICAgIGZvbnRTaXplOiAxOCxcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKFwibWRcIildOiB7XHJcbiAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmZvbnRTaXplLFxyXG4gICAgfSxcclxuICAgIGNvbG9yOiBcIiMxQTIwMkNcIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvblRpdGxlOiBSZWFjdC5GQzx7XHJcbiAgdHJhbnNhY3Rpb246IFRyYW5zYWN0aW9uUmVzcG9uc2VJdGVtO1xyXG59PiA9ICh7IHRyYW5zYWN0aW9uIH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPFN0eWxlZFR5cG9ncmFwaHkgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgY2xhc3NOYW1lPXtjbGFzc2VzLnRpdGxlfSBndXR0ZXJCb3R0b20+XHJcbiAgICAgIDxUeXBvZ3JhcGh5XHJcbiAgICAgICAgZGF0YS10ZXN0PXtgdHJhbnNhY3Rpb24tc2VuZGVyLSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGVOYW1lfVxyXG4gICAgICAgIGRpc3BsYXk9XCJpbmxpbmVcIlxyXG4gICAgICAgIGNvbXBvbmVudD1cInNwYW5cIlxyXG4gICAgICA+XHJcbiAgICAgICAge3RyYW5zYWN0aW9uLnNlbmRlck5hbWV9XHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICBkYXRhLXRlc3Q9e2B0cmFuc2FjdGlvbi1hY3Rpb24tJHt0cmFuc2FjdGlvbi5pZH1gfVxyXG4gICAgICAgIGRpc3BsYXk9XCJpbmxpbmVcIlxyXG4gICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50aXRsZUFjdGlvbn1cclxuICAgICAgICBjb21wb25lbnQ9XCJzcGFuXCJcclxuICAgICAgPlxyXG4gICAgICAgIHtpc1JlcXVlc3RUcmFuc2FjdGlvbih0cmFuc2FjdGlvbilcclxuICAgICAgICAgID8gaXNBY2NlcHRlZFJlcXVlc3RUcmFuc2FjdGlvbih0cmFuc2FjdGlvbilcclxuICAgICAgICAgICAgPyBcIiBjaGFyZ2VkIFwiXHJcbiAgICAgICAgICAgIDogXCIgcmVxdWVzdGVkIFwiXHJcbiAgICAgICAgICA6IFwiIHBhaWQgXCJ9XHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICBkYXRhLXRlc3Q9e2B0cmFuc2FjdGlvbi1yZWNlaXZlci0ke3RyYW5zYWN0aW9uLmlkfWB9XHJcbiAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnRpdGxlTmFtZX1cclxuICAgICAgICBkaXNwbGF5PVwiaW5saW5lXCJcclxuICAgICAgICBjb21wb25lbnQ9XCJzcGFuXCJcclxuICAgICAgPlxyXG4gICAgICAgIHt0cmFuc2FjdGlvbi5yZWNlaXZlck5hbWV9XHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgIDwvU3R5bGVkVHlwb2dyYXBoeT5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25UaXRsZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvblRpdGxlLnRzeCJ9