import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionInfiniteList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import __vite__cjsImport4_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const get = __vite__cjsImport4_lodash_fp["get"];
import { useTheme, useMediaQuery, Divider } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { InfiniteLoader, List } from "/node_modules/.vite/deps/react-virtualized.js?v=6af76b79";
import "/node_modules/react-virtualized/styles.css";
import TransactionItem from "/src/components/TransactionItem.tsx";
const PREFIX = "TransactionInfiniteList";
const classes = {
  transactionList: `${PREFIX}-transactionList`
};
const StyledInfiniteLoader = styled(InfiniteLoader)(({ theme }) => ({
  [`& .${classes.transactionList}`]: {
    width: "100%",
    minHeight: "80vh",
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  }
}));
_c = StyledInfiniteLoader;
const TransactionInfiniteList = ({
  transactions,
  loadNextPage,
  pagination
}) => {
  _s();
  const theme = useTheme();
  const isXsBreakpoint = useMediaQuery(theme.breakpoints.down("sm"));
  const isMobile = useMediaQuery(theme.breakpoints.down("md"));
  const itemCount = pagination.hasNextPages ? transactions.length + 1 : transactions.length;
  const loadMoreItems = () => {
    return new Promise((resolve) => {
      return resolve(pagination.hasNextPages && loadNextPage(pagination.page + 1));
    });
  };
  const isRowLoaded = (params) => !pagination.hasNextPages || params.index < transactions.length;
  function rowRenderer({ key, index, style }) {
    const transaction = get(index, transactions);
    if (index < transactions.length) {
      return /* @__PURE__ */ jsxDEV("div", { style, children: [
        /* @__PURE__ */ jsxDEV(TransactionItem, { transaction }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
          lineNumber: 60,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Divider, { variant: isMobile ? "fullWidth" : "inset" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
          lineNumber: 61,
          columnNumber: 11
        }, this)
      ] }, key, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
        lineNumber: 59,
        columnNumber: 9
      }, this);
    }
  }
  const removePx = (str) => +str.slice(0, str.length - 2);
  return /* @__PURE__ */ jsxDEV(
    StyledInfiniteLoader,
    {
      isRowLoaded,
      loadMoreRows: loadMoreItems,
      rowCount: itemCount,
      threshold: 2,
      children: ({ onRowsRendered, registerChild }) => /* @__PURE__ */ jsxDEV("div", { "data-test": "transaction-list", className: classes.transactionList, children: /* @__PURE__ */ jsxDEV(
        List,
        {
          rowCount: itemCount,
          ref: registerChild,
          onRowsRendered,
          height: isXsBreakpoint ? removePx(theme.spacing(74)) : removePx(theme.spacing(88)),
          width: isXsBreakpoint ? removePx(theme.spacing(38)) : removePx(theme.spacing(90)),
          rowHeight: isXsBreakpoint ? removePx(theme.spacing(28)) : removePx(theme.spacing(16)),
          rowRenderer
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
          lineNumber: 78,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
        lineNumber: 77,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx",
      lineNumber: 70,
      columnNumber: 5
    },
    this
  );
};
_s(TransactionInfiniteList, "vgTm9UAguVk3ebs2tYmWbGrrw8Q=", false, function() {
  return [useTheme, useMediaQuery, useMediaQuery];
});
_c2 = TransactionInfiniteList;
export default TransactionInfiniteList;
var _c, _c2;
$RefreshReg$(_c, "StyledInfiniteLoader");
$RefreshReg$(_c2, "TransactionInfiniteList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionInfiniteList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkRVOzJCQTNEVjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVc7QUFDcEIsU0FBU0MsVUFBVUMsZUFBZUMsZUFBZTtBQUNqRCxTQUFTQyxnQkFBZ0JDLFlBQW1CO0FBQzVDLE9BQU87QUFFUCxPQUFPQyxxQkFBcUI7QUFHNUIsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxpQkFBaUIsR0FBR0YsTUFBTTtBQUM1QjtBQUVBLE1BQU1HLHVCQUF1QlgsT0FBT0ssY0FBYyxFQUFFLENBQUMsRUFBRU8sTUFBTSxPQUFPO0FBQUEsRUFDbEUsQ0FBQyxNQUFNSCxRQUFRQyxlQUFlLEVBQUUsR0FBRztBQUFBLElBQ2pDRyxPQUFPO0FBQUEsSUFDUEMsV0FBVztBQUFBLElBQ1hDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsZUFBZTtBQUFBLEVBQ2pCO0FBQ0YsRUFBRTtBQUFFQyxLQVJFUDtBQWdCTixNQUFNUSwwQkFBMERBLENBQUM7QUFBQSxFQUMvREM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNWCxRQUFRVixTQUFTO0FBQ3ZCLFFBQU1zQixpQkFBaUJyQixjQUFjUyxNQUFNYSxZQUFZQyxLQUFLLElBQUksQ0FBQztBQUNqRSxRQUFNQyxXQUFXeEIsY0FBY1MsTUFBTWEsWUFBWUMsS0FBSyxJQUFJLENBQUM7QUFFM0QsUUFBTUUsWUFBWU4sV0FBV08sZUFBZVQsYUFBYVUsU0FBUyxJQUFJVixhQUFhVTtBQUVuRixRQUFNQyxnQkFBZ0JBLE1BQU07QUFDMUIsV0FBTyxJQUFJQyxRQUFRLENBQUNDLFlBQVk7QUFDOUIsYUFBT0EsUUFBUVgsV0FBV08sZ0JBQWdCUixhQUFhQyxXQUFXWSxPQUFPLENBQUMsQ0FBQztBQUFBLElBQzdFLENBQUM7QUFBQSxFQUNIO0FBRUEsUUFBTUMsY0FBY0EsQ0FBQ0MsV0FDbkIsQ0FBQ2QsV0FBV08sZ0JBQWdCTyxPQUFPQyxRQUFRakIsYUFBYVU7QUFHMUQsV0FBU1EsWUFBWSxFQUFFQyxLQUFLRixPQUFPRyxNQUFNLEdBQUc7QUFDMUMsVUFBTUMsY0FBY3hDLElBQUlvQyxPQUFPakIsWUFBWTtBQUUzQyxRQUFJaUIsUUFBUWpCLGFBQWFVLFFBQVE7QUFDL0IsYUFDRSx1QkFBQyxTQUFjLE9BQ2I7QUFBQSwrQkFBQyxtQkFBZ0IsZUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLFdBQVEsU0FBU0gsV0FBVyxjQUFjLFdBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBbUQ7QUFBQSxXQUYzQ1ksS0FBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0E7QUFBQSxJQUVKO0FBQUEsRUFDRjtBQUVBLFFBQU1HLFdBQVdBLENBQUNDLFFBQWdCLENBQUNBLElBQUlDLE1BQU0sR0FBR0QsSUFBSWIsU0FBUyxDQUFDO0FBRTlELFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQSxjQUFjQztBQUFBQSxNQUNkLFVBQVVIO0FBQUFBLE1BQ1YsV0FBVztBQUFBLE1BRVYsV0FBQyxFQUFFaUIsZ0JBQWdCQyxjQUFjLE1BQ2hDLHVCQUFDLFNBQUksYUFBVSxvQkFBbUIsV0FBV3JDLFFBQVFDLGlCQUNuRDtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsVUFBVWtCO0FBQUFBLFVBQ1YsS0FBS2tCO0FBQUFBLFVBQ0w7QUFBQSxVQUNBLFFBQVF0QixpQkFBaUJrQixTQUFTOUIsTUFBTW1DLFFBQVEsRUFBRSxDQUFDLElBQUlMLFNBQVM5QixNQUFNbUMsUUFBUSxFQUFFLENBQUM7QUFBQSxVQUNqRixPQUFPdkIsaUJBQWlCa0IsU0FBUzlCLE1BQU1tQyxRQUFRLEVBQUUsQ0FBQyxJQUFJTCxTQUFTOUIsTUFBTW1DLFFBQVEsRUFBRSxDQUFDO0FBQUEsVUFDaEYsV0FBV3ZCLGlCQUFpQmtCLFNBQVM5QixNQUFNbUMsUUFBUSxFQUFFLENBQUMsSUFBSUwsU0FBUzlCLE1BQU1tQyxRQUFRLEVBQUUsQ0FBQztBQUFBLFVBQ3BGO0FBQUE7QUFBQSxRQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU8yQixLQVI3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQTtBQUFBLElBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQW1CQTtBQUVKO0FBQUV4QixHQTFESUoseUJBQXVEO0FBQUEsVUFLN0NqQixVQUNTQyxlQUNOQSxhQUFhO0FBQUE7QUFBQTZDLE1BUDFCN0I7QUE0RE4sZUFBZUE7QUFBd0IsSUFBQUQsSUFBQThCO0FBQUFDLGFBQUEvQixJQUFBO0FBQUErQixhQUFBRCxLQUFBIiwibmFtZXMiOlsic3R5bGVkIiwiZ2V0IiwidXNlVGhlbWUiLCJ1c2VNZWRpYVF1ZXJ5IiwiRGl2aWRlciIsIkluZmluaXRlTG9hZGVyIiwiTGlzdCIsIlRyYW5zYWN0aW9uSXRlbSIsIlBSRUZJWCIsImNsYXNzZXMiLCJ0cmFuc2FjdGlvbkxpc3QiLCJTdHlsZWRJbmZpbml0ZUxvYWRlciIsInRoZW1lIiwid2lkdGgiLCJtaW5IZWlnaHQiLCJkaXNwbGF5Iiwib3ZlcmZsb3ciLCJmbGV4RGlyZWN0aW9uIiwiX2MiLCJUcmFuc2FjdGlvbkluZmluaXRlTGlzdCIsInRyYW5zYWN0aW9ucyIsImxvYWROZXh0UGFnZSIsInBhZ2luYXRpb24iLCJfcyIsImlzWHNCcmVha3BvaW50IiwiYnJlYWtwb2ludHMiLCJkb3duIiwiaXNNb2JpbGUiLCJpdGVtQ291bnQiLCJoYXNOZXh0UGFnZXMiLCJsZW5ndGgiLCJsb2FkTW9yZUl0ZW1zIiwiUHJvbWlzZSIsInJlc29sdmUiLCJwYWdlIiwiaXNSb3dMb2FkZWQiLCJwYXJhbXMiLCJpbmRleCIsInJvd1JlbmRlcmVyIiwia2V5Iiwic3R5bGUiLCJ0cmFuc2FjdGlvbiIsInJlbW92ZVB4Iiwic3RyIiwic2xpY2UiLCJvblJvd3NSZW5kZXJlZCIsInJlZ2lzdGVyQ2hpbGQiLCJzcGFjaW5nIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IGdldCB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHsgdXNlVGhlbWUsIHVzZU1lZGlhUXVlcnksIERpdmlkZXIgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBJbmZpbml0ZUxvYWRlciwgTGlzdCwgSW5kZXggfSBmcm9tIFwicmVhY3QtdmlydHVhbGl6ZWRcIjtcclxuaW1wb3J0IFwicmVhY3QtdmlydHVhbGl6ZWQvc3R5bGVzLmNzc1wiOyAvLyBvbmx5IG5lZWRzIHRvIGJlIGltcG9ydGVkIG9uY2VcclxuXHJcbmltcG9ydCBUcmFuc2FjdGlvbkl0ZW0gZnJvbSBcIi4vVHJhbnNhY3Rpb25JdGVtXCI7XHJcbmltcG9ydCB7IFRyYW5zYWN0aW9uUmVzcG9uc2VJdGVtLCBUcmFuc2FjdGlvblBhZ2luYXRpb24gfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uSW5maW5pdGVMaXN0XCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHRyYW5zYWN0aW9uTGlzdDogYCR7UFJFRklYfS10cmFuc2FjdGlvbkxpc3RgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkSW5maW5pdGVMb2FkZXIgPSBzdHlsZWQoSW5maW5pdGVMb2FkZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmIC4ke2NsYXNzZXMudHJhbnNhY3Rpb25MaXN0fWBdOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsXHJcbiAgICBtaW5IZWlnaHQ6IFwiODB2aFwiLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBvdmVyZmxvdzogXCJhdXRvXCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25MaXN0UHJvcHMge1xyXG4gIHRyYW5zYWN0aW9uczogVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW1bXTtcclxuICBsb2FkTmV4dFBhZ2U6IEZ1bmN0aW9uO1xyXG4gIHBhZ2luYXRpb246IFRyYW5zYWN0aW9uUGFnaW5hdGlvbjtcclxufVxyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3Q6IFJlYWN0LkZDPFRyYW5zYWN0aW9uTGlzdFByb3BzPiA9ICh7XHJcbiAgdHJhbnNhY3Rpb25zLFxyXG4gIGxvYWROZXh0UGFnZSxcclxuICBwYWdpbmF0aW9uLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpO1xyXG4gIGNvbnN0IGlzWHNCcmVha3BvaW50ID0gdXNlTWVkaWFRdWVyeSh0aGVtZS5icmVha3BvaW50cy5kb3duKFwic21cIikpO1xyXG4gIGNvbnN0IGlzTW9iaWxlID0gdXNlTWVkaWFRdWVyeSh0aGVtZS5icmVha3BvaW50cy5kb3duKFwibWRcIikpO1xyXG5cclxuICBjb25zdCBpdGVtQ291bnQgPSBwYWdpbmF0aW9uLmhhc05leHRQYWdlcyA/IHRyYW5zYWN0aW9ucy5sZW5ndGggKyAxIDogdHJhbnNhY3Rpb25zLmxlbmd0aDtcclxuXHJcbiAgY29uc3QgbG9hZE1vcmVJdGVtcyA9ICgpID0+IHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xyXG4gICAgICByZXR1cm4gcmVzb2x2ZShwYWdpbmF0aW9uLmhhc05leHRQYWdlcyAmJiBsb2FkTmV4dFBhZ2UocGFnaW5hdGlvbi5wYWdlICsgMSkpO1xyXG4gICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaXNSb3dMb2FkZWQgPSAocGFyYW1zOiBJbmRleCkgPT5cclxuICAgICFwYWdpbmF0aW9uLmhhc05leHRQYWdlcyB8fCBwYXJhbXMuaW5kZXggPCB0cmFuc2FjdGlvbnMubGVuZ3RoO1xyXG5cclxuICAvLyBAdHMtaWdub3JlXHJcbiAgZnVuY3Rpb24gcm93UmVuZGVyZXIoeyBrZXksIGluZGV4LCBzdHlsZSB9KSB7XHJcbiAgICBjb25zdCB0cmFuc2FjdGlvbiA9IGdldChpbmRleCwgdHJhbnNhY3Rpb25zKTtcclxuXHJcbiAgICBpZiAoaW5kZXggPCB0cmFuc2FjdGlvbnMubGVuZ3RoKSB7XHJcbiAgICAgIHJldHVybiAoXHJcbiAgICAgICAgPGRpdiBrZXk9e2tleX0gc3R5bGU9e3N0eWxlfT5cclxuICAgICAgICAgIDxUcmFuc2FjdGlvbkl0ZW0gdHJhbnNhY3Rpb249e3RyYW5zYWN0aW9ufSAvPlxyXG4gICAgICAgICAgPERpdmlkZXIgdmFyaWFudD17aXNNb2JpbGUgPyBcImZ1bGxXaWR0aFwiIDogXCJpbnNldFwifSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgY29uc3QgcmVtb3ZlUHggPSAoc3RyOiBzdHJpbmcpID0+ICtzdHIuc2xpY2UoMCwgc3RyLmxlbmd0aCAtIDIpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFN0eWxlZEluZmluaXRlTG9hZGVyXHJcbiAgICAgIGlzUm93TG9hZGVkPXtpc1Jvd0xvYWRlZH1cclxuICAgICAgbG9hZE1vcmVSb3dzPXtsb2FkTW9yZUl0ZW1zfVxyXG4gICAgICByb3dDb3VudD17aXRlbUNvdW50fVxyXG4gICAgICB0aHJlc2hvbGQ9ezJ9XHJcbiAgICA+XHJcbiAgICAgIHsoeyBvblJvd3NSZW5kZXJlZCwgcmVnaXN0ZXJDaGlsZCB9KSA9PiAoXHJcbiAgICAgICAgPGRpdiBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saXN0XCIgY2xhc3NOYW1lPXtjbGFzc2VzLnRyYW5zYWN0aW9uTGlzdH0+XHJcbiAgICAgICAgICA8TGlzdFxyXG4gICAgICAgICAgICByb3dDb3VudD17aXRlbUNvdW50fVxyXG4gICAgICAgICAgICByZWY9e3JlZ2lzdGVyQ2hpbGR9XHJcbiAgICAgICAgICAgIG9uUm93c1JlbmRlcmVkPXtvblJvd3NSZW5kZXJlZH1cclxuICAgICAgICAgICAgaGVpZ2h0PXtpc1hzQnJlYWtwb2ludCA/IHJlbW92ZVB4KHRoZW1lLnNwYWNpbmcoNzQpKSA6IHJlbW92ZVB4KHRoZW1lLnNwYWNpbmcoODgpKX1cclxuICAgICAgICAgICAgd2lkdGg9e2lzWHNCcmVha3BvaW50ID8gcmVtb3ZlUHgodGhlbWUuc3BhY2luZygzOCkpIDogcmVtb3ZlUHgodGhlbWUuc3BhY2luZyg5MCkpfVxyXG4gICAgICAgICAgICByb3dIZWlnaHQ9e2lzWHNCcmVha3BvaW50ID8gcmVtb3ZlUHgodGhlbWUuc3BhY2luZygyOCkpIDogcmVtb3ZlUHgodGhlbWUuc3BhY2luZygxNikpfVxyXG4gICAgICAgICAgICByb3dSZW5kZXJlcj17cm93UmVuZGVyZXJ9XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9TdHlsZWRJbmZpbml0ZUxvYWRlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3Q7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25JbmZpbml0ZUxpc3QudHN4In0=