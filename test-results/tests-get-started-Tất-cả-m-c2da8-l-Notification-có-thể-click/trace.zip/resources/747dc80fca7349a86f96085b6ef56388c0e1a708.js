import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BankAccountList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { List } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import BankAccountItem from "/src/components/BankAccountItem.tsx";
import EmptyList from "/src/components/EmptyList.tsx";
const BankAccountList = ({ bankAccounts, deleteBankAccount }) => {
  return /* @__PURE__ */ jsxDEV(Fragment, { children: bankAccounts?.length > 0 ? /* @__PURE__ */ jsxDEV(List, { "data-test": "bankaccount-list", children: bankAccounts.map(
    (bankAccount) => /* @__PURE__ */ jsxDEV(
      BankAccountItem,
      {
        bankAccount,
        deleteBankAccount
      },
      bankAccount.id,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx",
        lineNumber: 19,
        columnNumber: 9
      },
      this
    )
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx",
    lineNumber: 17,
    columnNumber: 7
  }, this) : /* @__PURE__ */ jsxDEV(EmptyList, { entity: "Bank Accounts" }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx",
    lineNumber: 27,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx",
    lineNumber: 15,
    columnNumber: 5
  }, this);
};
_c = BankAccountList;
export default BankAccountList;
var _c;
$RefreshReg$(_c, "BankAccountList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY0ksbUJBSVEsY0FKUjtBQWRKLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsWUFBWTtBQUdyQixPQUFPQyxxQkFBcUI7QUFDNUIsT0FBT0MsZUFBZTtBQU90QixNQUFNQyxrQkFBa0RBLENBQUMsRUFBRUMsY0FBY0Msa0JBQWtCLE1BQU07QUFDL0YsU0FDRSxtQ0FDR0Qsd0JBQWNFLFNBQVMsSUFDdEIsdUJBQUMsUUFBSyxhQUFVLG9CQUNiRix1QkFBYUc7QUFBQUEsSUFBSSxDQUFDQyxnQkFDakI7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUVDO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFGS0EsWUFBWUM7QUFBQUEsTUFEbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUd1QztBQUFBLEVBRXhDLEtBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBLElBRUEsdUJBQUMsYUFBVSxRQUFPLG1CQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQWlDLEtBWnJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FjQTtBQUVKO0FBQUVDLEtBbEJJUDtBQW9CTixlQUFlQTtBQUFnQixJQUFBTztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaXN0IiwiQmFua0FjY291bnRJdGVtIiwiRW1wdHlMaXN0IiwiQmFua0FjY291bnRMaXN0IiwiYmFua0FjY291bnRzIiwiZGVsZXRlQmFua0FjY291bnQiLCJsZW5ndGgiLCJtYXAiLCJiYW5rQWNjb3VudCIsImlkIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJCYW5rQWNjb3VudExpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgTGlzdCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcblxyXG5pbXBvcnQgeyBCYW5rQWNjb3VudCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IEJhbmtBY2NvdW50SXRlbSBmcm9tIFwiLi9CYW5rQWNjb3VudEl0ZW1cIjtcclxuaW1wb3J0IEVtcHR5TGlzdCBmcm9tIFwiLi9FbXB0eUxpc3RcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQmFua0FjY291bnRMaXN0UHJvcHMge1xyXG4gIGJhbmtBY2NvdW50czogQmFua0FjY291bnRbXTtcclxuICBkZWxldGVCYW5rQWNjb3VudDogRnVuY3Rpb247XHJcbn1cclxuXHJcbmNvbnN0IEJhbmtBY2NvdW50TGlzdDogUmVhY3QuRkM8QmFua0FjY291bnRMaXN0UHJvcHM+ID0gKHsgYmFua0FjY291bnRzLCBkZWxldGVCYW5rQWNjb3VudCB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDw+XHJcbiAgICAgIHtiYW5rQWNjb3VudHM/Lmxlbmd0aCA+IDAgPyAoXHJcbiAgICAgICAgPExpc3QgZGF0YS10ZXN0PVwiYmFua2FjY291bnQtbGlzdFwiPlxyXG4gICAgICAgICAge2JhbmtBY2NvdW50cy5tYXAoKGJhbmtBY2NvdW50OiBCYW5rQWNjb3VudCkgPT4gKFxyXG4gICAgICAgICAgICA8QmFua0FjY291bnRJdGVtXHJcbiAgICAgICAgICAgICAga2V5PXtiYW5rQWNjb3VudC5pZH1cclxuICAgICAgICAgICAgICBiYW5rQWNjb3VudD17YmFua0FjY291bnR9XHJcbiAgICAgICAgICAgICAgZGVsZXRlQmFua0FjY291bnQ9e2RlbGV0ZUJhbmtBY2NvdW50fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9MaXN0PlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxFbXB0eUxpc3QgZW50aXR5PVwiQmFuayBBY2NvdW50c1wiIC8+XHJcbiAgICAgICl9XHJcbiAgICA8Lz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQmFua0FjY291bnRMaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL0JhbmtBY2NvdW50TGlzdC50c3gifQ==