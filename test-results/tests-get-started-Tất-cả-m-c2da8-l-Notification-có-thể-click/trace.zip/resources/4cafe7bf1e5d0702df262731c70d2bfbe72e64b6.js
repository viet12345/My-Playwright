import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const omit = __vite__cjsImport0_lodash_fp["omit"]; const flow = __vite__cjsImport0_lodash_fp["flow"]; const first = __vite__cjsImport0_lodash_fp["first"]; const isEmpty = __vite__cjsImport0_lodash_fp["isEmpty"];
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const transactionDetailMachine = dataMachine("transactionData").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const payload = omit("type", event);
      const contextTransactionId = !isEmpty(ctx.results) && first(ctx.results)["id"];
      const transactionId = contextTransactionId || payload.transactionId;
      const resp = await httpClient.get(
        `http://localhost:${backendPort}/transactions/${transactionId}`
      );
      return { results: [resp.data.transaction] };
    },
    createData: async (ctx, event) => {
      let route = event.entity === "LIKE" ? "likes" : "comments";
      const payload = flow(omit("type"), omit("entity"))(event);
      const resp = await httpClient.post(
        `http://localhost:${backendPort}/${route}/${payload.transactionId}`,
        payload
      );
      return resp.data;
    },
    updateData: async (ctx, event) => {
      const payload = omit("type", event);
      const contextTransactionId = !isEmpty(ctx.results) && first(ctx.results)["id"];
      const transactionId = contextTransactionId || payload.id;
      const resp = await httpClient.patch(
        `http://localhost:${backendPort}/transactions/${transactionId}`,
        payload
      );
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zYWN0aW9uRGV0YWlsTWFjaGluZS50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBvbWl0LCBmbG93LCBmaXJzdCwgaXNFbXB0eSB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHsgZGF0YU1hY2hpbmUgfSBmcm9tIFwiLi9kYXRhTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBodHRwQ2xpZW50IH0gZnJvbSBcIi4uL3V0aWxzL2FzeW5jVXRpbHNcIjtcclxuaW1wb3J0IHsgYmFja2VuZFBvcnQgfSBmcm9tIFwiLi4vdXRpbHMvcG9ydFV0aWxzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgdHJhbnNhY3Rpb25EZXRhaWxNYWNoaW5lID0gZGF0YU1hY2hpbmUoXCJ0cmFuc2FjdGlvbkRhdGFcIikud2l0aENvbmZpZyh7XHJcbiAgc2VydmljZXM6IHtcclxuICAgIGZldGNoRGF0YTogYXN5bmMgKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0gb21pdChcInR5cGVcIiwgZXZlbnQpO1xyXG4gICAgICBjb25zdCBjb250ZXh0VHJhbnNhY3Rpb25JZCA9ICFpc0VtcHR5KGN0eC5yZXN1bHRzKSAmJiBmaXJzdChjdHgucmVzdWx0cylbXCJpZFwiXTtcclxuICAgICAgY29uc3QgdHJhbnNhY3Rpb25JZCA9IGNvbnRleHRUcmFuc2FjdGlvbklkIHx8IHBheWxvYWQudHJhbnNhY3Rpb25JZDtcclxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQuZ2V0KFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L3RyYW5zYWN0aW9ucy8ke3RyYW5zYWN0aW9uSWR9YFxyXG4gICAgICApO1xyXG4gICAgICAvLyBAdHMtaWdub3JlXHJcbiAgICAgIHJldHVybiB7IHJlc3VsdHM6IFtyZXNwLmRhdGEudHJhbnNhY3Rpb25dIH07XHJcbiAgICB9LFxyXG4gICAgY3JlYXRlRGF0YTogYXN5bmMgKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICBsZXQgcm91dGUgPSBldmVudC5lbnRpdHkgPT09IFwiTElLRVwiID8gXCJsaWtlc1wiIDogXCJjb21tZW50c1wiO1xyXG4gICAgICBjb25zdCBwYXlsb2FkID0gZmxvdyhvbWl0KFwidHlwZVwiKSwgb21pdChcImVudGl0eVwiKSkoZXZlbnQpO1xyXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgaHR0cENsaWVudC5wb3N0KFxyXG4gICAgICAgIGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9LyR7cm91dGV9LyR7cGF5bG9hZC50cmFuc2FjdGlvbklkfWAsXHJcbiAgICAgICAgcGF5bG9hZFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgfSxcclxuICAgIHVwZGF0ZURhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgY29uc3QgY29udGV4dFRyYW5zYWN0aW9uSWQgPSAhaXNFbXB0eShjdHgucmVzdWx0cykgJiYgZmlyc3QoY3R4LnJlc3VsdHMpW1wiaWRcIl07XHJcbiAgICAgIGNvbnN0IHRyYW5zYWN0aW9uSWQgPSBjb250ZXh0VHJhbnNhY3Rpb25JZCB8fCBwYXlsb2FkLmlkO1xyXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgaHR0cENsaWVudC5wYXRjaChcclxuICAgICAgICBgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS90cmFuc2FjdGlvbnMvJHt0cmFuc2FjdGlvbklkfWAsXHJcbiAgICAgICAgcGF5bG9hZFxyXG4gICAgICApO1xyXG4gICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgfSxcclxuICB9LFxyXG59KTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLE1BQU0sTUFBTSxPQUFPLGVBQWU7QUFDM0MsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxtQkFBbUI7QUFFckIsYUFBTSwyQkFBMkIsWUFBWSxpQkFBaUIsRUFBRSxXQUFXO0FBQUEsRUFDaEYsVUFBVTtBQUFBLElBQ1IsV0FBVyxPQUFPLEtBQUssVUFBZTtBQUNwQyxZQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsWUFBTSx1QkFBdUIsQ0FBQyxRQUFRLElBQUksT0FBTyxLQUFLLE1BQU0sSUFBSSxPQUFPLEVBQUUsSUFBSTtBQUM3RSxZQUFNLGdCQUFnQix3QkFBd0IsUUFBUTtBQUN0RCxZQUFNLE9BQU8sTUFBTSxXQUFXO0FBQUEsUUFDNUIsb0JBQW9CLFdBQVcsaUJBQWlCLGFBQWE7QUFBQSxNQUMvRDtBQUVBLGFBQU8sRUFBRSxTQUFTLENBQUMsS0FBSyxLQUFLLFdBQVcsRUFBRTtBQUFBLElBQzVDO0FBQUEsSUFDQSxZQUFZLE9BQU8sS0FBSyxVQUFlO0FBQ3JDLFVBQUksUUFBUSxNQUFNLFdBQVcsU0FBUyxVQUFVO0FBQ2hELFlBQU0sVUFBVSxLQUFLLEtBQUssTUFBTSxHQUFHLEtBQUssUUFBUSxDQUFDLEVBQUUsS0FBSztBQUN4RCxZQUFNLE9BQU8sTUFBTSxXQUFXO0FBQUEsUUFDNUIsb0JBQW9CLFdBQVcsSUFBSSxLQUFLLElBQUksUUFBUSxhQUFhO0FBQUEsUUFDakU7QUFBQSxNQUNGO0FBQ0EsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUFBLElBQ0EsWUFBWSxPQUFPLEtBQUssVUFBZTtBQUNyQyxZQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsWUFBTSx1QkFBdUIsQ0FBQyxRQUFRLElBQUksT0FBTyxLQUFLLE1BQU0sSUFBSSxPQUFPLEVBQUUsSUFBSTtBQUM3RSxZQUFNLGdCQUFnQix3QkFBd0IsUUFBUTtBQUN0RCxZQUFNLE9BQU8sTUFBTSxXQUFXO0FBQUEsUUFDNUIsb0JBQW9CLFdBQVcsaUJBQWlCLGFBQWE7QUFBQSxRQUM3RDtBQUFBLE1BQ0Y7QUFDQSxhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsRUFDRjtBQUNGLENBQUM7IiwibmFtZXMiOltdfQ==