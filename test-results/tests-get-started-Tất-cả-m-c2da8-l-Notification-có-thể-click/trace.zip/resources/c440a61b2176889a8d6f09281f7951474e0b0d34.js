import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommentForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { TextField } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
const validationSchema = object({
  content: string()
});
const PREFIX = "CommentForm";
const classes = {
  paper: `${PREFIX}-paper`,
  form: `${PREFIX}-form`
};
const Root = styled("div")(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.form}`]: {
    width: "100%",
    // Fix IE 11 issue.
    marginTop: theme.spacing(1)
  }
}));
_c = Root;
const CommentForm = ({ transactionId, transactionComment }) => {
  const initialValues = { content: "" };
  return /* @__PURE__ */ jsxDEV(Root, { children: /* @__PURE__ */ jsxDEV(
    Formik,
    {
      initialValues,
      validationSchema,
      onSubmit: (values, { setSubmitting }) => {
        setSubmitting(true);
        transactionComment({ transactionId, ...values });
      },
      children: () => /* @__PURE__ */ jsxDEV(Form, { className: classes.form, children: /* @__PURE__ */ jsxDEV(Field, { name: "content", children: ({ field, meta }) => /* @__PURE__ */ jsxDEV(
        TextField,
        {
          variant: "outlined",
          margin: "dense",
          fullWidth: true,
          id: `transaction-comment-input-${transactionId}`,
          type: "text",
          placeholder: "Write a comment...",
          inputProps: { "data-test": `transaction-comment-input-${transactionId}` },
          error: meta.touched && Boolean(meta.error),
          helperText: meta.touched ? meta.error : "",
          ...field
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx",
          lineNumber: 54,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx",
        lineNumber: 52,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx",
        lineNumber: 51,
        columnNumber: 9
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx",
      lineNumber: 42,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx",
    lineNumber: 41,
    columnNumber: 5
  }, this);
};
_c2 = CommentForm;
export default CommentForm;
var _c, _c2;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "CommentForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcURnQjtBQXJEaEIsT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLGlCQUFpQjtBQUMxQixTQUFTQyxRQUFRQyxNQUFNQyxhQUF5QjtBQUNoRCxTQUFTQyxRQUFRQyxjQUFjO0FBRS9CLE1BQU1DLG1CQUFtQkQsT0FBTztBQUFBLEVBQzlCRSxTQUFTSCxPQUFPO0FBQ2xCLENBQUM7QUFFRCxNQUFNSSxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE9BQU8sR0FBR0YsTUFBTTtBQUFBLEVBQ2hCRyxNQUFNLEdBQUdILE1BQU07QUFDakI7QUFFQSxNQUFNSSxPQUFPYixPQUFPLEtBQUssRUFBRSxDQUFDLEVBQUVjLE1BQU0sT0FBTztBQUFBLEVBQ3pDLENBQUMsTUFBTUosUUFBUUMsS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN2QkksV0FBV0QsTUFBTUUsUUFBUSxDQUFDO0FBQUEsSUFDMUJDLFNBQVM7QUFBQSxJQUNUQyxlQUFlO0FBQUEsSUFDZkMsWUFBWTtBQUFBLEVBQ2Q7QUFBQSxFQUVBLENBQUMsTUFBTVQsUUFBUUUsSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUN0QlEsT0FBTztBQUFBO0FBQUEsSUFDUEwsV0FBV0QsTUFBTUUsUUFBUSxDQUFDO0FBQUEsRUFDNUI7QUFDRixFQUFFO0FBQUVLLEtBWkVSO0FBbUJOLE1BQU1TLGNBQTBDQSxDQUFDLEVBQUVDLGVBQWVDLG1CQUFtQixNQUFNO0FBQ3pGLFFBQU1DLGdCQUFnQixFQUFFakIsU0FBUyxHQUFHO0FBRXBDLFNBQ0UsdUJBQUMsUUFDQztBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVLENBQUNrQixRQUFRLEVBQUVDLGNBQWMsTUFBTTtBQUN2Q0Esc0JBQWMsSUFBSTtBQUNsQkgsMkJBQW1CLEVBQUVELGVBQWUsR0FBR0csT0FBTyxDQUFDO0FBQUEsTUFDakQ7QUFBQSxNQUVDLGdCQUNDLHVCQUFDLFFBQUssV0FBV2hCLFFBQVFFLE1BQ3ZCLGlDQUFDLFNBQU0sTUFBSyxXQUNULFdBQUMsRUFBRWdCLE9BQU9DLEtBQWlCLE1BQzFCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixRQUFPO0FBQUEsVUFDUDtBQUFBLFVBQ0EsSUFBSSw2QkFBNkJOLGFBQWE7QUFBQSxVQUM5QyxNQUFLO0FBQUEsVUFDTCxhQUFZO0FBQUEsVUFDWixZQUFZLEVBQUUsYUFBYSw2QkFBNkJBLGFBQWEsR0FBRztBQUFBLFVBQ3hFLE9BQU9NLEtBQUtDLFdBQVdDLFFBQVFGLEtBQUtHLEtBQUs7QUFBQSxVQUN6QyxZQUFZSCxLQUFLQyxVQUFVRCxLQUFLRyxRQUFRO0FBQUEsVUFDeEMsR0FBSUo7QUFBQUE7QUFBQUEsUUFWTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFVWSxLQVpoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBZUEsS0FoQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWlCQTtBQUFBO0FBQUEsSUExQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBNEJBLEtBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSjtBQUFFSyxNQXBDSVg7QUFzQ04sZUFBZUE7QUFBWSxJQUFBRCxJQUFBWTtBQUFBQyxhQUFBYixJQUFBO0FBQUFhLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJSZWFjdCIsInN0eWxlZCIsIlRleHRGaWVsZCIsIkZvcm1payIsIkZvcm0iLCJGaWVsZCIsInN0cmluZyIsIm9iamVjdCIsInZhbGlkYXRpb25TY2hlbWEiLCJjb250ZW50IiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwiZm9ybSIsIlJvb3QiLCJ0aGVtZSIsIm1hcmdpblRvcCIsInNwYWNpbmciLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJ3aWR0aCIsIl9jIiwiQ29tbWVudEZvcm0iLCJ0cmFuc2FjdGlvbklkIiwidHJhbnNhY3Rpb25Db21tZW50IiwiaW5pdGlhbFZhbHVlcyIsInZhbHVlcyIsInNldFN1Ym1pdHRpbmciLCJmaWVsZCIsIm1ldGEiLCJ0b3VjaGVkIiwiQm9vbGVhbiIsImVycm9yIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29tbWVudEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IFRleHRGaWVsZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IEZvcm1paywgRm9ybSwgRmllbGQsIEZpZWxkUHJvcHMgfSBmcm9tIFwiZm9ybWlrXCI7XHJcbmltcG9ydCB7IHN0cmluZywgb2JqZWN0IH0gZnJvbSBcInl1cFwiO1xyXG5cclxuY29uc3QgdmFsaWRhdGlvblNjaGVtYSA9IG9iamVjdCh7XHJcbiAgY29udGVudDogc3RyaW5nKCksXHJcbn0pO1xyXG5cclxuY29uc3QgUFJFRklYID0gXCJDb21tZW50Rm9ybVwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwYXBlcjogYCR7UFJFRklYfS1wYXBlcmAsXHJcbiAgZm9ybTogYCR7UFJFRklYfS1mb3JtYCxcclxufTtcclxuXHJcbmNvbnN0IFJvb3QgPSBzdHlsZWQoXCJkaXZcIikoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYgLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDgpLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5mb3JtfWBdOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsIC8vIEZpeCBJRSAxMSBpc3N1ZS5cclxuICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZygxKSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIENvbW1lbnRGb3JtUHJvcHMge1xyXG4gIHRyYW5zYWN0aW9uSWQ6IHN0cmluZztcclxuICB0cmFuc2FjdGlvbkNvbW1lbnQ6IChwYXlsb2FkOiBvYmplY3QpID0+IHZvaWQ7XHJcbn1cclxuXHJcbmNvbnN0IENvbW1lbnRGb3JtOiBSZWFjdC5GQzxDb21tZW50Rm9ybVByb3BzPiA9ICh7IHRyYW5zYWN0aW9uSWQsIHRyYW5zYWN0aW9uQ29tbWVudCB9KSA9PiB7XHJcbiAgY29uc3QgaW5pdGlhbFZhbHVlcyA9IHsgY29udGVudDogXCJcIiB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFJvb3Q+XHJcbiAgICAgIDxGb3JtaWtcclxuICAgICAgICBpbml0aWFsVmFsdWVzPXtpbml0aWFsVmFsdWVzfVxyXG4gICAgICAgIHZhbGlkYXRpb25TY2hlbWE9e3ZhbGlkYXRpb25TY2hlbWF9XHJcbiAgICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHsgc2V0U3VibWl0dGluZyB9KSA9PiB7XHJcbiAgICAgICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xyXG4gICAgICAgICAgdHJhbnNhY3Rpb25Db21tZW50KHsgdHJhbnNhY3Rpb25JZCwgLi4udmFsdWVzIH0pO1xyXG4gICAgICAgIH19XHJcbiAgICAgID5cclxuICAgICAgICB7KCkgPT4gKFxyXG4gICAgICAgICAgPEZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19PlxyXG4gICAgICAgICAgICA8RmllbGQgbmFtZT1cImNvbnRlbnRcIj5cclxuICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGEgfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICBpZD17YHRyYW5zYWN0aW9uLWNvbW1lbnQtaW5wdXQtJHt0cmFuc2FjdGlvbklkfWB9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXcml0ZSBhIGNvbW1lbnQuLi5cIlxyXG4gICAgICAgICAgICAgICAgICBpbnB1dFByb3BzPXt7IFwiZGF0YS10ZXN0XCI6IGB0cmFuc2FjdGlvbi1jb21tZW50LWlucHV0LSR7dHJhbnNhY3Rpb25JZH1gIH19XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXttZXRhLnRvdWNoZWQgJiYgQm9vbGVhbihtZXRhLmVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17bWV0YS50b3VjaGVkID8gbWV0YS5lcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHsuLi5maWVsZH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICApfVxyXG4gICAgICA8L0Zvcm1paz5cclxuICAgIDwvUm9vdD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29tbWVudEZvcm07XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvQ29tbWVudEZvcm0udHN4In0=