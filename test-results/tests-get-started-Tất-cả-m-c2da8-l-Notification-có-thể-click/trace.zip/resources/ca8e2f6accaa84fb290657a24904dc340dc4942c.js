import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SvgUndrawTransferMoneyRywa.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function SvgUndrawTransferMoneyRywa(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      "data-name": "Layer 1",
      xmlns: "http://www.w3.org/2000/svg",
      width: "1099",
      height: "797.68034",
      viewBox: "0 0 1099 797.68",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 471, cy: 373, r: 373, fill: "#f2f2f2" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 13,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("ellipse", { cx: 148, cy: 774, rx: 148, ry: 23.68, fill: "#f2f2f2" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 14,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("ellipse", { cx: 870, cy: 736.969, rx: 229, ry: 36.64, fill: "#f2f2f2" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 15,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M819.12 384.785s1.95 6.498-9.098 12.347-14.297 27.945-1.3 34.444 16.897 14.947 10.398 20.796-18.196 21.446-2.6 25.345 17.547 11.698 12.998 14.947 10.398-5.849 10.398-5.849 2.6 15.597 16.247 11.698 51.99-77.985 32.494-88.383-69.537-25.345-69.537-25.345z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 16,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M842.675 447.537s6.741 23.594-5.056 25.28a46.052 46.052 0 00-20.223 8.426l21.908 28.65h40.448l25.28-25.28s-33.707-25.28-26.966-40.447-35.39 3.37-35.39 3.37z",
            fill: "#ffb9b9"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 20,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M842.675 447.537s6.741 23.594-5.056 25.28a46.052 46.052 0 00-20.223 8.426l21.908 28.65h40.448l25.28-25.28s-33.707-25.28-26.966-40.447-35.39 3.37-35.39 3.37z",
            opacity: 0.1
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 24,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#ffb9b9",
            d: "M852.787 740.779l38.762 13.482 26.964 1.685-1.685-23.594-55.615-16.448-8.426 24.875z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 28,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M902.503 735.723s0 23.594 3.37 23.594 48.874-5.056 62.357 0 33.706-13.483 23.594-23.594-26.606-25.28-36.897-21.91-52.424 11.798-52.424 11.798zM778.634 713.814s-20.224 40.447-6.741 43.818 28.65-1.686 30.335-3.371 25.28-8.427 28.65-5.056 3.37-13.482 3.37-13.482z",
            fill: "#575a89"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 32,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M795.487 658.199s-32.02 43.818-8.427 55.615 136.51 11.797 144.936 0 11.797-48.874 0-52.244-136.51-3.371-136.51-3.371z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 36,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M795.487 658.199s-32.02 43.818-8.427 55.615 136.51 11.797 144.936 0 11.797-48.874 0-52.244-136.51-3.371-136.51-3.371z",
            opacity: 0.2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 40,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 856.157, cy: 420.572, r: 38.762, fill: "#ffb9b9" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 44,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M795.487 481.243l33.706-6.741s8.426 26.964 35.39 21.909 33.707-21.91 33.707-21.91 20.223 8.427 21.909 8.427 23.594 8.427 23.594 13.483-25.28 55.614-25.28 55.614l3.371 91.006-124.712-3.37 8.427-89.321z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 45,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M776.949 525.06s-10.112 89.321-3.371 96.062 33.706 25.28 33.706 25.28v-20.224l-13.483-25.28 13.483-58.984zM951.377 522.533s-5.899 91.848-5.899 95.219-15.167 15.168-20.223 15.168-8.427-8.427-8.427-8.427l11.797-13.482-8.426-69.097z",
            fill: "#ffb9b9"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 49,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M935.366 651.458s75.839-42.133 77.524 0-38.762 58.985-38.762 58.985-104.488 31.332-108.701 19.88-12.64-29.992-5.899-31.677 15.168-5.056 18.538-1.685 45.503-25.28 45.503-25.28z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 53,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M970.758 646.402s-15.168 6.741-20.224 11.797-26.965 13.482-26.965 13.482",
            fill: "none",
            stroke: "#000",
            strokeMiterlimit: 10,
            strokeWidth: 2,
            opacity: 0.2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 57,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M805.599 484.613l-10.112-3.37s-37.077 38.762-25.28 48.873 18.539 13.483 21.91 16.853 20.223 5.056 20.223 5.056zM928.625 493.04l15.168 3.37s11.797 25.28 15.168 28.65-5.056 1.686-10.112 8.427-10.112 18.538-20.224 18.538-23.594-16.853-23.594-16.853z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 65,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M798.857 666.625s-64.04-45.503-85.95-11.797 94.377 79.21 111.23 85.95 32.02 13.483 32.02 13.483 15.168-37.077 15.168-43.818-11.797-6.741-15.168-6.741-18.538-3.37-21.908-8.426-35.392-28.65-35.392-28.65z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 69,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M763.466 654.828s16.853 13.483 32.02 16.853 20.224 11.797 20.224 11.797",
            fill: "none",
            stroke: "#000",
            strokeMiterlimit: 10,
            strokeWidth: 2,
            opacity: 0.2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 73,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M787.232 591.462l1.346 71.356a8.933 8.933 0 009.032 8.764l132.79-1.492a8.933 8.933 0 008.817-8.418l4.03-69.864a8.933 8.933 0 00-8.917-9.447H796.163a8.933 8.933 0 00-8.931 9.1z",
            fill: "#575a89"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 81,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M858.228 371.88s2.16 7.2-10.079 13.679-15.838 30.957-1.44 38.156 18.719 16.559 11.52 23.038-20.159 23.758-2.88 28.077 19.438 12.96 14.398 16.559 11.52-6.48 11.52-6.48 2.879 17.279 17.998 12.96 30.203-82.84 13.35-103.064c-15.67-18.805-54.387-22.925-54.387-22.925z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 85,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M853.63 364.47c.003-10.548 31.558-2.97 45.088 11.757 9.368 10.198 23.598 25.54 11.674 36.356s20.44 24.992 29.119 29.29 25.817 17.443 10.343 26.261-15.224 17.72-9.4 19.828-12.84-3.134-12.84-3.134 1.885 17.415-13.838 17.332-60.832-86.495-50.056-110.513c10.02-22.333-10.09-27.178-10.09-27.178z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 89,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M860.465 362.158c-42.198-2.541-46.433 29.223-46.433 29.223.291 18.382 29.482 9.425 37.59 12.165 9.781-7.036 28.636-20.35 42.12-29.851a63.774 63.774 0 00-33.277-11.537z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 93,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M848.442 564.849S810.59 387.449 573.67 258.76",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 97,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M583.431 254.891l.474 1.945-9.583 2.324 3.019 9.389-1.906.611-3.675-11.436 11.671-2.833z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 104,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M68.473 746.111c0 22.47-13.356 30.314-29.834 30.314q-.572 0-1.143-.012a48.69 48.69 0 01-2.267-.104c-14.87-1.053-26.423-9.301-26.423-30.198 0-21.625 27.634-48.912 29.71-50.931l.003-.004.12-.116s29.834 28.583 29.834 51.051z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 108,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M37.552 772.988l10.912-15.247-10.939 16.921-.029 1.75a48.69 48.69 0 01-2.267-.103l1.177-22.48-.01-.174.02-.033.111-2.123-10.966-16.963 11 15.37.026.452.89-16.985-9.39-17.528 9.504 14.547.925-35.212.003-.12v.116l-.154 27.767 9.347-11.008-9.385 13.4-.247 15.207 8.726-14.594-8.763 16.832-.138 8.454 12.67-20.313-12.717 23.263z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 112,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M210.773 740.29l6.382-4.74s4.224 23.596-.49 27.131-22.39 9.428-22.39 16.499-40.068 16.498-41.246 5.892 3.535-16.498 3.535-16.498 18.855-18.856 21.212-22.391 8.25-10.606 8.25-10.606z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 116,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M116.496 446.854s.177 1.037.483 2.934c.283 1.685.672 4.066 1.144 7 4.95 30.204 19.385 119.119 18.407 122.053-1.178 3.536-9.427 16.499 0 20.034.908.342 1.886 1.45 2.935 3.194a68.494 68.494 0 014.984 11.76c5.622 16.31 11.632 42.414 15.108 60.491 1.52 7.943 2.558 14.33 2.864 17.677a9.612 9.612 0 01.035 2.334c-1.178 4.713 7.071 21.212 10.606 25.926s9.428 9.427 8.25 14.141 29.461 17.677 32.997 9.428 3.535-12.963 4.713-15.32 2.357-18.856-3.535-21.212-2.357-43.603-8.25-51.853c-1.967-2.746-4.972-12.044-8.119-23.227a764.882 764.882 0 01-3.712-13.73c-4.973-19.173-9.38-38.464-9.38-38.464l1.178-137.88-64.815-8.25-1.662 3.666-3.311 7.27zM112.961 673.118s-9.428-9.428-14.142 0-9.427 45.96-17.676 54.21-18.856 49.495-7.071 51.852 24.747-3.536 25.926-10.606 25.926-43.604 25.926-47.139-16.498-16.498-16.498-16.498z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 120,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M257.912 382.038s-15.32 137.88-18.856 150.843-22.39 62.459-28.283 70.708-43.603 75.421-48.317 78.957-14.141 12.963-14.141 12.963-17.677 17.677-20.034 21.212-22.39-7.07-23.57-14.141 1.18-18.856 2.358-23.57-2.357-11.784 1.178-15.32 21.212-21.212 21.212-29.461 30.64-56.566 42.425-67.172 9.428-28.283 9.428-28.283v-71.886l-64.816-20.034s3.536-56.566 11.785-56.566 116.668-18.856 129.63-8.25z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 124,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 162.456, cy: 146.346, r: 38.889, fill: "#9f616a" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 128,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M175.42 176.986s4.713 17.677 10.606 22.39-15.32 24.749-15.32 24.749l-40.068 2.356-7.07-22.39s12.962-25.926 9.427-42.425 42.424 15.32 42.424 15.32z",
            fill: "#9f616a"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 129,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M191.918 197.02s-10.606 1.178-12.963 4.714-18.856 14.141-31.819 11.784-21.212-5.892-23.569-4.713-7.07 25.926-7.07 25.926l12.962 37.71-2.356 103.705-3.536 28.283s-7.07-9.428 21.212-3.535 64.816-4.714 76.6-5.893 31.819-4.713 32.997-11.784-3.535-32.997-3.535-32.997l-18.855-78.957-11.785-42.425z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 133,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M180.77 191.701s9.97-5.287 13.505-.573 48.317 11.784 48.317 15.32 9.427 98.99 7.07 107.24 4.714 17.677 4.714 17.677l8.25 35.353s22.39 67.173 12.963 69.53-17.677 0-21.213 0-2.357-44.782-11.784-56.567-22.391-41.246-24.748-47.138-31.818-87.206-30.64-96.634-6.433-44.208-6.433-44.208zM131.816 197.02s-9.427 0-10.606 2.357-12.963 17.677-17.677 21.212-21.212 18.856-21.212 22.39 34.175 29.462 34.175 29.462 14.142 69.53 7.071 93.099-17.677 80.135-12.963 83.67 15.32 4.714 15.32 0 7.07-55.387 12.963-65.993 23.57-77.779 16.499-96.634-23.57-89.563-23.57-89.563z",
            fill: "#d0cde1"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 137,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M287.373 313.688s1.179 36.532-11.784 55.387-21.213 40.068-21.213 40.068-21.212-5.892-24.747-12.963-25.927-1.179-25.927-3.536 27.105-14.141 29.462-16.498 10.606-2.357 15.32-7.07 5.892-15.32 5.892-15.32l4.714-30.64z",
            fill: "#9f616a"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 141,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M189.241 122.368c2.992-.272 6.078-.571 8.722-1.997 5.924-3.195 7.495-12.294 2.985-17.29a22.344 22.344 0 00-4.143-3.332l-8.958-6.097c-3.962-2.697-8.017-5.438-12.638-6.709-4.18-1.15-8.594-1.032-12.92-.763-8.399.522-16.85 1.6-24.749 4.5s-15.268 7.751-20.052 14.674c-7.585 10.974-7.689 25.775-3.512 38.444s12.113 23.701 19.932 34.51l4.056-19.795c.362-1.763.83-3.696 2.295-4.739 3.645-2.593 8.103 2.731 12.576 2.697 2.874-.022 5.287-2.386 6.376-5.046s1.161-5.605 1.413-8.468c.534-6.065 2.654-14.502 8.396-17.847 5.352-3.116 14.206-2.196 20.221-2.742z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 145,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { d: "M187.06 447.805s-3.98 115.127-6.338 118.662 0-119.024 0-119.024z", opacity: 0.1 }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 149,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M233.164 206.448h9.428s40.067 54.209 35.354 57.744 0 12.963 0 12.963l9.427 17.677s11.785 10.606 8.25 12.963-8.25 11.785-8.25 11.785-23.569-3.535-30.64 10.606L241.45 310.89z",
            fill: "#d0cde1"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 150,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { fill: "#2f2e41", d: "M204.145 237.243l32.35-13.36 24.895 60.287-32.35 13.359z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 154,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 280.75,
            cy: 304.458,
            rx: 7,
            ry: 6.431,
            transform: "rotate(-22.438 126.536 406.18)",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 155,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M209.595 300.725s-84.85 70.707-98.99 48.316 15.32-41.246 15.32-41.246 25.925 1.179 55.387-17.677l29.461-12.963s26.896-38.399 36.062-23.777-15.645 40.07-37.24 47.347z",
            fill: "#9f616a"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 163,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M95.284 238.266l-12.963 4.714v35.354l-4.714 7.07s1.179 14.142 4.714 17.677 10.606 2.357 8.25 10.607a44.667 44.667 0 00-1.18 16.498s21.213 27.105 22.392 23.57 17.676-47.14 20.033-47.14-23.569-68.35-23.569-68.35z",
            fill: "#d0cde1"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 167,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M250.252 416.803s12.185-11.785 6.092-12.374-27.305-12.374-30.84-6.481 24.748 18.855 24.748 18.855z",
            fill: "#2f2e41"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 171,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("ellipse", { cx: 482, cy: 183, rx: 17, ry: 9, fill: "#57b894" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
          lineNumber: 175,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M547 213q-57.5-21.716-115 0v-47a199.038 199.038 0 01115 0z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 176,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M531 203.28q-41.5-15.673-83 0V169.36a143.653 143.653 0 0183 0z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 183,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 488,
            cy: 179,
            rx: 17,
            ry: 9,
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 190,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 543.2,
            cy: 290.706,
            rx: 17,
            ry: 9,
            transform: "rotate(-11.535 264.702 515.108)",
            fill: "#57b894"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 200,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M562.386 255.941q-60.68-9.779-112.677 22.997l-9.398-46.05a199.038 199.038 0 01112.677-22.997z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 208,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M544.766 249.617q-43.796-7.058-81.323 16.598l-6.784-33.236a143.653 143.653 0 0181.323-16.598z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 215,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 548.279,
            cy: 285.587,
            rx: 17,
            ry: 9,
            transform: "rotate(-11.535 269.781 509.989)",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 222,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 539.675,
            cy: 346.645,
            rx: 9,
            ry: 17,
            transform: "rotate(-86.019 487.003 348.133)",
            fill: "#57b894"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 233,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M551.935 329.925q-55.853-25.656-114.722-7.983l3.262-46.887a199.038 199.038 0 01114.723 7.983z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 241,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M536.649 319.118q-40.312-18.517-82.8-5.762l2.355-33.84a143.653 143.653 0 0182.8 5.762z",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 248,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "ellipse",
          {
            cx: 545.938,
            cy: 343.071,
            rx: 9,
            ry: 17,
            transform: "rotate(-86.019 493.266 344.56)",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 255,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M414.922 214.092s-73.496-10.055-125.982 20.703",
            fill: "none",
            stroke: "#3f3d56",
            strokeMiterlimit: 10,
            strokeWidth: 2
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 266,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M290.708 224.459l1.909.604-2.984 9.399 9.594 2.289-.467 1.947-11.683-2.791 3.631-11.448z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
            lineNumber: 273,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = SvgUndrawTransferMoneyRywa;
export default SvgUndrawTransferMoneyRywa;
var _c;
$RefreshReg$(_c, "SvgUndrawTransferMoneyRywa");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawTransferMoneyRywa.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFOUIsU0FBU0EsMkJBQTJCQyxPQUFZO0FBQzlDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLEdBQUlBO0FBQUFBLE1BRUo7QUFBQSwrQkFBQyxZQUFPLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRyxLQUFLLE1BQUssYUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFnRDtBQUFBLFFBQ2hELHVCQUFDLGFBQVEsSUFBSSxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssSUFBSSxPQUFPLE1BQUssYUFBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE2RDtBQUFBLFFBQzdELHVCQUFDLGFBQVEsSUFBSSxLQUFLLElBQUksU0FBUyxJQUFJLEtBQUssSUFBSSxPQUFPLE1BQUssYUFBeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpRTtBQUFBLFFBQ2pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixTQUFTO0FBQUE7QUFBQSxVQUZYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVlO0FBQUEsUUFFZjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFMEY7QUFBQSxRQUUxRjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsU0FBUztBQUFBO0FBQUEsVUFGWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZTtBQUFBLFFBRWYsdUJBQUMsWUFBTyxJQUFJLFNBQVMsSUFBSSxTQUFTLEdBQUcsUUFBUSxNQUFLLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBLFlBQ0wsUUFBTztBQUFBLFlBQ1Asa0JBQWtCO0FBQUEsWUFDbEIsYUFBYTtBQUFBLFlBQ2IsU0FBUztBQUFBO0FBQUEsVUFOWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFNZTtBQUFBLFFBRWY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQSxZQUNiLFNBQVM7QUFBQTtBQUFBLFVBTlg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWU7QUFBQSxRQUVmO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUEsWUFDTCxRQUFPO0FBQUEsWUFDUCxrQkFBa0I7QUFBQSxZQUNsQixhQUFhO0FBQUE7QUFBQSxVQUxmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtpQjtBQUFBLFFBRWpCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUU4RjtBQUFBLFFBRTlGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCLHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0Q7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsVUFBSyxHQUFFLG9FQUFtRSxTQUFTLE9BQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBd0Y7QUFBQSxRQUN4RjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQix1QkFBQyxVQUFLLE1BQUssV0FBVSxHQUFFLDhEQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlGO0FBQUEsUUFDakY7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQTtBQUFBLFVBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsYUFBUSxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUksSUFBSSxJQUFJLEdBQUcsTUFBSyxhQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXdEO0FBQUEsUUFDeEQ7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBUmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBUWlCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQTtBQUFBLFVBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBVGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQTtBQUFBLFVBTlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBTWdCO0FBQUEsUUFFaEI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLElBQUk7QUFBQSxZQUNKLFdBQVU7QUFBQSxZQUNWLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBVGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBU2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQSxZQUNMLFFBQU87QUFBQSxZQUNQLGtCQUFrQjtBQUFBLFlBQ2xCLGFBQWE7QUFBQTtBQUFBLFVBTGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBS2lCO0FBQUEsUUFFakI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE1BQUs7QUFBQSxZQUNMLEdBQUU7QUFBQTtBQUFBLFVBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRThGO0FBQUE7QUFBQTtBQUFBLElBOVFoRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFnUkE7QUFFSjtBQUFDQyxLQXBSUUY7QUFzUlQsZUFBZUE7QUFBMkIsSUFBQUU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlN2Z1VuZHJhd1RyYW5zZmVyTW9uZXlSeXdhIiwicHJvcHMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN2Z1VuZHJhd1RyYW5zZmVyTW9uZXlSeXdhLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgKiBhcyBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmZ1bmN0aW9uIFN2Z1VuZHJhd1RyYW5zZmVyTW9uZXlSeXdhKHByb3BzOiBhbnkpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPHN2Z1xyXG4gICAgICBkYXRhLW5hbWU9XCJMYXllciAxXCJcclxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgIHdpZHRoPVwiMTA5OVwiXHJcbiAgICAgIGhlaWdodD1cIjc5Ny42ODAzNFwiXHJcbiAgICAgIHZpZXdCb3g9XCIwIDAgMTA5OSA3OTcuNjhcIlxyXG4gICAgICB7Li4ucHJvcHN9XHJcbiAgICA+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezQ3MX0gY3k9ezM3M30gcj17MzczfSBmaWxsPVwiI2YyZjJmMlwiIC8+XHJcbiAgICAgIDxlbGxpcHNlIGN4PXsxNDh9IGN5PXs3NzR9IHJ4PXsxNDh9IHJ5PXsyMy42OH0gZmlsbD1cIiNmMmYyZjJcIiAvPlxyXG4gICAgICA8ZWxsaXBzZSBjeD17ODcwfSBjeT17NzM2Ljk2OX0gcng9ezIyOX0gcnk9ezM2LjY0fSBmaWxsPVwiI2YyZjJmMlwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk04MTkuMTIgMzg0Ljc4NXMxLjk1IDYuNDk4LTkuMDk4IDEyLjM0Ny0xNC4yOTcgMjcuOTQ1LTEuMyAzNC40NDQgMTYuODk3IDE0Ljk0NyAxMC4zOTggMjAuNzk2LTE4LjE5NiAyMS40NDYtMi42IDI1LjM0NSAxNy41NDcgMTEuNjk4IDEyLjk5OCAxNC45NDcgMTAuMzk4LTUuODQ5IDEwLjM5OC01Ljg0OSAyLjYgMTUuNTk3IDE2LjI0NyAxMS42OTggNTEuOTktNzcuOTg1IDMyLjQ5NC04OC4zODMtNjkuNTM3LTI1LjM0NS02OS41MzctMjUuMzQ1elwiXHJcbiAgICAgICAgZmlsbD1cIiMyZjJlNDFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNODQyLjY3NSA0NDcuNTM3czYuNzQxIDIzLjU5NC01LjA1NiAyNS4yOGE0Ni4wNTIgNDYuMDUyIDAgMDAtMjAuMjIzIDguNDI2bDIxLjkwOCAyOC42NWg0MC40NDhsMjUuMjgtMjUuMjhzLTMzLjcwNy0yNS4yOC0yNi45NjYtNDAuNDQ3LTM1LjM5IDMuMzctMzUuMzkgMy4zN3pcIlxyXG4gICAgICAgIGZpbGw9XCIjZmZiOWI5XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTg0Mi42NzUgNDQ3LjUzN3M2Ljc0MSAyMy41OTQtNS4wNTYgMjUuMjhhNDYuMDUyIDQ2LjA1MiAwIDAwLTIwLjIyMyA4LjQyNmwyMS45MDggMjguNjVoNDAuNDQ4bDI1LjI4LTI1LjI4cy0zMy43MDctMjUuMjgtMjYuOTY2LTQwLjQ0Ny0zNS4zOSAzLjM3LTM1LjM5IDMuMzd6XCJcclxuICAgICAgICBvcGFjaXR5PXswLjF9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiNmZmI5YjlcIlxyXG4gICAgICAgIGQ9XCJNODUyLjc4NyA3NDAuNzc5bDM4Ljc2MiAxMy40ODIgMjYuOTY0IDEuNjg1LTEuNjg1LTIzLjU5NC01NS42MTUtMTYuNDQ4LTguNDI2IDI0Ljg3NXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNOTAyLjUwMyA3MzUuNzIzczAgMjMuNTk0IDMuMzcgMjMuNTk0IDQ4Ljg3NC01LjA1NiA2Mi4zNTcgMCAzMy43MDYtMTMuNDgzIDIzLjU5NC0yMy41OTQtMjYuNjA2LTI1LjI4LTM2Ljg5Ny0yMS45MS01Mi40MjQgMTEuNzk4LTUyLjQyNCAxMS43OTh6TTc3OC42MzQgNzEzLjgxNHMtMjAuMjI0IDQwLjQ0Ny02Ljc0MSA0My44MTggMjguNjUtMS42ODYgMzAuMzM1LTMuMzcxIDI1LjI4LTguNDI3IDI4LjY1LTUuMDU2IDMuMzctMTMuNDgyIDMuMzctMTMuNDgyelwiXHJcbiAgICAgICAgZmlsbD1cIiM1NzVhODlcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNzk1LjQ4NyA2NTguMTk5cy0zMi4wMiA0My44MTgtOC40MjcgNTUuNjE1IDEzNi41MSAxMS43OTcgMTQ0LjkzNiAwIDExLjc5Ny00OC44NzQgMC01Mi4yNDQtMTM2LjUxLTMuMzcxLTEzNi41MS0zLjM3MXpcIlxyXG4gICAgICAgIGZpbGw9XCIjMmYyZTQxXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTc5NS40ODcgNjU4LjE5OXMtMzIuMDIgNDMuODE4LTguNDI3IDU1LjYxNSAxMzYuNTEgMTEuNzk3IDE0NC45MzYgMCAxMS43OTctNDguODc0IDAtNTIuMjQ0LTEzNi41MS0zLjM3MS0xMzYuNTEtMy4zNzF6XCJcclxuICAgICAgICBvcGFjaXR5PXswLjJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezg1Ni4xNTd9IGN5PXs0MjAuNTcyfSByPXszOC43NjJ9IGZpbGw9XCIjZmZiOWI5XCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTc5NS40ODcgNDgxLjI0M2wzMy43MDYtNi43NDFzOC40MjYgMjYuOTY0IDM1LjM5IDIxLjkwOSAzMy43MDctMjEuOTEgMzMuNzA3LTIxLjkxIDIwLjIyMyA4LjQyNyAyMS45MDkgOC40MjcgMjMuNTk0IDguNDI3IDIzLjU5NCAxMy40ODMtMjUuMjggNTUuNjE0LTI1LjI4IDU1LjYxNGwzLjM3MSA5MS4wMDYtMTI0LjcxMi0zLjM3IDguNDI3LTg5LjMyMXpcIlxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTc3Ni45NDkgNTI1LjA2cy0xMC4xMTIgODkuMzIxLTMuMzcxIDk2LjA2MiAzMy43MDYgMjUuMjggMzMuNzA2IDI1LjI4di0yMC4yMjRsLTEzLjQ4My0yNS4yOCAxMy40ODMtNTguOTg0ek05NTEuMzc3IDUyMi41MzNzLTUuODk5IDkxLjg0OC01Ljg5OSA5NS4yMTktMTUuMTY3IDE1LjE2OC0yMC4yMjMgMTUuMTY4LTguNDI3LTguNDI3LTguNDI3LTguNDI3bDExLjc5Ny0xMy40ODItOC40MjYtNjkuMDk3elwiXHJcbiAgICAgICAgZmlsbD1cIiNmZmI5YjlcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNOTM1LjM2NiA2NTEuNDU4czc1LjgzOS00Mi4xMzMgNzcuNTI0IDAtMzguNzYyIDU4Ljk4NS0zOC43NjIgNTguOTg1LTEwNC40ODggMzEuMzMyLTEwOC43MDEgMTkuODgtMTIuNjQtMjkuOTkyLTUuODk5LTMxLjY3NyAxNS4xNjgtNS4wNTYgMTguNTM4LTEuNjg1IDQ1LjUwMy0yNS4yOCA0NS41MDMtMjUuMjh6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk05NzAuNzU4IDY0Ni40MDJzLTE1LjE2OCA2Ljc0MS0yMC4yMjQgMTEuNzk3LTI2Ljk2NSAxMy40ODItMjYuOTY1IDEzLjQ4MlwiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cIiMwMDBcIlxyXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9ezEwfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgIG9wYWNpdHk9ezAuMn1cclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTgwNS41OTkgNDg0LjYxM2wtMTAuMTEyLTMuMzdzLTM3LjA3NyAzOC43NjItMjUuMjggNDguODczIDE4LjUzOSAxMy40ODMgMjEuOTEgMTYuODUzIDIwLjIyMyA1LjA1NiAyMC4yMjMgNS4wNTZ6TTkyOC42MjUgNDkzLjA0bDE1LjE2OCAzLjM3czExLjc5NyAyNS4yOCAxNS4xNjggMjguNjUtNS4wNTYgMS42ODYtMTAuMTEyIDguNDI3LTEwLjExMiAxOC41MzgtMjAuMjI0IDE4LjUzOC0yMy41OTQtMTYuODUzLTIzLjU5NC0xNi44NTN6XCJcclxuICAgICAgICBmaWxsPVwiIzNmNTFiNVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk03OTguODU3IDY2Ni42MjVzLTY0LjA0LTQ1LjUwMy04NS45NS0xMS43OTcgOTQuMzc3IDc5LjIxIDExMS4yMyA4NS45NSAzMi4wMiAxMy40ODMgMzIuMDIgMTMuNDgzIDE1LjE2OC0zNy4wNzcgMTUuMTY4LTQzLjgxOC0xMS43OTctNi43NDEtMTUuMTY4LTYuNzQxLTE4LjUzOC0zLjM3LTIxLjkwOC04LjQyNi0zNS4zOTItMjguNjUtMzUuMzkyLTI4LjY1elwiXHJcbiAgICAgICAgZmlsbD1cIiMyZjJlNDFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNzYzLjQ2NiA2NTQuODI4czE2Ljg1MyAxMy40ODMgMzIuMDIgMTYuODUzIDIwLjIyNCAxMS43OTcgMjAuMjI0IDExLjc5N1wiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cIiMwMDBcIlxyXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9ezEwfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAgIG9wYWNpdHk9ezAuMn1cclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTc4Ny4yMzIgNTkxLjQ2MmwxLjM0NiA3MS4zNTZhOC45MzMgOC45MzMgMCAwMDkuMDMyIDguNzY0bDEzMi43OS0xLjQ5MmE4LjkzMyA4LjkzMyAwIDAwOC44MTctOC40MThsNC4wMy02OS44NjRhOC45MzMgOC45MzMgMCAwMC04LjkxNy05LjQ0N0g3OTYuMTYzYTguOTMzIDguOTMzIDAgMDAtOC45MzEgOS4xelwiXHJcbiAgICAgICAgZmlsbD1cIiM1NzVhODlcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNODU4LjIyOCAzNzEuODhzMi4xNiA3LjItMTAuMDc5IDEzLjY3OS0xNS44MzggMzAuOTU3LTEuNDQgMzguMTU2IDE4LjcxOSAxNi41NTkgMTEuNTIgMjMuMDM4LTIwLjE1OSAyMy43NTgtMi44OCAyOC4wNzcgMTkuNDM4IDEyLjk2IDE0LjM5OCAxNi41NTkgMTEuNTItNi40OCAxMS41Mi02LjQ4IDIuODc5IDE3LjI3OSAxNy45OTggMTIuOTYgMzAuMjAzLTgyLjg0IDEzLjM1LTEwMy4wNjRjLTE1LjY3LTE4LjgwNS01NC4zODctMjIuOTI1LTU0LjM4Ny0yMi45MjV6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk04NTMuNjMgMzY0LjQ3Yy4wMDMtMTAuNTQ4IDMxLjU1OC0yLjk3IDQ1LjA4OCAxMS43NTcgOS4zNjggMTAuMTk4IDIzLjU5OCAyNS41NCAxMS42NzQgMzYuMzU2czIwLjQ0IDI0Ljk5MiAyOS4xMTkgMjkuMjkgMjUuODE3IDE3LjQ0MyAxMC4zNDMgMjYuMjYxLTE1LjIyNCAxNy43Mi05LjQgMTkuODI4LTEyLjg0LTMuMTM0LTEyLjg0LTMuMTM0IDEuODg1IDE3LjQxNS0xMy44MzggMTcuMzMyLTYwLjgzMi04Ni40OTUtNTAuMDU2LTExMC41MTNjMTAuMDItMjIuMzMzLTEwLjA5LTI3LjE3OC0xMC4wOS0yNy4xNzh6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk04NjAuNDY1IDM2Mi4xNThjLTQyLjE5OC0yLjU0MS00Ni40MzMgMjkuMjIzLTQ2LjQzMyAyOS4yMjMuMjkxIDE4LjM4MiAyOS40ODIgOS40MjUgMzcuNTkgMTIuMTY1IDkuNzgxLTcuMDM2IDI4LjYzNi0yMC4zNSA0Mi4xMi0yOS44NTFhNjMuNzc0IDYzLjc3NCAwIDAwLTMzLjI3Ny0xMS41Mzd6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk04NDguNDQyIDU2NC44NDlTODEwLjU5IDM4Ny40NDkgNTczLjY3IDI1OC43NlwiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cIiMzZjNkNTZcIlxyXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9ezEwfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjM2YzZDU2XCJcclxuICAgICAgICBkPVwiTTU4My40MzEgMjU0Ljg5MWwuNDc0IDEuOTQ1LTkuNTgzIDIuMzI0IDMuMDE5IDkuMzg5LTEuOTA2LjYxMS0zLjY3NS0xMS40MzYgMTEuNjcxLTIuODMzelwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk02OC40NzMgNzQ2LjExMWMwIDIyLjQ3LTEzLjM1NiAzMC4zMTQtMjkuODM0IDMwLjMxNHEtLjU3MiAwLTEuMTQzLS4wMTJhNDguNjkgNDguNjkgMCAwMS0yLjI2Ny0uMTA0Yy0xNC44Ny0xLjA1My0yNi40MjMtOS4zMDEtMjYuNDIzLTMwLjE5OCAwLTIxLjYyNSAyNy42MzQtNDguOTEyIDI5LjcxLTUwLjkzMWwuMDAzLS4wMDQuMTItLjExNnMyOS44MzQgMjguNTgzIDI5LjgzNCA1MS4wNTF6XCJcclxuICAgICAgICBmaWxsPVwiIzNmNTFiNVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0zNy41NTIgNzcyLjk4OGwxMC45MTItMTUuMjQ3LTEwLjkzOSAxNi45MjEtLjAyOSAxLjc1YTQ4LjY5IDQ4LjY5IDAgMDEtMi4yNjctLjEwM2wxLjE3Ny0yMi40OC0uMDEtLjE3NC4wMi0uMDMzLjExMS0yLjEyMy0xMC45NjYtMTYuOTYzIDExIDE1LjM3LjAyNi40NTIuODktMTYuOTg1LTkuMzktMTcuNTI4IDkuNTA0IDE0LjU0Ny45MjUtMzUuMjEyLjAwMy0uMTJ2LjExNmwtLjE1NCAyNy43NjcgOS4zNDctMTEuMDA4LTkuMzg1IDEzLjQtLjI0NyAxNS4yMDcgOC43MjYtMTQuNTk0LTguNzYzIDE2LjgzMi0uMTM4IDguNDU0IDEyLjY3LTIwLjMxMy0xMi43MTcgMjMuMjYzelwiXHJcbiAgICAgICAgZmlsbD1cIiMzZjNkNTZcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMjEwLjc3MyA3NDAuMjlsNi4zODItNC43NHM0LjIyNCAyMy41OTYtLjQ5IDI3LjEzMS0yMi4zOSA5LjQyOC0yMi4zOSAxNi40OTktNDAuMDY4IDE2LjQ5OC00MS4yNDYgNS44OTIgMy41MzUtMTYuNDk4IDMuNTM1LTE2LjQ5OCAxOC44NTUtMTguODU2IDIxLjIxMi0yMi4zOTEgOC4yNS0xMC42MDYgOC4yNS0xMC42MDZ6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0xMTYuNDk2IDQ0Ni44NTRzLjE3NyAxLjAzNy40ODMgMi45MzRjLjI4MyAxLjY4NS42NzIgNC4wNjYgMS4xNDQgNyA0Ljk1IDMwLjIwNCAxOS4zODUgMTE5LjExOSAxOC40MDcgMTIyLjA1My0xLjE3OCAzLjUzNi05LjQyNyAxNi40OTkgMCAyMC4wMzQuOTA4LjM0MiAxLjg4NiAxLjQ1IDIuOTM1IDMuMTk0YTY4LjQ5NCA2OC40OTQgMCAwMTQuOTg0IDExLjc2YzUuNjIyIDE2LjMxIDExLjYzMiA0Mi40MTQgMTUuMTA4IDYwLjQ5MSAxLjUyIDcuOTQzIDIuNTU4IDE0LjMzIDIuODY0IDE3LjY3N2E5LjYxMiA5LjYxMiAwIDAxLjAzNSAyLjMzNGMtMS4xNzggNC43MTMgNy4wNzEgMjEuMjEyIDEwLjYwNiAyNS45MjZzOS40MjggOS40MjcgOC4yNSAxNC4xNDEgMjkuNDYxIDE3LjY3NyAzMi45OTcgOS40MjggMy41MzUtMTIuOTYzIDQuNzEzLTE1LjMyIDIuMzU3LTE4Ljg1Ni0zLjUzNS0yMS4yMTItMi4zNTctNDMuNjAzLTguMjUtNTEuODUzYy0xLjk2Ny0yLjc0Ni00Ljk3Mi0xMi4wNDQtOC4xMTktMjMuMjI3YTc2NC44ODIgNzY0Ljg4MiAwIDAxLTMuNzEyLTEzLjczYy00Ljk3My0xOS4xNzMtOS4zOC0zOC40NjQtOS4zOC0zOC40NjRsMS4xNzgtMTM3Ljg4LTY0LjgxNS04LjI1LTEuNjYyIDMuNjY2LTMuMzExIDcuMjd6TTExMi45NjEgNjczLjExOHMtOS40MjgtOS40MjgtMTQuMTQyIDAtOS40MjcgNDUuOTYtMTcuNjc2IDU0LjIxLTE4Ljg1NiA0OS40OTUtNy4wNzEgNTEuODUyIDI0Ljc0Ny0zLjUzNiAyNS45MjYtMTAuNjA2IDI1LjkyNi00My42MDQgMjUuOTI2LTQ3LjEzOS0xNi40OTgtMTYuNDk4LTE2LjQ5OC0xNi40OTh6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0yNTcuOTEyIDM4Mi4wMzhzLTE1LjMyIDEzNy44OC0xOC44NTYgMTUwLjg0My0yMi4zOSA2Mi40NTktMjguMjgzIDcwLjcwOC00My42MDMgNzUuNDIxLTQ4LjMxNyA3OC45NTctMTQuMTQxIDEyLjk2My0xNC4xNDEgMTIuOTYzLTE3LjY3NyAxNy42NzctMjAuMDM0IDIxLjIxMi0yMi4zOS03LjA3LTIzLjU3LTE0LjE0MSAxLjE4LTE4Ljg1NiAyLjM1OC0yMy41Ny0yLjM1Ny0xMS43ODQgMS4xNzgtMTUuMzIgMjEuMjEyLTIxLjIxMiAyMS4yMTItMjkuNDYxIDMwLjY0LTU2LjU2NiA0Mi40MjUtNjcuMTcyIDkuNDI4LTI4LjI4MyA5LjQyOC0yOC4yODN2LTcxLjg4NmwtNjQuODE2LTIwLjAzNHMzLjUzNi01Ni41NjYgMTEuNzg1LTU2LjU2NiAxMTYuNjY4LTE4Ljg1NiAxMjkuNjMtOC4yNXpcIlxyXG4gICAgICAgIGZpbGw9XCIjMmYyZTQxXCJcclxuICAgICAgLz5cclxuICAgICAgPGNpcmNsZSBjeD17MTYyLjQ1Nn0gY3k9ezE0Ni4zNDZ9IHI9ezM4Ljg4OX0gZmlsbD1cIiM5ZjYxNmFcIiAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMTc1LjQyIDE3Ni45ODZzNC43MTMgMTcuNjc3IDEwLjYwNiAyMi4zOS0xNS4zMiAyNC43NDktMTUuMzIgMjQuNzQ5bC00MC4wNjggMi4zNTYtNy4wNy0yMi4zOXMxMi45NjItMjUuOTI2IDkuNDI3LTQyLjQyNSA0Mi40MjQgMTUuMzIgNDIuNDI0IDE1LjMyelwiXHJcbiAgICAgICAgZmlsbD1cIiM5ZjYxNmFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMTkxLjkxOCAxOTcuMDJzLTEwLjYwNiAxLjE3OC0xMi45NjMgNC43MTQtMTguODU2IDE0LjE0MS0zMS44MTkgMTEuNzg0LTIxLjIxMi01Ljg5Mi0yMy41NjktNC43MTMtNy4wNyAyNS45MjYtNy4wNyAyNS45MjZsMTIuOTYyIDM3LjcxLTIuMzU2IDEwMy43MDUtMy41MzYgMjguMjgzcy03LjA3LTkuNDI4IDIxLjIxMi0zLjUzNSA2NC44MTYtNC43MTQgNzYuNi01Ljg5MyAzMS44MTktNC43MTMgMzIuOTk3LTExLjc4NC0zLjUzNS0zMi45OTctMy41MzUtMzIuOTk3bC0xOC44NTUtNzguOTU3LTExLjc4NS00Mi40MjV6XCJcclxuICAgICAgICBmaWxsPVwiIzNmNTFiNVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0xODAuNzcgMTkxLjcwMXM5Ljk3LTUuMjg3IDEzLjUwNS0uNTczIDQ4LjMxNyAxMS43ODQgNDguMzE3IDE1LjMyIDkuNDI3IDk4Ljk5IDcuMDcgMTA3LjI0IDQuNzE0IDE3LjY3NyA0LjcxNCAxNy42NzdsOC4yNSAzNS4zNTNzMjIuMzkgNjcuMTczIDEyLjk2MyA2OS41My0xNy42NzcgMC0yMS4yMTMgMC0yLjM1Ny00NC43ODItMTEuNzg0LTU2LjU2Ny0yMi4zOTEtNDEuMjQ2LTI0Ljc0OC00Ny4xMzgtMzEuODE4LTg3LjIwNi0zMC42NC05Ni42MzQtNi40MzMtNDQuMjA4LTYuNDMzLTQ0LjIwOHpNMTMxLjgxNiAxOTcuMDJzLTkuNDI3IDAtMTAuNjA2IDIuMzU3LTEyLjk2MyAxNy42NzctMTcuNjc3IDIxLjIxMi0yMS4yMTIgMTguODU2LTIxLjIxMiAyMi4zOSAzNC4xNzUgMjkuNDYyIDM0LjE3NSAyOS40NjIgMTQuMTQyIDY5LjUzIDcuMDcxIDkzLjA5OS0xNy42NzcgODAuMTM1LTEyLjk2MyA4My42NyAxNS4zMiA0LjcxNCAxNS4zMiAwIDcuMDctNTUuMzg3IDEyLjk2My02NS45OTMgMjMuNTctNzcuNzc5IDE2LjQ5OS05Ni42MzQtMjMuNTctODkuNTYzLTIzLjU3LTg5LjU2M3pcIlxyXG4gICAgICAgIGZpbGw9XCIjZDBjZGUxXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTI4Ny4zNzMgMzEzLjY4OHMxLjE3OSAzNi41MzItMTEuNzg0IDU1LjM4Ny0yMS4yMTMgNDAuMDY4LTIxLjIxMyA0MC4wNjgtMjEuMjEyLTUuODkyLTI0Ljc0Ny0xMi45NjMtMjUuOTI3LTEuMTc5LTI1LjkyNy0zLjUzNiAyNy4xMDUtMTQuMTQxIDI5LjQ2Mi0xNi40OTggMTAuNjA2LTIuMzU3IDE1LjMyLTcuMDcgNS44OTItMTUuMzIgNS44OTItMTUuMzJsNC43MTQtMzAuNjR6XCJcclxuICAgICAgICBmaWxsPVwiIzlmNjE2YVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0xODkuMjQxIDEyMi4zNjhjMi45OTItLjI3MiA2LjA3OC0uNTcxIDguNzIyLTEuOTk3IDUuOTI0LTMuMTk1IDcuNDk1LTEyLjI5NCAyLjk4NS0xNy4yOWEyMi4zNDQgMjIuMzQ0IDAgMDAtNC4xNDMtMy4zMzJsLTguOTU4LTYuMDk3Yy0zLjk2Mi0yLjY5Ny04LjAxNy01LjQzOC0xMi42MzgtNi43MDktNC4xOC0xLjE1LTguNTk0LTEuMDMyLTEyLjkyLS43NjMtOC4zOTkuNTIyLTE2Ljg1IDEuNi0yNC43NDkgNC41cy0xNS4yNjggNy43NTEtMjAuMDUyIDE0LjY3NGMtNy41ODUgMTAuOTc0LTcuNjg5IDI1Ljc3NS0zLjUxMiAzOC40NDRzMTIuMTEzIDIzLjcwMSAxOS45MzIgMzQuNTFsNC4wNTYtMTkuNzk1Yy4zNjItMS43NjMuODMtMy42OTYgMi4yOTUtNC43MzkgMy42NDUtMi41OTMgOC4xMDMgMi43MzEgMTIuNTc2IDIuNjk3IDIuODc0LS4wMjIgNS4yODctMi4zODYgNi4zNzYtNS4wNDZzMS4xNjEtNS42MDUgMS40MTMtOC40NjhjLjUzNC02LjA2NSAyLjY1NC0xNC41MDIgOC4zOTYtMTcuODQ3IDUuMzUyLTMuMTE2IDE0LjIwNi0yLjE5NiAyMC4yMjEtMi43NDJ6XCJcclxuICAgICAgICBmaWxsPVwiIzJmMmU0MVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoIGQ9XCJNMTg3LjA2IDQ0Ny44MDVzLTMuOTggMTE1LjEyNy02LjMzOCAxMTguNjYyIDAtMTE5LjAyNCAwLTExOS4wMjR6XCIgb3BhY2l0eT17MC4xfSAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMjMzLjE2NCAyMDYuNDQ4aDkuNDI4czQwLjA2NyA1NC4yMDkgMzUuMzU0IDU3Ljc0NCAwIDEyLjk2MyAwIDEyLjk2M2w5LjQyNyAxNy42NzdzMTEuNzg1IDEwLjYwNiA4LjI1IDEyLjk2My04LjI1IDExLjc4NS04LjI1IDExLjc4NS0yMy41NjktMy41MzUtMzAuNjQgMTAuNjA2TDI0MS40NSAzMTAuODl6XCJcclxuICAgICAgICBmaWxsPVwiI2QwY2RlMVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoIGZpbGw9XCIjMmYyZTQxXCIgZD1cIk0yMDQuMTQ1IDIzNy4yNDNsMzIuMzUtMTMuMzYgMjQuODk1IDYwLjI4Ny0zMi4zNSAxMy4zNTl6XCIgLz5cclxuICAgICAgPGVsbGlwc2VcclxuICAgICAgICBjeD17MjgwLjc1fVxyXG4gICAgICAgIGN5PXszMDQuNDU4fVxyXG4gICAgICAgIHJ4PXs3fVxyXG4gICAgICAgIHJ5PXs2LjQzMX1cclxuICAgICAgICB0cmFuc2Zvcm09XCJyb3RhdGUoLTIyLjQzOCAxMjYuNTM2IDQwNi4xOClcIlxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTIwOS41OTUgMzAwLjcyNXMtODQuODUgNzAuNzA3LTk4Ljk5IDQ4LjMxNiAxNS4zMi00MS4yNDYgMTUuMzItNDEuMjQ2IDI1LjkyNSAxLjE3OSA1NS4zODctMTcuNjc3bDI5LjQ2MS0xMi45NjNzMjYuODk2LTM4LjM5OSAzNi4wNjItMjMuNzc3LTE1LjY0NSA0MC4wNy0zNy4yNCA0Ny4zNDd6XCJcclxuICAgICAgICBmaWxsPVwiIzlmNjE2YVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk05NS4yODQgMjM4LjI2NmwtMTIuOTYzIDQuNzE0djM1LjM1NGwtNC43MTQgNy4wN3MxLjE3OSAxNC4xNDIgNC43MTQgMTcuNjc3IDEwLjYwNiAyLjM1NyA4LjI1IDEwLjYwN2E0NC42NjcgNDQuNjY3IDAgMDAtMS4xOCAxNi40OThzMjEuMjEzIDI3LjEwNSAyMi4zOTIgMjMuNTcgMTcuNjc2LTQ3LjE0IDIwLjAzMy00Ny4xNC0yMy41NjktNjguMzUtMjMuNTY5LTY4LjM1elwiXHJcbiAgICAgICAgZmlsbD1cIiNkMGNkZTFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNMjUwLjI1MiA0MTYuODAzczEyLjE4NS0xMS43ODUgNi4wOTItMTIuMzc0LTI3LjMwNS0xMi4zNzQtMzAuODQtNi40ODEgMjQuNzQ4IDE4Ljg1NSAyNC43NDggMTguODU1elwiXHJcbiAgICAgICAgZmlsbD1cIiMyZjJlNDFcIlxyXG4gICAgICAvPlxyXG4gICAgICA8ZWxsaXBzZSBjeD17NDgyfSBjeT17MTgzfSByeD17MTd9IHJ5PXs5fSBmaWxsPVwiIzU3Yjg5NFwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01NDcgMjEzcS01Ny41LTIxLjcxNi0xMTUgMHYtNDdhMTk5LjAzOCAxOTkuMDM4IDAgMDExMTUgMHpcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCIjM2YzZDU2XCJcclxuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PXsxMH1cclxuICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTUzMSAyMDMuMjhxLTQxLjUtMTUuNjczLTgzIDBWMTY5LjM2YTE0My42NTMgMTQzLjY1MyAwIDAxODMgMHpcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCIjM2YzZDU2XCJcclxuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PXsxMH1cclxuICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgLz5cclxuICAgICAgPGVsbGlwc2VcclxuICAgICAgICBjeD17NDg4fVxyXG4gICAgICAgIGN5PXsxNzl9XHJcbiAgICAgICAgcng9ezE3fVxyXG4gICAgICAgIHJ5PXs5fVxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgICBzdHJva2U9XCIjM2YzZDU2XCJcclxuICAgICAgICBzdHJva2VNaXRlcmxpbWl0PXsxMH1cclxuICAgICAgICBzdHJva2VXaWR0aD17Mn1cclxuICAgICAgLz5cclxuICAgICAgPGVsbGlwc2VcclxuICAgICAgICBjeD17NTQzLjJ9XHJcbiAgICAgICAgY3k9ezI5MC43MDZ9XHJcbiAgICAgICAgcng9ezE3fVxyXG4gICAgICAgIHJ5PXs5fVxyXG4gICAgICAgIHRyYW5zZm9ybT1cInJvdGF0ZSgtMTEuNTM1IDI2NC43MDIgNTE1LjEwOClcIlxyXG4gICAgICAgIGZpbGw9XCIjNTdiODk0XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTU2Mi4zODYgMjU1Ljk0MXEtNjAuNjgtOS43NzktMTEyLjY3NyAyMi45OTdsLTkuMzk4LTQ2LjA1YTE5OS4wMzggMTk5LjAzOCAwIDAxMTEyLjY3Ny0yMi45OTd6XCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD17MTB9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01NDQuNzY2IDI0OS42MTdxLTQzLjc5Ni03LjA1OC04MS4zMjMgMTYuNTk4bC02Ljc4NC0zMy4yMzZhMTQzLjY1MyAxNDMuNjUzIDAgMDE4MS4zMjMtMTYuNTk4elwiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cIiMzZjNkNTZcIlxyXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9ezEwfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAvPlxyXG4gICAgICA8ZWxsaXBzZVxyXG4gICAgICAgIGN4PXs1NDguMjc5fVxyXG4gICAgICAgIGN5PXsyODUuNTg3fVxyXG4gICAgICAgIHJ4PXsxN31cclxuICAgICAgICByeT17OX1cclxuICAgICAgICB0cmFuc2Zvcm09XCJyb3RhdGUoLTExLjUzNSAyNjkuNzgxIDUwOS45ODkpXCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD17MTB9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgY3g9ezUzOS42NzV9XHJcbiAgICAgICAgY3k9ezM0Ni42NDV9XHJcbiAgICAgICAgcng9ezl9XHJcbiAgICAgICAgcnk9ezE3fVxyXG4gICAgICAgIHRyYW5zZm9ybT1cInJvdGF0ZSgtODYuMDE5IDQ4Ny4wMDMgMzQ4LjEzMylcIlxyXG4gICAgICAgIGZpbGw9XCIjNTdiODk0XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTU1MS45MzUgMzI5LjkyNXEtNTUuODUzLTI1LjY1Ni0xMTQuNzIyLTcuOTgzbDMuMjYyLTQ2Ljg4N2ExOTkuMDM4IDE5OS4wMzggMCAwMTExNC43MjMgNy45ODN6XCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD17MTB9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01MzYuNjQ5IDMxOS4xMThxLTQwLjMxMi0xOC41MTctODIuOC01Ljc2MmwyLjM1NS0zMy44NGExNDMuNjUzIDE0My42NTMgMCAwMTgyLjggNS43NjJ6XCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD17MTB9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxlbGxpcHNlXHJcbiAgICAgICAgY3g9ezU0NS45Mzh9XHJcbiAgICAgICAgY3k9ezM0My4wNzF9XHJcbiAgICAgICAgcng9ezl9XHJcbiAgICAgICAgcnk9ezE3fVxyXG4gICAgICAgIHRyYW5zZm9ybT1cInJvdGF0ZSgtODYuMDE5IDQ5My4yNjYgMzQ0LjU2KVwiXHJcbiAgICAgICAgZmlsbD1cIm5vbmVcIlxyXG4gICAgICAgIHN0cm9rZT1cIiMzZjNkNTZcIlxyXG4gICAgICAgIHN0cm9rZU1pdGVybGltaXQ9ezEwfVxyXG4gICAgICAgIHN0cm9rZVdpZHRoPXsyfVxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNDE0LjkyMiAyMTQuMDkycy03My40OTYtMTAuMDU1LTEyNS45ODIgMjAuNzAzXCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgICAgc3Ryb2tlPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgc3Ryb2tlTWl0ZXJsaW1pdD17MTB9XHJcbiAgICAgICAgc3Ryb2tlV2lkdGg9ezJ9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiMzZjNkNTZcIlxyXG4gICAgICAgIGQ9XCJNMjkwLjcwOCAyMjQuNDU5bDEuOTA5LjYwNC0yLjk4NCA5LjM5OSA5LjU5NCAyLjI4OS0uNDY3IDEuOTQ3LTExLjY4My0yLjc5MSAzLjYzMS0xMS40NDh6XCJcclxuICAgICAgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN2Z1VuZHJhd1RyYW5zZmVyTW9uZXlSeXdhO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1N2Z1VuZHJhd1RyYW5zZmVyTW9uZXlSeXdhLnRzeCJ9