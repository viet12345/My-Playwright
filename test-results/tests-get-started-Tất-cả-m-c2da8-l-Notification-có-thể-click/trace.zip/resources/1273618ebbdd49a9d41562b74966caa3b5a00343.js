import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionCreateStepOne.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Paper } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import UsersList from "/src/components/UsersList.tsx";
import UserListSearchForm from "/src/components/UserListSearchForm.tsx";
const PREFIX = "TransactionCreateStepOne";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    //marginTop: theme.spacing(2),
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  }
}));
_c = StyledPaper;
const TransactionCreateStepOne = ({
  setReceiver,
  userListSearch,
  users
}) => {
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, elevation: 0, children: [
    /* @__PURE__ */ jsxDEV(UserListSearchForm, { userListSearch }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx",
      lineNumber: 37,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(UsersList, { users, setReceiver }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx",
      lineNumber: 38,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx",
    lineNumber: 36,
    columnNumber: 5
  }, this);
};
_c2 = TransactionCreateStepOne;
export default TransactionCreateStepOne;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "TransactionCreateStepOne");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepOne.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0NNO0FBcENOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxhQUFhO0FBQ3RCLE9BQU9DLGVBQWU7QUFFdEIsT0FBT0Msd0JBQXdCO0FBRS9CLE1BQU1DLFNBQVM7QUFFZixNQUFNQyxVQUFVO0FBQUEsRUFDZEMsT0FBTyxHQUFHRixNQUFNO0FBQ2xCO0FBRUEsTUFBTUcsY0FBY1AsT0FBT0MsS0FBSyxFQUFFLENBQUMsRUFBRU8sTUFBTSxPQUFPO0FBQUEsRUFDaEQsQ0FBQyxLQUFLSCxRQUFRQyxLQUFLLEVBQUUsR0FBRztBQUFBO0FBQUEsSUFFdEJHLFNBQVNELE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQ3hCQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLGVBQWU7QUFBQSxFQUNqQjtBQUNGLEVBQUU7QUFBRUMsS0FSRVA7QUFnQk4sTUFBTVEsMkJBQW9FQSxDQUFDO0FBQUEsRUFDekVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsZUFBWSxXQUFXYixRQUFRQyxPQUFPLFdBQVcsR0FDaEQ7QUFBQSwyQkFBQyxzQkFBbUIsa0JBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUQ7QUFBQSxJQUNuRCx1QkFBQyxhQUFVLE9BQWMsZUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrRDtBQUFBLE9BRnBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FHQTtBQUVKO0FBQUVhLE1BWElKO0FBYU4sZUFBZUE7QUFBeUIsSUFBQUQsSUFBQUs7QUFBQUMsYUFBQU4sSUFBQTtBQUFBTSxhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJzdHlsZWQiLCJQYXBlciIsIlVzZXJzTGlzdCIsIlVzZXJMaXN0U2VhcmNoRm9ybSIsIlBSRUZJWCIsImNsYXNzZXMiLCJwYXBlciIsIlN0eWxlZFBhcGVyIiwidGhlbWUiLCJwYWRkaW5nIiwic3BhY2luZyIsImRpc3BsYXkiLCJvdmVyZmxvdyIsImZsZXhEaXJlY3Rpb24iLCJfYyIsIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcE9uZSIsInNldFJlY2VpdmVyIiwidXNlckxpc3RTZWFyY2giLCJ1c2VycyIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcE9uZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgUGFwZXIgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgVXNlcnNMaXN0IGZyb20gXCIuL1VzZXJzTGlzdFwiO1xyXG5pbXBvcnQgeyBVc2VyIH0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5pbXBvcnQgVXNlckxpc3RTZWFyY2hGb3JtIGZyb20gXCIuL1VzZXJMaXN0U2VhcmNoRm9ybVwiO1xyXG5cclxuY29uc3QgUFJFRklYID0gXCJUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBPbmVcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgcGFwZXI6IGAke1BSRUZJWH0tcGFwZXJgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkUGFwZXIgPSBzdHlsZWQoUGFwZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgLy9tYXJnaW5Ub3A6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgICBwYWRkaW5nOiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBvdmVyZmxvdzogXCJhdXRvXCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25DcmVhdGVTdGVwT25lUHJvcHMge1xyXG4gIHNldFJlY2VpdmVyOiBGdW5jdGlvbjtcclxuICB1c2VyTGlzdFNlYXJjaDogRnVuY3Rpb247XHJcbiAgdXNlcnM6IFVzZXJbXTtcclxufVxyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25DcmVhdGVTdGVwT25lOiBSZWFjdC5GQzxUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBPbmVQcm9wcz4gPSAoe1xyXG4gIHNldFJlY2VpdmVyLFxyXG4gIHVzZXJMaXN0U2VhcmNoLFxyXG4gIHVzZXJzLFxyXG59KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRQYXBlciBjbGFzc05hbWU9e2NsYXNzZXMucGFwZXJ9IGVsZXZhdGlvbj17MH0+XHJcbiAgICAgIDxVc2VyTGlzdFNlYXJjaEZvcm0gdXNlckxpc3RTZWFyY2g9e3VzZXJMaXN0U2VhcmNofSAvPlxyXG4gICAgICA8VXNlcnNMaXN0IHVzZXJzPXt1c2Vyc30gc2V0UmVjZWl2ZXI9e3NldFJlY2VpdmVyfSAvPlxyXG4gICAgPC9TdHlsZWRQYXBlcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVHJhbnNhY3Rpb25DcmVhdGVTdGVwT25lO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1RyYW5zYWN0aW9uQ3JlYXRlU3RlcE9uZS50c3gifQ==