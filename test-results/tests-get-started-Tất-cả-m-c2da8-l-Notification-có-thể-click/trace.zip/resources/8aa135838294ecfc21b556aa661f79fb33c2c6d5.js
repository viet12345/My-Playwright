import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/MainLayout.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Container, Grid, useMediaQuery, useTheme } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import Footer from "/src/components/Footer.tsx";
import NavBar from "/src/components/NavBar.tsx";
import NavDrawer from "/src/components/NavDrawer.tsx";
import { drawerMachine } from "/src/machines/drawerMachine.ts";
const PREFIX = "MainLayout";
const classes = {
  toolbar: `${PREFIX}-toolbar`,
  appBarSpacer: `${PREFIX}-appBarSpacer`,
  content: `${PREFIX}-content`,
  container: `${PREFIX}-container`
};
const Root = styled("div")(({ theme }) => ({
  [`&`]: { display: "flex", flexGrow: 1 },
  [`& .${classes.toolbar}`]: {
    paddingRight: 24
    // keep right padding when drawer closed
  },
  [`& .${classes.appBarSpacer}`]: {
    minHeight: theme.spacing(13),
    [theme.breakpoints.up("sm")]: {
      minHeight: theme.spacing(14)
    }
  },
  [`& .${classes.content}`]: {
    flexGrow: 1,
    height: "100vh",
    overflow: "auto"
  },
  [`& .${classes.container}`]: {
    minHeight: "77vh",
    paddingTop: theme.spacing(1),
    paddingBottom: theme.spacing(1),
    [theme.breakpoints.up("sm")]: {
      paddingTop: theme.spacing(4),
      padding: theme.spacing(4)
    }
  }
}));
_c = Root;
const MainLayout = ({ children, notificationsService, authService }) => {
  _s();
  const theme = useTheme();
  const [drawerState, sendDrawer] = useMachine(drawerMachine);
  const aboveSmallBreakpoint = useMediaQuery(theme.breakpoints.up("sm"));
  const xsBreakpoint = useMediaQuery(theme.breakpoints.only("xs"));
  const desktopDrawerOpen = drawerState?.matches({ desktop: "open" });
  const mobileDrawerOpen = drawerState?.matches({ mobile: "open" });
  const toggleDesktopDrawer = () => {
    sendDrawer("TOGGLE_DESKTOP");
  };
  const toggleMobileDrawer = () => {
    sendDrawer("TOGGLE_MOBILE");
  };
  const openDesktopDrawer = (payload) => sendDrawer("OPEN_DESKTOP", payload);
  const closeMobileDrawer = () => sendDrawer("CLOSE_MOBILE");
  useEffect(() => {
    if (!desktopDrawerOpen && aboveSmallBreakpoint) {
      openDesktopDrawer({ aboveSmallBreakpoint });
    }
  }, [aboveSmallBreakpoint, desktopDrawerOpen]);
  return /* @__PURE__ */ jsxDEV(Root, { children: [
    /* @__PURE__ */ jsxDEV(
      NavBar,
      {
        toggleDrawer: xsBreakpoint ? toggleMobileDrawer : toggleDesktopDrawer,
        drawerOpen: xsBreakpoint ? mobileDrawerOpen : desktopDrawerOpen,
        notificationsService
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 100,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      NavDrawer,
      {
        toggleDrawer: xsBreakpoint ? toggleMobileDrawer : toggleDesktopDrawer,
        drawerOpen: xsBreakpoint ? mobileDrawerOpen : desktopDrawerOpen,
        closeMobileDrawer,
        authService
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 105,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("main", { className: classes.content, "data-test": "main", children: [
      /* @__PURE__ */ jsxDEV("div", { className: classes.appBarSpacer }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 112,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Container, { maxWidth: "md", className: classes.container, children: /* @__PURE__ */ jsxDEV(Grid, { container: true, spacing: 3, children: /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: 12, children }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 115,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 114,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 113,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("footer", { children: /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 121,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
        lineNumber: 120,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx",
    lineNumber: 99,
    columnNumber: 5
  }, this);
};
_s(MainLayout, "Gf7hXXCqweLqIqjSe3JIKZgWh9Q=", false, function() {
  return [useTheme, useMachine, useMediaQuery, useMediaQuery];
});
_c2 = MainLayout;
export default MainLayout;
var _c, _c2;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "MainLayout");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/MainLayout.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUdNOzJCQW5HTjtBQUFnQkEsTUFBUyxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3hDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0Msa0JBQWtCO0FBUTNCLFNBQVNDLFdBQVdDLE1BQU1DLGVBQWVDLGdCQUFnQjtBQUV6RCxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLFlBQVk7QUFDbkIsT0FBT0MsZUFBZTtBQUd0QixTQUFTQyxxQkFBcUI7QUFFOUIsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxTQUFTLEdBQUdGLE1BQU07QUFBQSxFQUNsQkcsY0FBYyxHQUFHSCxNQUFNO0FBQUEsRUFDdkJJLFNBQVMsR0FBR0osTUFBTTtBQUFBLEVBQ2xCSyxXQUFXLEdBQUdMLE1BQU07QUFDdEI7QUFFQSxNQUFNTSxPQUFPaEIsT0FBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFaUIsTUFBTSxPQUFPO0FBQUEsRUFDekMsQ0FBQyxHQUFHLEdBQUcsRUFBRUMsU0FBUyxRQUFRQyxVQUFVLEVBQUU7QUFBQSxFQUV0QyxDQUFDLE1BQU1SLFFBQVFDLE9BQU8sRUFBRSxHQUFHO0FBQUEsSUFDekJRLGNBQWM7QUFBQTtBQUFBLEVBQ2hCO0FBQUEsRUFFQSxDQUFDLE1BQU1ULFFBQVFFLFlBQVksRUFBRSxHQUFHO0FBQUEsSUFDOUJRLFdBQVdKLE1BQU1LLFFBQVEsRUFBRTtBQUFBLElBQzNCLENBQUNMLE1BQU1NLFlBQVlDLEdBQUcsSUFBSSxDQUFDLEdBQUc7QUFBQSxNQUM1QkgsV0FBV0osTUFBTUssUUFBUSxFQUFFO0FBQUEsSUFDN0I7QUFBQSxFQUNGO0FBQUEsRUFFQSxDQUFDLE1BQU1YLFFBQVFHLE9BQU8sRUFBRSxHQUFHO0FBQUEsSUFDekJLLFVBQVU7QUFBQSxJQUNWTSxRQUFRO0FBQUEsSUFDUkMsVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUVBLENBQUMsTUFBTWYsUUFBUUksU0FBUyxFQUFFLEdBQUc7QUFBQSxJQUMzQk0sV0FBVztBQUFBLElBQ1hNLFlBQVlWLE1BQU1LLFFBQVEsQ0FBQztBQUFBLElBQzNCTSxlQUFlWCxNQUFNSyxRQUFRLENBQUM7QUFBQSxJQUM5QixDQUFDTCxNQUFNTSxZQUFZQyxHQUFHLElBQUksQ0FBQyxHQUFHO0FBQUEsTUFDNUJHLFlBQVlWLE1BQU1LLFFBQVEsQ0FBQztBQUFBLE1BQzNCTyxTQUFTWixNQUFNSyxRQUFRLENBQUM7QUFBQSxJQUMxQjtBQUFBLEVBQ0Y7QUFDRixFQUFFO0FBQUVRLEtBN0JFZDtBQTJDTixNQUFNZSxhQUE4QkEsQ0FBQyxFQUFFQyxVQUFVQyxzQkFBc0JDLFlBQVksTUFBTTtBQUFBQyxLQUFBO0FBQ3ZGLFFBQU1sQixRQUFRWixTQUFTO0FBQ3ZCLFFBQU0sQ0FBQytCLGFBQWFDLFVBQVUsSUFBSXBDLFdBQVdRLGFBQWE7QUFFMUQsUUFBTTZCLHVCQUF1QmxDLGNBQWNhLE1BQU1NLFlBQVlDLEdBQUcsSUFBSSxDQUFDO0FBQ3JFLFFBQU1lLGVBQWVuQyxjQUFjYSxNQUFNTSxZQUFZaUIsS0FBSyxJQUFJLENBQUM7QUFFL0QsUUFBTUMsb0JBQW9CTCxhQUFhTSxRQUFRLEVBQUVDLFNBQVMsT0FBTyxDQUFDO0FBQ2xFLFFBQU1DLG1CQUFtQlIsYUFBYU0sUUFBUSxFQUFFRyxRQUFRLE9BQU8sQ0FBQztBQUNoRSxRQUFNQyxzQkFBc0JBLE1BQU07QUFDaENULGVBQVcsZ0JBQWdCO0FBQUEsRUFDN0I7QUFDQSxRQUFNVSxxQkFBcUJBLE1BQU07QUFDL0JWLGVBQVcsZUFBZTtBQUFBLEVBQzVCO0FBRUEsUUFBTVcsb0JBQW9CQSxDQUFDQyxZQUFpQlosV0FBVyxnQkFBZ0JZLE9BQU87QUFDOUUsUUFBTUMsb0JBQW9CQSxNQUFNYixXQUFXLGNBQWM7QUFFekR0QyxZQUFVLE1BQU07QUFDZCxRQUFJLENBQUMwQyxxQkFBcUJILHNCQUFzQjtBQUM5Q1Usd0JBQWtCLEVBQUVWLHFCQUFxQixDQUFDO0FBQUEsSUFDNUM7QUFBQSxFQUVGLEdBQUcsQ0FBQ0Esc0JBQXNCRyxpQkFBaUIsQ0FBQztBQUU1QyxTQUNFLHVCQUFDLFFBQ0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsY0FBY0YsZUFBZVEscUJBQXFCRDtBQUFBQSxRQUNsRCxZQUFZUCxlQUFlSyxtQkFBbUJIO0FBQUFBLFFBQzlDO0FBQUE7QUFBQSxNQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUc2QztBQUFBLElBRTdDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxjQUFjRixlQUFlUSxxQkFBcUJEO0FBQUFBLFFBQ2xELFlBQVlQLGVBQWVLLG1CQUFtQkg7QUFBQUEsUUFDOUM7QUFBQSxRQUNBO0FBQUE7QUFBQSxNQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUkyQjtBQUFBLElBRTNCLHVCQUFDLFVBQUssV0FBVzlCLFFBQVFHLFNBQVMsYUFBVSxRQUMxQztBQUFBLDZCQUFDLFNBQUksV0FBV0gsUUFBUUUsZ0JBQXhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUM7QUFBQSxNQUNyQyx1QkFBQyxhQUFVLFVBQVMsTUFBSyxXQUFXRixRQUFRSSxXQUMxQyxpQ0FBQyxRQUFLLFdBQVMsTUFBQyxTQUFTLEdBQ3ZCLGlDQUFDLFFBQUssTUFBSSxNQUFDLElBQUksSUFDWmlCLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLEtBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxZQUNDLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFPLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBWUE7QUFBQSxPQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBeUJBO0FBRUo7QUFBRUcsR0F0RElKLFlBQTJCO0FBQUEsVUFDakIxQixVQUNvQkosWUFFTEcsZUFDUkEsYUFBYTtBQUFBO0FBQUErQyxNQUw5QnBCO0FBd0ROLGVBQWVBO0FBQVcsSUFBQUQsSUFBQXFCO0FBQUFDLGFBQUF0QixJQUFBO0FBQUFzQixhQUFBRCxLQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0Iiwic3R5bGVkIiwidXNlTWFjaGluZSIsIkNvbnRhaW5lciIsIkdyaWQiLCJ1c2VNZWRpYVF1ZXJ5IiwidXNlVGhlbWUiLCJGb290ZXIiLCJOYXZCYXIiLCJOYXZEcmF3ZXIiLCJkcmF3ZXJNYWNoaW5lIiwiUFJFRklYIiwiY2xhc3NlcyIsInRvb2xiYXIiLCJhcHBCYXJTcGFjZXIiLCJjb250ZW50IiwiY29udGFpbmVyIiwiUm9vdCIsInRoZW1lIiwiZGlzcGxheSIsImZsZXhHcm93IiwicGFkZGluZ1JpZ2h0IiwibWluSGVpZ2h0Iiwic3BhY2luZyIsImJyZWFrcG9pbnRzIiwidXAiLCJoZWlnaHQiLCJvdmVyZmxvdyIsInBhZGRpbmdUb3AiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZyIsIl9jIiwiTWFpbkxheW91dCIsImNoaWxkcmVuIiwibm90aWZpY2F0aW9uc1NlcnZpY2UiLCJhdXRoU2VydmljZSIsIl9zIiwiZHJhd2VyU3RhdGUiLCJzZW5kRHJhd2VyIiwiYWJvdmVTbWFsbEJyZWFrcG9pbnQiLCJ4c0JyZWFrcG9pbnQiLCJvbmx5IiwiZGVza3RvcERyYXdlck9wZW4iLCJtYXRjaGVzIiwiZGVza3RvcCIsIm1vYmlsZURyYXdlck9wZW4iLCJtb2JpbGUiLCJ0b2dnbGVEZXNrdG9wRHJhd2VyIiwidG9nZ2xlTW9iaWxlRHJhd2VyIiwib3BlbkRlc2t0b3BEcmF3ZXIiLCJwYXlsb2FkIiwiY2xvc2VNb2JpbGVEcmF3ZXIiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNYWluTGF5b3V0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyB1c2VNYWNoaW5lIH0gZnJvbSBcIkB4c3RhdGUvcmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBCYXNlQWN0aW9uT2JqZWN0LFxyXG4gIEludGVycHJldGVyLFxyXG4gIFJlc29sdmVUeXBlZ2VuTWV0YSxcclxuICBTZXJ2aWNlTWFwLFxyXG4gIFR5cGVnZW5EaXNhYmxlZCxcclxufSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IENvbnRhaW5lciwgR3JpZCwgdXNlTWVkaWFRdWVyeSwgdXNlVGhlbWUgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9Gb290ZXJcIjtcclxuaW1wb3J0IE5hdkJhciBmcm9tIFwiLi9OYXZCYXJcIjtcclxuaW1wb3J0IE5hdkRyYXdlciBmcm9tIFwiLi9OYXZEcmF3ZXJcIjtcclxuaW1wb3J0IHsgRGF0YUNvbnRleHQsIERhdGFFdmVudHMsIERhdGFTY2hlbWEgfSBmcm9tIFwiLi4vbWFjaGluZXMvZGF0YU1hY2hpbmVcIjtcclxuaW1wb3J0IHsgQXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZUV2ZW50cywgQXV0aE1hY2hpbmVTY2hlbWEgfSBmcm9tIFwiLi4vbWFjaGluZXMvYXV0aE1hY2hpbmVcIjtcclxuaW1wb3J0IHsgZHJhd2VyTWFjaGluZSB9IGZyb20gXCIuLi9tYWNoaW5lcy9kcmF3ZXJNYWNoaW5lXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIk1haW5MYXlvdXRcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgdG9vbGJhcjogYCR7UFJFRklYfS10b29sYmFyYCxcclxuICBhcHBCYXJTcGFjZXI6IGAke1BSRUZJWH0tYXBwQmFyU3BhY2VyYCxcclxuICBjb250ZW50OiBgJHtQUkVGSVh9LWNvbnRlbnRgLFxyXG4gIGNvbnRhaW5lcjogYCR7UFJFRklYfS1jb250YWluZXJgLFxyXG59O1xyXG4vLyBUT0RPIGpzcy10by1zdHlsZWQgY29kZW1vZDogVGhlIEZyYWdtZW50IHJvb3Qgd2FzIHJlcGxhY2VkIGJ5IGRpdi4gQ2hhbmdlIHRoZSB0YWcgaWYgbmVlZGVkLlxyXG5jb25zdCBSb290ID0gc3R5bGVkKFwiZGl2XCIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmYF06IHsgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhHcm93OiAxIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnRvb2xiYXJ9YF06IHtcclxuICAgIHBhZGRpbmdSaWdodDogMjQsIC8vIGtlZXAgcmlnaHQgcGFkZGluZyB3aGVuIGRyYXdlciBjbG9zZWRcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5hcHBCYXJTcGFjZXJ9YF06IHtcclxuICAgIG1pbkhlaWdodDogdGhlbWUuc3BhY2luZygxMyksXHJcbiAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoXCJzbVwiKV06IHtcclxuICAgICAgbWluSGVpZ2h0OiB0aGVtZS5zcGFjaW5nKDE0KSxcclxuICAgIH0sXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuY29udGVudH1gXToge1xyXG4gICAgZmxleEdyb3c6IDEsXHJcbiAgICBoZWlnaHQ6IFwiMTAwdmhcIixcclxuICAgIG92ZXJmbG93OiBcImF1dG9cIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5jb250YWluZXJ9YF06IHtcclxuICAgIG1pbkhlaWdodDogXCI3N3ZoXCIsXHJcbiAgICBwYWRkaW5nVG9wOiB0aGVtZS5zcGFjaW5nKDEpLFxyXG4gICAgcGFkZGluZ0JvdHRvbTogdGhlbWUuc3BhY2luZygxKSxcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy51cChcInNtXCIpXToge1xyXG4gICAgICBwYWRkaW5nVG9wOiB0aGVtZS5zcGFjaW5nKDQpLFxyXG4gICAgICBwYWRkaW5nOiB0aGVtZS5zcGFjaW5nKDQpLFxyXG4gICAgfSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5pbnRlcmZhY2UgUHJvcHMge1xyXG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbiAgYXV0aFNlcnZpY2U6IEludGVycHJldGVyPEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVTY2hlbWEsIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnksIGFueT47XHJcbiAgbm90aWZpY2F0aW9uc1NlcnZpY2U6IEludGVycHJldGVyPFxyXG4gICAgRGF0YUNvbnRleHQsXHJcbiAgICBEYXRhU2NoZW1hLFxyXG4gICAgRGF0YUV2ZW50cyxcclxuICAgIGFueSxcclxuICAgIFJlc29sdmVUeXBlZ2VuTWV0YTxUeXBlZ2VuRGlzYWJsZWQsIERhdGFFdmVudHMsIEJhc2VBY3Rpb25PYmplY3QsIFNlcnZpY2VNYXA+XHJcbiAgPjtcclxufVxyXG5cclxuY29uc3QgTWFpbkxheW91dDogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2hpbGRyZW4sIG5vdGlmaWNhdGlvbnNTZXJ2aWNlLCBhdXRoU2VydmljZSB9KSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpO1xyXG4gIGNvbnN0IFtkcmF3ZXJTdGF0ZSwgc2VuZERyYXdlcl0gPSB1c2VNYWNoaW5lKGRyYXdlck1hY2hpbmUpO1xyXG5cclxuICBjb25zdCBhYm92ZVNtYWxsQnJlYWtwb2ludCA9IHVzZU1lZGlhUXVlcnkodGhlbWUuYnJlYWtwb2ludHMudXAoXCJzbVwiKSk7XHJcbiAgY29uc3QgeHNCcmVha3BvaW50ID0gdXNlTWVkaWFRdWVyeSh0aGVtZS5icmVha3BvaW50cy5vbmx5KFwieHNcIikpO1xyXG5cclxuICBjb25zdCBkZXNrdG9wRHJhd2VyT3BlbiA9IGRyYXdlclN0YXRlPy5tYXRjaGVzKHsgZGVza3RvcDogXCJvcGVuXCIgfSk7XHJcbiAgY29uc3QgbW9iaWxlRHJhd2VyT3BlbiA9IGRyYXdlclN0YXRlPy5tYXRjaGVzKHsgbW9iaWxlOiBcIm9wZW5cIiB9KTtcclxuICBjb25zdCB0b2dnbGVEZXNrdG9wRHJhd2VyID0gKCkgPT4ge1xyXG4gICAgc2VuZERyYXdlcihcIlRPR0dMRV9ERVNLVE9QXCIpO1xyXG4gIH07XHJcbiAgY29uc3QgdG9nZ2xlTW9iaWxlRHJhd2VyID0gKCkgPT4ge1xyXG4gICAgc2VuZERyYXdlcihcIlRPR0dMRV9NT0JJTEVcIik7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb3BlbkRlc2t0b3BEcmF3ZXIgPSAocGF5bG9hZDogYW55KSA9PiBzZW5kRHJhd2VyKFwiT1BFTl9ERVNLVE9QXCIsIHBheWxvYWQpO1xyXG4gIGNvbnN0IGNsb3NlTW9iaWxlRHJhd2VyID0gKCkgPT4gc2VuZERyYXdlcihcIkNMT1NFX01PQklMRVwiKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGlmICghZGVza3RvcERyYXdlck9wZW4gJiYgYWJvdmVTbWFsbEJyZWFrcG9pbnQpIHtcclxuICAgICAgb3BlbkRlc2t0b3BEcmF3ZXIoeyBhYm92ZVNtYWxsQnJlYWtwb2ludCB9KTtcclxuICAgIH1cclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSByZWFjdC1ob29rcy9leGhhdXN0aXZlLWRlcHNcclxuICB9LCBbYWJvdmVTbWFsbEJyZWFrcG9pbnQsIGRlc2t0b3BEcmF3ZXJPcGVuXSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8Um9vdD5cclxuICAgICAgPE5hdkJhclxyXG4gICAgICAgIHRvZ2dsZURyYXdlcj17eHNCcmVha3BvaW50ID8gdG9nZ2xlTW9iaWxlRHJhd2VyIDogdG9nZ2xlRGVza3RvcERyYXdlcn1cclxuICAgICAgICBkcmF3ZXJPcGVuPXt4c0JyZWFrcG9pbnQgPyBtb2JpbGVEcmF3ZXJPcGVuIDogZGVza3RvcERyYXdlck9wZW59XHJcbiAgICAgICAgbm90aWZpY2F0aW9uc1NlcnZpY2U9e25vdGlmaWNhdGlvbnNTZXJ2aWNlfVxyXG4gICAgICAvPlxyXG4gICAgICA8TmF2RHJhd2VyXHJcbiAgICAgICAgdG9nZ2xlRHJhd2VyPXt4c0JyZWFrcG9pbnQgPyB0b2dnbGVNb2JpbGVEcmF3ZXIgOiB0b2dnbGVEZXNrdG9wRHJhd2VyfVxyXG4gICAgICAgIGRyYXdlck9wZW49e3hzQnJlYWtwb2ludCA/IG1vYmlsZURyYXdlck9wZW4gOiBkZXNrdG9wRHJhd2VyT3Blbn1cclxuICAgICAgICBjbG9zZU1vYmlsZURyYXdlcj17Y2xvc2VNb2JpbGVEcmF3ZXJ9XHJcbiAgICAgICAgYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfVxyXG4gICAgICAvPlxyXG4gICAgICA8bWFpbiBjbGFzc05hbWU9e2NsYXNzZXMuY29udGVudH0gZGF0YS10ZXN0PVwibWFpblwiPlxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtjbGFzc2VzLmFwcEJhclNwYWNlcn0gLz5cclxuICAgICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwibWRcIiBjbGFzc05hbWU9e2NsYXNzZXMuY29udGFpbmVyfT5cclxuICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXszfT5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9PlxyXG4gICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgIDxmb290ZXI+XHJcbiAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgPC9mb290ZXI+XHJcbiAgICAgIDwvbWFpbj5cclxuICAgIDwvUm9vdD5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTWFpbkxheW91dDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9NYWluTGF5b3V0LnRzeCJ9