import {
  InterpreterStatus,
  State,
  interpret,
  spawnBehavior,
  toObserver
} from "/node_modules/.vite/deps/chunk-5ACMDFWS.js?v=6af76b79";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=6af76b79";
import {
  __commonJS,
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";

// node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js
var require_use_sync_external_store_shim_development = __commonJS({
  "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim.development.js"(exports) {
    "use strict";
    (function() {
      function is2(x, y) {
        return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
      }
      function useSyncExternalStore$2(subscribe, getSnapshot) {
        didWarnOld18Alpha || void 0 === React3.startTransition || (didWarnOld18Alpha = true, console.error(
          "You are using an outdated, pre-release alpha of React 18 that does not support useSyncExternalStore. The use-sync-external-store shim will not work correctly. Upgrade to a newer pre-release."
        ));
        var value = getSnapshot();
        if (!didWarnUncachedGetSnapshot) {
          var cachedValue = getSnapshot();
          objectIs(value, cachedValue) || (console.error(
            "The result of getSnapshot should be cached to avoid an infinite loop"
          ), didWarnUncachedGetSnapshot = true);
        }
        cachedValue = useState2({
          inst: { value, getSnapshot }
        });
        var inst = cachedValue[0].inst, forceUpdate = cachedValue[1];
        useLayoutEffect2(
          function() {
            inst.value = value;
            inst.getSnapshot = getSnapshot;
            checkIfSnapshotChanged(inst) && forceUpdate({ inst });
          },
          [subscribe, value, getSnapshot]
        );
        useEffect3(
          function() {
            checkIfSnapshotChanged(inst) && forceUpdate({ inst });
            return subscribe(function() {
              checkIfSnapshotChanged(inst) && forceUpdate({ inst });
            });
          },
          [subscribe]
        );
        useDebugValue(value);
        return value;
      }
      function checkIfSnapshotChanged(inst) {
        var latestGetSnapshot = inst.getSnapshot;
        inst = inst.value;
        try {
          var nextValue = latestGetSnapshot();
          return !objectIs(inst, nextValue);
        } catch (error) {
          return true;
        }
      }
      function useSyncExternalStore$1(subscribe, getSnapshot) {
        return getSnapshot();
      }
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var React3 = require_react(), objectIs = "function" === typeof Object.is ? Object.is : is2, useState2 = React3.useState, useEffect3 = React3.useEffect, useLayoutEffect2 = React3.useLayoutEffect, useDebugValue = React3.useDebugValue, didWarnOld18Alpha = false, didWarnUncachedGetSnapshot = false, shim = "undefined" === typeof window || "undefined" === typeof window.document || "undefined" === typeof window.document.createElement ? useSyncExternalStore$1 : useSyncExternalStore$2;
      exports.useSyncExternalStore = void 0 !== React3.useSyncExternalStore ? React3.useSyncExternalStore : shim;
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  }
});

// node_modules/use-sync-external-store/shim/index.js
var require_shim = __commonJS({
  "node_modules/use-sync-external-store/shim/index.js"(exports, module) {
    "use strict";
    if (false) {
      module.exports = null;
    } else {
      module.exports = require_use_sync_external_store_shim_development();
    }
  }
});

// node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js
var require_with_selector_development = __commonJS({
  "node_modules/use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js"(exports) {
    "use strict";
    (function() {
      function is2(x, y) {
        return x === y && (0 !== x || 1 / x === 1 / y) || x !== x && y !== y;
      }
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStart(Error());
      var React3 = require_react(), shim = require_shim(), objectIs = "function" === typeof Object.is ? Object.is : is2, useSyncExternalStore = shim.useSyncExternalStore, useRef4 = React3.useRef, useEffect3 = React3.useEffect, useMemo = React3.useMemo, useDebugValue = React3.useDebugValue;
      exports.useSyncExternalStoreWithSelector = function(subscribe, getSnapshot, getServerSnapshot, selector, isEqual) {
        var instRef = useRef4(null);
        if (null === instRef.current) {
          var inst = { hasValue: false, value: null };
          instRef.current = inst;
        } else
          inst = instRef.current;
        instRef = useMemo(
          function() {
            function memoizedSelector(nextSnapshot) {
              if (!hasMemo) {
                hasMemo = true;
                memoizedSnapshot = nextSnapshot;
                nextSnapshot = selector(nextSnapshot);
                if (void 0 !== isEqual && inst.hasValue) {
                  var currentSelection = inst.value;
                  if (isEqual(currentSelection, nextSnapshot))
                    return memoizedSelection = currentSelection;
                }
                return memoizedSelection = nextSnapshot;
              }
              currentSelection = memoizedSelection;
              if (objectIs(memoizedSnapshot, nextSnapshot))
                return currentSelection;
              var nextSelection = selector(nextSnapshot);
              if (void 0 !== isEqual && isEqual(currentSelection, nextSelection))
                return memoizedSnapshot = nextSnapshot, currentSelection;
              memoizedSnapshot = nextSnapshot;
              return memoizedSelection = nextSelection;
            }
            var hasMemo = false, memoizedSnapshot, memoizedSelection, maybeGetServerSnapshot = void 0 === getServerSnapshot ? null : getServerSnapshot;
            return [
              function() {
                return memoizedSelector(getSnapshot());
              },
              null === maybeGetServerSnapshot ? void 0 : function() {
                return memoizedSelector(maybeGetServerSnapshot());
              }
            ];
          },
          [getSnapshot, getServerSnapshot, selector, isEqual]
        );
        var value = useSyncExternalStore(subscribe, instRef[0], instRef[1]);
        useEffect3(
          function() {
            inst.hasValue = true;
            inst.value = value;
          },
          [value]
        );
        useDebugValue(value);
        return value;
      };
      "undefined" !== typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ && "function" === typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop && __REACT_DEVTOOLS_GLOBAL_HOOK__.registerInternalModuleStop(Error());
    })();
  }
});

// node_modules/use-sync-external-store/shim/with-selector.js
var require_with_selector = __commonJS({
  "node_modules/use-sync-external-store/shim/with-selector.js"(exports, module) {
    "use strict";
    if (false) {
      module.exports = null;
    } else {
      module.exports = require_with_selector_development();
    }
  }
});

// node_modules/@xstate/react/es/useMachine.js
var import_react3 = __toESM(require_react());
var import_with_selector = __toESM(require_with_selector());

// node_modules/@xstate/react/es/useInterpret.js
var import_react2 = __toESM(require_react());

// node_modules/use-isomorphic-layout-effect/dist/use-isomorphic-layout-effect.browser.esm.js
var import_react = __toESM(require_react());
var index = import_react.useLayoutEffect;

// node_modules/@xstate/react/es/useConstant.js
var React = __toESM(require_react());
function useConstant(fn) {
  var ref = React.useRef();
  if (!ref.current) {
    ref.current = { v: fn() };
  }
  return ref.current.v;
}

// node_modules/@xstate/react/es/useInterpret.js
var __assign = function() {
  __assign = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
var __rest = function(s, e) {
  var t = {};
  for (var p in s)
    if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
      t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
};
var __read = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
function useIdleInterpreter(getMachine, options) {
  var machine = useConstant(function() {
    return typeof getMachine === "function" ? getMachine() : getMachine;
  });
  if (typeof getMachine !== "function") {
    var _a = __read((0, import_react2.useState)(machine), 1), initialMachine = _a[0];
    if (getMachine !== initialMachine) {
      console.warn("Machine given to `useMachine` has changed between renders. This is not supported and might lead to unexpected results.\nPlease make sure that you pass the same Machine as argument each time.");
    }
  }
  var context = options.context, guards = options.guards, actions = options.actions, activities = options.activities, services = options.services, delays = options.delays, rehydratedState = options.state, interpreterOptions = __rest(options, ["context", "guards", "actions", "activities", "services", "delays", "state"]);
  var service = useConstant(function() {
    var machineConfig = {
      context,
      guards,
      actions,
      activities,
      services,
      delays
    };
    var machineWithConfig = machine.withConfig(machineConfig, function() {
      return __assign(__assign({}, machine.context), context);
    });
    return interpret(machineWithConfig, interpreterOptions);
  });
  index(function() {
    Object.assign(service.machine.options.actions, actions);
    Object.assign(service.machine.options.guards, guards);
    Object.assign(service.machine.options.activities, activities);
    Object.assign(service.machine.options.services, services);
    Object.assign(service.machine.options.delays, delays);
  }, [actions, guards, activities, services, delays]);
  return service;
}
function useInterpret(getMachine) {
  var _a = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    _a[_i - 1] = arguments[_i];
  }
  var _b = __read(_a, 2), _c = _b[0], options = _c === void 0 ? {} : _c, observerOrListener = _b[1];
  var service = useIdleInterpreter(getMachine, options);
  (0, import_react2.useEffect)(function() {
    if (!observerOrListener) {
      return;
    }
    var sub = service.subscribe(toObserver(observerOrListener));
    return function() {
      sub.unsubscribe();
    };
  }, [observerOrListener]);
  (0, import_react2.useEffect)(function() {
    var rehydratedState = options.state;
    service.start(rehydratedState ? State.create(rehydratedState) : void 0);
    return function() {
      service.stop();
      service.status = InterpreterStatus.NotStarted;
    };
  }, []);
  return service;
}

// node_modules/@xstate/react/es/utils.js
function getServiceSnapshot(service) {
  return service.status !== 0 ? service.getSnapshot() : service.machine.initialState;
}
function is(x, y) {
  if (x === y) {
    return x !== 0 || y !== 0 || 1 / x === 1 / y;
  } else {
    return x !== x && y !== y;
  }
}
function shallowEqual(objA, objB) {
  if (is(objA, objB))
    return true;
  if (typeof objA !== "object" || objA === null || typeof objB !== "object" || objB === null) {
    return false;
  }
  var keysA = Object.keys(objA);
  var keysB = Object.keys(objB);
  if (keysA.length !== keysB.length)
    return false;
  for (var i = 0; i < keysA.length; i++) {
    if (!Object.prototype.hasOwnProperty.call(objB, keysA[i]) || !is(objA[keysA[i]], objB[keysA[i]])) {
      return false;
    }
  }
  return true;
}
function isService(actor) {
  return "state" in actor && "machine" in actor;
}
function isInterpreterStateEqual(service, prevState, nextState) {
  if (service.status === InterpreterStatus.NotStarted) {
    return true;
  }
  var initialStateChanged = nextState.changed === void 0 && (Object.keys(nextState.children).length > 0 || typeof prevState.changed === "boolean");
  return !(nextState.changed || initialStateChanged);
}

// node_modules/@xstate/react/es/useMachine.js
var __read2 = function(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m)
    return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done)
      ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"]))
        m.call(i);
    } finally {
      if (e)
        throw e.error;
    }
  }
  return ar;
};
function identity(a) {
  return a;
}
function useMachine(getMachine) {
  var _a = [];
  for (var _i = 1; _i < arguments.length; _i++) {
    _a[_i - 1] = arguments[_i];
  }
  var _b = __read2(_a, 1), _c = _b[0], options = _c === void 0 ? {} : _c;
  var service = useIdleInterpreter(getMachine, options);
  var getSnapshot = (0, import_react3.useCallback)(function() {
    if (service.status === InterpreterStatus.NotStarted) {
      return options.state ? State.create(options.state) : service.machine.initialState;
    }
    return service.getSnapshot();
  }, [service]);
  var isEqual = (0, import_react3.useCallback)(function(prevState, nextState) {
    return isInterpreterStateEqual(service, prevState, nextState);
  }, [service]);
  var subscribe = (0, import_react3.useCallback)(function(handleStoreChange) {
    var unsubscribe = service.subscribe(handleStoreChange).unsubscribe;
    return unsubscribe;
  }, [service]);
  var storeSnapshot = (0, import_with_selector.useSyncExternalStoreWithSelector)(subscribe, getSnapshot, getSnapshot, identity, isEqual);
  (0, import_react3.useEffect)(function() {
    var rehydratedState = options.state;
    service.start(rehydratedState ? State.create(rehydratedState) : void 0);
    return function() {
      service.stop();
      service.status = InterpreterStatus.NotStarted;
    };
  }, []);
  return [storeSnapshot, service.send, service];
}

// node_modules/@xstate/react/es/useActor.js
var import_react4 = __toESM(require_react());
var import_with_selector2 = __toESM(require_with_selector());
function identity2(a) {
  return a;
}
function isActorWithState(actorRef) {
  return "state" in actorRef;
}
function isDeferredActor(actorRef) {
  return "deferred" in actorRef;
}
function defaultGetSnapshot(actorRef) {
  return "getSnapshot" in actorRef ? isService(actorRef) ? getServiceSnapshot(actorRef) : actorRef.getSnapshot() : isActorWithState(actorRef) ? actorRef.state : void 0;
}
function useActor(actorRef, getSnapshot) {
  if (getSnapshot === void 0) {
    getSnapshot = defaultGetSnapshot;
  }
  var actorRefRef = (0, import_react4.useRef)(actorRef);
  var deferredEventsRef = (0, import_react4.useRef)([]);
  var subscribe = (0, import_react4.useCallback)(function(handleStoreChange) {
    var unsubscribe = actorRef.subscribe(handleStoreChange).unsubscribe;
    return unsubscribe;
  }, [actorRef]);
  var boundGetSnapshot = (0, import_react4.useCallback)(function() {
    return getSnapshot(actorRef);
  }, [actorRef, getSnapshot]);
  var isEqual = (0, import_react4.useCallback)(function(prevState, nextState) {
    if (isService(actorRef)) {
      return isInterpreterStateEqual(actorRef, prevState, nextState);
    }
    return prevState === nextState;
  }, [actorRef]);
  var storeSnapshot = (0, import_with_selector2.useSyncExternalStoreWithSelector)(subscribe, boundGetSnapshot, boundGetSnapshot, identity2, isEqual);
  var send = useConstant(function() {
    return function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      var event = args[0];
      if (args.length > 1) {
        console.warn("Unexpected payload: ".concat(JSON.stringify(args[1]), ". Only a single event object can be sent to actor send() functions."));
      }
      var currentActorRef = actorRefRef.current;
      if (isDeferredActor(currentActorRef) && currentActorRef.deferred) {
        deferredEventsRef.current.push(event);
      } else {
        currentActorRef.send(event);
      }
    };
  });
  index(function() {
    actorRefRef.current = actorRef;
    while (deferredEventsRef.current.length > 0) {
      var deferredEvent = deferredEventsRef.current.shift();
      actorRef.send(deferredEvent);
    }
  }, [actorRef]);
  return [storeSnapshot, send];
}

// node_modules/@xstate/react/es/useSelector.js
var import_react5 = __toESM(require_react());
var import_with_selector3 = __toESM(require_with_selector());
var defaultCompare = function(a, b) {
  return a === b;
};
var defaultGetSnapshot2 = function(a, initialStateCacheRef) {
  if (isService(a)) {
    if (a.status === 0 && initialStateCacheRef.current) {
      return initialStateCacheRef.current;
    }
    var snapshot = getServiceSnapshot(a);
    initialStateCacheRef.current = a.status === 0 ? snapshot : null;
    return snapshot;
  }
  return isActorWithState(a) ? a.state : void 0;
};
function useSelector(actor, selector, compare, getSnapshot) {
  if (compare === void 0) {
    compare = defaultCompare;
  }
  var initialStateCacheRef = (0, import_react5.useRef)(null);
  var subscribe = (0, import_react5.useCallback)(function(handleStoreChange) {
    var unsubscribe = actor.subscribe(handleStoreChange).unsubscribe;
    return unsubscribe;
  }, [actor]);
  var boundGetSnapshot = (0, import_react5.useCallback)(function() {
    if (getSnapshot) {
      return getSnapshot(actor);
    }
    return defaultGetSnapshot2(actor, initialStateCacheRef);
  }, [actor, getSnapshot]);
  var selectedSnapshot = (0, import_with_selector3.useSyncExternalStoreWithSelector)(subscribe, boundGetSnapshot, boundGetSnapshot, selector, compare);
  return selectedSnapshot;
}

// node_modules/@xstate/react/es/useSpawn.js
function useSpawn(behavior) {
  var actorRef = useConstant(function() {
    return spawnBehavior(behavior);
  });
  return actorRef;
}

// node_modules/@xstate/react/es/createActorContext.js
var React2 = __toESM(require_react());
var __assign2 = function() {
  __assign2 = Object.assign || function(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s)
        if (Object.prototype.hasOwnProperty.call(s, p))
          t[p] = s[p];
    }
    return t;
  };
  return __assign2.apply(this, arguments);
};
function createActorContext(machine, interpreterOptions, observerOrListener) {
  var ReactContext = React2.createContext(null);
  var OriginalProvider = ReactContext.Provider;
  function Provider(_a) {
    var children = _a.children, _b = _a.machine, providedMachine = _b === void 0 ? machine : _b, options = _a.options;
    var actor = useInterpret(providedMachine, __assign2(__assign2({}, interpreterOptions), options), observerOrListener);
    return React2.createElement(OriginalProvider, { value: actor }, children);
  }
  Provider.displayName = "ActorProvider(".concat(machine.id, ")");
  function useContext2() {
    var actor = React2.useContext(ReactContext);
    if (!actor) {
      throw new Error('You used a hook from "'.concat(Provider.displayName, `" but it's not inside a <`).concat(Provider.displayName, "> component."));
    }
    return actor;
  }
  function useActor2() {
    var actor = useContext2();
    return useActor(actor);
  }
  function useSelector2(selector, compare) {
    var actor = useContext2();
    return useSelector(actor, selector, compare);
  }
  return {
    Provider,
    useActorRef: useContext2,
    useActor: useActor2,
    useSelector: useSelector2
  };
}
export {
  createActorContext,
  shallowEqual,
  useActor,
  useInterpret,
  useMachine,
  useSelector,
  useSpawn
};
/*! Bundled license information:

use-sync-external-store/cjs/use-sync-external-store-shim.development.js:
  (**
   * @license React
   * use-sync-external-store-shim.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)

use-sync-external-store/cjs/use-sync-external-store-shim/with-selector.development.js:
  (**
   * @license React
   * use-sync-external-store-shim/with-selector.development.js
   *
   * Copyright (c) Meta Platforms, Inc. and affiliates.
   *
   * This source code is licensed under the MIT license found in the
   * LICENSE file in the root directory of this source tree.
   *)
*/
//# sourceMappingURL=@xstate_react.js.map
