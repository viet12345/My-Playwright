import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionPersonalList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPersonalList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import TransactionList from "/src/components/TransactionList.tsx";
import { personalTransactionsMachine } from "/src/machines/personalTransactionsMachine.ts";
const TransactionPersonalList = ({
  filterComponent,
  dateRangeFilters,
  amountRangeFilters
}) => {
  _s();
  const [current, send, personalTransactionService] = useMachine(personalTransactionsMachine);
  const { pageData, results } = current.context;
  if (window.Cypress) {
    window.personalTransactionService = personalTransactionService;
  }
  useEffect(() => {
    send("FETCH", { ...dateRangeFilters, ...amountRangeFilters });
  }, [send, dateRangeFilters, amountRangeFilters]);
  const loadNextPage = (page) => send("FETCH", { page, ...dateRangeFilters, ...amountRangeFilters });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
    TransactionList,
    {
      filterComponent,
      header: "Personal",
      transactions: results,
      isLoading: current.matches("loading"),
      loadNextPage,
      pagination: pageData,
      showCreateButton: true
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPersonalList.tsx",
      lineNumber: 41,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPersonalList.tsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_s(TransactionPersonalList, "o325ojOgMGdnXzOdBSYjIzeb3rI=", false, function() {
  return [useMachine];
});
_c = TransactionPersonalList;
export default TransactionPersonalList;
var _c;
$RefreshReg$(_c, "TransactionPersonalList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPersonalList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionPersonalList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNJLG1CQUNFLGNBREY7MkJBdkNKO0FBQWdCQSxNQUFXQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsU0FBU0Msa0JBQWtCO0FBTzNCLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxtQ0FBbUM7QUFRNUMsTUFBTUMsMEJBQWtFQSxDQUFDO0FBQUEsRUFDdkVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxTQUFTQyxNQUFNQywwQkFBMEIsSUFBSVYsV0FBV0UsMkJBQTJCO0FBQzFGLFFBQU0sRUFBRVMsVUFBVUMsUUFBUSxJQUFJSixRQUFRSztBQUd0QyxNQUFJQyxPQUFPQyxTQUFTO0FBRWxCRCxXQUFPSiw2QkFBNkJBO0FBQUFBLEVBQ3RDO0FBRUFaLFlBQVUsTUFBTTtBQUNkVyxTQUFLLFNBQVMsRUFBRSxHQUFHSixrQkFBa0IsR0FBR0MsbUJBQW1CLENBQUM7QUFBQSxFQUM5RCxHQUFHLENBQUNHLE1BQU1KLGtCQUFrQkMsa0JBQWtCLENBQUM7QUFFL0MsUUFBTVUsZUFBZUEsQ0FBQ0MsU0FDcEJSLEtBQUssU0FBUyxFQUFFUSxNQUFNLEdBQUdaLGtCQUFrQixHQUFHQyxtQkFBbUIsQ0FBQztBQUVwRSxTQUNFLG1DQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsUUFBTztBQUFBLE1BQ1AsY0FBY007QUFBQUEsTUFDZCxXQUFXSixRQUFRVSxRQUFRLFNBQVM7QUFBQSxNQUNwQztBQUFBLE1BQ0EsWUFBWVA7QUFBQUEsTUFDWixrQkFBa0I7QUFBQTtBQUFBLElBUHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU95QixLQVIzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFFSixHQWxDSUoseUJBQStEO0FBQUEsVUFLZkgsVUFBVTtBQUFBO0FBQUFtQixLQUwxRGhCO0FBb0NOLGVBQWVBO0FBQXdCLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiUmVhY3ROb2RlIiwidXNlTWFjaGluZSIsIlRyYW5zYWN0aW9uTGlzdCIsInBlcnNvbmFsVHJhbnNhY3Rpb25zTWFjaGluZSIsIlRyYW5zYWN0aW9uUGVyc29uYWxMaXN0IiwiZmlsdGVyQ29tcG9uZW50IiwiZGF0ZVJhbmdlRmlsdGVycyIsImFtb3VudFJhbmdlRmlsdGVycyIsIl9zIiwiY3VycmVudCIsInNlbmQiLCJwZXJzb25hbFRyYW5zYWN0aW9uU2VydmljZSIsInBhZ2VEYXRhIiwicmVzdWx0cyIsImNvbnRleHQiLCJ3aW5kb3ciLCJDeXByZXNzIiwibG9hZE5leHRQYWdlIiwicGFnZSIsIm1hdGNoZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uUGVyc29uYWxMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0LCBSZWFjdE5vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTWFjaGluZSB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgVHJhbnNhY3Rpb25QYWdpbmF0aW9uLFxyXG4gIFRyYW5zYWN0aW9uUmVzcG9uc2VJdGVtLFxyXG4gIFRyYW5zYWN0aW9uRGF0ZVJhbmdlUGF5bG9hZCxcclxuICBUcmFuc2FjdGlvbkFtb3VudFJhbmdlUGF5bG9hZCxcclxufSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvbkxpc3QgZnJvbSBcIi4vVHJhbnNhY3Rpb25MaXN0XCI7XHJcbmltcG9ydCB7IHBlcnNvbmFsVHJhbnNhY3Rpb25zTWFjaGluZSB9IGZyb20gXCIuLi9tYWNoaW5lcy9wZXJzb25hbFRyYW5zYWN0aW9uc01hY2hpbmVcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25QZXJzb25hbExpc3RQcm9wcyB7XHJcbiAgZmlsdGVyQ29tcG9uZW50OiBSZWFjdE5vZGU7XHJcbiAgZGF0ZVJhbmdlRmlsdGVyczogVHJhbnNhY3Rpb25EYXRlUmFuZ2VQYXlsb2FkO1xyXG4gIGFtb3VudFJhbmdlRmlsdGVyczogVHJhbnNhY3Rpb25BbW91bnRSYW5nZVBheWxvYWQ7XHJcbn1cclxuXHJcbmNvbnN0IFRyYW5zYWN0aW9uUGVyc29uYWxMaXN0OiBSZWFjdC5GQzxUcmFuc2FjdGlvblBlcnNvbmFsTGlzdFByb3BzPiA9ICh7XHJcbiAgZmlsdGVyQ29tcG9uZW50LFxyXG4gIGRhdGVSYW5nZUZpbHRlcnMsXHJcbiAgYW1vdW50UmFuZ2VGaWx0ZXJzLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW2N1cnJlbnQsIHNlbmQsIHBlcnNvbmFsVHJhbnNhY3Rpb25TZXJ2aWNlXSA9IHVzZU1hY2hpbmUocGVyc29uYWxUcmFuc2FjdGlvbnNNYWNoaW5lKTtcclxuICBjb25zdCB7IHBhZ2VEYXRhLCByZXN1bHRzIH0gPSBjdXJyZW50LmNvbnRleHQ7XHJcblxyXG4gIC8vIEB0cy1pZ25vcmVcclxuICBpZiAod2luZG93LkN5cHJlc3MpIHtcclxuICAgIC8vIEB0cy1pZ25vcmVcclxuICAgIHdpbmRvdy5wZXJzb25hbFRyYW5zYWN0aW9uU2VydmljZSA9IHBlcnNvbmFsVHJhbnNhY3Rpb25TZXJ2aWNlO1xyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmQoXCJGRVRDSFwiLCB7IC4uLmRhdGVSYW5nZUZpbHRlcnMsIC4uLmFtb3VudFJhbmdlRmlsdGVycyB9KTtcclxuICB9LCBbc2VuZCwgZGF0ZVJhbmdlRmlsdGVycywgYW1vdW50UmFuZ2VGaWx0ZXJzXSk7XHJcblxyXG4gIGNvbnN0IGxvYWROZXh0UGFnZSA9IChwYWdlOiBudW1iZXIpID0+XHJcbiAgICBzZW5kKFwiRkVUQ0hcIiwgeyBwYWdlLCAuLi5kYXRlUmFuZ2VGaWx0ZXJzLCAuLi5hbW91bnRSYW5nZUZpbHRlcnMgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8VHJhbnNhY3Rpb25MaXN0XHJcbiAgICAgICAgZmlsdGVyQ29tcG9uZW50PXtmaWx0ZXJDb21wb25lbnR9XHJcbiAgICAgICAgaGVhZGVyPVwiUGVyc29uYWxcIlxyXG4gICAgICAgIHRyYW5zYWN0aW9ucz17cmVzdWx0cyBhcyBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbVtdfVxyXG4gICAgICAgIGlzTG9hZGluZz17Y3VycmVudC5tYXRjaGVzKFwibG9hZGluZ1wiKX1cclxuICAgICAgICBsb2FkTmV4dFBhZ2U9e2xvYWROZXh0UGFnZX1cclxuICAgICAgICBwYWdpbmF0aW9uPXtwYWdlRGF0YSBhcyBUcmFuc2FjdGlvblBhZ2luYXRpb259XHJcbiAgICAgICAgc2hvd0NyZWF0ZUJ1dHRvbj17dHJ1ZX1cclxuICAgICAgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvblBlcnNvbmFsTGlzdDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvblBlcnNvbmFsTGlzdC50c3gifQ==