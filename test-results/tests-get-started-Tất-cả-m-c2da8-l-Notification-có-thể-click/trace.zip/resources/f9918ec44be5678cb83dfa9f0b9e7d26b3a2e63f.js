import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionDetail.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Button, Typography, Grid, Avatar, Paper, IconButton } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { AvatarGroup } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { ThumbUpAltOutlined as LikeIcon, CommentRounded as CommentIcon } from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import { TransactionRequestStatus } from "/src/models/index.ts";
import CommentForm from "/src/components/CommentForm.tsx";
import {
  isPendingRequestTransaction,
  receiverIsCurrentUser,
  currentUserLikesTransaction
} from "/src/utils/transactionUtils.ts";
import CommentsList from "/src/components/CommentList.tsx";
import TransactionTitle from "/src/components/TransactionTitle.tsx";
import TransactionAmount from "/src/components/TransactionAmount.tsx";
const PREFIX = "TransactionDetail";
const classes = {
  paper: `${PREFIX}-paper`,
  paperComments: `${PREFIX}-paperComments`,
  avatar: `${PREFIX}-avatar`,
  headline: `${PREFIX}-headline`,
  avatarLarge: `${PREFIX}-avatarLarge`,
  avatarGroup: `${PREFIX}-avatarGroup`,
  redButton: `${PREFIX}-redButton`,
  greenButton: `${PREFIX}-greenButton`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  },
  [`& .${classes.paperComments}`]: {
    marginTop: theme.spacing(6),
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  },
  [`& .${classes.avatar}`]: {
    width: theme.spacing(2)
  },
  [`& .${classes.headline}`]: {
    marginTop: theme.spacing(4)
  },
  [`& .${classes.avatarLarge}`]: {
    width: theme.spacing(7),
    height: theme.spacing(7)
  },
  [`& .${classes.avatarGroup}`]: {
    margin: 10
  },
  [`& .${classes.redButton}`]: {
    backgrounColor: "red",
    color: "#ffffff",
    backgroundColor: "red",
    paddingTop: 5,
    paddingBottom: 5,
    paddingRight: 20,
    fontWeight: "bold",
    "&:hover": {
      backgroundColor: "red",
      borderColor: "red",
      boxShadow: "none"
    }
  },
  [`& .${classes.greenButton}`]: {
    marginRight: theme.spacing(2),
    color: "#ffffff",
    backgroundColor: "#00C853",
    paddingTop: 5,
    paddingBottom: 5,
    paddingRight: 20,
    fontWeight: "bold",
    "&:hover": {
      backgroundColor: "#4CAF50",
      borderColor: "#00C853",
      boxShadow: "none"
    }
  }
}));
_c = StyledPaper;
const TransactionDetail = ({
  transaction,
  transactionLike,
  transactionComment,
  transactionUpdate,
  currentUser
}) => {
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
    /* @__PURE__ */ jsxDEV(
      Typography,
      {
        component: "h2",
        variant: "h6",
        color: "primary",
        gutterBottom: true,
        "data-test": "transaction-detail-header",
        children: "Transaction Detail"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
        lineNumber: 111,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Grid,
      {
        container: true,
        direction: "row",
        justifyContent: "space-between",
        alignItems: "center",
        "data-test": `transaction-item-${transaction.id}`,
        children: [
          /* @__PURE__ */ jsxDEV(Grid, { item: true, className: classes.headline, children: [
            /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", children: [
              /* @__PURE__ */ jsxDEV(AvatarGroup, { className: classes.avatarGroup, max: 2, children: [
                /* @__PURE__ */ jsxDEV(
                  Avatar,
                  {
                    "data-test": "transaction-sender-avatar",
                    className: classes.avatarLarge,
                    src: transaction.senderAvatar
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                    lineNumber: 130,
                    columnNumber: 15
                  },
                  this
                ),
                /* @__PURE__ */ jsxDEV(
                  Avatar,
                  {
                    "data-test": "transaction-receiver-avatar",
                    className: classes.avatarLarge,
                    src: transaction.receiverAvatar
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                    lineNumber: 135,
                    columnNumber: 15
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 129,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, sx: { width: "100%" } }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 142,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 128,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "column", justifyContent: "flex-start", alignItems: "flex-start", children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 145,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(TransactionTitle, { transaction }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 147,
                columnNumber: 15
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 146,
                columnNumber: 13
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
                Typography,
                {
                  variant: "body2",
                  color: "textSecondary",
                  gutterBottom: true,
                  "data-test": "transaction-description",
                  children: transaction.description
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                  lineNumber: 150,
                  columnNumber: 15
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 149,
                columnNumber: 13
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 144,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
            lineNumber: 127,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(TransactionAmount, { transaction }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
            lineNumber: 162,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
            lineNumber: 161,
            columnNumber: 9
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
        lineNumber: 120,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", justifyContent: "flex-start", alignItems: "center", spacing: 2, children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: [
      /* @__PURE__ */ jsxDEV(
        Grid,
        {
          container: true,
          direction: "row",
          justifyContent: "flex-start",
          alignItems: "center",
          spacing: 2,
          children: [
            /* @__PURE__ */ jsxDEV(Grid, { item: true, "data-test": `transaction-like-count-${transaction.id}`, children: [
              transaction.likes ? transaction.likes.length : 0,
              " "
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 174,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
              IconButton,
              {
                color: "primary",
                disabled: currentUserLikesTransaction(currentUser, transaction),
                onClick: () => transactionLike(transaction.id),
                "data-test": `transaction-like-button-${transaction.id}`,
                size: "large",
                children: /* @__PURE__ */ jsxDEV(LikeIcon, {}, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                  lineNumber: 185,
                  columnNumber: 17
                }, this)
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                lineNumber: 178,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 177,
              columnNumber: 13
            }, this),
            /* @__PURE__ */ jsxDEV(Grid, { item: true, children: receiverIsCurrentUser(currentUser, transaction) && isPendingRequestTransaction(transaction) && /* @__PURE__ */ jsxDEV(Grid, { item: true, children: [
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  className: classes.greenButton,
                  variant: "contained",
                  size: "small",
                  onClick: () => transactionUpdate({
                    id: transaction.id,
                    requestStatus: TransactionRequestStatus.accepted
                  }),
                  "data-test": `transaction-accept-request-${transaction.id}`,
                  children: "Accept Request"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                  lineNumber: 192,
                  columnNumber: 21
                },
                this
              ),
              /* @__PURE__ */ jsxDEV(
                Button,
                {
                  variant: "contained",
                  className: classes.redButton,
                  size: "small",
                  onClick: () => transactionUpdate({
                    id: transaction.id,
                    requestStatus: TransactionRequestStatus.rejected
                  }),
                  "data-test": `transaction-reject-request-${transaction.id}`,
                  children: "Reject Request"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
                  lineNumber: 206,
                  columnNumber: 21
                },
                this
              )
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 191,
              columnNumber: 15
            }, this) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
              lineNumber: 188,
              columnNumber: 13
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
          lineNumber: 167,
          columnNumber: 11
        },
        this
      ),
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
        CommentForm,
        {
          transactionId: transaction.id,
          transactionComment: (payload) => transactionComment(payload)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
          lineNumber: 225,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
        lineNumber: 224,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
      lineNumber: 166,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
      lineNumber: 165,
      columnNumber: 7
    }, this),
    transaction.comments.length > 0 && /* @__PURE__ */ jsxDEV(Paper, { className: classes.paperComments, children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: [
        /* @__PURE__ */ jsxDEV(CommentIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
          lineNumber: 235,
          columnNumber: 13
        }, this),
        " Comments"
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
        lineNumber: 234,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(CommentsList, { comments: transaction.comments }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
        lineNumber: 237,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
      lineNumber: 233,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx",
    lineNumber: 110,
    columnNumber: 5
  }, this);
};
_c2 = TransactionDetail;
export default TransactionDetail;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "TransactionDetail");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDetail.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEdNO0FBOUdOLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsY0FBYztBQUN2QixTQUFTQyxRQUFRQyxZQUFZQyxNQUFNQyxRQUFRQyxPQUFPQyxrQkFBa0I7QUFDcEUsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLHNCQUFzQkMsVUFBVUMsa0JBQWtCQyxtQkFBbUI7QUFDOUUsU0FBa0NDLGdDQUFzQztBQUN4RSxPQUFPQyxpQkFBaUI7QUFDeEI7QUFBQSxFQUNFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxPQUNLO0FBQ1AsT0FBT0Msa0JBQWtCO0FBQ3pCLE9BQU9DLHNCQUFzQjtBQUM3QixPQUFPQyx1QkFBdUI7QUFFOUIsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFBQSxFQUNoQkcsZUFBZSxHQUFHSCxNQUFNO0FBQUEsRUFDeEJJLFFBQVEsR0FBR0osTUFBTTtBQUFBLEVBQ2pCSyxVQUFVLEdBQUdMLE1BQU07QUFBQSxFQUNuQk0sYUFBYSxHQUFHTixNQUFNO0FBQUEsRUFDdEJPLGFBQWEsR0FBR1AsTUFBTTtBQUFBLEVBQ3RCUSxXQUFXLEdBQUdSLE1BQU07QUFBQSxFQUNwQlMsYUFBYSxHQUFHVCxNQUFNO0FBQ3hCO0FBRUEsTUFBTVUsY0FBYzlCLE9BQU9LLEtBQUssRUFBRSxDQUFDLEVBQUUwQixNQUFNLE9BQU87QUFBQSxFQUNoRCxDQUFDLEtBQUtWLFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdEJVLFNBQVNELE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQ3hCQyxTQUFTO0FBQUEsSUFDVEMsVUFBVTtBQUFBLElBQ1ZDLGVBQWU7QUFBQSxFQUNqQjtBQUFBLEVBRUEsQ0FBQyxNQUFNZixRQUFRRSxhQUFhLEVBQUUsR0FBRztBQUFBLElBQy9CYyxXQUFXTixNQUFNRSxRQUFRLENBQUM7QUFBQSxJQUMxQkQsU0FBU0QsTUFBTUUsUUFBUSxDQUFDO0FBQUEsSUFDeEJDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsZUFBZTtBQUFBLEVBQ2pCO0FBQUEsRUFFQSxDQUFDLE1BQU1mLFFBQVFHLE1BQU0sRUFBRSxHQUFHO0FBQUEsSUFDeEJjLE9BQU9QLE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQ3hCO0FBQUEsRUFFQSxDQUFDLE1BQU1aLFFBQVFJLFFBQVEsRUFBRSxHQUFHO0FBQUEsSUFDMUJZLFdBQVdOLE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQzVCO0FBQUEsRUFFQSxDQUFDLE1BQU1aLFFBQVFLLFdBQVcsRUFBRSxHQUFHO0FBQUEsSUFDN0JZLE9BQU9QLE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQ3RCTSxRQUFRUixNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUN6QjtBQUFBLEVBRUEsQ0FBQyxNQUFNWixRQUFRTSxXQUFXLEVBQUUsR0FBRztBQUFBLElBQzdCYSxRQUFRO0FBQUEsRUFDVjtBQUFBLEVBRUEsQ0FBQyxNQUFNbkIsUUFBUU8sU0FBUyxFQUFFLEdBQUc7QUFBQSxJQUMzQmEsZ0JBQWdCO0FBQUEsSUFDaEJDLE9BQU87QUFBQSxJQUNQQyxpQkFBaUI7QUFBQSxJQUNqQkMsWUFBWTtBQUFBLElBQ1pDLGVBQWU7QUFBQSxJQUNmQyxjQUFjO0FBQUEsSUFDZEMsWUFBWTtBQUFBLElBQ1osV0FBVztBQUFBLE1BQ1RKLGlCQUFpQjtBQUFBLE1BQ2pCSyxhQUFhO0FBQUEsTUFDYkMsV0FBVztBQUFBLElBQ2I7QUFBQSxFQUNGO0FBQUEsRUFFQSxDQUFDLE1BQU01QixRQUFRUSxXQUFXLEVBQUUsR0FBRztBQUFBLElBQzdCcUIsYUFBYW5CLE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQzVCUyxPQUFPO0FBQUEsSUFDUEMsaUJBQWlCO0FBQUEsSUFDakJDLFlBQVk7QUFBQSxJQUNaQyxlQUFlO0FBQUEsSUFDZkMsY0FBYztBQUFBLElBQ2RDLFlBQVk7QUFBQSxJQUNaLFdBQVc7QUFBQSxNQUNUSixpQkFBaUI7QUFBQSxNQUNqQkssYUFBYTtBQUFBLE1BQ2JDLFdBQVc7QUFBQSxJQUNiO0FBQUEsRUFDRjtBQUNGLEVBQUU7QUFBRUUsS0E5REVyQjtBQXdFTixNQUFNc0Isb0JBQWdEQSxDQUFDO0FBQUEsRUFDckRDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUNKLFNBQ0UsdUJBQUMsZUFBWSxXQUFXcEMsUUFBUUMsT0FDOUI7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsV0FBVTtBQUFBLFFBQ1YsU0FBUTtBQUFBLFFBQ1IsT0FBTTtBQUFBLFFBQ047QUFBQSxRQUNBLGFBQVU7QUFBQSxRQUEyQjtBQUFBO0FBQUEsTUFMdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUUE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0EsV0FBVTtBQUFBLFFBQ1YsZ0JBQWU7QUFBQSxRQUNmLFlBQVc7QUFBQSxRQUNYLGFBQVcsb0JBQW9CK0IsWUFBWUssRUFBRTtBQUFBLFFBRTdDO0FBQUEsaUNBQUMsUUFBSyxNQUFJLE1BQUMsV0FBV3JDLFFBQVFJLFVBQzVCO0FBQUEsbUNBQUMsUUFBSyxXQUFTLE1BQUMsV0FBVSxPQUN4QjtBQUFBLHFDQUFDLGVBQVksV0FBV0osUUFBUU0sYUFBYSxLQUFLLEdBQ2hEO0FBQUE7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsYUFBVTtBQUFBLG9CQUNWLFdBQVdOLFFBQVFLO0FBQUFBLG9CQUNuQixLQUFLMkIsWUFBWU07QUFBQUE7QUFBQUEsa0JBSG5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFHZ0M7QUFBQSxnQkFFaEM7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsYUFBVTtBQUFBLG9CQUNWLFdBQVd0QyxRQUFRSztBQUFBQSxvQkFDbkIsS0FBSzJCLFlBQVlPO0FBQUFBO0FBQUFBLGtCQUhuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBR2tDO0FBQUEsbUJBVHBDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBV0E7QUFBQSxjQUVBLHVCQUFDLFFBQUssTUFBSSxNQUFDLElBQUksRUFBRXRCLE9BQU8sT0FBTyxLQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFpQztBQUFBLGlCQWRuQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLFdBQVMsTUFBQyxXQUFVLFVBQVMsZ0JBQWUsY0FBYSxZQUFXLGNBQ3hFO0FBQUEscUNBQUMsUUFBSyxNQUFJLFFBQVY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBVztBQUFBLGNBQ1gsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsb0JBQWlCLGVBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQTJDLEtBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLFNBQVE7QUFBQSxrQkFDUixPQUFNO0FBQUEsa0JBQ047QUFBQSxrQkFDQSxhQUFVO0FBQUEsa0JBRVRlLHNCQUFZUTtBQUFBQTtBQUFBQSxnQkFOZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FPQSxLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBU0E7QUFBQSxpQkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWVBO0FBQUEsZUFoQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpQ0E7QUFBQSxVQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLHFCQUFrQixlQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUE7QUFBQTtBQUFBLE1BM0NGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQTRDQTtBQUFBLElBQ0EsdUJBQUMsUUFBSyxXQUFTLE1BQUMsV0FBVSxPQUFNLGdCQUFlLGNBQWEsWUFBVyxVQUFTLFNBQVMsR0FDdkYsaUNBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBLFdBQVU7QUFBQSxVQUNWLGdCQUFlO0FBQUEsVUFDZixZQUFXO0FBQUEsVUFDWCxTQUFTO0FBQUEsVUFFVDtBQUFBLG1DQUFDLFFBQUssTUFBSSxNQUFDLGFBQVcsMEJBQTBCUixZQUFZSyxFQUFFLElBQzNETDtBQUFBQSwwQkFBWVMsUUFBUVQsWUFBWVMsTUFBTUMsU0FBUztBQUFBLGNBQUc7QUFBQSxpQkFEckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxPQUFNO0FBQUEsZ0JBQ04sVUFBVS9DLDRCQUE0QnlDLGFBQWFKLFdBQVc7QUFBQSxnQkFDOUQsU0FBUyxNQUFNQyxnQkFBZ0JELFlBQVlLLEVBQUU7QUFBQSxnQkFDN0MsYUFBVywyQkFBMkJMLFlBQVlLLEVBQUU7QUFBQSxnQkFDcEQsTUFBSztBQUFBLGdCQUVMLGlDQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBUztBQUFBO0FBQUEsY0FQWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVUE7QUFBQSxZQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNQM0MsZ0NBQXNCMEMsYUFBYUosV0FBVyxLQUM3Q3ZDLDRCQUE0QnVDLFdBQVcsS0FDckMsdUJBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQTtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxXQUFXaEMsUUFBUVE7QUFBQUEsa0JBQ25CLFNBQVE7QUFBQSxrQkFDUixNQUFLO0FBQUEsa0JBQ0wsU0FBUyxNQUNQMkIsa0JBQWtCO0FBQUEsb0JBQ2hCRSxJQUFJTCxZQUFZSztBQUFBQSxvQkFDaEJNLGVBQWVwRCx5QkFBeUJxRDtBQUFBQSxrQkFDMUMsQ0FBQztBQUFBLGtCQUVILGFBQVcsOEJBQThCWixZQUFZSyxFQUFFO0FBQUEsa0JBQUc7QUFBQTtBQUFBLGdCQVY1RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FhQTtBQUFBLGNBQ0E7QUFBQSxnQkFBQztBQUFBO0FBQUEsa0JBQ0MsU0FBUTtBQUFBLGtCQUNSLFdBQVdyQyxRQUFRTztBQUFBQSxrQkFDbkIsTUFBSztBQUFBLGtCQUNMLFNBQVMsTUFDUDRCLGtCQUFrQjtBQUFBLG9CQUNoQkUsSUFBSUwsWUFBWUs7QUFBQUEsb0JBQ2hCTSxlQUFlcEQseUJBQXlCc0Q7QUFBQUEsa0JBQzFDLENBQUM7QUFBQSxrQkFFSCxhQUFXLDhCQUE4QmIsWUFBWUssRUFBRTtBQUFBLGtCQUFHO0FBQUE7QUFBQSxnQkFWNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYUE7QUFBQSxpQkE1QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE2QkEsS0FoQ047QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFrQ0E7QUFBQTtBQUFBO0FBQUEsUUF2REY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1Bd0RBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLE1BQUksTUFDUjtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0MsZUFBZUwsWUFBWUs7QUFBQUEsVUFDM0Isb0JBQW9CLENBQUNTLFlBQVlaLG1CQUFtQlksT0FBTztBQUFBO0FBQUEsUUFGN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BRStELEtBSGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBL0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FnRUEsS0FqRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWtFQTtBQUFBLElBQ0NkLFlBQVllLFNBQVNMLFNBQVMsS0FDN0IsdUJBQUMsU0FBTSxXQUFXMUMsUUFBUUUsZUFDeEI7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssT0FBTSxXQUFVLGNBQVksTUFDbEU7QUFBQSwrQkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVk7QUFBQSxRQUFHO0FBQUEsV0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxVQUFVOEIsWUFBWWUsWUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QztBQUFBLFNBSi9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FLQTtBQUFBLE9BaElKO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrSUE7QUFFSjtBQUFFQyxNQTVJSWpCO0FBOElOLGVBQWVBO0FBQWtCLElBQUFELElBQUFrQjtBQUFBQyxhQUFBbkIsSUFBQTtBQUFBbUIsYUFBQUQsS0FBQSIsIm5hbWVzIjpbIlJlYWN0Iiwic3R5bGVkIiwiQnV0dG9uIiwiVHlwb2dyYXBoeSIsIkdyaWQiLCJBdmF0YXIiLCJQYXBlciIsIkljb25CdXR0b24iLCJBdmF0YXJHcm91cCIsIlRodW1iVXBBbHRPdXRsaW5lZCIsIkxpa2VJY29uIiwiQ29tbWVudFJvdW5kZWQiLCJDb21tZW50SWNvbiIsIlRyYW5zYWN0aW9uUmVxdWVzdFN0YXR1cyIsIkNvbW1lbnRGb3JtIiwiaXNQZW5kaW5nUmVxdWVzdFRyYW5zYWN0aW9uIiwicmVjZWl2ZXJJc0N1cnJlbnRVc2VyIiwiY3VycmVudFVzZXJMaWtlc1RyYW5zYWN0aW9uIiwiQ29tbWVudHNMaXN0IiwiVHJhbnNhY3Rpb25UaXRsZSIsIlRyYW5zYWN0aW9uQW1vdW50IiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwicGFwZXJDb21tZW50cyIsImF2YXRhciIsImhlYWRsaW5lIiwiYXZhdGFyTGFyZ2UiLCJhdmF0YXJHcm91cCIsInJlZEJ1dHRvbiIsImdyZWVuQnV0dG9uIiwiU3R5bGVkUGFwZXIiLCJ0aGVtZSIsInBhZGRpbmciLCJzcGFjaW5nIiwiZGlzcGxheSIsIm92ZXJmbG93IiwiZmxleERpcmVjdGlvbiIsIm1hcmdpblRvcCIsIndpZHRoIiwiaGVpZ2h0IiwibWFyZ2luIiwiYmFja2dyb3VuQ29sb3IiLCJjb2xvciIsImJhY2tncm91bmRDb2xvciIsInBhZGRpbmdUb3AiLCJwYWRkaW5nQm90dG9tIiwicGFkZGluZ1JpZ2h0IiwiZm9udFdlaWdodCIsImJvcmRlckNvbG9yIiwiYm94U2hhZG93IiwibWFyZ2luUmlnaHQiLCJfYyIsIlRyYW5zYWN0aW9uRGV0YWlsIiwidHJhbnNhY3Rpb24iLCJ0cmFuc2FjdGlvbkxpa2UiLCJ0cmFuc2FjdGlvbkNvbW1lbnQiLCJ0cmFuc2FjdGlvblVwZGF0ZSIsImN1cnJlbnRVc2VyIiwiaWQiLCJzZW5kZXJBdmF0YXIiLCJyZWNlaXZlckF2YXRhciIsImRlc2NyaXB0aW9uIiwibGlrZXMiLCJsZW5ndGgiLCJyZXF1ZXN0U3RhdHVzIiwiYWNjZXB0ZWQiLCJyZWplY3RlZCIsInBheWxvYWQiLCJjb21tZW50cyIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uRGV0YWlsLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBCdXR0b24sIFR5cG9ncmFwaHksIEdyaWQsIEF2YXRhciwgUGFwZXIsIEljb25CdXR0b24gfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBBdmF0YXJHcm91cCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IFRodW1iVXBBbHRPdXRsaW5lZCBhcyBMaWtlSWNvbiwgQ29tbWVudFJvdW5kZWQgYXMgQ29tbWVudEljb24gfSBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbSwgVHJhbnNhY3Rpb25SZXF1ZXN0U3RhdHVzLCBVc2VyIH0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5pbXBvcnQgQ29tbWVudEZvcm0gZnJvbSBcIi4vQ29tbWVudEZvcm1cIjtcclxuaW1wb3J0IHtcclxuICBpc1BlbmRpbmdSZXF1ZXN0VHJhbnNhY3Rpb24sXHJcbiAgcmVjZWl2ZXJJc0N1cnJlbnRVc2VyLFxyXG4gIGN1cnJlbnRVc2VyTGlrZXNUcmFuc2FjdGlvbixcclxufSBmcm9tIFwiLi4vdXRpbHMvdHJhbnNhY3Rpb25VdGlsc1wiO1xyXG5pbXBvcnQgQ29tbWVudHNMaXN0IGZyb20gXCIuL0NvbW1lbnRMaXN0XCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvblRpdGxlIGZyb20gXCIuL1RyYW5zYWN0aW9uVGl0bGVcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQW1vdW50IGZyb20gXCIuL1RyYW5zYWN0aW9uQW1vdW50XCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uRGV0YWlsXCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHBhcGVyOiBgJHtQUkVGSVh9LXBhcGVyYCxcclxuICBwYXBlckNvbW1lbnRzOiBgJHtQUkVGSVh9LXBhcGVyQ29tbWVudHNgLFxyXG4gIGF2YXRhcjogYCR7UFJFRklYfS1hdmF0YXJgLFxyXG4gIGhlYWRsaW5lOiBgJHtQUkVGSVh9LWhlYWRsaW5lYCxcclxuICBhdmF0YXJMYXJnZTogYCR7UFJFRklYfS1hdmF0YXJMYXJnZWAsXHJcbiAgYXZhdGFyR3JvdXA6IGAke1BSRUZJWH0tYXZhdGFyR3JvdXBgLFxyXG4gIHJlZEJ1dHRvbjogYCR7UFJFRklYfS1yZWRCdXR0b25gLFxyXG4gIGdyZWVuQnV0dG9uOiBgJHtQUkVGSVh9LWdyZWVuQnV0dG9uYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZFBhcGVyID0gc3R5bGVkKFBhcGVyKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMucGFwZXJ9YF06IHtcclxuICAgIHBhZGRpbmc6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgIG92ZXJmbG93OiBcImF1dG9cIixcclxuICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMucGFwZXJDb21tZW50c31gXToge1xyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDYpLFxyXG4gICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5hdmF0YXJ9YF06IHtcclxuICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmhlYWRsaW5lfWBdOiB7XHJcbiAgICBtYXJnaW5Ub3A6IHRoZW1lLnNwYWNpbmcoNCksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuYXZhdGFyTGFyZ2V9YF06IHtcclxuICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDcpLFxyXG4gICAgaGVpZ2h0OiB0aGVtZS5zcGFjaW5nKDcpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmF2YXRhckdyb3VwfWBdOiB7XHJcbiAgICBtYXJnaW46IDEwLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnJlZEJ1dHRvbn1gXToge1xyXG4gICAgYmFja2dyb3VuQ29sb3I6IFwicmVkXCIsXHJcbiAgICBjb2xvcjogXCIjZmZmZmZmXCIsXHJcbiAgICBiYWNrZ3JvdW5kQ29sb3I6IFwicmVkXCIsXHJcbiAgICBwYWRkaW5nVG9wOiA1LFxyXG4gICAgcGFkZGluZ0JvdHRvbTogNSxcclxuICAgIHBhZGRpbmdSaWdodDogMjAsXHJcbiAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZWRcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwicmVkXCIsXHJcbiAgICAgIGJveFNoYWRvdzogXCJub25lXCIsXHJcbiAgICB9LFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmdyZWVuQnV0dG9ufWBdOiB7XHJcbiAgICBtYXJnaW5SaWdodDogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGNvbG9yOiBcIiNmZmZmZmZcIixcclxuICAgIGJhY2tncm91bmRDb2xvcjogXCIjMDBDODUzXCIsXHJcbiAgICBwYWRkaW5nVG9wOiA1LFxyXG4gICAgcGFkZGluZ0JvdHRvbTogNSxcclxuICAgIHBhZGRpbmdSaWdodDogMjAsXHJcbiAgICBmb250V2VpZ2h0OiBcImJvbGRcIixcclxuICAgIFwiJjpob3ZlclwiOiB7XHJcbiAgICAgIGJhY2tncm91bmRDb2xvcjogXCIjNENBRjUwXCIsXHJcbiAgICAgIGJvcmRlckNvbG9yOiBcIiMwMEM4NTNcIixcclxuICAgICAgYm94U2hhZG93OiBcIm5vbmVcIixcclxuICAgIH0sXHJcbiAgfSxcclxufSkpO1xyXG5cclxudHlwZSBUcmFuc2FjdGlvblByb3BzID0ge1xyXG4gIHRyYW5zYWN0aW9uOiBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbTtcclxuICB0cmFuc2FjdGlvbkxpa2U6IEZ1bmN0aW9uO1xyXG4gIHRyYW5zYWN0aW9uQ29tbWVudDogRnVuY3Rpb247XHJcbiAgdHJhbnNhY3Rpb25VcGRhdGU6IEZ1bmN0aW9uO1xyXG4gIGN1cnJlbnRVc2VyOiBVc2VyO1xyXG59O1xyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25EZXRhaWw6IFJlYWN0LkZDPFRyYW5zYWN0aW9uUHJvcHM+ID0gKHtcclxuICB0cmFuc2FjdGlvbixcclxuICB0cmFuc2FjdGlvbkxpa2UsXHJcbiAgdHJhbnNhY3Rpb25Db21tZW50LFxyXG4gIHRyYW5zYWN0aW9uVXBkYXRlLFxyXG4gIGN1cnJlbnRVc2VyLFxyXG59KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRQYXBlciBjbGFzc05hbWU9e2NsYXNzZXMucGFwZXJ9PlxyXG4gICAgICA8VHlwb2dyYXBoeVxyXG4gICAgICAgIGNvbXBvbmVudD1cImgyXCJcclxuICAgICAgICB2YXJpYW50PVwiaDZcIlxyXG4gICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgZ3V0dGVyQm90dG9tXHJcbiAgICAgICAgZGF0YS10ZXN0PVwidHJhbnNhY3Rpb24tZGV0YWlsLWhlYWRlclwiXHJcbiAgICAgID5cclxuICAgICAgICBUcmFuc2FjdGlvbiBEZXRhaWxcclxuICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8R3JpZFxyXG4gICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgIGRpcmVjdGlvbj1cInJvd1wiXHJcbiAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICBkYXRhLXRlc3Q9e2B0cmFuc2FjdGlvbi1pdGVtLSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0gY2xhc3NOYW1lPXtjbGFzc2VzLmhlYWRsaW5lfT5cclxuICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBkaXJlY3Rpb249XCJyb3dcIj5cclxuICAgICAgICAgICAgPEF2YXRhckdyb3VwIGNsYXNzTmFtZT17Y2xhc3Nlcy5hdmF0YXJHcm91cH0gbWF4PXsyfT5cclxuICAgICAgICAgICAgICA8QXZhdGFyXHJcbiAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1zZW5kZXItYXZhdGFyXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5hdmF0YXJMYXJnZX1cclxuICAgICAgICAgICAgICAgIHNyYz17dHJhbnNhY3Rpb24uc2VuZGVyQXZhdGFyfVxyXG4gICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgPEF2YXRhclxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwidHJhbnNhY3Rpb24tcmVjZWl2ZXItYXZhdGFyXCJcclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5hdmF0YXJMYXJnZX1cclxuICAgICAgICAgICAgICAgIHNyYz17dHJhbnNhY3Rpb24ucmVjZWl2ZXJBdmF0YXJ9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9BdmF0YXJHcm91cD5cclxuICAgICAgICAgICAgey8qIGVhdCB1cCBzcGFjZSB0byByaWdodCBvZiBBdmF0YXJHcm91cDogKi99XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0gc3g9e3sgd2lkdGg6IFwiMTAwJVwiIH19IC8+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8R3JpZCBjb250YWluZXIgZGlyZWN0aW9uPVwiY29sdW1uXCIganVzdGlmeUNvbnRlbnQ9XCJmbGV4LXN0YXJ0XCIgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIj5cclxuICAgICAgICAgICAgPEdyaWQgaXRlbT48L0dyaWQ+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAgPFRyYW5zYWN0aW9uVGl0bGUgdHJhbnNhY3Rpb249e3RyYW5zYWN0aW9ufSAvPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJib2R5MlwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInRleHRTZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgZ3V0dGVyQm90dG9tXHJcbiAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1kZXNjcmlwdGlvblwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAge3RyYW5zYWN0aW9uLmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPFRyYW5zYWN0aW9uQW1vdW50IHRyYW5zYWN0aW9uPXt0cmFuc2FjdGlvbn0gLz5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgICAgPEdyaWQgY29udGFpbmVyIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBzcGFjaW5nPXsyfT5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPEdyaWRcclxuICAgICAgICAgICAgY29udGFpbmVyXHJcbiAgICAgICAgICAgIGRpcmVjdGlvbj1cInJvd1wiXHJcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICBzcGFjaW5nPXsyfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R3JpZCBpdGVtIGRhdGEtdGVzdD17YHRyYW5zYWN0aW9uLWxpa2UtY291bnQtJHt0cmFuc2FjdGlvbi5pZH1gfT5cclxuICAgICAgICAgICAgICB7dHJhbnNhY3Rpb24ubGlrZXMgPyB0cmFuc2FjdGlvbi5saWtlcy5sZW5ndGggOiAwfXtcIiBcIn1cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2N1cnJlbnRVc2VyTGlrZXNUcmFuc2FjdGlvbihjdXJyZW50VXNlciwgdHJhbnNhY3Rpb24pfVxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdHJhbnNhY3Rpb25MaWtlKHRyYW5zYWN0aW9uLmlkKX1cclxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdD17YHRyYW5zYWN0aW9uLWxpa2UtYnV0dG9uLSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPExpa2VJY29uIC8+XHJcbiAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAge3JlY2VpdmVySXNDdXJyZW50VXNlcihjdXJyZW50VXNlciwgdHJhbnNhY3Rpb24pICYmXHJcbiAgICAgICAgICAgICAgICBpc1BlbmRpbmdSZXF1ZXN0VHJhbnNhY3Rpb24odHJhbnNhY3Rpb24pICYmIChcclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuZ3JlZW5CdXR0b259XHJcbiAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvblVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRyYW5zYWN0aW9uLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RTdGF0dXM6IFRyYW5zYWN0aW9uUmVxdWVzdFN0YXR1cy5hY2NlcHRlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdD17YHRyYW5zYWN0aW9uLWFjY2VwdC1yZXF1ZXN0LSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBBY2NlcHQgUmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnJlZEJ1dHRvbn1cclxuICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0cmFuc2FjdGlvblVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHRyYW5zYWN0aW9uLmlkLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHJlcXVlc3RTdGF0dXM6IFRyYW5zYWN0aW9uUmVxdWVzdFN0YXR1cy5yZWplY3RlZCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdD17YHRyYW5zYWN0aW9uLXJlamVjdC1yZXF1ZXN0LSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICBSZWplY3QgUmVxdWVzdFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICA8Q29tbWVudEZvcm1cclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbklkPXt0cmFuc2FjdGlvbi5pZH1cclxuICAgICAgICAgICAgICB0cmFuc2FjdGlvbkNvbW1lbnQ9eyhwYXlsb2FkKSA9PiB0cmFuc2FjdGlvbkNvbW1lbnQocGF5bG9hZCl9XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICAgIHt0cmFuc2FjdGlvbi5jb21tZW50cy5sZW5ndGggPiAwICYmIChcclxuICAgICAgICA8UGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyQ29tbWVudHN9PlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIiBjb2xvcj1cInByaW1hcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICAgIDxDb21tZW50SWNvbiAvPiBDb21tZW50c1xyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgPENvbW1lbnRzTGlzdCBjb21tZW50cz17dHJhbnNhY3Rpb24uY29tbWVudHN9IC8+XHJcbiAgICAgICAgPC9QYXBlcj5cclxuICAgICAgKX1cclxuICAgIDwvU3R5bGVkUGFwZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zYWN0aW9uRGV0YWlsO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1RyYW5zYWN0aW9uRGV0YWlsLnRzeCJ9