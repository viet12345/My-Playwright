import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserSettingsForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { TextField, Button, Grid } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object, mixed } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
import { DefaultPrivacyLevel } from "/src/models/index.ts";
const PREFIX = "UserSettingsForm";
const classes = {
  paper: `${PREFIX}-paper`,
  form: `${PREFIX}-form`
};
const StyledFormik = styled(Formik)(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  }
}));
_c = StyledFormik;
const MarginHonoringDiv = styled("div")(({ theme }) => ({
  width: "100%",
  // Fix IE 11 issue.
  marginTop: theme.spacing(1)
}));
_c2 = MarginHonoringDiv;
const phoneRegExp = /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/;
const DefaultPrivacyLevelValues = Object.values(DefaultPrivacyLevel);
_c3 = DefaultPrivacyLevelValues;
const validationSchema = object({
  firstName: string().required("Enter a first name"),
  lastName: string().required("Enter a last name"),
  email: string().email("Must contain a valid email address").required("Enter an email address"),
  phoneNumber: string().matches(phoneRegExp, "Phone number is not valid").required("Enter a phone number"),
  defaultPrivacyLevel: mixed().oneOf(DefaultPrivacyLevelValues)
});
const UserSettingsForm = ({ userProfile, updateUser }) => {
  const initialValues = {
    firstName: userProfile.firstName,
    lastName: userProfile.lastName,
    email: userProfile.email,
    phoneNumber: userProfile.phoneNumber,
    defaultPrivacyLevel: userProfile.defaultPrivacyLevel
  };
  return /* @__PURE__ */ jsxDEV(
    StyledFormik,
    {
      initialValues,
      validationSchema,
      onSubmit: (values, { setSubmitting }) => {
        setSubmitting(true);
        updateUser({ id: userProfile.id, ...values });
        setSubmitting(false);
      },
      children: ({ isValid, isSubmitting }) => /* @__PURE__ */ jsxDEV(MarginHonoringDiv, { children: /* @__PURE__ */ jsxDEV(Form, { "data-test": "user-settings-form", children: [
        /* @__PURE__ */ jsxDEV(Field, { name: "firstName", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "user-settings-firstName-input",
            type: "text",
            placeholder: "First Name",
            inputProps: { "data-test": "user-settings-firstName-input" },
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
            lineNumber: 73,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
          lineNumber: 71,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { name: "lastName", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "user-settings-lastName-input",
            type: "text",
            placeholder: "Last Name",
            inputProps: { "data-test": "user-settings-lastName-input" },
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
            lineNumber: 90,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
          lineNumber: 88,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { name: "email", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "user-settings-email-input",
            type: "text",
            placeholder: "Email",
            inputProps: { "data-test": "user-settings-email-input" },
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
            lineNumber: 107,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
          lineNumber: 105,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { name: "phoneNumber", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "user-settings-phoneNumber-input",
            type: "text",
            placeholder: "Phone Number",
            inputProps: { "data-test": "user-settings-phoneNumber-input" },
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
            lineNumber: 124,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
          lineNumber: 122,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            spacing: 2,
            direction: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "submit",
                fullWidth: true,
                variant: "contained",
                color: "primary",
                sx: { marginTop: 3, marginLeft: 0, marginBottom: 2 },
                "data-test": "user-settings-submit",
                disabled: !isValid || isSubmitting,
                children: "Save"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
                lineNumber: 147,
                columnNumber: 17
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
              lineNumber: 146,
              columnNumber: 15
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
            lineNumber: 139,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
        lineNumber: 70,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
        lineNumber: 69,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx",
      lineNumber: 59,
      columnNumber: 5
    },
    this
  );
};
_c4 = UserSettingsForm;
export default UserSettingsForm;
var _c, _c2, _c3, _c4;
$RefreshReg$(_c, "StyledFormik");
$RefreshReg$(_c2, "MarginHonoringDiv");
$RefreshReg$(_c3, "DefaultPrivacyLevelValues");
$RefreshReg$(_c4, "UserSettingsForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserSettingsForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0VnQjtBQXhFaEIsT0FBT0Esb0JBQWtCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQyxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVdDLFFBQVFDLFlBQVk7QUFDeEMsU0FBU0MsUUFBUUMsTUFBTUMsYUFBeUI7QUFDaEQsU0FBU0MsUUFBUUMsUUFBUUMsYUFBYTtBQUN0QyxTQUFlQywyQkFBZ0Q7QUFFL0QsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFBQSxFQUNoQkcsTUFBTSxHQUFHSCxNQUFNO0FBQ2pCO0FBRUEsTUFBTUksZUFBZWYsT0FBT0ksTUFBTSxFQUFFLENBQUMsRUFBRVksTUFBTSxPQUFPO0FBQUEsRUFDbEQsQ0FBQyxNQUFNSixRQUFRQyxLQUFLLEVBQUUsR0FBRztBQUFBLElBQ3ZCSSxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxJQUMxQkMsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsRUFDZDtBQUNGLEVBQUU7QUFBRUMsS0FQRVA7QUFTTixNQUFNUSxvQkFBb0J2QixPQUFPLEtBQUssRUFBRSxDQUFDLEVBQUVnQixNQUFNLE9BQU87QUFBQSxFQUN0RFEsT0FBTztBQUFBO0FBQUEsRUFDUFAsV0FBV0QsTUFBTUUsUUFBUSxDQUFDO0FBQzVCLEVBQUU7QUFBRU8sTUFIRUY7QUFLTixNQUFNRyxjQUNKO0FBRUYsTUFBTUMsNEJBQTRCQyxPQUFPQyxPQUFPbkIsbUJBQW1CO0FBQUVvQixNQUEvREg7QUFFTixNQUFNSSxtQkFBbUJ2QixPQUFPO0FBQUEsRUFDOUJ3QixXQUFXekIsT0FBTyxFQUFFMEIsU0FBUyxvQkFBb0I7QUFBQSxFQUNqREMsVUFBVTNCLE9BQU8sRUFBRTBCLFNBQVMsbUJBQW1CO0FBQUEsRUFDL0NFLE9BQU81QixPQUFPLEVBQUU0QixNQUFNLG9DQUFvQyxFQUFFRixTQUFTLHdCQUF3QjtBQUFBLEVBQzdGRyxhQUFhN0IsT0FBTyxFQUNqQjhCLFFBQVFYLGFBQWEsMkJBQTJCLEVBQ2hETyxTQUFTLHNCQUFzQjtBQUFBLEVBQ2xDSyxxQkFBcUI3QixNQUEyQixFQUFFOEIsTUFBTVoseUJBQXlCO0FBQ25GLENBQUM7QUFPRCxNQUFNYSxtQkFBZ0RBLENBQUMsRUFBRUMsYUFBYUMsV0FBVyxNQUFNO0FBQ3JGLFFBQU1DLGdCQUFxQztBQUFBLElBQ3pDWCxXQUFXUyxZQUFZVDtBQUFBQSxJQUN2QkUsVUFBVU8sWUFBWVA7QUFBQUEsSUFDdEJDLE9BQU9NLFlBQVlOO0FBQUFBLElBQ25CQyxhQUFhSyxZQUFZTDtBQUFBQSxJQUN6QkUscUJBQXFCRyxZQUFZSDtBQUFBQSxFQUNuQztBQUVBLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBVSxDQUFDVCxRQUFRLEVBQUVlLGNBQWMsTUFBTTtBQUN2Q0Esc0JBQWMsSUFBSTtBQUNsQkYsbUJBQVcsRUFBRUcsSUFBSUosWUFBWUksSUFBSSxHQUFHaEIsT0FBTyxDQUFDO0FBQzVDZSxzQkFBYyxLQUFLO0FBQUEsTUFDckI7QUFBQSxNQUVDLFdBQUMsRUFBRUUsU0FBU0MsYUFBYSxNQUN4Qix1QkFBQyxxQkFDQyxpQ0FBQyxRQUFLLGFBQVUsc0JBQ2Q7QUFBQSwrQkFBQyxTQUFNLE1BQUssYUFDVCxXQUFDLEVBQUVDLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixRQUFPO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLFlBQVksRUFBRSxhQUFhLGdDQUFnQztBQUFBLFlBQzNELFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLFlBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxZQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sTUFBSyxZQUNULFdBQUMsRUFBRUEsT0FBT0MsTUFBTSxFQUFFQyxPQUFPQyxPQUFPQyxjQUFjQyxRQUFRLEVBQWMsTUFDbkU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLFFBQU87QUFBQSxZQUNQO0FBQUEsWUFDQTtBQUFBLFlBQ0EsSUFBSTtBQUFBLFlBQ0osTUFBSztBQUFBLFlBQ0wsYUFBWTtBQUFBLFlBQ1osWUFBWSxFQUFFLGFBQWEsK0JBQStCO0FBQUEsWUFDMUQsUUFBUUEsV0FBV0YsVUFBVUMsaUJBQWlCRSxRQUFRSixLQUFLO0FBQUEsWUFDM0QsWUFBWUcsV0FBV0YsVUFBVUMsZUFBZUYsUUFBUTtBQUFBLFlBQ3hELEdBQUlGO0FBQUFBO0FBQUFBLFVBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBV1ksS0FiaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWdCQTtBQUFBLFFBQ0EsdUJBQUMsU0FBTSxNQUFLLFNBQ1QsV0FBQyxFQUFFQSxPQUFPQyxNQUFNLEVBQUVDLE9BQU9DLE9BQU9DLGNBQWNDLFFBQVEsRUFBYyxNQUNuRTtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsU0FBUTtBQUFBLFlBQ1IsUUFBTztBQUFBLFlBQ1A7QUFBQSxZQUNBO0FBQUEsWUFDQSxJQUFJO0FBQUEsWUFDSixNQUFLO0FBQUEsWUFDTCxhQUFZO0FBQUEsWUFDWixZQUFZLEVBQUUsYUFBYSw0QkFBNEI7QUFBQSxZQUN2RCxRQUFRQSxXQUFXRixVQUFVQyxpQkFBaUJFLFFBQVFKLEtBQUs7QUFBQSxZQUMzRCxZQUFZRyxXQUFXRixVQUFVQyxlQUFlRixRQUFRO0FBQUEsWUFDeEQsR0FBSUY7QUFBQUE7QUFBQUEsVUFYTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFXWSxLQWJoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZ0JBO0FBQUEsUUFDQSx1QkFBQyxTQUFNLE1BQUssZUFDVCxXQUFDLEVBQUVBLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixRQUFPO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLFlBQVksRUFBRSxhQUFhLGtDQUFrQztBQUFBLFlBQzdELFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLFlBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxZQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBUztBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQ1YsZ0JBQWU7QUFBQSxZQUNmLFlBQVc7QUFBQSxZQUVYLGlDQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsU0FBUTtBQUFBLGdCQUNSLE9BQU07QUFBQSxnQkFDTixJQUFJLEVBQUUvQixXQUFXLEdBQUdzQyxZQUFZLEdBQUdDLGNBQWMsRUFBRTtBQUFBLGdCQUNuRCxhQUFVO0FBQUEsZ0JBQ1YsVUFBVSxDQUFDVixXQUFXQztBQUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FQckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUE7QUFBQSxVQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxXQXpGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEZBLEtBM0ZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0RkE7QUFBQTtBQUFBLElBdEdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQXdHQTtBQUVKO0FBQUVVLE1BcEhJakI7QUFzSE4sZUFBZUE7QUFBaUIsSUFBQWxCLElBQUFHLEtBQUFLLEtBQUEyQjtBQUFBQyxhQUFBcEMsSUFBQTtBQUFBb0MsYUFBQWpDLEtBQUE7QUFBQWlDLGFBQUE1QixLQUFBO0FBQUE0QixhQUFBRCxLQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJzdHlsZWQiLCJUZXh0RmllbGQiLCJCdXR0b24iLCJHcmlkIiwiRm9ybWlrIiwiRm9ybSIsIkZpZWxkIiwic3RyaW5nIiwib2JqZWN0IiwibWl4ZWQiLCJEZWZhdWx0UHJpdmFjeUxldmVsIiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwiZm9ybSIsIlN0eWxlZEZvcm1payIsInRoZW1lIiwibWFyZ2luVG9wIiwic3BhY2luZyIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsIl9jIiwiTWFyZ2luSG9ub3JpbmdEaXYiLCJ3aWR0aCIsIl9jMiIsInBob25lUmVnRXhwIiwiRGVmYXVsdFByaXZhY3lMZXZlbFZhbHVlcyIsIk9iamVjdCIsInZhbHVlcyIsIl9jMyIsInZhbGlkYXRpb25TY2hlbWEiLCJmaXJzdE5hbWUiLCJyZXF1aXJlZCIsImxhc3ROYW1lIiwiZW1haWwiLCJwaG9uZU51bWJlciIsIm1hdGNoZXMiLCJkZWZhdWx0UHJpdmFjeUxldmVsIiwib25lT2YiLCJVc2VyU2V0dGluZ3NGb3JtIiwidXNlclByb2ZpbGUiLCJ1cGRhdGVVc2VyIiwiaW5pdGlhbFZhbHVlcyIsInNldFN1Ym1pdHRpbmciLCJpZCIsImlzVmFsaWQiLCJpc1N1Ym1pdHRpbmciLCJmaWVsZCIsIm1ldGEiLCJlcnJvciIsInZhbHVlIiwiaW5pdGlhbFZhbHVlIiwidG91Y2hlZCIsIkJvb2xlYW4iLCJtYXJnaW5MZWZ0IiwibWFyZ2luQm90dG9tIiwiX2M0IiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlclNldHRpbmdzRm9ybS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgVGV4dEZpZWxkLCBCdXR0b24sIEdyaWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBGb3JtaWssIEZvcm0sIEZpZWxkLCBGaWVsZFByb3BzIH0gZnJvbSBcImZvcm1pa1wiO1xyXG5pbXBvcnQgeyBzdHJpbmcsIG9iamVjdCwgbWl4ZWQgfSBmcm9tIFwieXVwXCI7XHJcbmltcG9ydCB7IFVzZXIsIERlZmF1bHRQcml2YWN5TGV2ZWwsIFVzZXJTZXR0aW5nc1BheWxvYWQgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlVzZXJTZXR0aW5nc0Zvcm1cIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgcGFwZXI6IGAke1BSRUZJWH0tcGFwZXJgLFxyXG4gIGZvcm06IGAke1BSRUZJWH0tZm9ybWAsXHJcbn07XHJcblxyXG5jb25zdCBTdHlsZWRGb3JtaWsgPSBzdHlsZWQoRm9ybWlrKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJiAuJHtjbGFzc2VzLnBhcGVyfWBdOiB7XHJcbiAgICBtYXJnaW5Ub3A6IHRoZW1lLnNwYWNpbmcoOCksXHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICAgIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsXHJcbiAgICBhbGlnbkl0ZW1zOiBcImNlbnRlclwiLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IE1hcmdpbkhvbm9yaW5nRGl2ID0gc3R5bGVkKFwiZGl2XCIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgd2lkdGg6IFwiMTAwJVwiLCAvLyBGaXggSUUgMTEgaXNzdWUuXHJcbiAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDEpLFxyXG59KSk7XHJcblxyXG5jb25zdCBwaG9uZVJlZ0V4cCA9XHJcbiAgL14oKFxcXFwrWzEtOV17MSw0fVsgXFxcXC1dKil8KFxcXFwoWzAtOV17MiwzfVxcXFwpWyBcXFxcLV0qKXwoWzAtOV17Miw0fSlbIFxcXFwtXSopKj9bMC05XXszLDR9P1sgXFxcXC1dKlswLTldezMsNH0/JC87XHJcblxyXG5jb25zdCBEZWZhdWx0UHJpdmFjeUxldmVsVmFsdWVzID0gT2JqZWN0LnZhbHVlcyhEZWZhdWx0UHJpdmFjeUxldmVsKTtcclxuXHJcbmNvbnN0IHZhbGlkYXRpb25TY2hlbWEgPSBvYmplY3Qoe1xyXG4gIGZpcnN0TmFtZTogc3RyaW5nKCkucmVxdWlyZWQoXCJFbnRlciBhIGZpcnN0IG5hbWVcIiksXHJcbiAgbGFzdE5hbWU6IHN0cmluZygpLnJlcXVpcmVkKFwiRW50ZXIgYSBsYXN0IG5hbWVcIiksXHJcbiAgZW1haWw6IHN0cmluZygpLmVtYWlsKFwiTXVzdCBjb250YWluIGEgdmFsaWQgZW1haWwgYWRkcmVzc1wiKS5yZXF1aXJlZChcIkVudGVyIGFuIGVtYWlsIGFkZHJlc3NcIiksXHJcbiAgcGhvbmVOdW1iZXI6IHN0cmluZygpXHJcbiAgICAubWF0Y2hlcyhwaG9uZVJlZ0V4cCwgXCJQaG9uZSBudW1iZXIgaXMgbm90IHZhbGlkXCIpXHJcbiAgICAucmVxdWlyZWQoXCJFbnRlciBhIHBob25lIG51bWJlclwiKSxcclxuICBkZWZhdWx0UHJpdmFjeUxldmVsOiBtaXhlZDxEZWZhdWx0UHJpdmFjeUxldmVsPigpLm9uZU9mKERlZmF1bHRQcml2YWN5TGV2ZWxWYWx1ZXMpLFxyXG59KTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVXNlclNldHRpbmdzUHJvcHMge1xyXG4gIHVzZXJQcm9maWxlOiBVc2VyO1xyXG4gIHVwZGF0ZVVzZXI6IEZ1bmN0aW9uO1xyXG59XHJcblxyXG5jb25zdCBVc2VyU2V0dGluZ3NGb3JtOiBSZWFjdC5GQzxVc2VyU2V0dGluZ3NQcm9wcz4gPSAoeyB1c2VyUHJvZmlsZSwgdXBkYXRlVXNlciB9KSA9PiB7XHJcbiAgY29uc3QgaW5pdGlhbFZhbHVlczogVXNlclNldHRpbmdzUGF5bG9hZCA9IHtcclxuICAgIGZpcnN0TmFtZTogdXNlclByb2ZpbGUuZmlyc3ROYW1lLFxyXG4gICAgbGFzdE5hbWU6IHVzZXJQcm9maWxlLmxhc3ROYW1lLFxyXG4gICAgZW1haWw6IHVzZXJQcm9maWxlLmVtYWlsLFxyXG4gICAgcGhvbmVOdW1iZXI6IHVzZXJQcm9maWxlLnBob25lTnVtYmVyLFxyXG4gICAgZGVmYXVsdFByaXZhY3lMZXZlbDogdXNlclByb2ZpbGUuZGVmYXVsdFByaXZhY3lMZXZlbCxcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFN0eWxlZEZvcm1pa1xyXG4gICAgICBpbml0aWFsVmFsdWVzPXtpbml0aWFsVmFsdWVzfVxyXG4gICAgICB2YWxpZGF0aW9uU2NoZW1hPXt2YWxpZGF0aW9uU2NoZW1hfVxyXG4gICAgICBvblN1Ym1pdD17KHZhbHVlcywgeyBzZXRTdWJtaXR0aW5nIH0pID0+IHtcclxuICAgICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xyXG4gICAgICAgIHVwZGF0ZVVzZXIoeyBpZDogdXNlclByb2ZpbGUuaWQsIC4uLnZhbHVlcyB9KTtcclxuICAgICAgICBzZXRTdWJtaXR0aW5nKGZhbHNlKTtcclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgeyh7IGlzVmFsaWQsIGlzU3VibWl0dGluZyB9KSA9PiAoXHJcbiAgICAgICAgPE1hcmdpbkhvbm9yaW5nRGl2PlxyXG4gICAgICAgICAgPEZvcm0gZGF0YS10ZXN0PVwidXNlci1zZXR0aW5ncy1mb3JtXCI+XHJcbiAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwiZmlyc3ROYW1lXCI+XHJcbiAgICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICBpZD17XCJ1c2VyLXNldHRpbmdzLWZpcnN0TmFtZS1pbnB1dFwifVxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRmlyc3QgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGlucHV0UHJvcHM9e3sgXCJkYXRhLXRlc3RcIjogXCJ1c2VyLXNldHRpbmdzLWZpcnN0TmFtZS1pbnB1dFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17dG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlID8gZXJyb3IgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwibGFzdE5hbWVcIj5cclxuICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGE6IHsgZXJyb3IsIHZhbHVlLCBpbml0aWFsVmFsdWUsIHRvdWNoZWQgfSB9OiBGaWVsZFByb3BzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbj1cImRlbnNlXCJcclxuICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGlkPXtcInVzZXItc2V0dGluZ3MtbGFzdE5hbWUtaW5wdXRcIn1cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkxhc3QgTmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgIGlucHV0UHJvcHM9e3sgXCJkYXRhLXRlc3RcIjogXCJ1c2VyLXNldHRpbmdzLWxhc3ROYW1lLWlucHV0XCIgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9eyh0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUpICYmIEJvb2xlYW4oZXJyb3IpfVxyXG4gICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHsuLi5maWVsZH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgICAgPEZpZWxkIG5hbWU9XCJlbWFpbFwiPlxyXG4gICAgICAgICAgICAgIHsoeyBmaWVsZCwgbWV0YTogeyBlcnJvciwgdmFsdWUsIGluaXRpYWxWYWx1ZSwgdG91Y2hlZCB9IH06IEZpZWxkUHJvcHMpID0+IChcclxuICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgbWFyZ2luPVwiZGVuc2VcIlxyXG4gICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgaWQ9e1widXNlci1zZXR0aW5ncy1lbWFpbC1pbnB1dFwifVxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICBpbnB1dFByb3BzPXt7IFwiZGF0YS10ZXN0XCI6IFwidXNlci1zZXR0aW5ncy1lbWFpbC1pbnB1dFwiIH19XHJcbiAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17dG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlID8gZXJyb3IgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwicGhvbmVOdW1iZXJcIj5cclxuICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGE6IHsgZXJyb3IsIHZhbHVlLCBpbml0aWFsVmFsdWUsIHRvdWNoZWQgfSB9OiBGaWVsZFByb3BzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgIG1hcmdpbj1cImRlbnNlXCJcclxuICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgIGlkPXtcInVzZXItc2V0dGluZ3MtcGhvbmVOdW1iZXItaW5wdXRcIn1cclxuICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlBob25lIE51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgIGlucHV0UHJvcHM9e3sgXCJkYXRhLXRlc3RcIjogXCJ1c2VyLXNldHRpbmdzLXBob25lTnVtYmVyLWlucHV0XCIgfX1cclxuICAgICAgICAgICAgICAgICAgZXJyb3I9eyh0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUpICYmIEJvb2xlYW4oZXJyb3IpfVxyXG4gICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgIHsuLi5maWVsZH1cclxuICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgICAgPEdyaWRcclxuICAgICAgICAgICAgICBjb250YWluZXJcclxuICAgICAgICAgICAgICBzcGFjaW5nPXsyfVxyXG4gICAgICAgICAgICAgIGRpcmVjdGlvbj1cInJvd1wiXHJcbiAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJmbGV4LXN0YXJ0XCJcclxuICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICBzeD17eyBtYXJnaW5Ub3A6IDMsIG1hcmdpbkxlZnQ6IDAsIG1hcmdpbkJvdHRvbTogMiB9fVxyXG4gICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ1c2VyLXNldHRpbmdzLXN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNWYWxpZCB8fCBpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFNhdmVcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgIDwvTWFyZ2luSG9ub3JpbmdEaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L1N0eWxlZEZvcm1paz5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlclNldHRpbmdzRm9ybTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9Vc2VyU2V0dGluZ3NGb3JtLnRzeCJ9