import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/PrivateRoutesContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { Switch } from "/node_modules/.vite/deps/react-router.js?v=6af76b79";
import MainLayout from "/src/components/MainLayout.tsx";
import PrivateRoute from "/src/components/PrivateRoute.tsx";
import TransactionsContainer from "/src/containers/TransactionsContainer.tsx";
import UserSettingsContainer from "/src/containers/UserSettingsContainer.tsx";
import NotificationsContainer from "/src/containers/NotificationsContainer.tsx";
import BankAccountsContainer from "/src/containers/BankAccountsContainer.tsx";
import TransactionCreateContainer from "/src/containers/TransactionCreateContainer.tsx";
import TransactionDetailContainer from "/src/containers/TransactionDetailContainer.tsx";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import UserOnboardingContainer from "/src/containers/UserOnboardingContainer.tsx";
const PrivateRoutesContainer = ({
  isLoggedIn,
  authService,
  notificationsService,
  snackbarService,
  bankAccountsService
}) => {
  _s();
  const [, sendNotifications] = useActor(notificationsService);
  useEffect(() => {
    sendNotifications({ type: "FETCH" });
  }, [sendNotifications]);
  return /* @__PURE__ */ jsxDEV(MainLayout, { notificationsService, authService, children: [
    /* @__PURE__ */ jsxDEV(
      UserOnboardingContainer,
      {
        authService,
        bankAccountsService
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 65,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(Switch, { children: [
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, exact: true, path: "/(public|contacts|personal)?", children: /* @__PURE__ */ jsxDEV(TransactionsContainer, {}, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 71,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, exact: true, path: "/user/settings", children: /* @__PURE__ */ jsxDEV(UserSettingsContainer, { authService }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 74,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 73,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, exact: true, path: "/notifications", children: /* @__PURE__ */ jsxDEV(
        NotificationsContainer,
        {
          authService,
          notificationsService
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
          lineNumber: 77,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 76,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, path: "/bankaccounts*", children: /* @__PURE__ */ jsxDEV(
        BankAccountsContainer,
        {
          authService,
          bankAccountsService
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
          lineNumber: 83,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 82,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, exact: true, path: "/transaction/new", children: /* @__PURE__ */ jsxDEV(TransactionCreateContainer, { authService, snackbarService }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 89,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(PrivateRoute, { isLoggedIn, exact: true, path: "/transaction/:transactionId", children: /* @__PURE__ */ jsxDEV(TransactionDetailContainer, { authService }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 92,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
        lineNumber: 91,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
      lineNumber: 69,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx",
    lineNumber: 64,
    columnNumber: 5
  }, this);
};
_s(PrivateRoutesContainer, "iym7jHxUY7Ax8qEiFYyz46VUJiI=", false, function() {
  return [useActor];
});
_c = PrivateRoutesContainer;
export default PrivateRoutesContainer;
var _c;
$RefreshReg$(_c, "PrivateRoutesContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/PrivateRoutesContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0VNOzJCQWhFTjtBQUFnQkEsTUFBUyxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3hDLFNBQVNDLGNBQWM7QUFRdkIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0MsMkJBQTJCO0FBQ2xDLE9BQU9DLDRCQUE0QjtBQUNuQyxPQUFPQywyQkFBMkI7QUFDbEMsT0FBT0MsZ0NBQWdDO0FBQ3ZDLE9BQU9DLGdDQUFnQztBQUl2QyxTQUFTQyxnQkFBZ0I7QUFDekIsT0FBT0MsNkJBQTZCO0FBNEJwQyxNQUFNQyx5QkFBMENBLENBQUM7QUFBQSxFQUMvQ0M7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNLEdBQUdDLGlCQUFpQixJQUFJVCxTQUFTSyxvQkFBb0I7QUFFM0RmLFlBQVUsTUFBTTtBQUNkbUIsc0JBQWtCLEVBQUVDLE1BQU0sUUFBUSxDQUFDO0FBQUEsRUFDckMsR0FBRyxDQUFDRCxpQkFBaUIsQ0FBQztBQUV0QixTQUNFLHVCQUFDLGNBQVcsc0JBQTRDLGFBQ3REO0FBQUE7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFFMkM7QUFBQSxJQUUzQyx1QkFBQyxVQUNDO0FBQUEsNkJBQUMsZ0JBQWEsWUFBd0IsT0FBSyxNQUFDLE1BQU0sZ0NBQ2hELGlDQUFDLDJCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBc0IsS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxZQUF3QixPQUFLLE1BQUMsTUFBSyxrQkFDL0MsaUNBQUMseUJBQXNCLGVBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0QsS0FEbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxZQUF3QixPQUFLLE1BQUMsTUFBSyxrQkFDL0M7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDO0FBQUEsVUFDQTtBQUFBO0FBQUEsUUFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFFNkMsS0FIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxZQUF3QixNQUFLLGtCQUN6QztBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUE7QUFBQSxRQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUUyQyxLQUg3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLGdCQUFhLFlBQXdCLE9BQUssTUFBQyxNQUFLLG9CQUMvQyxpQ0FBQyw4QkFBMkIsYUFBMEIsbUJBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBdUYsS0FEekY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxnQkFBYSxZQUF3QixPQUFLLE1BQUMsTUFBSywrQkFDL0MsaUNBQUMsOEJBQTJCLGVBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBcUQsS0FEdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLE9BOUJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErQkE7QUFFSjtBQUFFRCxHQS9DSU4sd0JBQXVDO0FBQUEsVUFPYkYsUUFBUTtBQUFBO0FBQUFXLEtBUGxDVDtBQWlETixlQUFlQTtBQUF1QixJQUFBUztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiU3dpdGNoIiwiTWFpbkxheW91dCIsIlByaXZhdGVSb3V0ZSIsIlRyYW5zYWN0aW9uc0NvbnRhaW5lciIsIlVzZXJTZXR0aW5nc0NvbnRhaW5lciIsIk5vdGlmaWNhdGlvbnNDb250YWluZXIiLCJCYW5rQWNjb3VudHNDb250YWluZXIiLCJUcmFuc2FjdGlvbkNyZWF0ZUNvbnRhaW5lciIsIlRyYW5zYWN0aW9uRGV0YWlsQ29udGFpbmVyIiwidXNlQWN0b3IiLCJVc2VyT25ib2FyZGluZ0NvbnRhaW5lciIsIlByaXZhdGVSb3V0ZXNDb250YWluZXIiLCJpc0xvZ2dlZEluIiwiYXV0aFNlcnZpY2UiLCJub3RpZmljYXRpb25zU2VydmljZSIsInNuYWNrYmFyU2VydmljZSIsImJhbmtBY2NvdW50c1NlcnZpY2UiLCJfcyIsInNlbmROb3RpZmljYXRpb25zIiwidHlwZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJpdmF0ZVJvdXRlc0NvbnRhaW5lci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBTd2l0Y2ggfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7XHJcbiAgQmFzZUFjdGlvbk9iamVjdCxcclxuICBJbnRlcnByZXRlcixcclxuICBSZXNvbHZlVHlwZWdlbk1ldGEsXHJcbiAgU2VydmljZU1hcCxcclxuICBUeXBlZ2VuRGlzYWJsZWQsXHJcbn0gZnJvbSBcInhzdGF0ZVwiO1xyXG5pbXBvcnQgTWFpbkxheW91dCBmcm9tIFwiLi4vY29tcG9uZW50cy9NYWluTGF5b3V0XCI7XHJcbmltcG9ydCBQcml2YXRlUm91dGUgZnJvbSBcIi4uL2NvbXBvbmVudHMvUHJpdmF0ZVJvdXRlXCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvbnNDb250YWluZXIgZnJvbSBcIi4vVHJhbnNhY3Rpb25zQ29udGFpbmVyXCI7XHJcbmltcG9ydCBVc2VyU2V0dGluZ3NDb250YWluZXIgZnJvbSBcIi4vVXNlclNldHRpbmdzQ29udGFpbmVyXCI7XHJcbmltcG9ydCBOb3RpZmljYXRpb25zQ29udGFpbmVyIGZyb20gXCIuL05vdGlmaWNhdGlvbnNDb250YWluZXJcIjtcclxuaW1wb3J0IEJhbmtBY2NvdW50c0NvbnRhaW5lciBmcm9tIFwiLi9CYW5rQWNjb3VudHNDb250YWluZXJcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQ3JlYXRlQ29udGFpbmVyIGZyb20gXCIuL1RyYW5zYWN0aW9uQ3JlYXRlQ29udGFpbmVyXCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvbkRldGFpbENvbnRhaW5lciBmcm9tIFwiLi9UcmFuc2FjdGlvbkRldGFpbENvbnRhaW5lclwiO1xyXG5pbXBvcnQgeyBEYXRhQ29udGV4dCwgRGF0YVNjaGVtYSwgRGF0YUV2ZW50cyB9IGZyb20gXCIuLi9tYWNoaW5lcy9kYXRhTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBBdXRoTWFjaGluZUNvbnRleHQsIEF1dGhNYWNoaW5lRXZlbnRzLCBBdXRoTWFjaGluZVNjaGVtYSB9IGZyb20gXCIuLi9tYWNoaW5lcy9hdXRoTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBTbmFja2JhckNvbnRleHQsIFNuYWNrYmFyU2NoZW1hLCBTbmFja2JhckV2ZW50cyB9IGZyb20gXCIuLi9tYWNoaW5lcy9zbmFja2Jhck1hY2hpbmVcIjtcclxuaW1wb3J0IHsgdXNlQWN0b3IgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQgVXNlck9uYm9hcmRpbmdDb250YWluZXIgZnJvbSBcIi4vVXNlck9uYm9hcmRpbmdDb250YWluZXJcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHJvcHMge1xyXG4gIGlzTG9nZ2VkSW46IGJvb2xlYW47XHJcbiAgYXV0aFNlcnZpY2U6IEludGVycHJldGVyPEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVTY2hlbWEsIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnksIGFueT47XHJcbiAgbm90aWZpY2F0aW9uc1NlcnZpY2U6IEludGVycHJldGVyPFxyXG4gICAgRGF0YUNvbnRleHQsXHJcbiAgICBEYXRhU2NoZW1hLFxyXG4gICAgRGF0YUV2ZW50cyxcclxuICAgIGFueSxcclxuICAgIFJlc29sdmVUeXBlZ2VuTWV0YTxUeXBlZ2VuRGlzYWJsZWQsIERhdGFFdmVudHMsIEJhc2VBY3Rpb25PYmplY3QsIFNlcnZpY2VNYXA+XHJcbiAgPjtcclxuICBzbmFja2JhclNlcnZpY2U6IEludGVycHJldGVyPFxyXG4gICAgU25hY2tiYXJDb250ZXh0LFxyXG4gICAgU25hY2tiYXJTY2hlbWEsXHJcbiAgICBTbmFja2JhckV2ZW50cyxcclxuICAgIGFueSxcclxuICAgIFJlc29sdmVUeXBlZ2VuTWV0YTxUeXBlZ2VuRGlzYWJsZWQsIFNuYWNrYmFyRXZlbnRzLCBCYXNlQWN0aW9uT2JqZWN0LCBTZXJ2aWNlTWFwPlxyXG4gID47XHJcbiAgYmFua0FjY291bnRzU2VydmljZTogSW50ZXJwcmV0ZXI8XHJcbiAgICBEYXRhQ29udGV4dCxcclxuICAgIERhdGFTY2hlbWEsXHJcbiAgICBEYXRhRXZlbnRzLFxyXG4gICAgYW55LFxyXG4gICAgUmVzb2x2ZVR5cGVnZW5NZXRhPFR5cGVnZW5EaXNhYmxlZCwgRGF0YUV2ZW50cywgQmFzZUFjdGlvbk9iamVjdCwgU2VydmljZU1hcD5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBQcml2YXRlUm91dGVzQ29udGFpbmVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xyXG4gIGlzTG9nZ2VkSW4sXHJcbiAgYXV0aFNlcnZpY2UsXHJcbiAgbm90aWZpY2F0aW9uc1NlcnZpY2UsXHJcbiAgc25hY2tiYXJTZXJ2aWNlLFxyXG4gIGJhbmtBY2NvdW50c1NlcnZpY2UsXHJcbn0pID0+IHtcclxuICBjb25zdCBbLCBzZW5kTm90aWZpY2F0aW9uc10gPSB1c2VBY3Rvcihub3RpZmljYXRpb25zU2VydmljZSk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZW5kTm90aWZpY2F0aW9ucyh7IHR5cGU6IFwiRkVUQ0hcIiB9KTtcclxuICB9LCBbc2VuZE5vdGlmaWNhdGlvbnNdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxNYWluTGF5b3V0IG5vdGlmaWNhdGlvbnNTZXJ2aWNlPXtub3RpZmljYXRpb25zU2VydmljZX0gYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfT5cclxuICAgICAgPFVzZXJPbmJvYXJkaW5nQ29udGFpbmVyXHJcbiAgICAgICAgYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfVxyXG4gICAgICAgIGJhbmtBY2NvdW50c1NlcnZpY2U9e2JhbmtBY2NvdW50c1NlcnZpY2V9XHJcbiAgICAgIC8+XHJcbiAgICAgIDxTd2l0Y2g+XHJcbiAgICAgICAgPFByaXZhdGVSb3V0ZSBpc0xvZ2dlZEluPXtpc0xvZ2dlZElufSBleGFjdCBwYXRoPXtcIi8ocHVibGljfGNvbnRhY3RzfHBlcnNvbmFsKT9cIn0+XHJcbiAgICAgICAgICA8VHJhbnNhY3Rpb25zQ29udGFpbmVyIC8+XHJcbiAgICAgICAgPC9Qcml2YXRlUm91dGU+XHJcbiAgICAgICAgPFByaXZhdGVSb3V0ZSBpc0xvZ2dlZEluPXtpc0xvZ2dlZElufSBleGFjdCBwYXRoPVwiL3VzZXIvc2V0dGluZ3NcIj5cclxuICAgICAgICAgIDxVc2VyU2V0dGluZ3NDb250YWluZXIgYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfSAvPlxyXG4gICAgICAgIDwvUHJpdmF0ZVJvdXRlPlxyXG4gICAgICAgIDxQcml2YXRlUm91dGUgaXNMb2dnZWRJbj17aXNMb2dnZWRJbn0gZXhhY3QgcGF0aD1cIi9ub3RpZmljYXRpb25zXCI+XHJcbiAgICAgICAgICA8Tm90aWZpY2F0aW9uc0NvbnRhaW5lclxyXG4gICAgICAgICAgICBhdXRoU2VydmljZT17YXV0aFNlcnZpY2V9XHJcbiAgICAgICAgICAgIG5vdGlmaWNhdGlvbnNTZXJ2aWNlPXtub3RpZmljYXRpb25zU2VydmljZX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9Qcml2YXRlUm91dGU+XHJcbiAgICAgICAgPFByaXZhdGVSb3V0ZSBpc0xvZ2dlZEluPXtpc0xvZ2dlZElufSBwYXRoPVwiL2JhbmthY2NvdW50cypcIj5cclxuICAgICAgICAgIDxCYW5rQWNjb3VudHNDb250YWluZXJcclxuICAgICAgICAgICAgYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfVxyXG4gICAgICAgICAgICBiYW5rQWNjb3VudHNTZXJ2aWNlPXtiYW5rQWNjb3VudHNTZXJ2aWNlfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L1ByaXZhdGVSb3V0ZT5cclxuICAgICAgICA8UHJpdmF0ZVJvdXRlIGlzTG9nZ2VkSW49e2lzTG9nZ2VkSW59IGV4YWN0IHBhdGg9XCIvdHJhbnNhY3Rpb24vbmV3XCI+XHJcbiAgICAgICAgICA8VHJhbnNhY3Rpb25DcmVhdGVDb250YWluZXIgYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfSBzbmFja2JhclNlcnZpY2U9e3NuYWNrYmFyU2VydmljZX0gLz5cclxuICAgICAgICA8L1ByaXZhdGVSb3V0ZT5cclxuICAgICAgICA8UHJpdmF0ZVJvdXRlIGlzTG9nZ2VkSW49e2lzTG9nZ2VkSW59IGV4YWN0IHBhdGg9XCIvdHJhbnNhY3Rpb24vOnRyYW5zYWN0aW9uSWRcIj5cclxuICAgICAgICAgIDxUcmFuc2FjdGlvbkRldGFpbENvbnRhaW5lciBhdXRoU2VydmljZT17YXV0aFNlcnZpY2V9IC8+XHJcbiAgICAgICAgPC9Qcml2YXRlUm91dGU+XHJcbiAgICAgIDwvU3dpdGNoPlxyXG4gICAgPC9NYWluTGF5b3V0PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcml2YXRlUm91dGVzQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL1ByaXZhdGVSb3V0ZXNDb250YWluZXIudHN4In0=