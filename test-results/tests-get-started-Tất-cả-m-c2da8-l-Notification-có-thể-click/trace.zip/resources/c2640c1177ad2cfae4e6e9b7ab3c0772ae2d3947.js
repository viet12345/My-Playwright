import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/BankAccountsContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Link as RouterLink, useRouteMatch } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import { Grid, Button, Paper, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import BankAccountForm from "/src/components/BankAccountForm.tsx";
import BankAccountList from "/src/components/BankAccountList.tsx";
const PREFIX = "BankAccountsContainer";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  }
}));
_c = StyledPaper;
const BankAccountsContainer = ({ authService, bankAccountsService }) => {
  _s();
  const match = useRouteMatch();
  const [authState] = useActor(authService);
  const [bankAccountsState, sendBankAccounts] = useActor(bankAccountsService);
  const currentUser = authState?.context.user;
  const createBankAccount = (payload) => {
    sendBankAccounts({ type: "CREATE", ...payload });
  };
  const deleteBankAccount = (payload) => {
    sendBankAccounts({ type: "DELETE", ...payload });
  };
  useEffect(() => {
    sendBankAccounts("FETCH");
  }, [sendBankAccounts]);
  if (match.url === "/bankaccounts/new" && currentUser?.id) {
    return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
      /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: "Create Bank Account" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 67,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(BankAccountForm, { userId: currentUser?.id, createBankAccount }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 70,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
      lineNumber: 66,
      columnNumber: 7
    }, this);
  }
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
    /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", justifyContent: "space-between", alignItems: "center", children: [
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: "Bank Accounts" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 79,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          variant: "contained",
          color: "primary",
          size: "large",
          component: RouterLink,
          to: "/bankaccounts/new",
          "data-test": "bankaccount-new",
          children: "Create"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
          lineNumber: 84,
          columnNumber: 11
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 83,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      BankAccountList,
      {
        bankAccounts: bankAccountsState?.context.results,
        deleteBankAccount
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
        lineNumber: 96,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx",
    lineNumber: 76,
    columnNumber: 5
  }, this);
};
_s(BankAccountsContainer, "Au45xB/LvJTuNQnYBPz+84/oNZo=", false, function() {
  return [useRouteMatch, useActor, useActor];
});
_c2 = BankAccountsContainer;
export default BankAccountsContainer;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "BankAccountsContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/BankAccountsContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0VROzJCQWxFUjtBQUFnQkEsTUFBUyxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3hDLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsZ0JBQWdCO0FBUXpCLFNBQVNDLFFBQVFDLFlBQVlDLHFCQUFxQjtBQUNsRCxTQUFTQyxNQUFNQyxRQUFRQyxPQUFPQyxrQkFBa0I7QUFJaEQsT0FBT0MscUJBQXFCO0FBQzVCLE9BQU9DLHFCQUFxQjtBQVk1QixNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE9BQU8sR0FBR0YsTUFBTTtBQUNsQjtBQUVBLE1BQU1HLGNBQWNkLE9BQU9PLEtBQUssRUFBRSxDQUFDLEVBQUVRLE1BQU0sT0FBTztBQUFBLEVBQ2hELENBQUMsS0FBS0gsUUFBUUMsS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN0QkcsU0FBU0QsTUFBTUUsUUFBUSxDQUFDO0FBQUEsSUFDeEJDLFNBQVM7QUFBQSxJQUNUQyxVQUFVO0FBQUEsSUFDVkMsZUFBZTtBQUFBLEVBQ2pCO0FBQ0YsRUFBRTtBQUFFQyxLQVBFUDtBQVNOLE1BQU1RLHdCQUF5Q0EsQ0FBQyxFQUFFQyxhQUFhQyxvQkFBb0IsTUFBTTtBQUFBQyxLQUFBO0FBQ3ZGLFFBQU1DLFFBQVF0QixjQUFjO0FBRTVCLFFBQU0sQ0FBQ3VCLFNBQVMsSUFBSTFCLFNBQVNzQixXQUFXO0FBQ3hDLFFBQU0sQ0FBQ0ssbUJBQW1CQyxnQkFBZ0IsSUFBSTVCLFNBQVN1QixtQkFBbUI7QUFFMUUsUUFBTU0sY0FBY0gsV0FBV0ksUUFBUUM7QUFFdkMsUUFBTUMsb0JBQW9CQSxDQUFDQyxZQUFpQjtBQUMxQ0wscUJBQWlCLEVBQUVNLE1BQU0sVUFBVSxHQUFHRCxRQUFRLENBQUM7QUFBQSxFQUNqRDtBQUVBLFFBQU1FLG9CQUFvQkEsQ0FBQ0YsWUFBaUI7QUFDMUNMLHFCQUFpQixFQUFFTSxNQUFNLFVBQVUsR0FBR0QsUUFBUSxDQUFDO0FBQUEsRUFDakQ7QUFFQW5DLFlBQVUsTUFBTTtBQUNkOEIscUJBQWlCLE9BQU87QUFBQSxFQUMxQixHQUFHLENBQUNBLGdCQUFnQixDQUFDO0FBRXJCLE1BQUlILE1BQU1XLFFBQVEsdUJBQXVCUCxhQUFhUSxJQUFJO0FBQ3hELFdBQ0UsdUJBQUMsZUFBWSxXQUFXMUIsUUFBUUMsT0FDOUI7QUFBQSw2QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssT0FBTSxXQUFVLGNBQVksTUFBQyxtQ0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxtQkFBZ0IsUUFBUWlCLGFBQWFRLElBQUkscUJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0U7QUFBQSxTQUpqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxFQUVKO0FBRUEsU0FDRSx1QkFBQyxlQUFZLFdBQVcxQixRQUFRQyxPQUM5QjtBQUFBLDJCQUFDLFFBQUssV0FBUyxNQUFDLFdBQVUsT0FBTSxnQkFBZSxpQkFBZ0IsWUFBVyxVQUN4RTtBQUFBLDZCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxPQUFNLFdBQVUsY0FBWSxNQUFDLDZCQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxTQUFRO0FBQUEsVUFDUixPQUFNO0FBQUEsVUFDTixNQUFLO0FBQUEsVUFDTCxXQUFXVjtBQUFBQSxVQUNYLElBQUc7QUFBQSxVQUNILGFBQVU7QUFBQSxVQUFpQjtBQUFBO0FBQUEsUUFON0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BU0EsS0FWRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBV0E7QUFBQSxTQWpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsY0FBY3lCLG1CQUFtQkcsUUFBUVE7QUFBQUEsUUFDekM7QUFBQTtBQUFBLE1BRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRXVDO0FBQUEsT0F0QnpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3QkE7QUFFSjtBQUFFZCxHQTFESUgsdUJBQXNDO0FBQUEsVUFDNUJsQixlQUVNSCxVQUMwQkEsUUFBUTtBQUFBO0FBQUF1QyxNQUpsRGxCO0FBMkROLGVBQWVBO0FBQXNCLElBQUFELElBQUFtQjtBQUFBQyxhQUFBcEIsSUFBQTtBQUFBb0IsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInN0eWxlZCIsInVzZUFjdG9yIiwiTGluayIsIlJvdXRlckxpbmsiLCJ1c2VSb3V0ZU1hdGNoIiwiR3JpZCIsIkJ1dHRvbiIsIlBhcGVyIiwiVHlwb2dyYXBoeSIsIkJhbmtBY2NvdW50Rm9ybSIsIkJhbmtBY2NvdW50TGlzdCIsIlBSRUZJWCIsImNsYXNzZXMiLCJwYXBlciIsIlN0eWxlZFBhcGVyIiwidGhlbWUiLCJwYWRkaW5nIiwic3BhY2luZyIsImRpc3BsYXkiLCJvdmVyZmxvdyIsImZsZXhEaXJlY3Rpb24iLCJfYyIsIkJhbmtBY2NvdW50c0NvbnRhaW5lciIsImF1dGhTZXJ2aWNlIiwiYmFua0FjY291bnRzU2VydmljZSIsIl9zIiwibWF0Y2giLCJhdXRoU3RhdGUiLCJiYW5rQWNjb3VudHNTdGF0ZSIsInNlbmRCYW5rQWNjb3VudHMiLCJjdXJyZW50VXNlciIsImNvbnRleHQiLCJ1c2VyIiwiY3JlYXRlQmFua0FjY291bnQiLCJwYXlsb2FkIiwidHlwZSIsImRlbGV0ZUJhbmtBY2NvdW50IiwidXJsIiwiaWQiLCJyZXN1bHRzIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmFua0FjY291bnRzQ29udGFpbmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyB1c2VBY3RvciB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgQmFzZUFjdGlvbk9iamVjdCxcclxuICBJbnRlcnByZXRlcixcclxuICBSZXNvbHZlVHlwZWdlbk1ldGEsXHJcbiAgU2VydmljZU1hcCxcclxuICBUeXBlZ2VuRGlzYWJsZWQsXHJcbn0gZnJvbSBcInhzdGF0ZVwiO1xyXG5pbXBvcnQgeyBMaW5rIGFzIFJvdXRlckxpbmssIHVzZVJvdXRlTWF0Y2ggfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBHcmlkLCBCdXR0b24sIFBhcGVyLCBUeXBvZ3JhcGh5IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuXHJcbmltcG9ydCB7IEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVFdmVudHMsIEF1dGhNYWNoaW5lU2NoZW1hIH0gZnJvbSBcIi4uL21hY2hpbmVzL2F1dGhNYWNoaW5lXCI7XHJcbmltcG9ydCB7IERhdGFDb250ZXh0LCBEYXRhRXZlbnRzLCBEYXRhU2NoZW1hIH0gZnJvbSBcIi4uL21hY2hpbmVzL2RhdGFNYWNoaW5lXCI7XHJcbmltcG9ydCBCYW5rQWNjb3VudEZvcm0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQmFua0FjY291bnRGb3JtXCI7XHJcbmltcG9ydCBCYW5rQWNjb3VudExpc3QgZnJvbSBcIi4uL2NvbXBvbmVudHMvQmFua0FjY291bnRMaXN0XCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFByb3BzIHtcclxuICBhdXRoU2VydmljZTogSW50ZXJwcmV0ZXI8QXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZVNjaGVtYSwgQXV0aE1hY2hpbmVFdmVudHMsIGFueSwgYW55PjtcclxuICBiYW5rQWNjb3VudHNTZXJ2aWNlOiBJbnRlcnByZXRlcjxcclxuICAgIERhdGFDb250ZXh0LFxyXG4gICAgRGF0YVNjaGVtYSxcclxuICAgIERhdGFFdmVudHMsXHJcbiAgICBhbnksXHJcbiAgICBSZXNvbHZlVHlwZWdlbk1ldGE8VHlwZWdlbkRpc2FibGVkLCBEYXRhRXZlbnRzLCBCYXNlQWN0aW9uT2JqZWN0LCBTZXJ2aWNlTWFwPlxyXG4gID47XHJcbn1cclxuY29uc3QgUFJFRklYID0gXCJCYW5rQWNjb3VudHNDb250YWluZXJcIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgcGFwZXI6IGAke1BSRUZJWH0tcGFwZXJgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkUGFwZXIgPSBzdHlsZWQoUGFwZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5jb25zdCBCYW5rQWNjb3VudHNDb250YWluZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGF1dGhTZXJ2aWNlLCBiYW5rQWNjb3VudHNTZXJ2aWNlIH0pID0+IHtcclxuICBjb25zdCBtYXRjaCA9IHVzZVJvdXRlTWF0Y2goKTtcclxuXHJcbiAgY29uc3QgW2F1dGhTdGF0ZV0gPSB1c2VBY3RvcihhdXRoU2VydmljZSk7XHJcbiAgY29uc3QgW2JhbmtBY2NvdW50c1N0YXRlLCBzZW5kQmFua0FjY291bnRzXSA9IHVzZUFjdG9yKGJhbmtBY2NvdW50c1NlcnZpY2UpO1xyXG5cclxuICBjb25zdCBjdXJyZW50VXNlciA9IGF1dGhTdGF0ZT8uY29udGV4dC51c2VyO1xyXG5cclxuICBjb25zdCBjcmVhdGVCYW5rQWNjb3VudCA9IChwYXlsb2FkOiBhbnkpID0+IHtcclxuICAgIHNlbmRCYW5rQWNjb3VudHMoeyB0eXBlOiBcIkNSRUFURVwiLCAuLi5wYXlsb2FkIH0pO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGRlbGV0ZUJhbmtBY2NvdW50ID0gKHBheWxvYWQ6IGFueSkgPT4ge1xyXG4gICAgc2VuZEJhbmtBY2NvdW50cyh7IHR5cGU6IFwiREVMRVRFXCIsIC4uLnBheWxvYWQgfSk7XHJcbiAgfTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmRCYW5rQWNjb3VudHMoXCJGRVRDSFwiKTtcclxuICB9LCBbc2VuZEJhbmtBY2NvdW50c10pO1xyXG5cclxuICBpZiAobWF0Y2gudXJsID09PSBcIi9iYW5rYWNjb3VudHMvbmV3XCIgJiYgY3VycmVudFVzZXI/LmlkKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICA8U3R5bGVkUGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfT5cclxuICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMlwiIHZhcmlhbnQ9XCJoNlwiIGNvbG9yPVwicHJpbWFyeVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgIENyZWF0ZSBCYW5rIEFjY291bnRcclxuICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgPEJhbmtBY2NvdW50Rm9ybSB1c2VySWQ9e2N1cnJlbnRVc2VyPy5pZH0gY3JlYXRlQmFua0FjY291bnQ9e2NyZWF0ZUJhbmtBY2NvdW50fSAvPlxyXG4gICAgICA8L1N0eWxlZFBhcGVyPlxyXG4gICAgKTtcclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkUGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfT5cclxuICAgICAgPEdyaWQgY29udGFpbmVyIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIiBjb2xvcj1cInByaW1hcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICAgIEJhbmsgQWNjb3VudHNcclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgIGNvbXBvbmVudD17Um91dGVyTGlua31cclxuICAgICAgICAgICAgdG89XCIvYmFua2FjY291bnRzL25ld1wiXHJcbiAgICAgICAgICAgIGRhdGEtdGVzdD1cImJhbmthY2NvdW50LW5ld1wiXHJcbiAgICAgICAgICA+XHJcbiAgICAgICAgICAgIENyZWF0ZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICAgIDxCYW5rQWNjb3VudExpc3RcclxuICAgICAgICBiYW5rQWNjb3VudHM9e2JhbmtBY2NvdW50c1N0YXRlPy5jb250ZXh0LnJlc3VsdHMhfVxyXG4gICAgICAgIGRlbGV0ZUJhbmtBY2NvdW50PXtkZWxldGVCYW5rQWNjb3VudH1cclxuICAgICAgLz5cclxuICAgIDwvU3R5bGVkUGFwZXI+XHJcbiAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgQmFua0FjY291bnRzQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL0JhbmtBY2NvdW50c0NvbnRhaW5lci50c3gifQ==