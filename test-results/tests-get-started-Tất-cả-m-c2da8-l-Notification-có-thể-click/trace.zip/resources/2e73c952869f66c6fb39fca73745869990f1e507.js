import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BankAccountItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Grid, Typography, Button, ListItem } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const BankAccountListItem = ({
  bankAccount,
  deleteBankAccount
}) => {
  return /* @__PURE__ */ jsxDEV(ListItem, { "data-test": `bankaccount-list-item-${bankAccount.id}`, children: /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", justifyContent: "space-between", alignItems: "flex-start", children: [
    /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { variant: "body1", color: "primary", gutterBottom: true, children: [
      bankAccount.bankName,
      " ",
      bankAccount.isDeleted ? "(Deleted)" : void 0
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
      lineNumber: 19,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
      lineNumber: 18,
      columnNumber: 9
    }, this),
    !bankAccount.isDeleted && /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
      Button,
      {
        variant: "contained",
        color: "secondary",
        size: "large",
        "data-test": "bankaccount-delete",
        onClick: () => {
          deleteBankAccount({ id: bankAccount.id });
        },
        children: "Delete"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
        lineNumber: 25,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
      lineNumber: 24,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
    lineNumber: 17,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx",
    lineNumber: 16,
    columnNumber: 5
  }, this);
};
_c = BankAccountListItem;
export default BankAccountListItem;
var _c;
$RefreshReg$(_c, "BankAccountListItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountItem.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0JVO0FBbEJWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFekIsU0FBU0MsTUFBTUMsWUFBWUMsUUFBUUMsZ0JBQWdCO0FBUW5ELE1BQU1DLHNCQUEwREEsQ0FBQztBQUFBLEVBQy9EQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFDSixTQUNFLHVCQUFDLFlBQVMsYUFBVyx5QkFBeUJELFlBQVlFLEVBQUUsSUFDMUQsaUNBQUMsUUFBSyxXQUFTLE1BQUMsV0FBVSxPQUFNLGdCQUFlLGlCQUFnQixZQUFXLGNBQ3hFO0FBQUEsMkJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsY0FBVyxTQUFRLFNBQVEsT0FBTSxXQUFVLGNBQVksTUFDckRGO0FBQUFBLGtCQUFZRztBQUFBQSxNQUFTO0FBQUEsTUFBRUgsWUFBWUksWUFBWSxjQUFjQztBQUFBQSxTQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNDLENBQUNMLFlBQVlJLGFBQ1osdUJBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVE7QUFBQSxRQUNSLE9BQU07QUFBQSxRQUNOLE1BQUs7QUFBQSxRQUNMLGFBQVU7QUFBQSxRQUNWLFNBQVMsTUFBTTtBQUNiSCw0QkFBa0IsRUFBRUMsSUFBSUYsWUFBWUUsR0FBRyxDQUFDO0FBQUEsUUFDMUM7QUFBQSxRQUFFO0FBQUE7QUFBQSxNQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVVBLEtBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsT0FuQko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXFCQSxLQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdUJBO0FBRUo7QUFBRUksS0E5QklQO0FBZ0NOLGVBQWVBO0FBQW9CLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkdyaWQiLCJUeXBvZ3JhcGh5IiwiQnV0dG9uIiwiTGlzdEl0ZW0iLCJCYW5rQWNjb3VudExpc3RJdGVtIiwiYmFua0FjY291bnQiLCJkZWxldGVCYW5rQWNjb3VudCIsImlkIiwiYmFua05hbWUiLCJpc0RlbGV0ZWQiLCJ1bmRlZmluZWQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJhbmtBY2NvdW50SXRlbS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuaW1wb3J0IHsgR3JpZCwgVHlwb2dyYXBoeSwgQnV0dG9uLCBMaXN0SXRlbSB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IEJhbmtBY2NvdW50IH0gZnJvbSBcIi4uL21vZGVsc1wiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBCYW5rQWNjb3VudExpc3RJdGVtUHJvcHMge1xyXG4gIGJhbmtBY2NvdW50OiBCYW5rQWNjb3VudDtcclxuICBkZWxldGVCYW5rQWNjb3VudDogRnVuY3Rpb247XHJcbn1cclxuXHJcbmNvbnN0IEJhbmtBY2NvdW50TGlzdEl0ZW06IFJlYWN0LkZDPEJhbmtBY2NvdW50TGlzdEl0ZW1Qcm9wcz4gPSAoe1xyXG4gIGJhbmtBY2NvdW50LFxyXG4gIGRlbGV0ZUJhbmtBY2NvdW50LFxyXG59KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxMaXN0SXRlbSBkYXRhLXRlc3Q9e2BiYW5rYWNjb3VudC1saXN0LWl0ZW0tJHtiYW5rQWNjb3VudC5pZH1gfT5cclxuICAgICAgPEdyaWQgY29udGFpbmVyIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIGFsaWduSXRlbXM9XCJmbGV4LXN0YXJ0XCI+XHJcbiAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJib2R5MVwiIGNvbG9yPVwicHJpbWFyeVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAge2JhbmtBY2NvdW50LmJhbmtOYW1lfSB7YmFua0FjY291bnQuaXNEZWxldGVkID8gXCIoRGVsZXRlZClcIiA6IHVuZGVmaW5lZH1cclxuICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgeyFiYW5rQWNjb3VudC5pc0RlbGV0ZWQgJiYgKFxyXG4gICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgIGNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgIGRhdGEtdGVzdD1cImJhbmthY2NvdW50LWRlbGV0ZVwiXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgZGVsZXRlQmFua0FjY291bnQoeyBpZDogYmFua0FjY291bnQuaWQgfSk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIERlbGV0ZVxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICApfVxyXG4gICAgICA8L0dyaWQ+XHJcbiAgICA8L0xpc3RJdGVtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCYW5rQWNjb3VudExpc3RJdGVtO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL0JhbmtBY2NvdW50SXRlbS50c3gifQ==