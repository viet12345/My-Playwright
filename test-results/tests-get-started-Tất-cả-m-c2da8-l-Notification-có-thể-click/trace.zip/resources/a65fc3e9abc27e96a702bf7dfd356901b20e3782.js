import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/NotificationsContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Paper, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import NotificationList from "/src/components/NotificationList.tsx";
const PREFIX = "NotificationsContainer";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    minHeight: "90vh",
    padding: theme.spacing(2),
    display: "flex",
    overflow: "auto",
    flexDirection: "column"
  }
}));
_c = StyledPaper;
const NotificationsContainer = ({ authService, notificationsService }) => {
  _s();
  const [authState] = useActor(authService);
  const [notificationsState, sendNotifications] = useActor(notificationsService);
  useEffect(() => {
    sendNotifications({ type: "FETCH" });
  }, [authState, sendNotifications]);
  const updateNotification = (payload) => sendNotifications({ type: "UPDATE", ...payload });
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, children: [
    /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: "Notifications" }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx",
      lineNumber: 57,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      NotificationList,
      {
        notifications: notificationsState?.context?.results,
        updateNotification
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx",
        lineNumber: 60,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx",
    lineNumber: 56,
    columnNumber: 5
  }, this);
};
_s(NotificationsContainer, "AB4ktPIxMugByk+HAqH34BApOQQ=", false, function() {
  return [useActor, useActor];
});
_c2 = NotificationsContainer;
export default NotificationsContainer;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "NotificationsContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/NotificationsContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0RNOzJCQXhETjtBQUFnQkEsTUFBUyxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3hDLFNBQVNDLGNBQWM7QUFRdkIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLE9BQU9DLGtCQUFrQjtBQUVsQyxPQUFPQyxzQkFBc0I7QUFJN0IsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFDbEI7QUFFQSxNQUFNRyxjQUFjUixPQUFPRSxLQUFLLEVBQUUsQ0FBQyxFQUFFTyxNQUFNLE9BQU87QUFBQSxFQUNoRCxDQUFDLEtBQUtILFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdEJHLFdBQVc7QUFBQSxJQUNYQyxTQUFTRixNQUFNRyxRQUFRLENBQUM7QUFBQSxJQUN4QkMsU0FBUztBQUFBLElBQ1RDLFVBQVU7QUFBQSxJQUNWQyxlQUFlO0FBQUEsRUFDakI7QUFDRixFQUFFO0FBQUVDLEtBUkVSO0FBcUJOLE1BQU1TLHlCQUEwQ0EsQ0FBQyxFQUFFQyxhQUFhQyxxQkFBcUIsTUFBTTtBQUFBQyxLQUFBO0FBQ3pGLFFBQU0sQ0FBQ0MsU0FBUyxJQUFJcEIsU0FBU2lCLFdBQVc7QUFDeEMsUUFBTSxDQUFDSSxvQkFBb0JDLGlCQUFpQixJQUFJdEIsU0FBU2tCLG9CQUFvQjtBQUU3RXBCLFlBQVUsTUFBTTtBQUNkd0Isc0JBQWtCLEVBQUVDLE1BQU0sUUFBUSxDQUFDO0FBQUEsRUFDckMsR0FBRyxDQUFDSCxXQUFXRSxpQkFBaUIsQ0FBQztBQUVqQyxRQUFNRSxxQkFBcUJBLENBQUNDLFlBQzFCSCxrQkFBa0IsRUFBRUMsTUFBTSxVQUFVLEdBQUdFLFFBQVEsQ0FBQztBQUVsRCxTQUNFLHVCQUFDLGVBQVksV0FBV3BCLFFBQVFDLE9BQzlCO0FBQUEsMkJBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxNQUFLLE9BQU0sV0FBVSxjQUFZLE1BQUMsNkJBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLGVBQWVlLG9CQUFvQkssU0FBU0M7QUFBQUEsUUFDNUM7QUFBQTtBQUFBLE1BRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRXlDO0FBQUEsT0FOM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVFBO0FBRUo7QUFBRVIsR0F0QklILHdCQUF1QztBQUFBLFVBQ3ZCaEIsVUFDNEJBLFFBQVE7QUFBQTtBQUFBNEIsTUFGcERaO0FBd0JOLGVBQWVBO0FBQXVCLElBQUFELElBQUFhO0FBQUFDLGFBQUFkLElBQUE7QUFBQWMsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInN0eWxlZCIsInVzZUFjdG9yIiwiUGFwZXIiLCJUeXBvZ3JhcGh5IiwiTm90aWZpY2F0aW9uTGlzdCIsIlBSRUZJWCIsImNsYXNzZXMiLCJwYXBlciIsIlN0eWxlZFBhcGVyIiwidGhlbWUiLCJtaW5IZWlnaHQiLCJwYWRkaW5nIiwic3BhY2luZyIsImRpc3BsYXkiLCJvdmVyZmxvdyIsImZsZXhEaXJlY3Rpb24iLCJfYyIsIk5vdGlmaWNhdGlvbnNDb250YWluZXIiLCJhdXRoU2VydmljZSIsIm5vdGlmaWNhdGlvbnNTZXJ2aWNlIiwiX3MiLCJhdXRoU3RhdGUiLCJub3RpZmljYXRpb25zU3RhdGUiLCJzZW5kTm90aWZpY2F0aW9ucyIsInR5cGUiLCJ1cGRhdGVOb3RpZmljYXRpb24iLCJwYXlsb2FkIiwiY29udGV4dCIsInJlc3VsdHMiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb25zQ29udGFpbmVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQge1xyXG4gIEJhc2VBY3Rpb25PYmplY3QsXHJcbiAgSW50ZXJwcmV0ZXIsXHJcbiAgUmVzb2x2ZVR5cGVnZW5NZXRhLFxyXG4gIFNlcnZpY2VNYXAsXHJcbiAgVHlwZWdlbkRpc2FibGVkLFxyXG59IGZyb20gXCJ4c3RhdGVcIjtcclxuaW1wb3J0IHsgdXNlQWN0b3IgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQgeyBQYXBlciwgVHlwb2dyYXBoeSB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IE5vdGlmaWNhdGlvblVwZGF0ZVBheWxvYWQgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCBOb3RpZmljYXRpb25MaXN0IGZyb20gXCIuLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbkxpc3RcIjtcclxuaW1wb3J0IHsgRGF0YUNvbnRleHQsIERhdGFTY2hlbWEsIERhdGFFdmVudHMgfSBmcm9tIFwiLi4vbWFjaGluZXMvZGF0YU1hY2hpbmVcIjtcclxuaW1wb3J0IHsgQXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZUV2ZW50cywgQXV0aE1hY2hpbmVTY2hlbWEgfSBmcm9tIFwiLi4vbWFjaGluZXMvYXV0aE1hY2hpbmVcIjtcclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiTm90aWZpY2F0aW9uc0NvbnRhaW5lclwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwYXBlcjogYCR7UFJFRklYfS1wYXBlcmAsXHJcbn07XHJcblxyXG5jb25zdCBTdHlsZWRQYXBlciA9IHN0eWxlZChQYXBlcikoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYuJHtjbGFzc2VzLnBhcGVyfWBdOiB7XHJcbiAgICBtaW5IZWlnaHQ6IFwiOTB2aFwiLFxyXG4gICAgcGFkZGluZzogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFByb3BzIHtcclxuICBhdXRoU2VydmljZTogSW50ZXJwcmV0ZXI8QXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZVNjaGVtYSwgQXV0aE1hY2hpbmVFdmVudHMsIGFueSwgYW55PjtcclxuICBub3RpZmljYXRpb25zU2VydmljZTogSW50ZXJwcmV0ZXI8XHJcbiAgICBEYXRhQ29udGV4dCxcclxuICAgIERhdGFTY2hlbWEsXHJcbiAgICBEYXRhRXZlbnRzLFxyXG4gICAgYW55LFxyXG4gICAgUmVzb2x2ZVR5cGVnZW5NZXRhPFR5cGVnZW5EaXNhYmxlZCwgRGF0YUV2ZW50cywgQmFzZUFjdGlvbk9iamVjdCwgU2VydmljZU1hcD5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBOb3RpZmljYXRpb25zQ29udGFpbmVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBhdXRoU2VydmljZSwgbm90aWZpY2F0aW9uc1NlcnZpY2UgfSkgPT4ge1xyXG4gIGNvbnN0IFthdXRoU3RhdGVdID0gdXNlQWN0b3IoYXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IFtub3RpZmljYXRpb25zU3RhdGUsIHNlbmROb3RpZmljYXRpb25zXSA9IHVzZUFjdG9yKG5vdGlmaWNhdGlvbnNTZXJ2aWNlKTtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmROb3RpZmljYXRpb25zKHsgdHlwZTogXCJGRVRDSFwiIH0pO1xyXG4gIH0sIFthdXRoU3RhdGUsIHNlbmROb3RpZmljYXRpb25zXSk7XHJcblxyXG4gIGNvbnN0IHVwZGF0ZU5vdGlmaWNhdGlvbiA9IChwYXlsb2FkOiBOb3RpZmljYXRpb25VcGRhdGVQYXlsb2FkKSA9PlxyXG4gICAgc2VuZE5vdGlmaWNhdGlvbnMoeyB0eXBlOiBcIlVQREFURVwiLCAuLi5wYXlsb2FkIH0pO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFN0eWxlZFBhcGVyIGNsYXNzTmFtZT17Y2xhc3Nlcy5wYXBlcn0+XHJcbiAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgyXCIgdmFyaWFudD1cImg2XCIgY29sb3I9XCJwcmltYXJ5XCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgIE5vdGlmaWNhdGlvbnNcclxuICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICA8Tm90aWZpY2F0aW9uTGlzdFxyXG4gICAgICAgIG5vdGlmaWNhdGlvbnM9e25vdGlmaWNhdGlvbnNTdGF0ZT8uY29udGV4dD8ucmVzdWx0cyF9XHJcbiAgICAgICAgdXBkYXRlTm90aWZpY2F0aW9uPXt1cGRhdGVOb3RpZmljYXRpb259XHJcbiAgICAgIC8+XHJcbiAgICA8L1N0eWxlZFBhcGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25zQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL05vdGlmaWNhdGlvbnNDb250YWluZXIudHN4In0=