import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useHistory } from "/node_modules/.vite/deps/react-router.js?v=6af76b79";
import {
  ListItem,
  Typography,
  Grid,
  Avatar,
  ListItemAvatar,
  Paper,
  Badge
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { ThumbUpAltOutlined as LikeIcon, CommentRounded as CommentIcon } from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import TransactionTitle from "/src/components/TransactionTitle.tsx";
import TransactionAmount from "/src/components/TransactionAmount.tsx";
const PREFIX = "TransactionItem";
const classes = {
  root: `${PREFIX}-root`,
  paper: `${PREFIX}-paper`,
  avatar: `${PREFIX}-avatar`,
  socialStats: `${PREFIX}-socialStats`,
  countIcons: `${PREFIX}-countIcons`,
  countText: `${PREFIX}-countText`
};
const StyledListItem = styled(ListItem)(({ theme }) => ({
  [`& .${classes.root}`]: {
    flexGrow: 1
  },
  [`& .${classes.paper}`]: {
    padding: theme.spacing(0),
    margin: "auto",
    width: "100%"
  },
  [`& .${classes.avatar}`]: {
    width: theme.spacing(2)
  },
  [`& .${classes.socialStats}`]: {
    [theme.breakpoints.down("md")]: {
      marginTop: theme.spacing(2)
    }
  },
  [`& .${classes.countIcons}`]: {
    color: theme.palette.grey[400]
  },
  [`& .${classes.countText}`]: {
    color: theme.palette.grey[400],
    marginTop: 2,
    height: theme.spacing(2),
    width: theme.spacing(2)
  }
}));
_c = StyledListItem;
const SmallAvatar = styled(Avatar)(({ theme }) => {
  return {
    width: 22,
    height: 22,
    border: `2px solid ${theme.palette.background.paper}`
  };
});
_c2 = SmallAvatar;
const TransactionItem = ({ transaction }) => {
  _s();
  const history = useHistory();
  const showTransactionDetail = (transactionId) => {
    history.push(`/transaction/${transactionId}`);
  };
  return /* @__PURE__ */ jsxDEV(
    StyledListItem,
    {
      "data-test": `transaction-item-${transaction.id}`,
      alignItems: "flex-start",
      onClick: () => showTransactionDetail(transaction.id),
      children: /* @__PURE__ */ jsxDEV(Paper, { className: classes.paper, elevation: 0, children: /* @__PURE__ */ jsxDEV(Grid, { container: true, spacing: 2, children: [
        /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(ListItemAvatar, { children: /* @__PURE__ */ jsxDEV(
          Badge,
          {
            overlap: "circular",
            anchorOrigin: {
              vertical: "bottom",
              horizontal: "right"
            },
            badgeContent: /* @__PURE__ */ jsxDEV(
              SmallAvatar,
              {
                src: transaction.receiverAvatar,
                classes: {
                  root: classes.root
                }
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                lineNumber: 99,
                columnNumber: 17
              },
              this
            ),
            children: /* @__PURE__ */ jsxDEV(Avatar, { src: transaction.senderAvatar }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
              lineNumber: 107,
              columnNumber: 17
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
            lineNumber: 92,
            columnNumber: 15
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
          lineNumber: 91,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
          lineNumber: 90,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: 12, sm: true, container: true, children: [
          /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: true, container: true, direction: "column", spacing: 2, children: /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: true, children: [
            /* @__PURE__ */ jsxDEV(TransactionTitle, { transaction }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
              lineNumber: 114,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "textSecondary", gutterBottom: true, children: transaction.description }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
              lineNumber: 115,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV(
              Grid,
              {
                container: true,
                direction: "row",
                justifyContent: "flex-start",
                alignItems: "flex-start",
                spacing: 1,
                className: classes.socialStats,
                children: [
                  /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(LikeIcon, { className: classes.countIcons }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 127,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 126,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { "data-test": "transaction-like-count", className: classes.countText, children: transaction.likes.length }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 130,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 129,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(CommentIcon, { className: classes.countIcons }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 135,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 134,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { "data-test": "transaction-comment-count", className: classes.countText, children: transaction.comments.length }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 138,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                    lineNumber: 137,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
                lineNumber: 118,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
            lineNumber: 113,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
            lineNumber: 112,
            columnNumber: 13
          }, this),
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(TransactionAmount, { transaction }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
            lineNumber: 146,
            columnNumber: 15
          }, this) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
            lineNumber: 145,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
          lineNumber: 111,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
        lineNumber: 89,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
        lineNumber: 88,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx",
      lineNumber: 83,
      columnNumber: 5
    },
    this
  );
};
_s(TransactionItem, "9cZfZ04734qoCGIctmKX7+sX6eU=", false, function() {
  return [useHistory];
});
_c3 = TransactionItem;
export default TransactionItem;
var _c, _c2, _c3;
$RefreshReg$(_c, "StyledListItem");
$RefreshReg$(_c2, "SmallAvatar");
$RefreshReg$(_c3, "TransactionItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionItem.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0drQjsyQkFsR2xCO0FBQWtCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0Msa0JBQWtCO0FBQzNCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUNQLFNBQVNDLHNCQUFzQkMsVUFBVUMsa0JBQWtCQyxtQkFBbUI7QUFFOUUsT0FBT0Msc0JBQXNCO0FBQzdCLE9BQU9DLHVCQUF1QjtBQUU5QixNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE1BQU0sR0FBR0YsTUFBTTtBQUFBLEVBQ2ZHLE9BQU8sR0FBR0gsTUFBTTtBQUFBLEVBQ2hCSSxRQUFRLEdBQUdKLE1BQU07QUFBQSxFQUNqQkssYUFBYSxHQUFHTCxNQUFNO0FBQUEsRUFDdEJNLFlBQVksR0FBR04sTUFBTTtBQUFBLEVBQ3JCTyxXQUFXLEdBQUdQLE1BQU07QUFDdEI7QUFFQSxNQUFNUSxpQkFBaUJ2QixPQUFPRSxRQUFRLEVBQUUsQ0FBQyxFQUFFc0IsTUFBTSxPQUFPO0FBQUEsRUFDdEQsQ0FBQyxNQUFNUixRQUFRQyxJQUFJLEVBQUUsR0FBRztBQUFBLElBQ3RCUSxVQUFVO0FBQUEsRUFDWjtBQUFBLEVBRUEsQ0FBQyxNQUFNVCxRQUFRRSxLQUFLLEVBQUUsR0FBRztBQUFBLElBQ3ZCUSxTQUFTRixNQUFNRyxRQUFRLENBQUM7QUFBQSxJQUN4QkMsUUFBUTtBQUFBLElBQ1JDLE9BQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxDQUFDLE1BQU1iLFFBQVFHLE1BQU0sRUFBRSxHQUFHO0FBQUEsSUFDeEJVLE9BQU9MLE1BQU1HLFFBQVEsQ0FBQztBQUFBLEVBQ3hCO0FBQUEsRUFFQSxDQUFDLE1BQU1YLFFBQVFJLFdBQVcsRUFBRSxHQUFHO0FBQUEsSUFDN0IsQ0FBQ0ksTUFBTU0sWUFBWUMsS0FBSyxJQUFJLENBQUMsR0FBRztBQUFBLE1BQzlCQyxXQUFXUixNQUFNRyxRQUFRLENBQUM7QUFBQSxJQUM1QjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLENBQUMsTUFBTVgsUUFBUUssVUFBVSxFQUFFLEdBQUc7QUFBQSxJQUM1QlksT0FBT1QsTUFBTVUsUUFBUUMsS0FBSyxHQUFHO0FBQUEsRUFDL0I7QUFBQSxFQUVBLENBQUMsTUFBTW5CLFFBQVFNLFNBQVMsRUFBRSxHQUFHO0FBQUEsSUFDM0JXLE9BQU9ULE1BQU1VLFFBQVFDLEtBQUssR0FBRztBQUFBLElBQzdCSCxXQUFXO0FBQUEsSUFDWEksUUFBUVosTUFBTUcsUUFBUSxDQUFDO0FBQUEsSUFDdkJFLE9BQU9MLE1BQU1HLFFBQVEsQ0FBQztBQUFBLEVBQ3hCO0FBQ0YsRUFBRTtBQUFFVSxLQS9CRWQ7QUFxQ04sTUFBTWUsY0FBY3RDLE9BQU9LLE1BQU0sRUFBRSxDQUFDLEVBQUVtQixNQUF3QixNQUFNO0FBQ2xFLFNBQU87QUFBQSxJQUNMSyxPQUFPO0FBQUEsSUFDUE8sUUFBUTtBQUFBLElBQ1JHLFFBQVEsYUFBYWYsTUFBTVUsUUFBUU0sV0FBV3RCLEtBQUs7QUFBQSxFQUNyRDtBQUNGLENBQUM7QUFBRXVCLE1BTkdIO0FBUU4sTUFBTUksa0JBQThDQSxDQUFDLEVBQUVDLFlBQVksTUFBTTtBQUFBQyxLQUFBO0FBQ3ZFLFFBQU1DLFVBQVU1QyxXQUFXO0FBRTNCLFFBQU02Qyx3QkFBd0JBLENBQUNDLGtCQUEwQjtBQUN2REYsWUFBUUcsS0FBSyxnQkFBZ0JELGFBQWEsRUFBRTtBQUFBLEVBQzlDO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsYUFBVyxvQkFBb0JKLFlBQVlNLEVBQUU7QUFBQSxNQUM3QyxZQUFXO0FBQUEsTUFDWCxTQUFTLE1BQU1ILHNCQUFzQkgsWUFBWU0sRUFBRTtBQUFBLE1BRW5ELGlDQUFDLFNBQU0sV0FBV2pDLFFBQVFFLE9BQU8sV0FBVyxHQUMxQyxpQ0FBQyxRQUFLLFdBQVMsTUFBQyxTQUFTLEdBQ3ZCO0FBQUEsK0JBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsa0JBQ0M7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLFNBQVE7QUFBQSxZQUNSLGNBQWM7QUFBQSxjQUNaZ0MsVUFBVTtBQUFBLGNBQ1ZDLFlBQVk7QUFBQSxZQUNkO0FBQUEsWUFDQSxjQUNFO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsS0FBS1IsWUFBWVM7QUFBQUEsZ0JBQ2pCLFNBQVM7QUFBQSxrQkFDUG5DLE1BQU1ELFFBQVFDO0FBQUFBLGdCQUNoQjtBQUFBO0FBQUEsY0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFJSTtBQUFBLFlBSU4saUNBQUMsVUFBTyxLQUFLMEIsWUFBWVUsZ0JBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQXNDO0FBQUE7QUFBQSxVQWZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFnQkEsS0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBb0JBO0FBQUEsUUFDQSx1QkFBQyxRQUFLLE1BQUksTUFBQyxJQUFJLElBQUksSUFBRSxNQUFDLFdBQVMsTUFDN0I7QUFBQSxpQ0FBQyxRQUFLLE1BQUksTUFBQyxJQUFFLE1BQUMsV0FBUyxNQUFDLFdBQVUsVUFBUyxTQUFTLEdBQ2xELGlDQUFDLFFBQUssTUFBSSxNQUFDLElBQUUsTUFDWDtBQUFBLG1DQUFDLG9CQUFpQixlQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUEyQztBQUFBLFlBQzNDLHVCQUFDLGNBQVcsU0FBUSxTQUFRLE9BQU0saUJBQWdCLGNBQVksTUFDM0RWLHNCQUFZVyxlQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRUE7QUFBQSxZQUNBO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0M7QUFBQSxnQkFDQSxXQUFVO0FBQUEsZ0JBQ1YsZ0JBQWU7QUFBQSxnQkFDZixZQUFXO0FBQUEsZ0JBQ1gsU0FBUztBQUFBLGdCQUNULFdBQVd0QyxRQUFRSTtBQUFBQSxnQkFFbkI7QUFBQSx5Q0FBQyxRQUFLLE1BQUksTUFDUixpQ0FBQyxZQUFTLFdBQVdKLFFBQVFLLGNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXdDLEtBRDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUE7QUFBQSxrQkFDQSx1QkFBQyxRQUFLLE1BQUksTUFDUixpQ0FBQyxjQUFXLGFBQVUsMEJBQXlCLFdBQVdMLFFBQVFNLFdBQy9EcUIsc0JBQVlZLE1BQU1DLFVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUlBO0FBQUEsa0JBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsZUFBWSxXQUFXeEMsUUFBUUssY0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBMkMsS0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQTtBQUFBLGtCQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLGNBQVcsYUFBVSw2QkFBNEIsV0FBV0wsUUFBUU0sV0FDbEVxQixzQkFBWWMsU0FBU0QsVUFEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSUE7QUFBQTtBQUFBO0FBQUEsY0F2QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBd0JBO0FBQUEsZUE3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE4QkEsS0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQ0E7QUFBQSxVQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLHFCQUFrQixlQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXFDQTtBQUFBLFdBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUE0REEsS0E3REY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQThEQTtBQUFBO0FBQUEsSUFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBb0VBO0FBRUo7QUFBRVosR0E5RUlGLGlCQUEyQztBQUFBLFVBQy9CekMsVUFBVTtBQUFBO0FBQUF5RCxNQUR0QmhCO0FBZ0ZOLGVBQWVBO0FBQWdCLElBQUFMLElBQUFJLEtBQUFpQjtBQUFBQyxhQUFBdEIsSUFBQTtBQUFBc0IsYUFBQWxCLEtBQUE7QUFBQWtCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJzdHlsZWQiLCJ1c2VIaXN0b3J5IiwiTGlzdEl0ZW0iLCJUeXBvZ3JhcGh5IiwiR3JpZCIsIkF2YXRhciIsIkxpc3RJdGVtQXZhdGFyIiwiUGFwZXIiLCJCYWRnZSIsIlRodW1iVXBBbHRPdXRsaW5lZCIsIkxpa2VJY29uIiwiQ29tbWVudFJvdW5kZWQiLCJDb21tZW50SWNvbiIsIlRyYW5zYWN0aW9uVGl0bGUiLCJUcmFuc2FjdGlvbkFtb3VudCIsIlBSRUZJWCIsImNsYXNzZXMiLCJyb290IiwicGFwZXIiLCJhdmF0YXIiLCJzb2NpYWxTdGF0cyIsImNvdW50SWNvbnMiLCJjb3VudFRleHQiLCJTdHlsZWRMaXN0SXRlbSIsInRoZW1lIiwiZmxleEdyb3ciLCJwYWRkaW5nIiwic3BhY2luZyIsIm1hcmdpbiIsIndpZHRoIiwiYnJlYWtwb2ludHMiLCJkb3duIiwibWFyZ2luVG9wIiwiY29sb3IiLCJwYWxldHRlIiwiZ3JleSIsImhlaWdodCIsIl9jIiwiU21hbGxBdmF0YXIiLCJib3JkZXIiLCJiYWNrZ3JvdW5kIiwiX2MyIiwiVHJhbnNhY3Rpb25JdGVtIiwidHJhbnNhY3Rpb24iLCJfcyIsImhpc3RvcnkiLCJzaG93VHJhbnNhY3Rpb25EZXRhaWwiLCJ0cmFuc2FjdGlvbklkIiwicHVzaCIsImlkIiwidmVydGljYWwiLCJob3Jpem9udGFsIiwicmVjZWl2ZXJBdmF0YXIiLCJzZW5kZXJBdmF0YXIiLCJkZXNjcmlwdGlvbiIsImxpa2VzIiwibGVuZ3RoIiwiY29tbWVudHMiLCJfYzMiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUcmFuc2FjdGlvbkl0ZW0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcbmltcG9ydCB7XHJcbiAgTGlzdEl0ZW0sXHJcbiAgVHlwb2dyYXBoeSxcclxuICBHcmlkLFxyXG4gIEF2YXRhcixcclxuICBMaXN0SXRlbUF2YXRhcixcclxuICBQYXBlcixcclxuICBCYWRnZSxcclxuICBUaGVtZSxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBUaHVtYlVwQWx0T3V0bGluZWQgYXMgTGlrZUljb24sIENvbW1lbnRSb3VuZGVkIGFzIENvbW1lbnRJY29uIH0gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW0gfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCBUcmFuc2FjdGlvblRpdGxlIGZyb20gXCIuL1RyYW5zYWN0aW9uVGl0bGVcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uQW1vdW50IGZyb20gXCIuL1RyYW5zYWN0aW9uQW1vdW50XCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uSXRlbVwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICByb290OiBgJHtQUkVGSVh9LXJvb3RgLFxyXG4gIHBhcGVyOiBgJHtQUkVGSVh9LXBhcGVyYCxcclxuICBhdmF0YXI6IGAke1BSRUZJWH0tYXZhdGFyYCxcclxuICBzb2NpYWxTdGF0czogYCR7UFJFRklYfS1zb2NpYWxTdGF0c2AsXHJcbiAgY291bnRJY29uczogYCR7UFJFRklYfS1jb3VudEljb25zYCxcclxuICBjb3VudFRleHQ6IGAke1BSRUZJWH0tY291bnRUZXh0YCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZExpc3RJdGVtID0gc3R5bGVkKExpc3RJdGVtKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJiAuJHtjbGFzc2VzLnJvb3R9YF06IHtcclxuICAgIGZsZXhHcm93OiAxLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnBhcGVyfWBdOiB7XHJcbiAgICBwYWRkaW5nOiB0aGVtZS5zcGFjaW5nKDApLFxyXG4gICAgbWFyZ2luOiBcImF1dG9cIixcclxuICAgIHdpZHRoOiBcIjEwMCVcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5hdmF0YXJ9YF06IHtcclxuICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnNvY2lhbFN0YXRzfWBdOiB7XHJcbiAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bihcIm1kXCIpXToge1xyXG4gICAgICBtYXJnaW5Ub3A6IHRoZW1lLnNwYWNpbmcoMiksXHJcbiAgICB9LFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmNvdW50SWNvbnN9YF06IHtcclxuICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLmdyZXlbNDAwXSxcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5jb3VudFRleHR9YF06IHtcclxuICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLmdyZXlbNDAwXSxcclxuICAgIG1hcmdpblRvcDogMixcclxuICAgIGhlaWdodDogdGhlbWUuc3BhY2luZygyKSxcclxuICAgIHdpZHRoOiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbnR5cGUgVHJhbnNhY3Rpb25Qcm9wcyA9IHtcclxuICB0cmFuc2FjdGlvbjogVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW07XHJcbn07XHJcblxyXG5jb25zdCBTbWFsbEF2YXRhciA9IHN0eWxlZChBdmF0YXIpKCh7IHRoZW1lIH06IHsgdGhlbWU6IFRoZW1lIH0pID0+IHtcclxuICByZXR1cm4ge1xyXG4gICAgd2lkdGg6IDIyLFxyXG4gICAgaGVpZ2h0OiAyMixcclxuICAgIGJvcmRlcjogYDJweCBzb2xpZCAke3RoZW1lLnBhbGV0dGUuYmFja2dyb3VuZC5wYXBlcn1gLFxyXG4gIH07XHJcbn0pO1xyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25JdGVtOiBSZWFjdC5GQzxUcmFuc2FjdGlvblByb3BzPiA9ICh7IHRyYW5zYWN0aW9uIH0pID0+IHtcclxuICBjb25zdCBoaXN0b3J5ID0gdXNlSGlzdG9yeSgpO1xyXG5cclxuICBjb25zdCBzaG93VHJhbnNhY3Rpb25EZXRhaWwgPSAodHJhbnNhY3Rpb25JZDogc3RyaW5nKSA9PiB7XHJcbiAgICBoaXN0b3J5LnB1c2goYC90cmFuc2FjdGlvbi8ke3RyYW5zYWN0aW9uSWR9YCk7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRMaXN0SXRlbVxyXG4gICAgICBkYXRhLXRlc3Q9e2B0cmFuc2FjdGlvbi1pdGVtLSR7dHJhbnNhY3Rpb24uaWR9YH1cclxuICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICBvbkNsaWNrPXsoKSA9PiBzaG93VHJhbnNhY3Rpb25EZXRhaWwodHJhbnNhY3Rpb24uaWQpfVxyXG4gICAgPlxyXG4gICAgICA8UGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfSBlbGV2YXRpb249ezB9PlxyXG4gICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXsyfT5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgIDxMaXN0SXRlbUF2YXRhcj5cclxuICAgICAgICAgICAgICA8QmFkZ2VcclxuICAgICAgICAgICAgICAgIG92ZXJsYXA9XCJjaXJjdWxhclwiXHJcbiAgICAgICAgICAgICAgICBhbmNob3JPcmlnaW49e3tcclxuICAgICAgICAgICAgICAgICAgdmVydGljYWw6IFwiYm90dG9tXCIsXHJcbiAgICAgICAgICAgICAgICAgIGhvcml6b250YWw6IFwicmlnaHRcIixcclxuICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICBiYWRnZUNvbnRlbnQ9e1xyXG4gICAgICAgICAgICAgICAgICA8U21hbGxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgICBzcmM9e3RyYW5zYWN0aW9uLnJlY2VpdmVyQXZhdGFyfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzZXM9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIHJvb3Q6IGNsYXNzZXMucm9vdCxcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxBdmF0YXIgc3JjPXt0cmFuc2FjdGlvbi5zZW5kZXJBdmF0YXJ9IC8+XHJcbiAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgPC9MaXN0SXRlbUF2YXRhcj5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBzbSBjb250YWluZXI+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0geHMgY29udGFpbmVyIGRpcmVjdGlvbj1cImNvbHVtblwiIHNwYWNpbmc9ezJ9PlxyXG4gICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM+XHJcbiAgICAgICAgICAgICAgICA8VHJhbnNhY3Rpb25UaXRsZSB0cmFuc2FjdGlvbj17dHJhbnNhY3Rpb259IC8+XHJcbiAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiYm9keTJcIiBjb2xvcj1cInRleHRTZWNvbmRhcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbi5kZXNjcmlwdGlvbn1cclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgIDxHcmlkXHJcbiAgICAgICAgICAgICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgICAgICAgICAgICBkaXJlY3Rpb249XCJyb3dcIlxyXG4gICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgICAgICAgICAgIHNwYWNpbmc9ezF9XHJcbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5zb2NpYWxTdGF0c31cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8TGlrZUljb24gY2xhc3NOYW1lPXtjbGFzc2VzLmNvdW50SWNvbnN9IC8+XHJcbiAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saWtlLWNvdW50XCIgY2xhc3NOYW1lPXtjbGFzc2VzLmNvdW50VGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7dHJhbnNhY3Rpb24ubGlrZXMubGVuZ3RofVxyXG4gICAgICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb21tZW50SWNvbiBjbGFzc05hbWU9e2NsYXNzZXMuY291bnRJY29uc30gLz5cclxuICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWNvbW1lbnQtY291bnRcIiBjbGFzc05hbWU9e2NsYXNzZXMuY291bnRUZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgIHt0cmFuc2FjdGlvbi5jb21tZW50cy5sZW5ndGh9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAgPFRyYW5zYWN0aW9uQW1vdW50IHRyYW5zYWN0aW9uPXt0cmFuc2FjdGlvbn0gLz5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgPC9QYXBlcj5cclxuICAgIDwvU3R5bGVkTGlzdEl0ZW0+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zYWN0aW9uSXRlbTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvbkl0ZW0udHN4In0=