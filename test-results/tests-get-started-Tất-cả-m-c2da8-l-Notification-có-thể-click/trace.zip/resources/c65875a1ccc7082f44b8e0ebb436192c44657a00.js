import {
  createBrowserHistory,
  createHashHistory,
  createLocation,
  createMemoryHistory,
  createPath,
  locationsAreEqual,
  parsePath
} from "/node_modules/.vite/deps/chunk-ICEXKG2N.js?v=6af76b79";
import "/node_modules/.vite/deps/chunk-DGAH7IWJ.js?v=6af76b79";
import "/node_modules/.vite/deps/chunk-64QIVKMX.js?v=6af76b79";
import "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";
export {
  createBrowserHistory,
  createHashHistory,
  createLocation,
  createMemoryHistory,
  createPath,
  locationsAreEqual,
  parsePath
};
//# sourceMappingURL=history.js.map
