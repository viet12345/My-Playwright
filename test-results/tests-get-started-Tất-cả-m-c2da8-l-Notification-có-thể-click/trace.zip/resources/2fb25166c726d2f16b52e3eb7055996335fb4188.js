import { Machine, assign, interpret, State } from "/node_modules/.vite/deps/xstate.js?v=6af76b79";
import __vite__cjsImport1_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const omit = __vite__cjsImport1_lodash_fp["omit"];
import { httpClient } from "/src/utils/asyncUtils.ts";
import { history } from "/src/utils/historyUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const authMachine = Machine(
  {
    id: "authentication",
    initial: "unauthorized",
    context: {
      user: void 0,
      message: void 0
    },
    states: {
      unauthorized: {
        entry: "resetUser",
        on: {
          LOGIN: "loading",
          SIGNUP: "signup",
          GOOGLE: "google",
          AUTH0: "auth0",
          OKTA: "okta",
          COGNITO: "cognito"
        }
      },
      signup: {
        invoke: {
          src: "performSignup",
          onDone: { target: "unauthorized", actions: "onSuccess" },
          onError: { target: "unauthorized", actions: "onError" }
        }
      },
      loading: {
        invoke: {
          src: "performLogin",
          onDone: { target: "authorized", actions: "onSuccess" },
          onError: { target: "unauthorized", actions: "onError" }
        }
      },
      updating: {
        invoke: {
          src: "updateProfile",
          onDone: { target: "refreshing" },
          onError: { target: "unauthorized", actions: "onError" }
        }
      },
      refreshing: {
        invoke: {
          src: "getUserProfile",
          onDone: { target: "authorized", actions: "setUserProfile" },
          onError: { target: "unauthorized", actions: "onError" }
        },
        on: {
          LOGOUT: "logout"
        }
      },
      google: {
        invoke: {
          src: "getGoogleUserProfile",
          onDone: { target: "authorized", actions: "setUserProfile" },
          onError: { target: "unauthorized", actions: "onError" }
        },
        on: {
          LOGOUT: "logout"
        }
      },
      logout: {
        invoke: {
          src: "performLogout",
          onDone: { target: "unauthorized" },
          onError: { target: "unauthorized", actions: "onError" }
        }
      },
      authorized: {
        entry: "redirectHomeAfterLogin",
        on: {
          UPDATE: "updating",
          REFRESH: "refreshing",
          LOGOUT: "logout"
        }
      },
      auth0: {
        invoke: {
          src: "getAuth0UserProfile",
          onDone: { target: "authorized", actions: "setUserProfile" },
          onError: { target: "unauthorized", actions: "onError" }
        },
        on: {
          LOGOUT: "logout"
        }
      },
      okta: {
        invoke: {
          src: "getOktaUserProfile",
          onDone: { target: "authorized", actions: "setUserProfile" },
          onError: { target: "unauthorized", actions: "onError" }
        },
        on: {
          LOGOUT: "logout"
        }
      },
      cognito: {
        invoke: {
          src: "getCognitoUserProfile",
          onDone: { target: "authorized", actions: "setUserProfile" },
          onError: { target: "unauthorized", actions: "onError" }
        },
        on: {
          LOGOUT: "logout"
        }
      }
    }
  },
  {
    services: {
      performSignup: async (ctx, event) => {
        const payload = omit("type", event);
        const resp = await httpClient.post(`http://localhost:${backendPort}/users`, payload);
        history.push("/signin");
        return resp.data;
      },
      performLogin: async (ctx, event) => {
        return await httpClient.post(`http://localhost:${backendPort}/login`, event).then(({ data }) => {
          history.push("/");
          return data;
        }).catch((error) => {
          throw new Error("Username or password is invalid");
        });
      },
      getOktaUserProfile: (
        /* istanbul ignore next */
        (ctx, event) => {
          const user = {
            id: event.user.sub,
            email: event.user.email,
            firstName: event.user.given_name,
            lastName: event.user.family_name,
            username: event.user.preferred_username
          };
          localStorage.setItem(process.env.VITE_AUTH_TOKEN_NAME, event.token);
          return Promise.resolve({ user });
        }
      ),
      getUserProfile: async (ctx, event) => {
        const resp = await httpClient.get(`http://localhost:${backendPort}/checkAuth`);
        return resp.data;
      },
      getGoogleUserProfile: (
        /* istanbul ignore next */
        (ctx, event) => {
          const user = {
            id: event.user.googleId,
            email: event.user.email,
            firstName: event.user.givenName,
            lastName: event.user.familyName,
            avatar: event.user.imageUrl
          };
          localStorage.setItem(process.env.VITE_AUTH_TOKEN_NAME, event.token);
          return Promise.resolve({ user });
        }
      ),
      getAuth0UserProfile: (
        /* istanbul ignore next */
        (ctx, event) => {
          const user = {
            id: event.user.sub,
            email: event.user.email,
            firstName: event.user.nickname,
            avatar: event.user.picture
          };
          localStorage.setItem(process.env.VITE_AUTH_TOKEN_NAME, event.token);
          return Promise.resolve({ user });
        }
      ),
      updateProfile: async (ctx, event) => {
        const payload = omit("type", event);
        const resp = await httpClient.patch(
          `http://localhost:${backendPort}/users/${payload.id}`,
          payload
        );
        return resp.data;
      },
      performLogout: async (ctx, event) => {
        localStorage.removeItem("authState");
        return await httpClient.post(`http://localhost:${backendPort}/logout`);
      },
      getCognitoUserProfile: (
        /* istanbul ignore next */
        (ctx, event) => {
          const ourUser = {
            id: event.userSub,
            email: event.email
          };
          localStorage.setItem(process.env.VITE_AUTH_TOKEN_NAME, event.accessTokenJwtString);
          return Promise.resolve(ourUser);
        }
      )
    },
    actions: {
      redirectHomeAfterLogin: async (ctx, event) => {
        if (history.location.pathname === "/signin") {
          window.location.pathname = "/";
        }
      },
      resetUser: assign((ctx, event) => ({
        user: void 0
      })),
      setUserProfile: assign((ctx, event) => ({
        user: event.data.user
      })),
      onSuccess: assign((ctx, event) => ({
        user: event.data.user,
        message: void 0
      })),
      onError: assign((ctx, event) => ({
        message: event.data.message
      }))
    }
  }
);
const stateDefinition = JSON.parse(localStorage.getItem("authState"));
let resolvedState;
if (stateDefinition) {
  const previousState = State.create(stateDefinition);
  resolvedState = authMachine.resolveState(previousState);
}
export const authService = interpret(authMachine).onTransition((state) => {
  if (state.changed) {
    localStorage.setItem("authState", JSON.stringify(state));
  }
}).start(resolvedState);

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImF1dGhNYWNoaW5lLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE1hY2hpbmUsIGFzc2lnbiwgaW50ZXJwcmV0LCBTdGF0ZSB9IGZyb20gXCJ4c3RhdGVcIjtcclxuaW1wb3J0IHsgb21pdCB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHsgaHR0cENsaWVudCB9IGZyb20gXCIuLi91dGlscy9hc3luY1V0aWxzXCI7XHJcbmltcG9ydCB7IGhpc3RvcnkgfSBmcm9tIFwiLi4vdXRpbHMvaGlzdG9yeVV0aWxzXCI7XHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCB7IGJhY2tlbmRQb3J0IH0gZnJvbSBcIi4uL3V0aWxzL3BvcnRVdGlsc1wiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBBdXRoTWFjaGluZVNjaGVtYSB7XHJcbiAgc3RhdGVzOiB7XHJcbiAgICB1bmF1dGhvcml6ZWQ6IHt9O1xyXG4gICAgc2lnbnVwOiB7fTtcclxuICAgIGxvYWRpbmc6IHt9O1xyXG4gICAgdXBkYXRpbmc6IHt9O1xyXG4gICAgbG9nb3V0OiB7fTtcclxuICAgIHJlZnJlc2hpbmc6IHt9O1xyXG4gICAgZ29vZ2xlOiB7fTtcclxuICAgIGF1dGhvcml6ZWQ6IHt9O1xyXG4gICAgYXV0aDA6IHt9O1xyXG4gICAgY29nbml0bzoge307XHJcbiAgICBva3RhOiB7fTtcclxuICB9O1xyXG59XHJcblxyXG5leHBvcnQgdHlwZSBBdXRoTWFjaGluZUV2ZW50cyA9XHJcbiAgfCB7IHR5cGU6IFwiTE9HSU5cIiB9XHJcbiAgfCB7IHR5cGU6IFwiTE9HT1VUXCIgfVxyXG4gIHwgeyB0eXBlOiBcIlVQREFURVwiIH1cclxuICB8IHsgdHlwZTogXCJSRUZSRVNIXCIgfVxyXG4gIHwgeyB0eXBlOiBcIkFVVEgwXCIgfVxyXG4gIHwgeyB0eXBlOiBcIkNPR05JVE9cIiB9XHJcbiAgfCB7IHR5cGU6IFwiT0tUQVwiIH1cclxuICB8IHsgdHlwZTogXCJHT09HTEVcIiB9XHJcbiAgfCB7IHR5cGU6IFwiU0lHTlVQXCIgfTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQXV0aE1hY2hpbmVDb250ZXh0IHtcclxuICB1c2VyPzogVXNlcjtcclxuICBtZXNzYWdlPzogc3RyaW5nO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgYXV0aE1hY2hpbmUgPSBNYWNoaW5lPEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVTY2hlbWEsIEF1dGhNYWNoaW5lRXZlbnRzPihcclxuICB7XHJcbiAgICBpZDogXCJhdXRoZW50aWNhdGlvblwiLFxyXG4gICAgaW5pdGlhbDogXCJ1bmF1dGhvcml6ZWRcIixcclxuICAgIGNvbnRleHQ6IHtcclxuICAgICAgdXNlcjogdW5kZWZpbmVkLFxyXG4gICAgICBtZXNzYWdlOiB1bmRlZmluZWQsXHJcbiAgICB9LFxyXG4gICAgc3RhdGVzOiB7XHJcbiAgICAgIHVuYXV0aG9yaXplZDoge1xyXG4gICAgICAgIGVudHJ5OiBcInJlc2V0VXNlclwiLFxyXG4gICAgICAgIG9uOiB7XHJcbiAgICAgICAgICBMT0dJTjogXCJsb2FkaW5nXCIsXHJcbiAgICAgICAgICBTSUdOVVA6IFwic2lnbnVwXCIsXHJcbiAgICAgICAgICBHT09HTEU6IFwiZ29vZ2xlXCIsXHJcbiAgICAgICAgICBBVVRIMDogXCJhdXRoMFwiLFxyXG4gICAgICAgICAgT0tUQTogXCJva3RhXCIsXHJcbiAgICAgICAgICBDT0dOSVRPOiBcImNvZ25pdG9cIixcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBzaWdudXA6IHtcclxuICAgICAgICBpbnZva2U6IHtcclxuICAgICAgICAgIHNyYzogXCJwZXJmb3JtU2lnbnVwXCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcInVuYXV0aG9yaXplZFwiLCBhY3Rpb25zOiBcIm9uU3VjY2Vzc1wiIH0sXHJcbiAgICAgICAgICBvbkVycm9yOiB7IHRhcmdldDogXCJ1bmF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJvbkVycm9yXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBsb2FkaW5nOiB7XHJcbiAgICAgICAgaW52b2tlOiB7XHJcbiAgICAgICAgICBzcmM6IFwicGVyZm9ybUxvZ2luXCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcImF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJvblN1Y2Nlc3NcIiB9LFxyXG4gICAgICAgICAgb25FcnJvcjogeyB0YXJnZXQ6IFwidW5hdXRob3JpemVkXCIsIGFjdGlvbnM6IFwib25FcnJvclwiIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgdXBkYXRpbmc6IHtcclxuICAgICAgICBpbnZva2U6IHtcclxuICAgICAgICAgIHNyYzogXCJ1cGRhdGVQcm9maWxlXCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcInJlZnJlc2hpbmdcIiB9LFxyXG4gICAgICAgICAgb25FcnJvcjogeyB0YXJnZXQ6IFwidW5hdXRob3JpemVkXCIsIGFjdGlvbnM6IFwib25FcnJvclwiIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgcmVmcmVzaGluZzoge1xyXG4gICAgICAgIGludm9rZToge1xyXG4gICAgICAgICAgc3JjOiBcImdldFVzZXJQcm9maWxlXCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcImF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJzZXRVc2VyUHJvZmlsZVwiIH0sXHJcbiAgICAgICAgICBvbkVycm9yOiB7IHRhcmdldDogXCJ1bmF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJvbkVycm9yXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uOiB7XHJcbiAgICAgICAgICBMT0dPVVQ6IFwibG9nb3V0XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgICAgZ29vZ2xlOiB7XHJcbiAgICAgICAgaW52b2tlOiB7XHJcbiAgICAgICAgICBzcmM6IFwiZ2V0R29vZ2xlVXNlclByb2ZpbGVcIixcclxuICAgICAgICAgIG9uRG9uZTogeyB0YXJnZXQ6IFwiYXV0aG9yaXplZFwiLCBhY3Rpb25zOiBcInNldFVzZXJQcm9maWxlXCIgfSxcclxuICAgICAgICAgIG9uRXJyb3I6IHsgdGFyZ2V0OiBcInVuYXV0aG9yaXplZFwiLCBhY3Rpb25zOiBcIm9uRXJyb3JcIiB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb246IHtcclxuICAgICAgICAgIExPR09VVDogXCJsb2dvdXRcIixcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBsb2dvdXQ6IHtcclxuICAgICAgICBpbnZva2U6IHtcclxuICAgICAgICAgIHNyYzogXCJwZXJmb3JtTG9nb3V0XCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcInVuYXV0aG9yaXplZFwiIH0sXHJcbiAgICAgICAgICBvbkVycm9yOiB7IHRhcmdldDogXCJ1bmF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJvbkVycm9yXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBhdXRob3JpemVkOiB7XHJcbiAgICAgICAgZW50cnk6IFwicmVkaXJlY3RIb21lQWZ0ZXJMb2dpblwiLFxyXG4gICAgICAgIG9uOiB7XHJcbiAgICAgICAgICBVUERBVEU6IFwidXBkYXRpbmdcIixcclxuICAgICAgICAgIFJFRlJFU0g6IFwicmVmcmVzaGluZ1wiLFxyXG4gICAgICAgICAgTE9HT1VUOiBcImxvZ291dFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIGF1dGgwOiB7XHJcbiAgICAgICAgaW52b2tlOiB7XHJcbiAgICAgICAgICBzcmM6IFwiZ2V0QXV0aDBVc2VyUHJvZmlsZVwiLFxyXG4gICAgICAgICAgb25Eb25lOiB7IHRhcmdldDogXCJhdXRob3JpemVkXCIsIGFjdGlvbnM6IFwic2V0VXNlclByb2ZpbGVcIiB9LFxyXG4gICAgICAgICAgb25FcnJvcjogeyB0YXJnZXQ6IFwidW5hdXRob3JpemVkXCIsIGFjdGlvbnM6IFwib25FcnJvclwiIH0sXHJcbiAgICAgICAgfSxcclxuICAgICAgICBvbjoge1xyXG4gICAgICAgICAgTE9HT1VUOiBcImxvZ291dFwiLFxyXG4gICAgICAgIH0sXHJcbiAgICAgIH0sXHJcbiAgICAgIG9rdGE6IHtcclxuICAgICAgICBpbnZva2U6IHtcclxuICAgICAgICAgIHNyYzogXCJnZXRPa3RhVXNlclByb2ZpbGVcIixcclxuICAgICAgICAgIG9uRG9uZTogeyB0YXJnZXQ6IFwiYXV0aG9yaXplZFwiLCBhY3Rpb25zOiBcInNldFVzZXJQcm9maWxlXCIgfSxcclxuICAgICAgICAgIG9uRXJyb3I6IHsgdGFyZ2V0OiBcInVuYXV0aG9yaXplZFwiLCBhY3Rpb25zOiBcIm9uRXJyb3JcIiB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgb246IHtcclxuICAgICAgICAgIExPR09VVDogXCJsb2dvdXRcIixcclxuICAgICAgICB9LFxyXG4gICAgICB9LFxyXG4gICAgICBjb2duaXRvOiB7XHJcbiAgICAgICAgaW52b2tlOiB7XHJcbiAgICAgICAgICBzcmM6IFwiZ2V0Q29nbml0b1VzZXJQcm9maWxlXCIsXHJcbiAgICAgICAgICBvbkRvbmU6IHsgdGFyZ2V0OiBcImF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJzZXRVc2VyUHJvZmlsZVwiIH0sXHJcbiAgICAgICAgICBvbkVycm9yOiB7IHRhcmdldDogXCJ1bmF1dGhvcml6ZWRcIiwgYWN0aW9uczogXCJvbkVycm9yXCIgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIG9uOiB7XHJcbiAgICAgICAgICBMT0dPVVQ6IFwibG9nb3V0XCIsXHJcbiAgICAgICAgfSxcclxuICAgICAgfSxcclxuICAgIH0sXHJcbiAgfSxcclxuICB7XHJcbiAgICBzZXJ2aWNlczoge1xyXG4gICAgICBwZXJmb3JtU2lnbnVwOiBhc3luYyAoY3R4LCBldmVudCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSBvbWl0KFwidHlwZVwiLCBldmVudCk7XHJcbiAgICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQucG9zdChgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS91c2Vyc2AsIHBheWxvYWQpO1xyXG4gICAgICAgIGhpc3RvcnkucHVzaChcIi9zaWduaW5cIik7XHJcbiAgICAgICAgcmV0dXJuIHJlc3AuZGF0YTtcclxuICAgICAgfSxcclxuICAgICAgcGVyZm9ybUxvZ2luOiBhc3luYyAoY3R4LCBldmVudCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBhd2FpdCBodHRwQ2xpZW50XHJcbiAgICAgICAgICAucG9zdChgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS9sb2dpbmAsIGV2ZW50KVxyXG4gICAgICAgICAgLnRoZW4oKHsgZGF0YSB9KSA9PiB7XHJcbiAgICAgICAgICAgIGhpc3RvcnkucHVzaChcIi9cIik7XHJcbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xyXG4gICAgICAgICAgfSlcclxuICAgICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVXNlcm5hbWUgb3IgcGFzc3dvcmQgaXMgaW52YWxpZFwiKTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICBnZXRPa3RhVXNlclByb2ZpbGU6IC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgICAvLyBNYXAgT2t0YSBVc2VyIGZpZWxkcyB0byBvdXIgVXNlciBNb2RlbFxyXG4gICAgICAgIGNvbnN0IHVzZXIgPSB7XHJcbiAgICAgICAgICBpZDogZXZlbnQudXNlci5zdWIsXHJcbiAgICAgICAgICBlbWFpbDogZXZlbnQudXNlci5lbWFpbCxcclxuICAgICAgICAgIGZpcnN0TmFtZTogZXZlbnQudXNlci5naXZlbl9uYW1lLFxyXG4gICAgICAgICAgbGFzdE5hbWU6IGV2ZW50LnVzZXIuZmFtaWx5X25hbWUsXHJcbiAgICAgICAgICB1c2VybmFtZTogZXZlbnQudXNlci5wcmVmZXJyZWRfdXNlcm5hbWUsXHJcbiAgICAgICAgfTtcclxuXHJcbiAgICAgICAgLy8gU2V0IEFjY2VzcyBUb2tlbiBpbiBMb2NhbCBTdG9yYWdlIGZvciBBUEkgY2FsbHNcclxuICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShwcm9jZXNzLmVudi5WSVRFX0FVVEhfVE9LRU5fTkFNRSEsIGV2ZW50LnRva2VuKTtcclxuXHJcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7IHVzZXIgfSk7XHJcbiAgICAgIH0sXHJcbiAgICAgIGdldFVzZXJQcm9maWxlOiBhc3luYyAoY3R4LCBldmVudCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBodHRwQ2xpZW50LmdldChgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS9jaGVja0F1dGhgKTtcclxuICAgICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgICB9LFxyXG4gICAgICBnZXRHb29nbGVVc2VyUHJvZmlsZTogLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi8gKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICAgIC8vIE1hcCBHb29nbGUgVXNlciBmaWVsZHMgdG8gb3VyIFVzZXIgTW9kZWxcclxuICAgICAgICBjb25zdCB1c2VyID0ge1xyXG4gICAgICAgICAgaWQ6IGV2ZW50LnVzZXIuZ29vZ2xlSWQsXHJcbiAgICAgICAgICBlbWFpbDogZXZlbnQudXNlci5lbWFpbCxcclxuICAgICAgICAgIGZpcnN0TmFtZTogZXZlbnQudXNlci5naXZlbk5hbWUsXHJcbiAgICAgICAgICBsYXN0TmFtZTogZXZlbnQudXNlci5mYW1pbHlOYW1lLFxyXG4gICAgICAgICAgYXZhdGFyOiBldmVudC51c2VyLmltYWdlVXJsLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIC8vIFNldCBHb29nbGUgQWNjZXNzIFRva2VuIGluIExvY2FsIFN0b3JhZ2UgZm9yIEFQSSBjYWxsc1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHByb2Nlc3MuZW52LlZJVEVfQVVUSF9UT0tFTl9OQU1FISwgZXZlbnQudG9rZW4pO1xyXG5cclxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHsgdXNlciB9KTtcclxuICAgICAgfSxcclxuICAgICAgZ2V0QXV0aDBVc2VyUHJvZmlsZTogLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi8gKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICAgIC8vIE1hcCBBdXRoMCBVc2VyIGZpZWxkcyB0byBvdXIgVXNlciBNb2RlbFxyXG4gICAgICAgIGNvbnN0IHVzZXIgPSB7XHJcbiAgICAgICAgICBpZDogZXZlbnQudXNlci5zdWIsXHJcbiAgICAgICAgICBlbWFpbDogZXZlbnQudXNlci5lbWFpbCxcclxuICAgICAgICAgIGZpcnN0TmFtZTogZXZlbnQudXNlci5uaWNrbmFtZSxcclxuICAgICAgICAgIGF2YXRhcjogZXZlbnQudXNlci5waWN0dXJlLFxyXG4gICAgICAgIH07XHJcblxyXG4gICAgICAgIC8vIFNldCBBdXRoMCBBY2Nlc3MgVG9rZW4gaW4gTG9jYWwgU3RvcmFnZSBmb3IgQVBJIGNhbGxzXHJcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0ocHJvY2Vzcy5lbnYuVklURV9BVVRIX1RPS0VOX05BTUUhLCBldmVudC50b2tlbik7XHJcblxyXG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoeyB1c2VyIH0pO1xyXG4gICAgICB9LFxyXG4gICAgICB1cGRhdGVQcm9maWxlOiBhc3luYyAoY3R4LCBldmVudDogYW55KSA9PiB7XHJcbiAgICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgICBjb25zdCByZXNwID0gYXdhaXQgaHR0cENsaWVudC5wYXRjaChcclxuICAgICAgICAgIGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L3VzZXJzLyR7cGF5bG9hZC5pZH1gLFxyXG4gICAgICAgICAgcGF5bG9hZFxyXG4gICAgICAgICk7XHJcbiAgICAgICAgcmV0dXJuIHJlc3AuZGF0YTtcclxuICAgICAgfSxcclxuICAgICAgcGVyZm9ybUxvZ291dDogYXN5bmMgKGN0eCwgZXZlbnQpID0+IHtcclxuICAgICAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcImF1dGhTdGF0ZVwiKTtcclxuICAgICAgICByZXR1cm4gYXdhaXQgaHR0cENsaWVudC5wb3N0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L2xvZ291dGApO1xyXG4gICAgICB9LFxyXG4gICAgICBnZXRDb2duaXRvVXNlclByb2ZpbGU6IC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgICAvLyBNYXAgQ29nbml0byBVc2VyIGZpZWxkcyB0byBvdXIgVXNlciBNb2RlbFxyXG4gICAgICAgIGNvbnN0IG91clVzZXIgPSB7XHJcbiAgICAgICAgICBpZDogZXZlbnQudXNlclN1YixcclxuICAgICAgICAgIGVtYWlsOiBldmVudC5lbWFpbCxcclxuICAgICAgICB9O1xyXG5cclxuICAgICAgICAvLyBTZXQgQWNjZXNzIFRva2VuIGluIExvY2FsIFN0b3JhZ2UgZm9yIEFQSSBjYWxsc1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKHByb2Nlc3MuZW52LlZJVEVfQVVUSF9UT0tFTl9OQU1FISwgZXZlbnQuYWNjZXNzVG9rZW5Kd3RTdHJpbmcpO1xyXG5cclxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKG91clVzZXIpO1xyXG4gICAgICB9LFxyXG4gICAgfSxcclxuICAgIGFjdGlvbnM6IHtcclxuICAgICAgcmVkaXJlY3RIb21lQWZ0ZXJMb2dpbjogYXN5bmMgKGN0eCwgZXZlbnQpID0+IHtcclxuICAgICAgICBpZiAoaGlzdG9yeS5sb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvc2lnbmluXCIpIHtcclxuICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXHJcbiAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucGF0aG5hbWUgPSBcIi9cIjtcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHJlc2V0VXNlcjogYXNzaWduKChjdHg6IGFueSwgZXZlbnQ6IGFueSkgPT4gKHtcclxuICAgICAgICB1c2VyOiB1bmRlZmluZWQsXHJcbiAgICAgIH0pKSxcclxuICAgICAgc2V0VXNlclByb2ZpbGU6IGFzc2lnbigoY3R4OiBhbnksIGV2ZW50OiBhbnkpID0+ICh7XHJcbiAgICAgICAgdXNlcjogZXZlbnQuZGF0YS51c2VyLFxyXG4gICAgICB9KSksXHJcbiAgICAgIG9uU3VjY2VzczogYXNzaWduKChjdHg6IGFueSwgZXZlbnQ6IGFueSkgPT4gKHtcclxuICAgICAgICB1c2VyOiBldmVudC5kYXRhLnVzZXIsXHJcbiAgICAgICAgbWVzc2FnZTogdW5kZWZpbmVkLFxyXG4gICAgICB9KSksXHJcbiAgICAgIG9uRXJyb3I6IGFzc2lnbigoY3R4OiBhbnksIGV2ZW50OiBhbnkpID0+ICh7XHJcbiAgICAgICAgbWVzc2FnZTogZXZlbnQuZGF0YS5tZXNzYWdlLFxyXG4gICAgICB9KSksXHJcbiAgICB9LFxyXG4gIH1cclxuKTtcclxuXHJcbi8vIEB0cy1pZ25vcmVcclxuY29uc3Qgc3RhdGVEZWZpbml0aW9uID0gSlNPTi5wYXJzZShsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcImF1dGhTdGF0ZVwiKSk7XHJcblxyXG5sZXQgcmVzb2x2ZWRTdGF0ZTtcclxuaWYgKHN0YXRlRGVmaW5pdGlvbikge1xyXG4gIGNvbnN0IHByZXZpb3VzU3RhdGUgPSBTdGF0ZS5jcmVhdGUoc3RhdGVEZWZpbml0aW9uKTtcclxuXHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIHJlc29sdmVkU3RhdGUgPSBhdXRoTWFjaGluZS5yZXNvbHZlU3RhdGUocHJldmlvdXNTdGF0ZSk7XHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBhdXRoU2VydmljZSA9IGludGVycHJldChhdXRoTWFjaGluZSlcclxuICAub25UcmFuc2l0aW9uKChzdGF0ZSkgPT4ge1xyXG4gICAgaWYgKHN0YXRlLmNoYW5nZWQpIHtcclxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJhdXRoU3RhdGVcIiwgSlNPTi5zdHJpbmdpZnkoc3RhdGUpKTtcclxuICAgIH1cclxuICB9KVxyXG4gIC5zdGFydChyZXNvbHZlZFN0YXRlKTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVMsUUFBUSxXQUFXLGFBQWE7QUFDbEQsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsZUFBZTtBQUV4QixTQUFTLG1CQUFtQjtBQWtDckIsYUFBTSxjQUFjO0FBQUEsRUFDekI7QUFBQSxJQUNFLElBQUk7QUFBQSxJQUNKLFNBQVM7QUFBQSxJQUNULFNBQVM7QUFBQSxNQUNQLE1BQU07QUFBQSxNQUNOLFNBQVM7QUFBQSxJQUNYO0FBQUEsSUFDQSxRQUFRO0FBQUEsTUFDTixjQUFjO0FBQUEsUUFDWixPQUFPO0FBQUEsUUFDUCxJQUFJO0FBQUEsVUFDRixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixRQUFRO0FBQUEsVUFDUixPQUFPO0FBQUEsVUFDUCxNQUFNO0FBQUEsVUFDTixTQUFTO0FBQUEsUUFDWDtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLFFBQVE7QUFBQSxVQUNOLEtBQUs7QUFBQSxVQUNMLFFBQVEsRUFBRSxRQUFRLGdCQUFnQixTQUFTLFlBQVk7QUFBQSxVQUN2RCxTQUFTLEVBQUUsUUFBUSxnQkFBZ0IsU0FBUyxVQUFVO0FBQUEsUUFDeEQ7QUFBQSxNQUNGO0FBQUEsTUFDQSxTQUFTO0FBQUEsUUFDUCxRQUFRO0FBQUEsVUFDTixLQUFLO0FBQUEsVUFDTCxRQUFRLEVBQUUsUUFBUSxjQUFjLFNBQVMsWUFBWTtBQUFBLFVBQ3JELFNBQVMsRUFBRSxRQUFRLGdCQUFnQixTQUFTLFVBQVU7QUFBQSxRQUN4RDtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFVBQVU7QUFBQSxRQUNSLFFBQVE7QUFBQSxVQUNOLEtBQUs7QUFBQSxVQUNMLFFBQVEsRUFBRSxRQUFRLGFBQWE7QUFBQSxVQUMvQixTQUFTLEVBQUUsUUFBUSxnQkFBZ0IsU0FBUyxVQUFVO0FBQUEsUUFDeEQ7QUFBQSxNQUNGO0FBQUEsTUFDQSxZQUFZO0FBQUEsUUFDVixRQUFRO0FBQUEsVUFDTixLQUFLO0FBQUEsVUFDTCxRQUFRLEVBQUUsUUFBUSxjQUFjLFNBQVMsaUJBQWlCO0FBQUEsVUFDMUQsU0FBUyxFQUFFLFFBQVEsZ0JBQWdCLFNBQVMsVUFBVTtBQUFBLFFBQ3hEO0FBQUEsUUFDQSxJQUFJO0FBQUEsVUFDRixRQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFFBQVE7QUFBQSxRQUNOLFFBQVE7QUFBQSxVQUNOLEtBQUs7QUFBQSxVQUNMLFFBQVEsRUFBRSxRQUFRLGNBQWMsU0FBUyxpQkFBaUI7QUFBQSxVQUMxRCxTQUFTLEVBQUUsUUFBUSxnQkFBZ0IsU0FBUyxVQUFVO0FBQUEsUUFDeEQ7QUFBQSxRQUNBLElBQUk7QUFBQSxVQUNGLFFBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUFBLE1BQ0EsUUFBUTtBQUFBLFFBQ04sUUFBUTtBQUFBLFVBQ04sS0FBSztBQUFBLFVBQ0wsUUFBUSxFQUFFLFFBQVEsZUFBZTtBQUFBLFVBQ2pDLFNBQVMsRUFBRSxRQUFRLGdCQUFnQixTQUFTLFVBQVU7QUFBQSxRQUN4RDtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFlBQVk7QUFBQSxRQUNWLE9BQU87QUFBQSxRQUNQLElBQUk7QUFBQSxVQUNGLFFBQVE7QUFBQSxVQUNSLFNBQVM7QUFBQSxVQUNULFFBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUFBLE1BQ0EsT0FBTztBQUFBLFFBQ0wsUUFBUTtBQUFBLFVBQ04sS0FBSztBQUFBLFVBQ0wsUUFBUSxFQUFFLFFBQVEsY0FBYyxTQUFTLGlCQUFpQjtBQUFBLFVBQzFELFNBQVMsRUFBRSxRQUFRLGdCQUFnQixTQUFTLFVBQVU7QUFBQSxRQUN4RDtBQUFBLFFBQ0EsSUFBSTtBQUFBLFVBQ0YsUUFBUTtBQUFBLFFBQ1Y7QUFBQSxNQUNGO0FBQUEsTUFDQSxNQUFNO0FBQUEsUUFDSixRQUFRO0FBQUEsVUFDTixLQUFLO0FBQUEsVUFDTCxRQUFRLEVBQUUsUUFBUSxjQUFjLFNBQVMsaUJBQWlCO0FBQUEsVUFDMUQsU0FBUyxFQUFFLFFBQVEsZ0JBQWdCLFNBQVMsVUFBVTtBQUFBLFFBQ3hEO0FBQUEsUUFDQSxJQUFJO0FBQUEsVUFDRixRQUFRO0FBQUEsUUFDVjtBQUFBLE1BQ0Y7QUFBQSxNQUNBLFNBQVM7QUFBQSxRQUNQLFFBQVE7QUFBQSxVQUNOLEtBQUs7QUFBQSxVQUNMLFFBQVEsRUFBRSxRQUFRLGNBQWMsU0FBUyxpQkFBaUI7QUFBQSxVQUMxRCxTQUFTLEVBQUUsUUFBUSxnQkFBZ0IsU0FBUyxVQUFVO0FBQUEsUUFDeEQ7QUFBQSxRQUNBLElBQUk7QUFBQSxVQUNGLFFBQVE7QUFBQSxRQUNWO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFDQTtBQUFBLElBQ0UsVUFBVTtBQUFBLE1BQ1IsZUFBZSxPQUFPLEtBQUssVUFBVTtBQUNuQyxjQUFNLFVBQVUsS0FBSyxRQUFRLEtBQUs7QUFDbEMsY0FBTSxPQUFPLE1BQU0sV0FBVyxLQUFLLG9CQUFvQixXQUFXLFVBQVUsT0FBTztBQUNuRixnQkFBUSxLQUFLLFNBQVM7QUFDdEIsZUFBTyxLQUFLO0FBQUEsTUFDZDtBQUFBLE1BQ0EsY0FBYyxPQUFPLEtBQUssVUFBVTtBQUNsQyxlQUFPLE1BQU0sV0FDVixLQUFLLG9CQUFvQixXQUFXLFVBQVUsS0FBSyxFQUNuRCxLQUFLLENBQUMsRUFBRSxLQUFLLE1BQU07QUFDbEIsa0JBQVEsS0FBSyxHQUFHO0FBQ2hCLGlCQUFPO0FBQUEsUUFDVCxDQUFDLEVBQ0EsTUFBTSxDQUFDLFVBQVU7QUFDaEIsZ0JBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUFBLFFBQ25ELENBQUM7QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBO0FBQUEsUUFBK0MsQ0FBQyxLQUFLLFVBQWU7QUFFbEUsZ0JBQU0sT0FBTztBQUFBLFlBQ1gsSUFBSSxNQUFNLEtBQUs7QUFBQSxZQUNmLE9BQU8sTUFBTSxLQUFLO0FBQUEsWUFDbEIsV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUN0QixVQUFVLE1BQU0sS0FBSztBQUFBLFlBQ3JCLFVBQVUsTUFBTSxLQUFLO0FBQUEsVUFDdkI7QUFHQSx1QkFBYSxRQUFRLFFBQVEsSUFBSSxzQkFBdUIsTUFBTSxLQUFLO0FBRW5FLGlCQUFPLFFBQVEsUUFBUSxFQUFFLEtBQUssQ0FBQztBQUFBLFFBQ2pDO0FBQUE7QUFBQSxNQUNBLGdCQUFnQixPQUFPLEtBQUssVUFBVTtBQUNwQyxjQUFNLE9BQU8sTUFBTSxXQUFXLElBQUksb0JBQW9CLFdBQVcsWUFBWTtBQUM3RSxlQUFPLEtBQUs7QUFBQSxNQUNkO0FBQUEsTUFDQTtBQUFBO0FBQUEsUUFBaUQsQ0FBQyxLQUFLLFVBQWU7QUFFcEUsZ0JBQU0sT0FBTztBQUFBLFlBQ1gsSUFBSSxNQUFNLEtBQUs7QUFBQSxZQUNmLE9BQU8sTUFBTSxLQUFLO0FBQUEsWUFDbEIsV0FBVyxNQUFNLEtBQUs7QUFBQSxZQUN0QixVQUFVLE1BQU0sS0FBSztBQUFBLFlBQ3JCLFFBQVEsTUFBTSxLQUFLO0FBQUEsVUFDckI7QUFHQSx1QkFBYSxRQUFRLFFBQVEsSUFBSSxzQkFBdUIsTUFBTSxLQUFLO0FBRW5FLGlCQUFPLFFBQVEsUUFBUSxFQUFFLEtBQUssQ0FBQztBQUFBLFFBQ2pDO0FBQUE7QUFBQSxNQUNBO0FBQUE7QUFBQSxRQUFnRCxDQUFDLEtBQUssVUFBZTtBQUVuRSxnQkFBTSxPQUFPO0FBQUEsWUFDWCxJQUFJLE1BQU0sS0FBSztBQUFBLFlBQ2YsT0FBTyxNQUFNLEtBQUs7QUFBQSxZQUNsQixXQUFXLE1BQU0sS0FBSztBQUFBLFlBQ3RCLFFBQVEsTUFBTSxLQUFLO0FBQUEsVUFDckI7QUFHQSx1QkFBYSxRQUFRLFFBQVEsSUFBSSxzQkFBdUIsTUFBTSxLQUFLO0FBRW5FLGlCQUFPLFFBQVEsUUFBUSxFQUFFLEtBQUssQ0FBQztBQUFBLFFBQ2pDO0FBQUE7QUFBQSxNQUNBLGVBQWUsT0FBTyxLQUFLLFVBQWU7QUFDeEMsY0FBTSxVQUFVLEtBQUssUUFBUSxLQUFLO0FBQ2xDLGNBQU0sT0FBTyxNQUFNLFdBQVc7QUFBQSxVQUM1QixvQkFBb0IsV0FBVyxVQUFVLFFBQVEsRUFBRTtBQUFBLFVBQ25EO0FBQUEsUUFDRjtBQUNBLGVBQU8sS0FBSztBQUFBLE1BQ2Q7QUFBQSxNQUNBLGVBQWUsT0FBTyxLQUFLLFVBQVU7QUFDbkMscUJBQWEsV0FBVyxXQUFXO0FBQ25DLGVBQU8sTUFBTSxXQUFXLEtBQUssb0JBQW9CLFdBQVcsU0FBUztBQUFBLE1BQ3ZFO0FBQUEsTUFDQTtBQUFBO0FBQUEsUUFBa0QsQ0FBQyxLQUFLLFVBQWU7QUFFckUsZ0JBQU0sVUFBVTtBQUFBLFlBQ2QsSUFBSSxNQUFNO0FBQUEsWUFDVixPQUFPLE1BQU07QUFBQSxVQUNmO0FBR0EsdUJBQWEsUUFBUSxRQUFRLElBQUksc0JBQXVCLE1BQU0sb0JBQW9CO0FBRWxGLGlCQUFPLFFBQVEsUUFBUSxPQUFPO0FBQUEsUUFDaEM7QUFBQTtBQUFBLElBQ0Y7QUFBQSxJQUNBLFNBQVM7QUFBQSxNQUNQLHdCQUF3QixPQUFPLEtBQUssVUFBVTtBQUM1QyxZQUFJLFFBQVEsU0FBUyxhQUFhLFdBQVc7QUFFM0MsaUJBQU8sU0FBUyxXQUFXO0FBQUEsUUFDN0I7QUFBQSxNQUNGO0FBQUEsTUFDQSxXQUFXLE9BQU8sQ0FBQyxLQUFVLFdBQWdCO0FBQUEsUUFDM0MsTUFBTTtBQUFBLE1BQ1IsRUFBRTtBQUFBLE1BQ0YsZ0JBQWdCLE9BQU8sQ0FBQyxLQUFVLFdBQWdCO0FBQUEsUUFDaEQsTUFBTSxNQUFNLEtBQUs7QUFBQSxNQUNuQixFQUFFO0FBQUEsTUFDRixXQUFXLE9BQU8sQ0FBQyxLQUFVLFdBQWdCO0FBQUEsUUFDM0MsTUFBTSxNQUFNLEtBQUs7QUFBQSxRQUNqQixTQUFTO0FBQUEsTUFDWCxFQUFFO0FBQUEsTUFDRixTQUFTLE9BQU8sQ0FBQyxLQUFVLFdBQWdCO0FBQUEsUUFDekMsU0FBUyxNQUFNLEtBQUs7QUFBQSxNQUN0QixFQUFFO0FBQUEsSUFDSjtBQUFBLEVBQ0Y7QUFDRjtBQUdBLE1BQU0sa0JBQWtCLEtBQUssTUFBTSxhQUFhLFFBQVEsV0FBVyxDQUFDO0FBRXBFLElBQUk7QUFDSixJQUFJLGlCQUFpQjtBQUNuQixRQUFNLGdCQUFnQixNQUFNLE9BQU8sZUFBZTtBQUdsRCxrQkFBZ0IsWUFBWSxhQUFhLGFBQWE7QUFDeEQ7QUFFTyxhQUFNLGNBQWMsVUFBVSxXQUFXLEVBQzdDLGFBQWEsQ0FBQyxVQUFVO0FBQ3ZCLE1BQUksTUFBTSxTQUFTO0FBQ2pCLGlCQUFhLFFBQVEsYUFBYSxLQUFLLFVBQVUsS0FBSyxDQUFDO0FBQUEsRUFDekQ7QUFDRixDQUFDLEVBQ0EsTUFBTSxhQUFhOyIsIm5hbWVzIjpbXX0=