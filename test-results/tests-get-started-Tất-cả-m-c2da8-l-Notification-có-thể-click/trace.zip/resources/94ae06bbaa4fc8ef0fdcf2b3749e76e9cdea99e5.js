import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/PrivateRoute.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/PrivateRoute.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Route, Redirect } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
function PrivateRoute({ isLoggedIn, children, ...rest }) {
  return /* @__PURE__ */ jsxDEV(
    Route,
    {
      ...rest,
      render: ({ location }) => isLoggedIn ? children : (
        /* istanbul ignore next */
        /* @__PURE__ */ jsxDEV(
          Redirect,
          {
            to: {
              pathname: "/signin",
              state: { from: location }
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/PrivateRoute.tsx",
            lineNumber: 17,
            columnNumber: 7
          },
          this
        )
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/PrivateRoute.tsx",
      lineNumber: 10,
      columnNumber: 5
    },
    this
  );
}
_c = PrivateRoute;
export default PrivateRoute;
var _c;
$RefreshReg$(_c, "PrivateRoute");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/PrivateRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/PrivateRoute.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVO0FBaEJWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsT0FBT0MsZ0JBQTRCO0FBTTVDLFNBQVNDLGFBQWEsRUFBRUMsWUFBWUMsVUFBVSxHQUFHQyxLQUF5QixHQUFHO0FBQzNFLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEdBQUlBO0FBQUFBLE1BQ0osUUFBUSxDQUFDLEVBQUVDLFNBQVMsTUFDbEJILGFBQ0VDO0FBQUFBO0FBQUFBLFFBR0E7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLElBQUk7QUFBQSxjQUNGRyxVQUFVO0FBQUEsY0FDVkMsT0FBTyxFQUFFQyxNQUFNSCxTQUFTO0FBQUEsWUFDMUI7QUFBQTtBQUFBLFVBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSUk7QUFBQTtBQUFBO0FBQUEsSUFYVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFjRztBQUdQO0FBQUNJLEtBbkJRUjtBQXFCVCxlQUFlQTtBQUFhLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIlJvdXRlIiwiUmVkaXJlY3QiLCJQcml2YXRlUm91dGUiLCJpc0xvZ2dlZEluIiwiY2hpbGRyZW4iLCJyZXN0IiwibG9jYXRpb24iLCJwYXRobmFtZSIsInN0YXRlIiwiZnJvbSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiUHJpdmF0ZVJvdXRlLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFJvdXRlLCBSZWRpcmVjdCwgUm91dGVQcm9wcyB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5pbnRlcmZhY2UgSVByaXZhdGVSb3V0ZVByb3BzIGV4dGVuZHMgUm91dGVQcm9wcyB7XHJcbiAgaXNMb2dnZWRJbjogYm9vbGVhbjtcclxufVxyXG5cclxuZnVuY3Rpb24gUHJpdmF0ZVJvdXRlKHsgaXNMb2dnZWRJbiwgY2hpbGRyZW4sIC4uLnJlc3QgfTogSVByaXZhdGVSb3V0ZVByb3BzKSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxSb3V0ZVxyXG4gICAgICB7Li4ucmVzdH1cclxuICAgICAgcmVuZGVyPXsoeyBsb2NhdGlvbiB9KSA9PlxyXG4gICAgICAgIGlzTG9nZ2VkSW4gPyAoXHJcbiAgICAgICAgICBjaGlsZHJlblxyXG4gICAgICAgICkgOiAoXHJcbiAgICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xyXG4gICAgICAgICAgPFJlZGlyZWN0XHJcbiAgICAgICAgICAgIHRvPXt7XHJcbiAgICAgICAgICAgICAgcGF0aG5hbWU6IFwiL3NpZ25pblwiLFxyXG4gICAgICAgICAgICAgIHN0YXRlOiB7IGZyb206IGxvY2F0aW9uIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgLz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQcml2YXRlUm91dGU7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvUHJpdmF0ZVJvdXRlLnRzeCJ9