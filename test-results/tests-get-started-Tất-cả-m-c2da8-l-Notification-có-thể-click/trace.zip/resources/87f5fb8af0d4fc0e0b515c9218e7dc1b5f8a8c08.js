import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SvgUndrawNavigatorA479.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function SvgUndrawNavigatorA479(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      "data-name": "Layer 1",
      xmlns: "http://www.w3.org/2000/svg",
      width: "886.35125",
      height: "491.63114",
      viewBox: "0 0 886.351 491.631",
      ...props,
      children: [
        /* @__PURE__ */ jsxDEV("circle", { cx: 232.396, cy: 103.246, r: 50.763, fill: "#ff6584" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 13,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M391.582 259.678H142.556a5.08 5.08 0 01-.931-.073L259.403 55.596a8.246 8.246 0 0114.355 0l79.044 136.906 3.787 6.55z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 14,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            opacity: 0.2,
            d: "M391.582 259.678h-85.024l41.738-60.626 3.004-4.367 1.502-2.183 3.787 6.55 34.993 60.626z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 18,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M530.238 259.678H314.851l41.738-60.626 3.003-4.367 54.388-79.007c3.566-5.178 12.144-5.5 16.336-.976a9.83 9.83 0 01.783.976z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 22,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 593.463, cy: 210.82, r: 15.296, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 26,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M594.938 256.894h-3.133l1.428-48.378 1.705 48.378z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 27,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M593.509 217.685l3.364-4.654-3.41 5.806-.368-.645.414-.507zM593.141 222.384l-3.364-4.653 3.41 5.805.368-.645-.414-.507z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 28,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 733.78, cy: 210.82, r: 15.296, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 32,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M735.254 256.894h-3.133l1.429-48.378 1.704 48.378z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 33,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M733.826 217.685l3.364-4.654-3.41 5.806-.369-.645.415-.507zM733.458 222.384l-3.364-4.653 3.41 5.805.368-.645-.414-.507z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 34,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 637.775, cy: 188.846, r: 22.592, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 38,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M639.952 256.894h-4.627l2.109-71.45 2.518 71.45z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 39,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M637.843 198.985l4.967-6.872-5.035 8.574-.545-.953.613-.749zM637.298 205.926l-4.967-6.872 5.035 8.573.545-.952-.613-.749z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 40,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 692.868, cy: 188.846, r: 22.592, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 44,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M695.046 256.894h-4.627l2.109-71.45 2.518 71.45z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 45,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M692.936 198.985l4.968-6.872-5.036 8.574-.544-.953.612-.749zM692.392 205.926l-4.968-6.872 5.036 8.573.544-.952-.612-.749z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 46,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 549.969, cy: 188.846, r: 22.592, fill: "#3f51b5" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 50,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M552.146 256.894h-4.627l2.11-71.45 2.517 71.45z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 51,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M550.037 198.985l4.967-6.872-5.035 8.574-.544-.953.612-.749zM549.493 205.926l-4.968-6.872 5.036 8.573.544-.952-.612-.749z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 52,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M817.25 491.631H79.984a70.734 70.734 0 110-141.468h735.633a27.205 27.205 0 000-54.41H55.5v-43.53h760.118a70.734 70.734 0 110 141.469H79.984a27.205 27.205 0 100 54.41H817.25z",
            fill: "#e6e6e6"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 56,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#fff",
            d: "M82.704 272.9h33.735v2.176H82.704zM178.467 272.9h33.735v2.176h-33.735zM274.23 272.9h33.735v2.176H274.23zM369.993 272.9h33.735v2.176h-33.735zM465.756 272.9h33.735v2.176h-33.735zM561.519 272.9h33.735v2.176h-33.735zM657.282 272.9h33.735v2.176h-33.735zM753.045 272.9h33.735v2.176h-33.735zM82.704 370.839h33.735v2.176H82.704zM178.467 370.839h33.735v2.176h-33.735zM274.23 370.839h33.735v2.176H274.23zM369.993 370.839h33.735v2.176h-33.735zM465.756 370.839h33.735v2.176h-33.735zM561.519 370.839h33.735v2.176h-33.735zM657.282 370.839h33.735v2.176h-33.735zM753.045 370.839h33.735v2.176h-33.735zM82.704 468.779h33.735v2.176H82.704zM178.467 468.779h33.735v2.176h-33.735zM274.23 468.779h33.735v2.176H274.23zM369.993 468.779h33.735v2.176h-33.735zM465.756 468.779h33.735v2.176h-33.735zM561.519 468.779h33.735v2.176h-33.735zM657.282 468.779h33.735v2.176h-33.735zM753.045 468.779h33.735v2.176h-33.735z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 60,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M575.186 94.695a28.992 28.992 0 00-6.045-5.703h12.624a21.114 21.114 0 00-6.58 5.703zM533.919 88.992h2.176c-.467.328-.936.655-1.383 1.01-.255-.345-.527-.675-.793-1.01z",
            fill: "none"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 64,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M591.868 86.374a20.833 20.833 0 0110.129 2.618h-20.232a20.742 20.742 0 0110.103-2.618zM552.607 83.757a28.623 28.623 0 0116.534 5.235h-33.046a28.616 28.616 0 0116.512-5.235zM330.212 50.623A53.656 53.656 0 01435.486 39.31c.65-.023 1.3-.049 1.955-.049a53.67 53.67 0 0151.482 38.538 37.92 37.92 0 0144.996 11.193H366.547a36.293 36.293 0 01-36.373-37.578q.016-.395.038-.791z",
            fill: "#e6e6e6"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 68,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M620.763 133.87a28.992 28.992 0 016.045-5.703h-12.624a21.114 21.114 0 016.579 5.704zM662.03 128.167h-2.177c.468.329.937.656 1.384 1.01.254-.344.527-.674.793-1.01z",
            fill: "none"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 72,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M604.08 125.55a20.833 20.833 0 00-10.128 2.617h20.232a20.742 20.742 0 00-10.103-2.617zM643.342 122.932a28.623 28.623 0 00-16.534 5.235h33.045a28.616 28.616 0 00-16.511-5.235zM865.737 89.799a53.656 53.656 0 00-105.275-11.313c-.65-.023-1.299-.05-1.955-.05a53.67 53.67 0 00-51.482 38.539 37.92 37.92 0 00-44.995 11.192h167.372a36.293 36.293 0 0036.373-37.577q-.016-.395-.038-.791z",
            fill: "#e6e6e6"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 76,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("path", { fill: "#3f3d56", d: "M773.604 461.223l-19.453-.01.002-3.088 19.453.01z" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 80,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M613.507 458.822l4.014.928 152.533.082 1.372-3.196a32.257 32.257 0 002.371-17.442c-.657-4.414-2.303-8.8-6.042-10.704l-6.769-45.084-84.389-.151-32.65 26.334s-15.4-.277-23.768 10.14a24.45 24.45 0 00-5.114 13.465l-.33 5.42z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 81,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 647.009, cy: 458.067, r: 18.835, fill: "#3f3d56" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 85,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 647.009, cy: 458.067, r: 9.913, fill: "#ccc" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 86,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 739.95, cy: 458.117, r: 18.835, fill: "#3f3d56" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 87,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("circle", { cx: 739.95, cy: 458.117, r: 9.913, fill: "#ccc" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 88,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#fff",
            d: "M656.92 406.511l45.563.019h5.562l9.39.007v-.685l.007-8.258.007-9.272h-6.248l-5.562-.006-9.852-.007h-5.562l-11.374-.007-21.931 18.209zM724.849 406.544l24.08.013.006-4.725v-8.258l.007-5.232h-3.526l-5.562-.007-14.998-.006-.007 18.215z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 89,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#3f3d56",
            d: "M717.426 425.993l-3.088-.002.003-5.867 3.088.002zM669.266 411.764l-.002 3.088-5.867-.004.002-3.088z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 93,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M667.104 413.12h-.34a6.453 6.453 0 01-6.45-6.456 6.453 6.453 0 016.457-6.45h.34l-.007 12.907zM614.735 438.613a9.975 9.975 0 005.444-18.885 24.45 24.45 0 00-5.114 13.466z",
            fill: "#3f3d56"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 97,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            fill: "#f2f2f2",
            d: "M705.639 388.316l11.796 17.536.007-8.258-6.241-9.272-5.562-.006zM739.854 388.335l9.081 13.497v-8.258l-3.519-5.232-5.562-.007zM690.225 388.309l12.258 18.221h5.562l-12.258-18.221h-5.562z"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 101,
            columnNumber: 7
          },
          this
        ),
        /* @__PURE__ */ jsxDEV("circle", { cx: 50.058, cy: 260.93, r: 50.058, fill: "#3f3d56" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
          lineNumber: 105,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(
          "path",
          {
            d: "M50.266 276l-25.05-25.05a4.353 4.353 0 016.156-6.157L49.85 263.27l58.964-67.24a4.353 4.353 0 016.545 5.74z",
            fill: "#3f51b5"
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
            lineNumber: 106,
            columnNumber: 7
          },
          this
        )
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = SvgUndrawNavigatorA479;
export default SvgUndrawNavigatorA479;
var _c;
$RefreshReg$(_c, "SvgUndrawNavigatorA479");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgUndrawNavigatorA479.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFOUIsU0FBU0EsdUJBQXVCQyxPQUFZO0FBQzFDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLGFBQVU7QUFBQSxNQUNWLE9BQU07QUFBQSxNQUNOLE9BQU07QUFBQSxNQUNOLFFBQU87QUFBQSxNQUNQLFNBQVE7QUFBQSxNQUNSLEdBQUlBO0FBQUFBLE1BRUo7QUFBQSwrQkFBQyxZQUFPLElBQUksU0FBUyxJQUFJLFNBQVMsR0FBRyxRQUFRLE1BQUssYUFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRDtBQUFBLFFBQzNEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFTO0FBQUEsWUFDVCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUU4RjtBQUFBLFFBRTlGO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCLHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBSyxhQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSx3REFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUU2SDtBQUFBLFFBRTdILHVCQUFDLFlBQU8sSUFBSSxRQUFRLElBQUksUUFBUSxHQUFHLFFBQVEsTUFBSyxhQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXlEO0FBQUEsUUFDekQsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSx3REFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEyRTtBQUFBLFFBQzNFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUU2SDtBQUFBLFFBRTdILHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSxzREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFFBQ3pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUrSDtBQUFBLFFBRS9ILHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSxzREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RTtBQUFBLFFBQ3pFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUrSDtBQUFBLFFBRS9ILHVCQUFDLFlBQU8sSUFBSSxTQUFTLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTJEO0FBQUEsUUFDM0QsdUJBQUMsVUFBSyxNQUFLLFdBQVUsR0FBRSxxREFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF3RTtBQUFBLFFBQ3hFO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUrSDtBQUFBLFFBRS9IO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxNQUFLO0FBQUEsWUFDTCxHQUFFO0FBQUE7QUFBQSxVQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUUwM0I7QUFBQSxRQUUxM0I7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWE7QUFBQSxRQUViO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBLFFBRWhCO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVhO0FBQUEsUUFFYjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQix1QkFBQyxVQUFLLE1BQUssV0FBVSxHQUFFLHVEQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFDMUU7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLEdBQUU7QUFBQSxZQUNGLE1BQUs7QUFBQTtBQUFBLFVBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBRWdCO0FBQUEsUUFFaEIsdUJBQUMsWUFBTyxJQUFJLFNBQVMsSUFBSSxTQUFTLEdBQUcsUUFBUSxNQUFLLGFBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkQ7QUFBQSxRQUMzRCx1QkFBQyxZQUFPLElBQUksU0FBUyxJQUFJLFNBQVMsR0FBRyxPQUFPLE1BQUssVUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1RDtBQUFBLFFBQ3ZELHVCQUFDLFlBQU8sSUFBSSxRQUFRLElBQUksU0FBUyxHQUFHLFFBQVEsTUFBSyxhQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBEO0FBQUEsUUFDMUQsdUJBQUMsWUFBTyxJQUFJLFFBQVEsSUFBSSxTQUFTLEdBQUcsT0FBTyxNQUFLLFVBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0Q7QUFBQSxRQUN0RDtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFNk87QUFBQSxRQUU3TztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFeUc7QUFBQSxRQUV6RztBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsR0FBRTtBQUFBLFlBQ0YsTUFBSztBQUFBO0FBQUEsVUFGUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFZ0I7QUFBQSxRQUVoQjtBQUFBLFVBQUM7QUFBQTtBQUFBLFlBQ0MsTUFBSztBQUFBLFlBQ0wsR0FBRTtBQUFBO0FBQUEsVUFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFFOEw7QUFBQSxRQUU5TCx1QkFBQyxZQUFPLElBQUksUUFBUSxJQUFJLFFBQVEsR0FBRyxRQUFRLE1BQUssYUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF5RDtBQUFBLFFBQ3pEO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxHQUFFO0FBQUEsWUFDRixNQUFLO0FBQUE7QUFBQSxVQUZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUVnQjtBQUFBO0FBQUE7QUFBQSxJQXZHbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBeUdBO0FBRUo7QUFBQ0MsS0E3R1FGO0FBK0dULGVBQWVBO0FBQXVCLElBQUFFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTdmdVbmRyYXdOYXZpZ2F0b3JBNDc5IiwicHJvcHMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlN2Z1VuZHJhd05hdmlnYXRvckE0NzkudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuZnVuY3Rpb24gU3ZnVW5kcmF3TmF2aWdhdG9yQTQ3OShwcm9wczogYW55KSB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxzdmdcclxuICAgICAgZGF0YS1uYW1lPVwiTGF5ZXIgMVwiXHJcbiAgICAgIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIlxyXG4gICAgICB3aWR0aD1cIjg4Ni4zNTEyNVwiXHJcbiAgICAgIGhlaWdodD1cIjQ5MS42MzExNFwiXHJcbiAgICAgIHZpZXdCb3g9XCIwIDAgODg2LjM1MSA0OTEuNjMxXCJcclxuICAgICAgey4uLnByb3BzfVxyXG4gICAgPlxyXG4gICAgICA8Y2lyY2xlIGN4PXsyMzIuMzk2fSBjeT17MTAzLjI0Nn0gcj17NTAuNzYzfSBmaWxsPVwiI2ZmNjU4NFwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk0zOTEuNTgyIDI1OS42NzhIMTQyLjU1NmE1LjA4IDUuMDggMCAwMS0uOTMxLS4wNzNMMjU5LjQwMyA1NS41OTZhOC4yNDYgOC4yNDYgMCAwMTE0LjM1NSAwbDc5LjA0NCAxMzYuOTA2IDMuNzg3IDYuNTV6XCJcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgb3BhY2l0eT17MC4yfVxyXG4gICAgICAgIGQ9XCJNMzkxLjU4MiAyNTkuNjc4aC04NS4wMjRsNDEuNzM4LTYwLjYyNiAzLjAwNC00LjM2NyAxLjUwMi0yLjE4MyAzLjc4NyA2LjU1IDM0Ljk5MyA2MC42MjZ6XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTUzMC4yMzggMjU5LjY3OEgzMTQuODUxbDQxLjczOC02MC42MjYgMy4wMDMtNC4zNjcgNTQuMzg4LTc5LjAwN2MzLjU2Ni01LjE3OCAxMi4xNDQtNS41IDE2LjMzNi0uOTc2YTkuODMgOS44MyAwIDAxLjc4My45NzZ6XCJcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezU5My40NjN9IGN5PXsyMTAuODJ9IHI9ezE1LjI5Nn0gZmlsbD1cIiMzZjUxYjVcIiAvPlxyXG4gICAgICA8cGF0aCBmaWxsPVwiIzNmM2Q1NlwiIGQ9XCJNNTk0LjkzOCAyNTYuODk0aC0zLjEzM2wxLjQyOC00OC4zNzggMS43MDUgNDguMzc4elwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiMzZjNkNTZcIlxyXG4gICAgICAgIGQ9XCJNNTkzLjUwOSAyMTcuNjg1bDMuMzY0LTQuNjU0LTMuNDEgNS44MDYtLjM2OC0uNjQ1LjQxNC0uNTA3ek01OTMuMTQxIDIyMi4zODRsLTMuMzY0LTQuNjUzIDMuNDEgNS44MDUuMzY4LS42NDUtLjQxNC0uNTA3elwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezczMy43OH0gY3k9ezIxMC44Mn0gcj17MTUuMjk2fSBmaWxsPVwiIzNmNTFiNVwiIC8+XHJcbiAgICAgIDxwYXRoIGZpbGw9XCIjM2YzZDU2XCIgZD1cIk03MzUuMjU0IDI1Ni44OTRoLTMuMTMzbDEuNDI5LTQ4LjM3OCAxLjcwNCA0OC4zNzh6XCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgZD1cIk03MzMuODI2IDIxNy42ODVsMy4zNjQtNC42NTQtMy40MSA1LjgwNi0uMzY5LS42NDUuNDE1LS41MDd6TTczMy40NTggMjIyLjM4NGwtMy4zNjQtNC42NTMgMy40MSA1LjgwNS4zNjgtLjY0NS0uNDE0LS41MDd6XCJcclxuICAgICAgLz5cclxuICAgICAgPGNpcmNsZSBjeD17NjM3Ljc3NX0gY3k9ezE4OC44NDZ9IHI9ezIyLjU5Mn0gZmlsbD1cIiMzZjUxYjVcIiAvPlxyXG4gICAgICA8cGF0aCBmaWxsPVwiIzNmM2Q1NlwiIGQ9XCJNNjM5Ljk1MiAyNTYuODk0aC00LjYyN2wyLjEwOS03MS40NSAyLjUxOCA3MS40NXpcIiAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjM2YzZDU2XCJcclxuICAgICAgICBkPVwiTTYzNy44NDMgMTk4Ljk4NWw0Ljk2Ny02Ljg3Mi01LjAzNSA4LjU3NC0uNTQ1LS45NTMuNjEzLS43NDl6TTYzNy4yOTggMjA1LjkyNmwtNC45NjctNi44NzIgNS4wMzUgOC41NzMuNTQ1LS45NTItLjYxMy0uNzQ5elwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezY5Mi44Njh9IGN5PXsxODguODQ2fSByPXsyMi41OTJ9IGZpbGw9XCIjM2Y1MWI1XCIgLz5cclxuICAgICAgPHBhdGggZmlsbD1cIiMzZjNkNTZcIiBkPVwiTTY5NS4wNDYgMjU2Ljg5NGgtNC42MjdsMi4xMDktNzEuNDUgMi41MTggNzEuNDV6XCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgZD1cIk02OTIuOTM2IDE5OC45ODVsNC45NjgtNi44NzItNS4wMzYgOC41NzQtLjU0NC0uOTUzLjYxMi0uNzQ5ek02OTIuMzkyIDIwNS45MjZsLTQuOTY4LTYuODcyIDUuMDM2IDguNTczLjU0NC0uOTUyLS42MTItLjc0OXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PXs1NDkuOTY5fSBjeT17MTg4Ljg0Nn0gcj17MjIuNTkyfSBmaWxsPVwiIzNmNTFiNVwiIC8+XHJcbiAgICAgIDxwYXRoIGZpbGw9XCIjM2YzZDU2XCIgZD1cIk01NTIuMTQ2IDI1Ni44OTRoLTQuNjI3bDIuMTEtNzEuNDUgMi41MTcgNzEuNDV6XCIgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBmaWxsPVwiIzNmM2Q1NlwiXHJcbiAgICAgICAgZD1cIk01NTAuMDM3IDE5OC45ODVsNC45NjctNi44NzItNS4wMzUgOC41NzQtLjU0NC0uOTUzLjYxMi0uNzQ5ek01NDkuNDkzIDIwNS45MjZsLTQuOTY4LTYuODcyIDUuMDM2IDguNTczLjU0NC0uOTUyLS42MTItLjc0OXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNODE3LjI1IDQ5MS42MzFINzkuOTg0YTcwLjczNCA3MC43MzQgMCAxMTAtMTQxLjQ2OGg3MzUuNjMzYTI3LjIwNSAyNy4yMDUgMCAwMDAtNTQuNDFINTUuNXYtNDMuNTNoNzYwLjExOGE3MC43MzQgNzAuNzM0IDAgMTEwIDE0MS40NjlINzkuOTg0YTI3LjIwNSAyNy4yMDUgMCAxMDAgNTQuNDFIODE3LjI1elwiXHJcbiAgICAgICAgZmlsbD1cIiNlNmU2ZTZcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjZmZmXCJcclxuICAgICAgICBkPVwiTTgyLjcwNCAyNzIuOWgzMy43MzV2Mi4xNzZIODIuNzA0ek0xNzguNDY3IDI3Mi45aDMzLjczNXYyLjE3NmgtMzMuNzM1ek0yNzQuMjMgMjcyLjloMzMuNzM1djIuMTc2SDI3NC4yM3pNMzY5Ljk5MyAyNzIuOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNDY1Ljc1NiAyNzIuOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNTYxLjUxOSAyNzIuOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNjU3LjI4MiAyNzIuOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNzUzLjA0NSAyNzIuOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNODIuNzA0IDM3MC44MzloMzMuNzM1djIuMTc2SDgyLjcwNHpNMTc4LjQ2NyAzNzAuODM5aDMzLjczNXYyLjE3NmgtMzMuNzM1ek0yNzQuMjMgMzcwLjgzOWgzMy43MzV2Mi4xNzZIMjc0LjIzek0zNjkuOTkzIDM3MC44MzloMzMuNzM1djIuMTc2aC0zMy43MzV6TTQ2NS43NTYgMzcwLjgzOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNTYxLjUxOSAzNzAuODM5aDMzLjczNXYyLjE3NmgtMzMuNzM1ek02NTcuMjgyIDM3MC44MzloMzMuNzM1djIuMTc2aC0zMy43MzV6TTc1My4wNDUgMzcwLjgzOWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNODIuNzA0IDQ2OC43NzloMzMuNzM1djIuMTc2SDgyLjcwNHpNMTc4LjQ2NyA0NjguNzc5aDMzLjczNXYyLjE3NmgtMzMuNzM1ek0yNzQuMjMgNDY4Ljc3OWgzMy43MzV2Mi4xNzZIMjc0LjIzek0zNjkuOTkzIDQ2OC43NzloMzMuNzM1djIuMTc2aC0zMy43MzV6TTQ2NS43NTYgNDY4Ljc3OWgzMy43MzV2Mi4xNzZoLTMzLjczNXpNNTYxLjUxOSA0NjguNzc5aDMzLjczNXYyLjE3NmgtMzMuNzM1ek02NTcuMjgyIDQ2OC43NzloMzMuNzM1djIuMTc2aC0zMy43MzV6TTc1My4wNDUgNDY4Ljc3OWgzMy43MzV2Mi4xNzZoLTMzLjczNXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNTc1LjE4NiA5NC42OTVhMjguOTkyIDI4Ljk5MiAwIDAwLTYuMDQ1LTUuNzAzaDEyLjYyNGEyMS4xMTQgMjEuMTE0IDAgMDAtNi41OCA1LjcwM3pNNTMzLjkxOSA4OC45OTJoMi4xNzZjLS40NjcuMzI4LS45MzYuNjU1LTEuMzgzIDEuMDEtLjI1NS0uMzQ1LS41MjctLjY3NS0uNzkzLTEuMDF6XCJcclxuICAgICAgICBmaWxsPVwibm9uZVwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01OTEuODY4IDg2LjM3NGEyMC44MzMgMjAuODMzIDAgMDExMC4xMjkgMi42MThoLTIwLjIzMmEyMC43NDIgMjAuNzQyIDAgMDExMC4xMDMtMi42MTh6TTU1Mi42MDcgODMuNzU3YTI4LjYyMyAyOC42MjMgMCAwMTE2LjUzNCA1LjIzNWgtMzMuMDQ2YTI4LjYxNiAyOC42MTYgMCAwMTE2LjUxMi01LjIzNXpNMzMwLjIxMiA1MC42MjNBNTMuNjU2IDUzLjY1NiAwIDAxNDM1LjQ4NiAzOS4zMWMuNjUtLjAyMyAxLjMtLjA0OSAxLjk1NS0uMDQ5YTUzLjY3IDUzLjY3IDAgMDE1MS40ODIgMzguNTM4IDM3LjkyIDM3LjkyIDAgMDE0NC45OTYgMTEuMTkzSDM2Ni41NDdhMzYuMjkzIDM2LjI5MyAwIDAxLTM2LjM3My0zNy41NzhxLjAxNi0uMzk1LjAzOC0uNzkxelwiXHJcbiAgICAgICAgZmlsbD1cIiNlNmU2ZTZcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGQ9XCJNNjIwLjc2MyAxMzMuODdhMjguOTkyIDI4Ljk5MiAwIDAxNi4wNDUtNS43MDNoLTEyLjYyNGEyMS4xMTQgMjEuMTE0IDAgMDE2LjU3OSA1LjcwNHpNNjYyLjAzIDEyOC4xNjdoLTIuMTc3Yy40NjguMzI5LjkzNy42NTYgMS4zODQgMS4wMS4yNTQtLjM0NC41MjctLjY3NC43OTMtMS4wMXpcIlxyXG4gICAgICAgIGZpbGw9XCJub25lXCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTYwNC4wOCAxMjUuNTVhMjAuODMzIDIwLjgzMyAwIDAwLTEwLjEyOCAyLjYxN2gyMC4yMzJhMjAuNzQyIDIwLjc0MiAwIDAwLTEwLjEwMy0yLjYxN3pNNjQzLjM0MiAxMjIuOTMyYTI4LjYyMyAyOC42MjMgMCAwMC0xNi41MzQgNS4yMzVoMzMuMDQ1YTI4LjYxNiAyOC42MTYgMCAwMC0xNi41MTEtNS4yMzV6TTg2NS43MzcgODkuNzk5YTUzLjY1NiA1My42NTYgMCAwMC0xMDUuMjc1LTExLjMxM2MtLjY1LS4wMjMtMS4yOTktLjA1LTEuOTU1LS4wNWE1My42NyA1My42NyAwIDAwLTUxLjQ4MiAzOC41MzkgMzcuOTIgMzcuOTIgMCAwMC00NC45OTUgMTEuMTkyaDE2Ny4zNzJhMzYuMjkzIDM2LjI5MyAwIDAwMzYuMzczLTM3LjU3N3EtLjAxNi0uMzk1LS4wMzgtLjc5MXpcIlxyXG4gICAgICAgIGZpbGw9XCIjZTZlNmU2XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGggZmlsbD1cIiMzZjNkNTZcIiBkPVwiTTc3My42MDQgNDYxLjIyM2wtMTkuNDUzLS4wMS4wMDItMy4wODggMTkuNDUzLjAxelwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk02MTMuNTA3IDQ1OC44MjJsNC4wMTQuOTI4IDE1Mi41MzMuMDgyIDEuMzcyLTMuMTk2YTMyLjI1NyAzMi4yNTcgMCAwMDIuMzcxLTE3LjQ0MmMtLjY1Ny00LjQxNC0yLjMwMy04LjgtNi4wNDItMTAuNzA0bC02Ljc2OS00NS4wODQtODQuMzg5LS4xNTEtMzIuNjUgMjYuMzM0cy0xNS40LS4yNzctMjMuNzY4IDEwLjE0YTI0LjQ1IDI0LjQ1IDAgMDAtNS4xMTQgMTMuNDY1bC0uMzMgNS40MnpcIlxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgLz5cclxuICAgICAgPGNpcmNsZSBjeD17NjQ3LjAwOX0gY3k9ezQ1OC4wNjd9IHI9ezE4LjgzNX0gZmlsbD1cIiMzZjNkNTZcIiAvPlxyXG4gICAgICA8Y2lyY2xlIGN4PXs2NDcuMDA5fSBjeT17NDU4LjA2N30gcj17OS45MTN9IGZpbGw9XCIjY2NjXCIgLz5cclxuICAgICAgPGNpcmNsZSBjeD17NzM5Ljk1fSBjeT17NDU4LjExN30gcj17MTguODM1fSBmaWxsPVwiIzNmM2Q1NlwiIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezczOS45NX0gY3k9ezQ1OC4xMTd9IHI9ezkuOTEzfSBmaWxsPVwiI2NjY1wiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZmlsbD1cIiNmZmZcIlxyXG4gICAgICAgIGQ9XCJNNjU2LjkyIDQwNi41MTFsNDUuNTYzLjAxOWg1LjU2Mmw5LjM5LjAwN3YtLjY4NWwuMDA3LTguMjU4LjAwNy05LjI3MmgtNi4yNDhsLTUuNTYyLS4wMDYtOS44NTItLjAwN2gtNS41NjJsLTExLjM3NC0uMDA3LTIxLjkzMSAxOC4yMDl6TTcyNC44NDkgNDA2LjU0NGwyNC4wOC4wMTMuMDA2LTQuNzI1di04LjI1OGwuMDA3LTUuMjMyaC0zLjUyNmwtNS41NjItLjAwNy0xNC45OTgtLjAwNi0uMDA3IDE4LjIxNXpcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjM2YzZDU2XCJcclxuICAgICAgICBkPVwiTTcxNy40MjYgNDI1Ljk5M2wtMy4wODgtLjAwMi4wMDMtNS44NjcgMy4wODguMDAyek02NjkuMjY2IDQxMS43NjRsLS4wMDIgMy4wODgtNS44NjctLjAwNC4wMDItMy4wODh6XCJcclxuICAgICAgLz5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTY2Ny4xMDQgNDEzLjEyaC0uMzRhNi40NTMgNi40NTMgMCAwMS02LjQ1LTYuNDU2IDYuNDUzIDYuNDUzIDAgMDE2LjQ1Ny02LjQ1aC4zNGwtLjAwNyAxMi45MDd6TTYxNC43MzUgNDM4LjYxM2E5Ljk3NSA5Ljk3NSAwIDAwNS40NDQtMTguODg1IDI0LjQ1IDI0LjQ1IDAgMDAtNS4xMTQgMTMuNDY2elwiXHJcbiAgICAgICAgZmlsbD1cIiMzZjNkNTZcIlxyXG4gICAgICAvPlxyXG4gICAgICA8cGF0aFxyXG4gICAgICAgIGZpbGw9XCIjZjJmMmYyXCJcclxuICAgICAgICBkPVwiTTcwNS42MzkgMzg4LjMxNmwxMS43OTYgMTcuNTM2LjAwNy04LjI1OC02LjI0MS05LjI3Mi01LjU2Mi0uMDA2ek03MzkuODU0IDM4OC4zMzVsOS4wODEgMTMuNDk3di04LjI1OGwtMy41MTktNS4yMzItNS41NjItLjAwN3pNNjkwLjIyNSAzODguMzA5bDEyLjI1OCAxOC4yMjFoNS41NjJsLTEyLjI1OC0xOC4yMjFoLTUuNTYyelwiXHJcbiAgICAgIC8+XHJcbiAgICAgIDxjaXJjbGUgY3g9ezUwLjA1OH0gY3k9ezI2MC45M30gcj17NTAuMDU4fSBmaWxsPVwiIzNmM2Q1NlwiIC8+XHJcbiAgICAgIDxwYXRoXHJcbiAgICAgICAgZD1cIk01MC4yNjYgMjc2bC0yNS4wNS0yNS4wNWE0LjM1MyA0LjM1MyAwIDAxNi4xNTYtNi4xNTdMNDkuODUgMjYzLjI3bDU4Ljk2NC02Ny4yNGE0LjM1MyA0LjM1MyAwIDAxNi41NDUgNS43NHpcIlxyXG4gICAgICAgIGZpbGw9XCIjM2Y1MWI1XCJcclxuICAgICAgLz5cclxuICAgIDwvc3ZnPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFN2Z1VuZHJhd05hdmlnYXRvckE0Nzk7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvU3ZnVW5kcmF3TmF2aWdhdG9yQTQ3OS50c3gifQ==