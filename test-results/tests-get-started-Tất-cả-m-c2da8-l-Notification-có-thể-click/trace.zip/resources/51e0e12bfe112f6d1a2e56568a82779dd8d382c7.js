import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationListItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import {
  Check as CheckIcon,
  ThumbUpAltOutlined as LikeIcon,
  Payment as PaymentIcon,
  CommentRounded as CommentIcon,
  MonetizationOn as MonetizationOnIcon
} from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import {
  Button,
  ListItemIcon,
  ListItemText,
  useTheme,
  useMediaQuery,
  ListItem,
  IconButton
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import {
  isCommentNotification,
  isLikeNotification,
  isPaymentNotification,
  isPaymentRequestedNotification,
  isPaymentReceivedNotification
} from "/src/utils/transactionUtils.ts";
const PREFIX = "NotificationListItem";
const classes = {
  card: `${PREFIX}-card`,
  title: `${PREFIX}-title`,
  green: `${PREFIX}-green`,
  red: `${PREFIX}-red`,
  blue: `${PREFIX}-blue`
};
const StyledListItem = styled(ListItem)({
  [`& .${classes.card}`]: {
    minWidth: "100%"
  },
  [`& .${classes.title}`]: {
    fontSize: 18
  },
  [`& .${classes.green}`]: {
    color: "#4CAF50"
  },
  [`& .${classes.red}`]: {
    color: "red"
  },
  [`& .${classes.blue}`]: {
    color: "blue"
  }
});
_c = StyledListItem;
const NotificationListItem = ({
  notification,
  updateNotification
}) => {
  _s();
  const theme = useTheme();
  let listItemText = void 0;
  let listItemIcon = void 0;
  const xsBreakpoint = useMediaQuery(theme.breakpoints.only("xs"));
  if (isCommentNotification(notification)) {
    listItemIcon = /* @__PURE__ */ jsxDEV(CommentIcon, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
      lineNumber: 73,
      columnNumber: 20
    }, this);
    listItemText = `${notification.userFullName} commented on a transaction.`;
  }
  if (isLikeNotification(notification)) {
    listItemIcon = /* @__PURE__ */ jsxDEV(LikeIcon, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
      lineNumber: 78,
      columnNumber: 20
    }, this);
    listItemText = `${notification.userFullName} liked a transaction.`;
  }
  if (isPaymentNotification(notification)) {
    if (isPaymentRequestedNotification(notification)) {
      listItemIcon = /* @__PURE__ */ jsxDEV(PaymentIcon, { className: classes.red }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
        lineNumber: 84,
        columnNumber: 22
      }, this);
      listItemText = `${notification.userFullName} requested payment.`;
    } else if (isPaymentReceivedNotification(notification)) {
      listItemIcon = /* @__PURE__ */ jsxDEV(MonetizationOnIcon, { className: classes.green }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
        lineNumber: 87,
        columnNumber: 22
      }, this);
      listItemText = `${notification.userFullName} received payment.`;
    }
  }
  return /* @__PURE__ */ jsxDEV(StyledListItem, { "data-test": `notification-list-item-${notification.id}`, children: [
    /* @__PURE__ */ jsxDEV(ListItemIcon, { children: listItemIcon }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ListItemText, { primary: listItemText }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    xsBreakpoint && /* @__PURE__ */ jsxDEV(
      IconButton,
      {
        "aria-label": "mark as read",
        color: "primary",
        onClick: () => updateNotification({ id: notification.id, isRead: true }),
        "data-test": `notification-mark-read-${notification.id}`,
        size: "large",
        children: /* @__PURE__ */ jsxDEV(CheckIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
          lineNumber: 104,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
        lineNumber: 97,
        columnNumber: 7
      },
      this
    ),
    !xsBreakpoint && /* @__PURE__ */ jsxDEV(
      Button,
      {
        color: "primary",
        size: "small",
        onClick: () => updateNotification({ id: notification.id, isRead: true }),
        "data-test": `notification-mark-read-${notification.id}`,
        children: "Dismiss"
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
        lineNumber: 108,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx",
    lineNumber: 93,
    columnNumber: 5
  }, this);
};
_s(NotificationListItem, "EYknzVIJFZbV16Fq/7hdpbyJKbA=", false, function() {
  return [useTheme, useMediaQuery];
});
_c2 = NotificationListItem;
export default NotificationListItem;
var _c, _c2;
$RefreshReg$(_c, "StyledListItem");
$RefreshReg$(_c2, "NotificationListItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NotificationListItem.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0VtQjsyQkF4RW5CO0FBQWtCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXpCLFNBQVNBLGNBQWM7QUFFdkI7QUFBQSxFQUNFQyxTQUFTQztBQUFBQSxFQUNUQyxzQkFBc0JDO0FBQUFBLEVBQ3RCQyxXQUFXQztBQUFBQSxFQUNYQyxrQkFBa0JDO0FBQUFBLEVBQ2xCQyxrQkFBa0JDO0FBQUFBLE9BQ2I7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFDUDtBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFRUCxNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE1BQU0sR0FBR0YsTUFBTTtBQUFBLEVBQ2ZHLE9BQU8sR0FBR0gsTUFBTTtBQUFBLEVBQ2hCSSxPQUFPLEdBQUdKLE1BQU07QUFBQSxFQUNoQkssS0FBSyxHQUFHTCxNQUFNO0FBQUEsRUFDZE0sTUFBTSxHQUFHTixNQUFNO0FBQ2pCO0FBRUEsTUFBTU8saUJBQWlCOUIsT0FBT2dCLFFBQVEsRUFBRTtBQUFBLEVBQ3RDLENBQUMsTUFBTVEsUUFBUUMsSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUN0Qk0sVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBLENBQUMsTUFBTVAsUUFBUUUsS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN2Qk0sVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBLENBQUMsTUFBTVIsUUFBUUcsS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN2Qk0sT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLENBQUMsTUFBTVQsUUFBUUksR0FBRyxFQUFFLEdBQUc7QUFBQSxJQUNyQkssT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLENBQUMsTUFBTVQsUUFBUUssSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUN0QkksT0FBTztBQUFBLEVBQ1Q7QUFDRixDQUFDO0FBQUVDLEtBaEJHSjtBQWtCTixNQUFNSyx1QkFBNERBLENBQUM7QUFBQSxFQUNqRUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQUFDLEtBQUE7QUFDSixRQUFNQyxRQUFRekIsU0FBUztBQUN2QixNQUFJMEIsZUFBZUM7QUFDbkIsTUFBSUMsZUFBZUQ7QUFDbkIsUUFBTUUsZUFBZTVCLGNBQWN3QixNQUFNSyxZQUFZQyxLQUFLLElBQUksQ0FBQztBQUUvRCxNQUFJM0Isc0JBQXNCa0IsWUFBWSxHQUFHO0FBQ3ZDTSxtQkFBZSx1QkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFDM0JGLG1CQUFlLEdBQUdKLGFBQWFVLFlBQVk7QUFBQSxFQUM3QztBQUVBLE1BQUkzQixtQkFBbUJpQixZQUFZLEdBQUc7QUFDcENNLG1CQUFlLHVCQUFDLGNBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFTO0FBQ3hCRixtQkFBZSxHQUFHSixhQUFhVSxZQUFZO0FBQUEsRUFDN0M7QUFFQSxNQUFJMUIsc0JBQXNCZ0IsWUFBWSxHQUFHO0FBQ3ZDLFFBQUlmLCtCQUErQmUsWUFBWSxHQUFHO0FBQ2hETSxxQkFBZSx1QkFBQyxlQUFZLFdBQVdsQixRQUFRSSxPQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9DO0FBQ25EWSxxQkFBZSxHQUFHSixhQUFhVSxZQUFZO0FBQUEsSUFDN0MsV0FBV3hCLDhCQUE4QmMsWUFBWSxHQUFHO0FBQ3RETSxxQkFBZSx1QkFBQyxzQkFBbUIsV0FBV2xCLFFBQVFHLFNBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBNkM7QUFDNURhLHFCQUFlLEdBQUdKLGFBQWFVLFlBQVk7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFFQSxTQUNFLHVCQUFDLGtCQUFlLGFBQVcsMEJBQTBCVixhQUFhVyxFQUFFLElBQ2xFO0FBQUEsMkJBQUMsZ0JBQWNMLDBCQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxJQUM3Qix1QkFBQyxnQkFBYSxTQUFTRixnQkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvQztBQUFBLElBQ25DRyxnQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsY0FBVztBQUFBLFFBQ1gsT0FBTTtBQUFBLFFBQ04sU0FBUyxNQUFNTixtQkFBbUIsRUFBRVUsSUFBSVgsYUFBYVcsSUFBSUMsUUFBUSxLQUFLLENBQUM7QUFBQSxRQUN2RSxhQUFXLDBCQUEwQlosYUFBYVcsRUFBRTtBQUFBLFFBQ3BELE1BQUs7QUFBQSxRQUVMLGlDQUFDLGVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFVO0FBQUE7QUFBQSxNQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQVFBO0FBQUEsSUFFRCxDQUFDSixnQkFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sTUFBSztBQUFBLFFBQ0wsU0FBUyxNQUFNTixtQkFBbUIsRUFBRVUsSUFBSVgsYUFBYVcsSUFBSUMsUUFBUSxLQUFLLENBQUM7QUFBQSxRQUN2RSxhQUFXLDBCQUEwQlosYUFBYVcsRUFBRTtBQUFBLFFBQUc7QUFBQTtBQUFBLE1BSnpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9BO0FBQUEsT0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVKO0FBQUVULEdBeERJSCxzQkFBeUQ7QUFBQSxVQUkvQ3JCLFVBR09DLGFBQWE7QUFBQTtBQUFBa0MsTUFQOUJkO0FBMEROLGVBQWVBO0FBQXFCLElBQUFELElBQUFlO0FBQUFDLGFBQUFoQixJQUFBO0FBQUFnQixhQUFBRCxLQUFBIiwibmFtZXMiOlsic3R5bGVkIiwiQ2hlY2siLCJDaGVja0ljb24iLCJUaHVtYlVwQWx0T3V0bGluZWQiLCJMaWtlSWNvbiIsIlBheW1lbnQiLCJQYXltZW50SWNvbiIsIkNvbW1lbnRSb3VuZGVkIiwiQ29tbWVudEljb24iLCJNb25ldGl6YXRpb25PbiIsIk1vbmV0aXphdGlvbk9uSWNvbiIsIkJ1dHRvbiIsIkxpc3RJdGVtSWNvbiIsIkxpc3RJdGVtVGV4dCIsInVzZVRoZW1lIiwidXNlTWVkaWFRdWVyeSIsIkxpc3RJdGVtIiwiSWNvbkJ1dHRvbiIsImlzQ29tbWVudE5vdGlmaWNhdGlvbiIsImlzTGlrZU5vdGlmaWNhdGlvbiIsImlzUGF5bWVudE5vdGlmaWNhdGlvbiIsImlzUGF5bWVudFJlcXVlc3RlZE5vdGlmaWNhdGlvbiIsImlzUGF5bWVudFJlY2VpdmVkTm90aWZpY2F0aW9uIiwiUFJFRklYIiwiY2xhc3NlcyIsImNhcmQiLCJ0aXRsZSIsImdyZWVuIiwicmVkIiwiYmx1ZSIsIlN0eWxlZExpc3RJdGVtIiwibWluV2lkdGgiLCJmb250U2l6ZSIsImNvbG9yIiwiX2MiLCJOb3RpZmljYXRpb25MaXN0SXRlbSIsIm5vdGlmaWNhdGlvbiIsInVwZGF0ZU5vdGlmaWNhdGlvbiIsIl9zIiwidGhlbWUiLCJsaXN0SXRlbVRleHQiLCJ1bmRlZmluZWQiLCJsaXN0SXRlbUljb24iLCJ4c0JyZWFrcG9pbnQiLCJicmVha3BvaW50cyIsIm9ubHkiLCJ1c2VyRnVsbE5hbWUiLCJpZCIsImlzUmVhZCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5vdGlmaWNhdGlvbkxpc3RJdGVtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcblxyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuXHJcbmltcG9ydCB7XHJcbiAgQ2hlY2sgYXMgQ2hlY2tJY29uLFxyXG4gIFRodW1iVXBBbHRPdXRsaW5lZCBhcyBMaWtlSWNvbixcclxuICBQYXltZW50IGFzIFBheW1lbnRJY29uLFxyXG4gIENvbW1lbnRSb3VuZGVkIGFzIENvbW1lbnRJY29uLFxyXG4gIE1vbmV0aXphdGlvbk9uIGFzIE1vbmV0aXphdGlvbk9uSWNvbixcclxufSBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbFwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBMaXN0SXRlbUljb24sXHJcbiAgTGlzdEl0ZW1UZXh0LFxyXG4gIHVzZVRoZW1lLFxyXG4gIHVzZU1lZGlhUXVlcnksXHJcbiAgTGlzdEl0ZW0sXHJcbiAgSWNvbkJ1dHRvbixcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQge1xyXG4gIGlzQ29tbWVudE5vdGlmaWNhdGlvbixcclxuICBpc0xpa2VOb3RpZmljYXRpb24sXHJcbiAgaXNQYXltZW50Tm90aWZpY2F0aW9uLFxyXG4gIGlzUGF5bWVudFJlcXVlc3RlZE5vdGlmaWNhdGlvbixcclxuICBpc1BheW1lbnRSZWNlaXZlZE5vdGlmaWNhdGlvbixcclxufSBmcm9tIFwiLi4vdXRpbHMvdHJhbnNhY3Rpb25VdGlsc1wiO1xyXG5pbXBvcnQgeyBOb3RpZmljYXRpb25SZXNwb25zZUl0ZW0gfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIE5vdGlmaWNhdGlvbkxpc3RJdGVtUHJvcHMge1xyXG4gIG5vdGlmaWNhdGlvbjogTm90aWZpY2F0aW9uUmVzcG9uc2VJdGVtO1xyXG4gIHVwZGF0ZU5vdGlmaWNhdGlvbjogRnVuY3Rpb247XHJcbn1cclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiTm90aWZpY2F0aW9uTGlzdEl0ZW1cIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgY2FyZDogYCR7UFJFRklYfS1jYXJkYCxcclxuICB0aXRsZTogYCR7UFJFRklYfS10aXRsZWAsXHJcbiAgZ3JlZW46IGAke1BSRUZJWH0tZ3JlZW5gLFxyXG4gIHJlZDogYCR7UFJFRklYfS1yZWRgLFxyXG4gIGJsdWU6IGAke1BSRUZJWH0tYmx1ZWAsXHJcbn07XHJcblxyXG5jb25zdCBTdHlsZWRMaXN0SXRlbSA9IHN0eWxlZChMaXN0SXRlbSkoe1xyXG4gIFtgJiAuJHtjbGFzc2VzLmNhcmR9YF06IHtcclxuICAgIG1pbldpZHRoOiBcIjEwMCVcIixcclxuICB9LFxyXG4gIFtgJiAuJHtjbGFzc2VzLnRpdGxlfWBdOiB7XHJcbiAgICBmb250U2l6ZTogMTgsXHJcbiAgfSxcclxuICBbYCYgLiR7Y2xhc3Nlcy5ncmVlbn1gXToge1xyXG4gICAgY29sb3I6IFwiIzRDQUY1MFwiLFxyXG4gIH0sXHJcbiAgW2AmIC4ke2NsYXNzZXMucmVkfWBdOiB7XHJcbiAgICBjb2xvcjogXCJyZWRcIixcclxuICB9LFxyXG4gIFtgJiAuJHtjbGFzc2VzLmJsdWV9YF06IHtcclxuICAgIGNvbG9yOiBcImJsdWVcIixcclxuICB9LFxyXG59KTtcclxuXHJcbmNvbnN0IE5vdGlmaWNhdGlvbkxpc3RJdGVtOiBSZWFjdC5GQzxOb3RpZmljYXRpb25MaXN0SXRlbVByb3BzPiA9ICh7XHJcbiAgbm90aWZpY2F0aW9uLFxyXG4gIHVwZGF0ZU5vdGlmaWNhdGlvbixcclxufSkgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKTtcclxuICBsZXQgbGlzdEl0ZW1UZXh0ID0gdW5kZWZpbmVkO1xyXG4gIGxldCBsaXN0SXRlbUljb24gPSB1bmRlZmluZWQ7XHJcbiAgY29uc3QgeHNCcmVha3BvaW50ID0gdXNlTWVkaWFRdWVyeSh0aGVtZS5icmVha3BvaW50cy5vbmx5KFwieHNcIikpO1xyXG5cclxuICBpZiAoaXNDb21tZW50Tm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbikpIHtcclxuICAgIGxpc3RJdGVtSWNvbiA9IDxDb21tZW50SWNvbiAvPjtcclxuICAgIGxpc3RJdGVtVGV4dCA9IGAke25vdGlmaWNhdGlvbi51c2VyRnVsbE5hbWV9IGNvbW1lbnRlZCBvbiBhIHRyYW5zYWN0aW9uLmA7XHJcbiAgfVxyXG5cclxuICBpZiAoaXNMaWtlTm90aWZpY2F0aW9uKG5vdGlmaWNhdGlvbikpIHtcclxuICAgIGxpc3RJdGVtSWNvbiA9IDxMaWtlSWNvbiAvPjtcclxuICAgIGxpc3RJdGVtVGV4dCA9IGAke25vdGlmaWNhdGlvbi51c2VyRnVsbE5hbWV9IGxpa2VkIGEgdHJhbnNhY3Rpb24uYDtcclxuICB9XHJcblxyXG4gIGlmIChpc1BheW1lbnROb3RpZmljYXRpb24obm90aWZpY2F0aW9uKSkge1xyXG4gICAgaWYgKGlzUGF5bWVudFJlcXVlc3RlZE5vdGlmaWNhdGlvbihub3RpZmljYXRpb24pKSB7XHJcbiAgICAgIGxpc3RJdGVtSWNvbiA9IDxQYXltZW50SWNvbiBjbGFzc05hbWU9e2NsYXNzZXMucmVkfSAvPjtcclxuICAgICAgbGlzdEl0ZW1UZXh0ID0gYCR7bm90aWZpY2F0aW9uLnVzZXJGdWxsTmFtZX0gcmVxdWVzdGVkIHBheW1lbnQuYDtcclxuICAgIH0gZWxzZSBpZiAoaXNQYXltZW50UmVjZWl2ZWROb3RpZmljYXRpb24obm90aWZpY2F0aW9uKSkge1xyXG4gICAgICBsaXN0SXRlbUljb24gPSA8TW9uZXRpemF0aW9uT25JY29uIGNsYXNzTmFtZT17Y2xhc3Nlcy5ncmVlbn0gLz47XHJcbiAgICAgIGxpc3RJdGVtVGV4dCA9IGAke25vdGlmaWNhdGlvbi51c2VyRnVsbE5hbWV9IHJlY2VpdmVkIHBheW1lbnQuYDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkTGlzdEl0ZW0gZGF0YS10ZXN0PXtgbm90aWZpY2F0aW9uLWxpc3QtaXRlbS0ke25vdGlmaWNhdGlvbi5pZH1gfT5cclxuICAgICAgPExpc3RJdGVtSWNvbj57bGlzdEl0ZW1JY29uIX08L0xpc3RJdGVtSWNvbj5cclxuICAgICAgPExpc3RJdGVtVGV4dCBwcmltYXJ5PXtsaXN0SXRlbVRleHR9IC8+XHJcbiAgICAgIHt4c0JyZWFrcG9pbnQgJiYgKFxyXG4gICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICBhcmlhLWxhYmVsPVwibWFyayBhcyByZWFkXCJcclxuICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB1cGRhdGVOb3RpZmljYXRpb24oeyBpZDogbm90aWZpY2F0aW9uLmlkLCBpc1JlYWQ6IHRydWUgfSl9XHJcbiAgICAgICAgICBkYXRhLXRlc3Q9e2Bub3RpZmljYXRpb24tbWFyay1yZWFkLSR7bm90aWZpY2F0aW9uLmlkfWB9XHJcbiAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxDaGVja0ljb24gLz5cclxuICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICl9XHJcbiAgICAgIHsheHNCcmVha3BvaW50ICYmIChcclxuICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgc2l6ZT1cInNtYWxsXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHVwZGF0ZU5vdGlmaWNhdGlvbih7IGlkOiBub3RpZmljYXRpb24uaWQsIGlzUmVhZDogdHJ1ZSB9KX1cclxuICAgICAgICAgIGRhdGEtdGVzdD17YG5vdGlmaWNhdGlvbi1tYXJrLXJlYWQtJHtub3RpZmljYXRpb24uaWR9YH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBEaXNtaXNzXHJcbiAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICl9XHJcbiAgICA8L1N0eWxlZExpc3RJdGVtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb25MaXN0SXRlbTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9Ob3RpZmljYXRpb25MaXN0SXRlbS50c3gifQ==