import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionContactsList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionContactsList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import TransactionList from "/src/components/TransactionList.tsx";
import { contactsTransactionsMachine } from "/src/machines/contactsTransactionsMachine.ts";
const TransactionContactsList = ({
  filterComponent,
  dateRangeFilters,
  amountRangeFilters
}) => {
  _s();
  const [current, send, contactTransactionService] = useMachine(contactsTransactionsMachine);
  const { pageData, results } = current.context;
  if (window.Cypress) {
    window.contactTransactionService = contactTransactionService;
  }
  useEffect(() => {
    send("FETCH", { ...dateRangeFilters, ...amountRangeFilters });
  }, [send, dateRangeFilters, amountRangeFilters]);
  const loadNextPage = (page) => send("FETCH", { page, ...dateRangeFilters, ...amountRangeFilters });
  return /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(
    TransactionList,
    {
      filterComponent,
      header: "Contacts",
      transactions: results,
      isLoading: current.matches("loading"),
      loadNextPage,
      pagination: pageData,
      showCreateButton: true
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionContactsList.tsx",
      lineNumber: 41,
      columnNumber: 7
    },
    this
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionContactsList.tsx",
    lineNumber: 40,
    columnNumber: 5
  }, this);
};
_s(TransactionContactsList, "QZ9WiT1+1q2+QbH7HC0fi4PI99g=", false, function() {
  return [useMachine];
});
_c = TransactionContactsList;
export default TransactionContactsList;
var _c;
$RefreshReg$(_c, "TransactionContactsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionContactsList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionContactsList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUNJLG1CQUNFLGNBREY7MkJBdkNKO0FBQWdCQSxNQUFXQyxjQUFTLE9BQVEsc0JBQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDbkQsU0FBU0Msa0JBQWtCO0FBTzNCLE9BQU9DLHFCQUFxQjtBQUM1QixTQUFTQyxtQ0FBbUM7QUFRNUMsTUFBTUMsMEJBQWlFQSxDQUFDO0FBQUEsRUFDdEVDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTSxDQUFDQyxTQUFTQyxNQUFNQyx5QkFBeUIsSUFBSVYsV0FBV0UsMkJBQTJCO0FBQ3pGLFFBQU0sRUFBRVMsVUFBVUMsUUFBUSxJQUFJSixRQUFRSztBQUd0QyxNQUFJQyxPQUFPQyxTQUFTO0FBRWxCRCxXQUFPSiw0QkFBNEJBO0FBQUFBLEVBQ3JDO0FBRUFaLFlBQVUsTUFBTTtBQUNkVyxTQUFLLFNBQVMsRUFBRSxHQUFHSixrQkFBa0IsR0FBR0MsbUJBQW1CLENBQUM7QUFBQSxFQUM5RCxHQUFHLENBQUNHLE1BQU1KLGtCQUFrQkMsa0JBQWtCLENBQUM7QUFFL0MsUUFBTVUsZUFBZUEsQ0FBQ0MsU0FDcEJSLEtBQUssU0FBUyxFQUFFUSxNQUFNLEdBQUdaLGtCQUFrQixHQUFHQyxtQkFBbUIsQ0FBQztBQUVwRSxTQUNFLG1DQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQztBQUFBLE1BQ0EsUUFBTztBQUFBLE1BQ1AsY0FBY007QUFBQUEsTUFDZCxXQUFXSixRQUFRVSxRQUFRLFNBQVM7QUFBQSxNQUNwQztBQUFBLE1BQ0EsWUFBWVA7QUFBQUEsTUFDWixrQkFBZ0I7QUFBQTtBQUFBLElBUGxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9rQixLQVJwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFFSjtBQUFFSixHQWxDSUoseUJBQThEO0FBQUEsVUFLZkgsVUFBVTtBQUFBO0FBQUFtQixLQUx6RGhCO0FBb0NOLGVBQWVBO0FBQXdCLElBQUFnQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRWZmZWN0IiwiUmVhY3ROb2RlIiwidXNlTWFjaGluZSIsIlRyYW5zYWN0aW9uTGlzdCIsImNvbnRhY3RzVHJhbnNhY3Rpb25zTWFjaGluZSIsIlRyYW5zYWN0aW9uQ29udGFjdHNMaXN0IiwiZmlsdGVyQ29tcG9uZW50IiwiZGF0ZVJhbmdlRmlsdGVycyIsImFtb3VudFJhbmdlRmlsdGVycyIsIl9zIiwiY3VycmVudCIsInNlbmQiLCJjb250YWN0VHJhbnNhY3Rpb25TZXJ2aWNlIiwicGFnZURhdGEiLCJyZXN1bHRzIiwiY29udGV4dCIsIndpbmRvdyIsIkN5cHJlc3MiLCJsb2FkTmV4dFBhZ2UiLCJwYWdlIiwibWF0Y2hlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVHJhbnNhY3Rpb25Db250YWN0c0xpc3QudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QsIFJlYWN0Tm9kZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VNYWNoaW5lIH0gZnJvbSBcIkB4c3RhdGUvcmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBUcmFuc2FjdGlvblBhZ2luYXRpb24sXHJcbiAgVHJhbnNhY3Rpb25SZXNwb25zZUl0ZW0sXHJcbiAgVHJhbnNhY3Rpb25EYXRlUmFuZ2VQYXlsb2FkLFxyXG4gIFRyYW5zYWN0aW9uQW1vdW50UmFuZ2VQYXlsb2FkLFxyXG59IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IFRyYW5zYWN0aW9uTGlzdCBmcm9tIFwiLi9UcmFuc2FjdGlvbkxpc3RcIjtcclxuaW1wb3J0IHsgY29udGFjdHNUcmFuc2FjdGlvbnNNYWNoaW5lIH0gZnJvbSBcIi4uL21hY2hpbmVzL2NvbnRhY3RzVHJhbnNhY3Rpb25zTWFjaGluZVwiO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2FjdGlvbkNvbnRhY3RMaXN0UHJvcHMge1xyXG4gIGZpbHRlckNvbXBvbmVudDogUmVhY3ROb2RlO1xyXG4gIGRhdGVSYW5nZUZpbHRlcnM6IFRyYW5zYWN0aW9uRGF0ZVJhbmdlUGF5bG9hZDtcclxuICBhbW91bnRSYW5nZUZpbHRlcnM6IFRyYW5zYWN0aW9uQW1vdW50UmFuZ2VQYXlsb2FkO1xyXG59XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbkNvbnRhY3RzTGlzdDogUmVhY3QuRkM8VHJhbnNhY3Rpb25Db250YWN0TGlzdFByb3BzPiA9ICh7XHJcbiAgZmlsdGVyQ29tcG9uZW50LFxyXG4gIGRhdGVSYW5nZUZpbHRlcnMsXHJcbiAgYW1vdW50UmFuZ2VGaWx0ZXJzLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgW2N1cnJlbnQsIHNlbmQsIGNvbnRhY3RUcmFuc2FjdGlvblNlcnZpY2VdID0gdXNlTWFjaGluZShjb250YWN0c1RyYW5zYWN0aW9uc01hY2hpbmUpO1xyXG4gIGNvbnN0IHsgcGFnZURhdGEsIHJlc3VsdHMgfSA9IGN1cnJlbnQuY29udGV4dDtcclxuXHJcbiAgLy8gQHRzLWlnbm9yZVxyXG4gIGlmICh3aW5kb3cuQ3lwcmVzcykge1xyXG4gICAgLy8gQHRzLWlnbm9yZVxyXG4gICAgd2luZG93LmNvbnRhY3RUcmFuc2FjdGlvblNlcnZpY2UgPSBjb250YWN0VHJhbnNhY3Rpb25TZXJ2aWNlO1xyXG4gIH1cclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmQoXCJGRVRDSFwiLCB7IC4uLmRhdGVSYW5nZUZpbHRlcnMsIC4uLmFtb3VudFJhbmdlRmlsdGVycyB9KTtcclxuICB9LCBbc2VuZCwgZGF0ZVJhbmdlRmlsdGVycywgYW1vdW50UmFuZ2VGaWx0ZXJzXSk7XHJcblxyXG4gIGNvbnN0IGxvYWROZXh0UGFnZSA9IChwYWdlOiBudW1iZXIpID0+XHJcbiAgICBzZW5kKFwiRkVUQ0hcIiwgeyBwYWdlLCAuLi5kYXRlUmFuZ2VGaWx0ZXJzLCAuLi5hbW91bnRSYW5nZUZpbHRlcnMgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8VHJhbnNhY3Rpb25MaXN0XHJcbiAgICAgICAgZmlsdGVyQ29tcG9uZW50PXtmaWx0ZXJDb21wb25lbnR9XHJcbiAgICAgICAgaGVhZGVyPVwiQ29udGFjdHNcIlxyXG4gICAgICAgIHRyYW5zYWN0aW9ucz17cmVzdWx0cyBhcyBUcmFuc2FjdGlvblJlc3BvbnNlSXRlbVtdfVxyXG4gICAgICAgIGlzTG9hZGluZz17Y3VycmVudC5tYXRjaGVzKFwibG9hZGluZ1wiKX1cclxuICAgICAgICBsb2FkTmV4dFBhZ2U9e2xvYWROZXh0UGFnZX1cclxuICAgICAgICBwYWdpbmF0aW9uPXtwYWdlRGF0YSBhcyBUcmFuc2FjdGlvblBhZ2luYXRpb259XHJcbiAgICAgICAgc2hvd0NyZWF0ZUJ1dHRvblxyXG4gICAgICAvPlxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zYWN0aW9uQ29udGFjdHNMaXN0O1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1RyYW5zYWN0aW9uQ29udGFjdHNMaXN0LnRzeCJ9