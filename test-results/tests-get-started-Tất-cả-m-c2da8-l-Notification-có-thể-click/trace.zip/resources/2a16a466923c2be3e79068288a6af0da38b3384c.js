import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CommentListItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentListItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ListItem, ListItemText } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const CommentListItem = ({ comment }) => {
  return /* @__PURE__ */ jsxDEV(ListItem, { "data-test": `comment-list-item-${comment.id}`, children: /* @__PURE__ */ jsxDEV(ListItemText, { primary: `${comment.content}` }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentListItem.tsx",
    lineNumber: 13,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentListItem.tsx",
    lineNumber: 12,
    columnNumber: 5
  }, this);
};
_c = CommentListItem;
export default CommentListItem;
var _c;
$RefreshReg$(_c, "CommentListItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentListItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/CommentListItem.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWU07QUFaTixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNDLFVBQVVDLG9CQUFvQjtBQVF2QyxNQUFNQyxrQkFBa0RBLENBQUMsRUFBRUMsUUFBUSxNQUFNO0FBQ3ZFLFNBQ0UsdUJBQUMsWUFBUyxhQUFXLHFCQUFxQkEsUUFBUUMsRUFBRSxJQUNsRCxpQ0FBQyxnQkFBYSxTQUFTLEdBQUdELFFBQVFFLE9BQU8sTUFBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUE0QyxLQUQ5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFFQyxLQU5JSjtBQVFOLGVBQWVBO0FBQWdCLElBQUFJO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkxpc3RJdGVtIiwiTGlzdEl0ZW1UZXh0IiwiQ29tbWVudExpc3RJdGVtIiwiY29tbWVudCIsImlkIiwiY29udGVudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ29tbWVudExpc3RJdGVtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpc3RJdGVtLCBMaXN0SXRlbVRleHQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IHsgQ29tbWVudCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgQ29tbWVudExpc3RJdGVtUHJvcHMge1xyXG4gIGNvbW1lbnQ6IENvbW1lbnQ7XHJcbn1cclxuXHJcbmNvbnN0IENvbW1lbnRMaXN0SXRlbTogUmVhY3QuRkM8Q29tbWVudExpc3RJdGVtUHJvcHM+ID0gKHsgY29tbWVudCB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxMaXN0SXRlbSBkYXRhLXRlc3Q9e2Bjb21tZW50LWxpc3QtaXRlbS0ke2NvbW1lbnQuaWR9YH0+XHJcbiAgICAgIDxMaXN0SXRlbVRleHQgcHJpbWFyeT17YCR7Y29tbWVudC5jb250ZW50fWB9IC8+XHJcbiAgICA8L0xpc3RJdGVtPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb21tZW50TGlzdEl0ZW07XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvQ29tbWVudExpc3RJdGVtLnRzeCJ9