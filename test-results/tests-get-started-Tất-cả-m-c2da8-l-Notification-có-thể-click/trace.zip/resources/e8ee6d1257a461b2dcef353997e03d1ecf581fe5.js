import {
  __commonJS
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";

// node_modules/@babel/runtime/helpers/interopRequireDefault.js
var require_interopRequireDefault = __commonJS({
  "node_modules/@babel/runtime/helpers/interopRequireDefault.js"(exports, module) {
    function _interopRequireDefault(e) {
      return e && e.__esModule ? e : {
        "default": e
      };
    }
    module.exports = _interopRequireDefault, module.exports.__esModule = true, module.exports["default"] = module.exports;
  }
});

export {
  require_interopRequireDefault
};
//# sourceMappingURL=chunk-L5I5XQMD.js.map
