import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Footer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Container, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import CypressLogo from "/src/components/SvgCypressLogo.tsx";
export default function Footer() {
  return /* @__PURE__ */ jsxDEV(Container, { maxWidth: "sm", style: { marginTop: 50 }, children: /* @__PURE__ */ jsxDEV(Typography, { variant: "body2", color: "textSecondary", align: "center", children: [
    "Built by",
    /* @__PURE__ */ jsxDEV(
      "a",
      {
        style: { textDecoration: "none" },
        target: "_blank",
        rel: "noopener noreferrer",
        href: "https://cypress.io",
        children: /* @__PURE__ */ jsxDEV(
          CypressLogo,
          {
            style: {
              marginTop: -2,
              marginLeft: 5,
              height: "20px",
              width: "55px",
              verticalAlign: "middle"
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx",
            lineNumber: 17,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx",
        lineNumber: 11,
        columnNumber: 9
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx",
    lineNumber: 9,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx",
    lineNumber: 8,
    columnNumber: 5
  }, this);
}
_c = Footer;
var _c;
$RefreshReg$(_c, "Footer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/Footer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVO0FBaEJWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsV0FBV0Msa0JBQWtCO0FBRXRDLE9BQU9DLGlCQUFpQjtBQUV4Qix3QkFBd0JDLFNBQVM7QUFDL0IsU0FDRSx1QkFBQyxhQUFVLFVBQVMsTUFBSyxPQUFPLEVBQUVDLFdBQVcsR0FBRyxHQUM5QyxpQ0FBQyxjQUFXLFNBQVEsU0FBUSxPQUFNLGlCQUFnQixPQUFNLFVBQVM7QUFBQTtBQUFBLElBRS9EO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxPQUFPLEVBQUVDLGdCQUFnQixPQUFPO0FBQUEsUUFDaEMsUUFBTztBQUFBLFFBQ1AsS0FBSTtBQUFBLFFBQ0osTUFBSztBQUFBLFFBRUw7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDLE9BQU87QUFBQSxjQUNMRCxXQUFXO0FBQUEsY0FDWEUsWUFBWTtBQUFBLGNBQ1pDLFFBQVE7QUFBQSxjQUNSQyxPQUFPO0FBQUEsY0FDUEMsZUFBZTtBQUFBLFlBQ2pCO0FBQUE7QUFBQSxVQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQU9JO0FBQUE7QUFBQSxNQWJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWVBO0FBQUEsT0FqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWtCQSxLQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQ0MsS0F4QnVCUDtBQUFNLElBQUFPO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJSZWFjdCIsIkNvbnRhaW5lciIsIlR5cG9ncmFwaHkiLCJDeXByZXNzTG9nbyIsIkZvb3RlciIsIm1hcmdpblRvcCIsInRleHREZWNvcmF0aW9uIiwibWFyZ2luTGVmdCIsImhlaWdodCIsIndpZHRoIiwidmVydGljYWxBbGlnbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRm9vdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IENvbnRhaW5lciwgVHlwb2dyYXBoeSB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcblxyXG5pbXBvcnQgQ3lwcmVzc0xvZ28gZnJvbSBcIi4uL2NvbXBvbmVudHMvU3ZnQ3lwcmVzc0xvZ29cIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZvb3RlcigpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPENvbnRhaW5lciBtYXhXaWR0aD1cInNtXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiA1MCB9fT5cclxuICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImJvZHkyXCIgY29sb3I9XCJ0ZXh0U2Vjb25kYXJ5XCIgYWxpZ249XCJjZW50ZXJcIj5cclxuICAgICAgICBCdWlsdCBieVxyXG4gICAgICAgIDxhXHJcbiAgICAgICAgICBzdHlsZT17eyB0ZXh0RGVjb3JhdGlvbjogXCJub25lXCIgfX1cclxuICAgICAgICAgIHRhcmdldD1cIl9ibGFua1wiXHJcbiAgICAgICAgICByZWw9XCJub29wZW5lciBub3JlZmVycmVyXCJcclxuICAgICAgICAgIGhyZWY9XCJodHRwczovL2N5cHJlc3MuaW9cIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxDeXByZXNzTG9nb1xyXG4gICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgIG1hcmdpblRvcDogLTIsXHJcbiAgICAgICAgICAgICAgbWFyZ2luTGVmdDogNSxcclxuICAgICAgICAgICAgICBoZWlnaHQ6IFwiMjBweFwiLFxyXG4gICAgICAgICAgICAgIHdpZHRoOiBcIjU1cHhcIixcclxuICAgICAgICAgICAgICB2ZXJ0aWNhbEFsaWduOiBcIm1pZGRsZVwiLFxyXG4gICAgICAgICAgICB9fVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2E+XHJcbiAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgIDwvQ29udGFpbmVyPlxyXG4gICk7XHJcbn1cclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9Gb290ZXIudHN4In0=