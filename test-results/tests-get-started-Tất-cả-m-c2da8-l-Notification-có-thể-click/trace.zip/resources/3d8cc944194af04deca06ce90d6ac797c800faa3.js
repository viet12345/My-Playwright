import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionCreateStepTwo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useState = __vite__cjsImport3_react["useState"];
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import NumberFormat from "/node_modules/.vite/deps/react-number-format.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object, number } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
import { Paper, Typography, Button, Grid, Container, Avatar, Box, TextField } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const PREFIX = "TransactionCreateStepTwo";
const classes = {
  paper: `${PREFIX}-paper`,
  form: `${PREFIX}-form`,
  submit: `${PREFIX}-submit`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.form}`]: {
    width: "100%",
    marginTop: theme.spacing(1)
  },
  [`& .${classes.submit}`]: {
    margin: theme.spacing(3, 0, 2)
  }
}));
_c = StyledPaper;
const validationSchema = object({
  amount: number().required("Please enter a valid amount"),
  description: string().required("Please enter a note"),
  senderId: string(),
  receiverId: string()
});
function NumberFormatCustom(props) {
  const { inputRef, onChange, ...other } = props;
  return /* @__PURE__ */ jsxDEV(
    NumberFormat,
    {
      ...other,
      getInputRef: inputRef,
      onValueChange: (values) => {
        onChange({
          target: {
            ...other,
            value: values.value
          }
        });
      },
      thousandSeparator: true,
      isNumericString: true,
      prefix: "$"
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
      lineNumber: 50,
      columnNumber: 5
    },
    this
  );
}
_c2 = NumberFormatCustom;
const TransactionCreateStepTwo = ({
  receiver,
  sender,
  createTransaction,
  showSnackbar
}) => {
  _s();
  const [transactionType, setTransactionType] = useState();
  const initialValues = {
    amount: "",
    description: "",
    senderId: sender.id,
    receiverId: receiver.id
  };
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, elevation: 0, children: [
    /* @__PURE__ */ jsxDEV(Box, { display: "flex", height: 200, alignItems: "center", justifyContent: "center", children: /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "column", justifyContent: "flex-start", alignItems: "center", children: [
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Avatar, { src: receiver.avatar }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
        lineNumber: 101,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
        lineNumber: 100,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: [
        receiver.firstName,
        " ",
        receiver.lastName,
        transactionType
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
        lineNumber: 104,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
        lineNumber: 103,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
      lineNumber: 99,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
      lineNumber: 98,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Container, { maxWidth: "xs", children: /* @__PURE__ */ jsxDEV(
      Formik,
      {
        initialValues,
        validationSchema,
        validateOnMount: true,
        onSubmit: (values, { setSubmitting }) => {
          setSubmitting(true);
          setTransactionType(void 0);
          createTransaction({ transactionType, ...values });
          showSnackbar({
            severity: "success",
            message: "Transaction Submitted!"
          });
        },
        children: ({ isValid, isSubmitting }) => /* @__PURE__ */ jsxDEV(Form, { className: classes.form, "data-test": "transaction-create-form", children: [
          /* @__PURE__ */ jsxDEV(Field, { name: "amount", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
            TextField,
            {
              variant: "outlined",
              margin: "dense",
              fullWidth: true,
              required: true,
              autoFocus: true,
              id: "transaction-create-amount-input",
              type: "text",
              placeholder: "Amount",
              "data-test": "transaction-create-amount-input",
              error: (touched || value !== initialValue) && Boolean(error),
              helperText: touched || value !== initialValue ? error : "",
              InputProps: {
                inputComponent: NumberFormatCustom,
                inputProps: { id: "amount" }
              },
              ...field
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
              lineNumber: 133,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
            lineNumber: 131,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(Field, { name: "description", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
            TextField,
            {
              variant: "outlined",
              margin: "dense",
              fullWidth: true,
              required: true,
              id: "transaction-create-description-input",
              type: "text",
              placeholder: "Add a note",
              "data-test": "transaction-create-description-input",
              error: (touched || value !== initialValue) && Boolean(error),
              helperText: touched || value !== initialValue ? error : "",
              ...field
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
              lineNumber: 155,
              columnNumber: 15
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
            lineNumber: 153,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(
            Grid,
            {
              container: true,
              spacing: 2,
              direction: "row",
              justifyContent: "center",
              alignItems: "center",
              children: [
                /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "submit",
                    fullWidth: true,
                    variant: "contained",
                    color: "primary",
                    className: classes.submit,
                    "data-test": "transaction-create-submit-request",
                    disabled: !isValid || isSubmitting,
                    onClick: () => setTransactionType("request"),
                    children: "Request"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
                    lineNumber: 178,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
                  lineNumber: 177,
                  columnNumber: 17
                }, this),
                /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
                  Button,
                  {
                    type: "submit",
                    fullWidth: true,
                    variant: "contained",
                    color: "primary",
                    className: classes.submit,
                    "data-test": "transaction-create-submit-payment",
                    disabled: !isValid || isSubmitting,
                    onClick: () => setTransactionType("payment"),
                    children: "Pay"
                  },
                  void 0,
                  false,
                  {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
                    lineNumber: 192,
                    columnNumber: 19
                  },
                  this
                ) }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
                  lineNumber: 191,
                  columnNumber: 17
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
              lineNumber: 170,
              columnNumber: 15
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
          lineNumber: 130,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
        lineNumber: 112,
        columnNumber: 9
      },
      this
    ) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
      lineNumber: 111,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx",
    lineNumber: 97,
    columnNumber: 5
  }, this);
};
_s(TransactionCreateStepTwo, "toNP8ZmzQkLWRsLCAB/3xubUFKI=");
_c3 = TransactionCreateStepTwo;
export default TransactionCreateStepTwo;
var _c, _c2, _c3;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "NumberFormatCustom");
$RefreshReg$(_c3, "TransactionCreateStepTwo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepTwo.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURJOzJCQWpESjtBQUFnQkEsTUFBUSxjQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3ZDLFNBQVNDLGNBQWM7QUFDdkIsT0FBT0Msa0JBQWtCO0FBQ3pCLFNBQVNDLFFBQVFDLE1BQU1DLGFBQXlCO0FBQ2hELFNBQVNDLFFBQVFDLFFBQVFDLGNBQWM7QUFDdkMsU0FBU0MsT0FBT0MsWUFBWUMsUUFBUUMsTUFBTUMsV0FBV0MsUUFBUUMsS0FBS0MsaUJBQWlCO0FBR25GLE1BQU1DLFNBQVM7QUFFZixNQUFNQyxVQUFVO0FBQUEsRUFDZEMsT0FBTyxHQUFHRixNQUFNO0FBQUEsRUFDaEJHLE1BQU0sR0FBR0gsTUFBTTtBQUFBLEVBQ2ZJLFFBQVEsR0FBR0osTUFBTTtBQUNuQjtBQUVBLE1BQU1LLGNBQWNyQixPQUFPUSxLQUFLLEVBQUUsQ0FBQyxFQUFFYyxNQUFNLE9BQU87QUFBQSxFQUNoRCxDQUFDLEtBQUtMLFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdEJLLFNBQVM7QUFBQSxJQUNUQyxlQUFlO0FBQUEsSUFDZkMsWUFBWTtBQUFBLEVBQ2Q7QUFBQSxFQUVBLENBQUMsTUFBTVIsUUFBUUUsSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUN0Qk8sT0FBTztBQUFBLElBQ1BDLFdBQVdMLE1BQU1NLFFBQVEsQ0FBQztBQUFBLEVBQzVCO0FBQUEsRUFFQSxDQUFDLE1BQU1YLFFBQVFHLE1BQU0sRUFBRSxHQUFHO0FBQUEsSUFDeEJTLFFBQVFQLE1BQU1NLFFBQVEsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUMvQjtBQUNGLEVBQUU7QUFBRUUsS0FmRVQ7QUFpQk4sTUFBTVUsbUJBQW1CekIsT0FBTztBQUFBLEVBQzlCMEIsUUFBUXpCLE9BQU8sRUFBRTBCLFNBQVMsNkJBQTZCO0FBQUEsRUFDdkRDLGFBQWE3QixPQUFPLEVBQUU0QixTQUFTLHFCQUFxQjtBQUFBLEVBQ3BERSxVQUFVOUIsT0FBTztBQUFBLEVBQ2pCK0IsWUFBWS9CLE9BQU87QUFDckIsQ0FBQztBQU9ELFNBQVNnQyxtQkFBbUJDLE9BQWdDO0FBQzFELFFBQU0sRUFBRUMsVUFBVUMsVUFBVSxHQUFHQyxNQUFNLElBQUlIO0FBRXpDLFNBQ0U7QUFBQSxJQUFDO0FBQUE7QUFBQSxNQUNDLEdBQUlHO0FBQUFBLE1BQ0osYUFBYUY7QUFBQUEsTUFDYixlQUFlLENBQUNHLFdBQVc7QUFDekJGLGlCQUFTO0FBQUEsVUFDUEcsUUFBUTtBQUFBLFlBQ04sR0FBR0Y7QUFBQUEsWUFDSEcsT0FBT0YsT0FBT0U7QUFBQUEsVUFDaEI7QUFBQSxRQUNGLENBQUM7QUFBQSxNQUNIO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBLFFBQU87QUFBQTtBQUFBLElBYlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYVk7QUFHaEI7QUFBQ0MsTUFwQlFSO0FBb0NULE1BQU1TLDJCQUFvRUEsQ0FBQztBQUFBLEVBQ3pFQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU0sQ0FBQ0MsaUJBQWlCQyxrQkFBa0IsSUFBSXRELFNBQWlCO0FBQy9ELFFBQU11RCxnQkFBNEI7QUFBQSxJQUNoQ3RCLFFBQVE7QUFBQSxJQUNSRSxhQUFhO0FBQUEsSUFDYkMsVUFBVWEsT0FBT087QUFBQUEsSUFDakJuQixZQUFZVyxTQUFTUTtBQUFBQSxFQUN2QjtBQUVBLFNBQ0UsdUJBQUMsZUFBWSxXQUFXdEMsUUFBUUMsT0FBTyxXQUFXLEdBQ2hEO0FBQUEsMkJBQUMsT0FBSSxTQUFRLFFBQU8sUUFBUSxLQUFLLFlBQVcsVUFBUyxnQkFBZSxVQUNsRSxpQ0FBQyxRQUFLLFdBQVMsTUFBQyxXQUFVLFVBQVMsZ0JBQWUsY0FBYSxZQUFXLFVBQ3hFO0FBQUEsNkJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsVUFBTyxLQUFLNkIsU0FBU1MsVUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE2QixLQUQvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxPQUFNLFdBQVUsY0FBWSxNQUNqRVQ7QUFBQUEsaUJBQVNVO0FBQUFBLFFBQVU7QUFBQSxRQUFFVixTQUFTVztBQUFBQSxRQUM5Qk47QUFBQUEsV0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBR0EsS0FKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBQ0EsdUJBQUMsYUFBVSxVQUFTLE1BQ2xCO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQztBQUFBLFFBQ0E7QUFBQSxRQUNBLGlCQUFpQjtBQUFBLFFBQ2pCLFVBQVUsQ0FBQ1YsUUFBUSxFQUFFaUIsY0FBYyxNQUFNO0FBQ3ZDQSx3QkFBYyxJQUFJO0FBR2xCTiw2QkFBbUJPLE1BQVM7QUFFNUJYLDRCQUFrQixFQUFFRyxpQkFBaUIsR0FBR1YsT0FBTyxDQUFDO0FBQ2hEUSx1QkFBYTtBQUFBLFlBQ1hXLFVBQVU7QUFBQSxZQUNWQyxTQUFTO0FBQUEsVUFDWCxDQUFDO0FBQUEsUUFDSDtBQUFBLFFBRUMsV0FBQyxFQUFFQyxTQUFTQyxhQUFhLE1BQ3hCLHVCQUFDLFFBQUssV0FBVy9DLFFBQVFFLE1BQU0sYUFBVSwyQkFDdkM7QUFBQSxpQ0FBQyxTQUFNLE1BQUssVUFDVCxXQUFDLEVBQUU4QyxPQUFPQyxNQUFNLEVBQUVDLE9BQU92QixPQUFPd0IsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixRQUFPO0FBQUEsY0FDUDtBQUFBLGNBQ0E7QUFBQSxjQUNBO0FBQUEsY0FDQSxJQUFJO0FBQUEsY0FDSixNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixhQUFXO0FBQUEsY0FDWCxRQUFRQSxXQUFXekIsVUFBVXdCLGlCQUFpQkUsUUFBUUgsS0FBSztBQUFBLGNBQzNELFlBQVlFLFdBQVd6QixVQUFVd0IsZUFBZUQsUUFBUTtBQUFBLGNBQ3hELFlBQVk7QUFBQSxnQkFDVkksZ0JBQWdCbEM7QUFBQUEsZ0JBQ2hCbUMsWUFBWSxFQUFFakIsSUFBSSxTQUFTO0FBQUEsY0FDN0I7QUFBQSxjQUNBLEdBQUlVO0FBQUFBO0FBQUFBLFlBaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQWdCWSxLQWxCaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFxQkE7QUFBQSxVQUNBLHVCQUFDLFNBQU0sTUFBSyxlQUNULFdBQUMsRUFBRUEsT0FBT0MsTUFBTSxFQUFFQyxPQUFPdkIsT0FBT3dCLGNBQWNDLFFBQVEsRUFBYyxNQUNuRTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsU0FBUTtBQUFBLGNBQ1IsUUFBTztBQUFBLGNBQ1A7QUFBQSxjQUNBO0FBQUEsY0FDQSxJQUFJO0FBQUEsY0FDSixNQUFLO0FBQUEsY0FDTCxhQUFZO0FBQUEsY0FDWixhQUFXO0FBQUEsY0FDWCxRQUFRQSxXQUFXekIsVUFBVXdCLGlCQUFpQkUsUUFBUUgsS0FBSztBQUFBLGNBQzNELFlBQVlFLFdBQVd6QixVQUFVd0IsZUFBZUQsUUFBUTtBQUFBLGNBQ3hELEdBQUlGO0FBQUFBO0FBQUFBLFlBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBV1ksS0FiaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFnQkE7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQztBQUFBLGNBQ0EsU0FBUztBQUFBLGNBQ1QsV0FBVTtBQUFBLGNBQ1YsZ0JBQWU7QUFBQSxjQUNmLFlBQVc7QUFBQSxjQUVYO0FBQUEsdUNBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQSxrQkFBQztBQUFBO0FBQUEsb0JBQ0MsTUFBSztBQUFBLG9CQUNMO0FBQUEsb0JBQ0EsU0FBUTtBQUFBLG9CQUNSLE9BQU07QUFBQSxvQkFDTixXQUFXaEQsUUFBUUc7QUFBQUEsb0JBQ25CLGFBQVU7QUFBQSxvQkFDVixVQUFVLENBQUMyQyxXQUFXQztBQUFBQSxvQkFDdEIsU0FBUyxNQUFNWCxtQkFBbUIsU0FBUztBQUFBLG9CQUFFO0FBQUE7QUFBQSxrQkFSL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFhQTtBQUFBLGdCQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsa0JBQUM7QUFBQTtBQUFBLG9CQUNDLE1BQUs7QUFBQSxvQkFDTDtBQUFBLG9CQUNBLFNBQVE7QUFBQSxvQkFDUixPQUFNO0FBQUEsb0JBQ04sV0FBV3BDLFFBQVFHO0FBQUFBLG9CQUNuQixhQUFVO0FBQUEsb0JBQ1YsVUFBVSxDQUFDMkMsV0FBV0M7QUFBQUEsb0JBQ3RCLFNBQVMsTUFBTVgsbUJBQW1CLFNBQVM7QUFBQSxvQkFBRTtBQUFBO0FBQUEsa0JBUi9DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFXQSxLQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYUE7QUFBQTtBQUFBO0FBQUEsWUFsQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBbUNBO0FBQUEsYUEzRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQTRFQTtBQUFBO0FBQUEsTUE5Rko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBZ0dBLEtBakdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrR0E7QUFBQSxPQWhIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUhBO0FBRUo7QUFBRUYsR0FsSUlMLDBCQUFpRTtBQUFBMkIsTUFBakUzQjtBQW9JTixlQUFlQTtBQUF5QixJQUFBaEIsSUFBQWUsS0FBQTRCO0FBQUFDLGFBQUE1QyxJQUFBO0FBQUE0QyxhQUFBN0IsS0FBQTtBQUFBNkIsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwic3R5bGVkIiwiTnVtYmVyRm9ybWF0IiwiRm9ybWlrIiwiRm9ybSIsIkZpZWxkIiwic3RyaW5nIiwib2JqZWN0IiwibnVtYmVyIiwiUGFwZXIiLCJUeXBvZ3JhcGh5IiwiQnV0dG9uIiwiR3JpZCIsIkNvbnRhaW5lciIsIkF2YXRhciIsIkJveCIsIlRleHRGaWVsZCIsIlBSRUZJWCIsImNsYXNzZXMiLCJwYXBlciIsImZvcm0iLCJzdWJtaXQiLCJTdHlsZWRQYXBlciIsInRoZW1lIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJhbGlnbkl0ZW1zIiwid2lkdGgiLCJtYXJnaW5Ub3AiLCJzcGFjaW5nIiwibWFyZ2luIiwiX2MiLCJ2YWxpZGF0aW9uU2NoZW1hIiwiYW1vdW50IiwicmVxdWlyZWQiLCJkZXNjcmlwdGlvbiIsInNlbmRlcklkIiwicmVjZWl2ZXJJZCIsIk51bWJlckZvcm1hdEN1c3RvbSIsInByb3BzIiwiaW5wdXRSZWYiLCJvbkNoYW5nZSIsIm90aGVyIiwidmFsdWVzIiwidGFyZ2V0IiwidmFsdWUiLCJfYzIiLCJUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUd28iLCJyZWNlaXZlciIsInNlbmRlciIsImNyZWF0ZVRyYW5zYWN0aW9uIiwic2hvd1NuYWNrYmFyIiwiX3MiLCJ0cmFuc2FjdGlvblR5cGUiLCJzZXRUcmFuc2FjdGlvblR5cGUiLCJpbml0aWFsVmFsdWVzIiwiaWQiLCJhdmF0YXIiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsInNldFN1Ym1pdHRpbmciLCJ1bmRlZmluZWQiLCJzZXZlcml0eSIsIm1lc3NhZ2UiLCJpc1ZhbGlkIiwiaXNTdWJtaXR0aW5nIiwiZmllbGQiLCJtZXRhIiwiZXJyb3IiLCJpbml0aWFsVmFsdWUiLCJ0b3VjaGVkIiwiQm9vbGVhbiIsImlucHV0Q29tcG9uZW50IiwiaW5wdXRQcm9wcyIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcFR3by50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgTnVtYmVyRm9ybWF0IGZyb20gXCJyZWFjdC1udW1iZXItZm9ybWF0XCI7XHJcbmltcG9ydCB7IEZvcm1paywgRm9ybSwgRmllbGQsIEZpZWxkUHJvcHMgfSBmcm9tIFwiZm9ybWlrXCI7XHJcbmltcG9ydCB7IHN0cmluZywgb2JqZWN0LCBudW1iZXIgfSBmcm9tIFwieXVwXCI7XHJcbmltcG9ydCB7IFBhcGVyLCBUeXBvZ3JhcGh5LCBCdXR0b24sIEdyaWQsIENvbnRhaW5lciwgQXZhdGFyLCBCb3gsIFRleHRGaWVsZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IFVzZXIgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcFR3b1wiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwYXBlcjogYCR7UFJFRklYfS1wYXBlcmAsXHJcbiAgZm9ybTogYCR7UFJFRklYfS1mb3JtYCxcclxuICBzdWJtaXQ6IGAke1BSRUZJWH0tc3VibWl0YCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZFBhcGVyID0gc3R5bGVkKFBhcGVyKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMucGFwZXJ9YF06IHtcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuZm9ybX1gXToge1xyXG4gICAgd2lkdGg6IFwiMTAwJVwiLFxyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDEpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnN1Ym1pdH1gXToge1xyXG4gICAgbWFyZ2luOiB0aGVtZS5zcGFjaW5nKDMsIDAsIDIpLFxyXG4gIH0sXHJcbn0pKTtcclxuXHJcbmNvbnN0IHZhbGlkYXRpb25TY2hlbWEgPSBvYmplY3Qoe1xyXG4gIGFtb3VudDogbnVtYmVyKCkucmVxdWlyZWQoXCJQbGVhc2UgZW50ZXIgYSB2YWxpZCBhbW91bnRcIiksXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZygpLnJlcXVpcmVkKFwiUGxlYXNlIGVudGVyIGEgbm90ZVwiKSxcclxuICBzZW5kZXJJZDogc3RyaW5nKCksXHJcbiAgcmVjZWl2ZXJJZDogc3RyaW5nKCksXHJcbn0pO1xyXG5cclxuaW50ZXJmYWNlIE51bWJlckZvcm1hdEN1c3RvbVByb3BzIHtcclxuICBpbnB1dFJlZjogKGVsOiBIVE1MSW5wdXRFbGVtZW50KSA9PiB2b2lkO1xyXG4gIG9uQ2hhbmdlOiAoZXZlbnQ6IHsgdGFyZ2V0OiB7IHZhbHVlOiBzdHJpbmcgfSB9KSA9PiB2b2lkO1xyXG59XHJcblxyXG5mdW5jdGlvbiBOdW1iZXJGb3JtYXRDdXN0b20ocHJvcHM6IE51bWJlckZvcm1hdEN1c3RvbVByb3BzKSB7XHJcbiAgY29uc3QgeyBpbnB1dFJlZiwgb25DaGFuZ2UsIC4uLm90aGVyIH0gPSBwcm9wcztcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxOdW1iZXJGb3JtYXRcclxuICAgICAgey4uLm90aGVyfVxyXG4gICAgICBnZXRJbnB1dFJlZj17aW5wdXRSZWZ9XHJcbiAgICAgIG9uVmFsdWVDaGFuZ2U9eyh2YWx1ZXMpID0+IHtcclxuICAgICAgICBvbkNoYW5nZSh7XHJcbiAgICAgICAgICB0YXJnZXQ6IHtcclxuICAgICAgICAgICAgLi4ub3RoZXIsXHJcbiAgICAgICAgICAgIHZhbHVlOiB2YWx1ZXMudmFsdWUsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9fVxyXG4gICAgICB0aG91c2FuZFNlcGFyYXRvclxyXG4gICAgICBpc051bWVyaWNTdHJpbmdcclxuICAgICAgcHJlZml4PVwiJFwiXHJcbiAgICAvPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVHJhbnNhY3Rpb25DcmVhdGVTdGVwVHdvUHJvcHMge1xyXG4gIHJlY2VpdmVyOiBVc2VyO1xyXG4gIHNlbmRlcjogVXNlcjtcclxuICBjcmVhdGVUcmFuc2FjdGlvbjogRnVuY3Rpb247XHJcbiAgc2hvd1NuYWNrYmFyOiBGdW5jdGlvbjtcclxufVxyXG5cclxuaW50ZXJmYWNlIEZvcm1WYWx1ZXMge1xyXG4gIGFtb3VudDogbnVtYmVyIHwgXCJcIjtcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nO1xyXG4gIHNlbmRlcklkOiBzdHJpbmc7XHJcbiAgcmVjZWl2ZXJJZDogc3RyaW5nO1xyXG59XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUd286IFJlYWN0LkZDPFRyYW5zYWN0aW9uQ3JlYXRlU3RlcFR3b1Byb3BzPiA9ICh7XHJcbiAgcmVjZWl2ZXIsXHJcbiAgc2VuZGVyLFxyXG4gIGNyZWF0ZVRyYW5zYWN0aW9uLFxyXG4gIHNob3dTbmFja2JhcixcclxufSkgPT4ge1xyXG4gIGNvbnN0IFt0cmFuc2FjdGlvblR5cGUsIHNldFRyYW5zYWN0aW9uVHlwZV0gPSB1c2VTdGF0ZTxzdHJpbmc+KCk7XHJcbiAgY29uc3QgaW5pdGlhbFZhbHVlczogRm9ybVZhbHVlcyA9IHtcclxuICAgIGFtb3VudDogXCJcIixcclxuICAgIGRlc2NyaXB0aW9uOiBcIlwiLFxyXG4gICAgc2VuZGVySWQ6IHNlbmRlci5pZCxcclxuICAgIHJlY2VpdmVySWQ6IHJlY2VpdmVyLmlkLFxyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkUGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfSBlbGV2YXRpb249ezB9PlxyXG4gICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgaGVpZ2h0PXsyMDB9IGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiPlxyXG4gICAgICAgIDxHcmlkIGNvbnRhaW5lciBkaXJlY3Rpb249XCJjb2x1bW5cIiBqdXN0aWZ5Q29udGVudD1cImZsZXgtc3RhcnRcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICA8QXZhdGFyIHNyYz17cmVjZWl2ZXIuYXZhdGFyfSAvPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIiBjb2xvcj1cInByaW1hcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICAgICAge3JlY2VpdmVyLmZpcnN0TmFtZX0ge3JlY2VpdmVyLmxhc3ROYW1lfVxyXG4gICAgICAgICAgICAgIHt0cmFuc2FjdGlvblR5cGV9XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgICA8Q29udGFpbmVyIG1heFdpZHRoPVwieHNcIj5cclxuICAgICAgICA8Rm9ybWlrXHJcbiAgICAgICAgICBpbml0aWFsVmFsdWVzPXtpbml0aWFsVmFsdWVzfVxyXG4gICAgICAgICAgdmFsaWRhdGlvblNjaGVtYT17dmFsaWRhdGlvblNjaGVtYX1cclxuICAgICAgICAgIHZhbGlkYXRlT25Nb3VudD17dHJ1ZX1cclxuICAgICAgICAgIG9uU3VibWl0PXsodmFsdWVzLCB7IHNldFN1Ym1pdHRpbmcgfSkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgLy8gcmVzZXQgdHJhbnNhY3Rpb25UeXBlXHJcbiAgICAgICAgICAgIHNldFRyYW5zYWN0aW9uVHlwZSh1bmRlZmluZWQpO1xyXG5cclxuICAgICAgICAgICAgY3JlYXRlVHJhbnNhY3Rpb24oeyB0cmFuc2FjdGlvblR5cGUsIC4uLnZhbHVlcyB9KTtcclxuICAgICAgICAgICAgc2hvd1NuYWNrYmFyKHtcclxuICAgICAgICAgICAgICBzZXZlcml0eTogXCJzdWNjZXNzXCIsXHJcbiAgICAgICAgICAgICAgbWVzc2FnZTogXCJUcmFuc2FjdGlvbiBTdWJtaXR0ZWQhXCIsXHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7KHsgaXNWYWxpZCwgaXNTdWJtaXR0aW5nIH0pID0+IChcclxuICAgICAgICAgICAgPEZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19IGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWNyZWF0ZS1mb3JtXCI+XHJcbiAgICAgICAgICAgICAgPEZpZWxkIG5hbWU9XCJhbW91bnRcIj5cclxuICAgICAgICAgICAgICAgIHsoeyBmaWVsZCwgbWV0YTogeyBlcnJvciwgdmFsdWUsIGluaXRpYWxWYWx1ZSwgdG91Y2hlZCB9IH06IEZpZWxkUHJvcHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luPVwiZGVuc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9e1widHJhbnNhY3Rpb24tY3JlYXRlLWFtb3VudC1pbnB1dFwifVxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcclxuICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFtb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0PXtcInRyYW5zYWN0aW9uLWNyZWF0ZS1hbW91bnQtaW5wdXRcIn1cclxuICAgICAgICAgICAgICAgICAgICBlcnJvcj17KHRvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSkgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17dG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlID8gZXJyb3IgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgIElucHV0UHJvcHM9e3tcclxuICAgICAgICAgICAgICAgICAgICAgIGlucHV0Q29tcG9uZW50OiBOdW1iZXJGb3JtYXRDdXN0b20gYXMgYW55LFxyXG4gICAgICAgICAgICAgICAgICAgICAgaW5wdXRQcm9wczogeyBpZDogXCJhbW91bnRcIiB9LFxyXG4gICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwiZGVzY3JpcHRpb25cIj5cclxuICAgICAgICAgICAgICAgIHsoeyBmaWVsZCwgbWV0YTogeyBlcnJvciwgdmFsdWUsIGluaXRpYWxWYWx1ZSwgdG91Y2hlZCB9IH06IEZpZWxkUHJvcHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luPVwiZGVuc2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9e1widHJhbnNhY3Rpb24tY3JlYXRlLWRlc2NyaXB0aW9uLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiQWRkIGEgbm90ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0PXtcInRyYW5zYWN0aW9uLWNyZWF0ZS1kZXNjcmlwdGlvbi1pbnB1dFwifVxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxHcmlkXHJcbiAgICAgICAgICAgICAgICBjb250YWluZXJcclxuICAgICAgICAgICAgICAgIHNwYWNpbmc9ezJ9XHJcbiAgICAgICAgICAgICAgICBkaXJlY3Rpb249XCJyb3dcIlxyXG4gICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnN1Ym1pdH1cclxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1jcmVhdGUtc3VibWl0LXJlcXVlc3RcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNWYWxpZCB8fCBpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0VHJhbnNhY3Rpb25UeXBlKFwicmVxdWVzdFwiKX1cclxuICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgIFJlcXVlc3RcclxuICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuc3VibWl0fVxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWNyZWF0ZS1zdWJtaXQtcGF5bWVudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc1ZhbGlkIHx8IGlzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRUcmFuc2FjdGlvblR5cGUoXCJwYXltZW50XCIpfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgUGF5XHJcbiAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPC9Gb3JtPlxyXG4gICAgICAgICAgKX1cclxuICAgICAgICA8L0Zvcm1paz5cclxuICAgICAgPC9Db250YWluZXI+XHJcbiAgICA8L1N0eWxlZFBhcGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUd287XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25DcmVhdGVTdGVwVHdvLnRzeCJ9