import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/TransactionDetailContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useMachine, useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import TransactionDetail from "/src/components/TransactionDetail.tsx";
import { transactionDetailMachine } from "/src/machines/transactionDetailMachine.ts";
import __vite__cjsImport8_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const first = __vite__cjsImport8_lodash_fp["first"];
const TransactionDetailsContainer = ({ authService }) => {
  _s();
  const { transactionId } = useParams();
  const [authState] = useActor(authService);
  const [transactionDetailState, sendTransactionDetail] = useMachine(transactionDetailMachine);
  useEffect(() => {
    sendTransactionDetail("FETCH", { transactionId });
  }, [sendTransactionDetail, transactionId]);
  const transactionLike = (transactionId2) => sendTransactionDetail("CREATE", { entity: "LIKE", transactionId: transactionId2 });
  const transactionComment = (payload) => sendTransactionDetail("CREATE", { entity: "COMMENT", ...payload });
  const transactionUpdate = (payload) => sendTransactionDetail("UPDATE", payload);
  const transaction = first(transactionDetailState.context?.results);
  const currentUser = authState?.context?.user;
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    transactionDetailState.matches("idle") && /* @__PURE__ */ jsxDEV("div", { children: [
      "Loading...",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx",
        lineNumber: 42,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx",
      lineNumber: 40,
      columnNumber: 7
    }, this),
    currentUser && transactionDetailState.matches("success") && /* @__PURE__ */ jsxDEV(
      TransactionDetail,
      {
        transaction,
        transactionLike,
        transactionComment,
        transactionUpdate,
        currentUser
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx",
        lineNumber: 46,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx",
    lineNumber: 38,
    columnNumber: 5
  }, this);
};
_s(TransactionDetailsContainer, "dJAgaAx2XRUQ2U3cF8Psoo7Cb/o=", false, function() {
  return [useParams, useActor, useMachine];
});
_c = TransactionDetailsContainer;
export default TransactionDetailsContainer;
var _c;
$RefreshReg$(_c, "TransactionDetailsContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/TransactionDetailContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNJLG1CQUlNLGNBSk47MkJBckNKO0FBQWdCQSxNQUFTLGNBQWU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDeEMsU0FBU0MsWUFBWUMsZ0JBQWdCO0FBQ3JDLFNBQVNDLGlCQUFpQjtBQUMxQixPQUFPQyx1QkFBdUI7QUFFOUIsU0FBU0MsZ0NBQWdDO0FBQ3pDLFNBQVNDLGFBQWE7QUFXdEIsTUFBTUMsOEJBQStDQSxDQUFDLEVBQUVDLFlBQVksTUFBTTtBQUFBQyxLQUFBO0FBQ3hFLFFBQU0sRUFBRUMsY0FBc0IsSUFBSVAsVUFBVTtBQUM1QyxRQUFNLENBQUNRLFNBQVMsSUFBSVQsU0FBU00sV0FBVztBQUN4QyxRQUFNLENBQUNJLHdCQUF3QkMscUJBQXFCLElBQUlaLFdBQVdJLHdCQUF3QjtBQUMzRkwsWUFBVSxNQUFNO0FBQ2RhLDBCQUFzQixTQUFTLEVBQUVILGNBQWMsQ0FBQztBQUFBLEVBQ2xELEdBQUcsQ0FBQ0csdUJBQXVCSCxhQUFhLENBQUM7QUFFekMsUUFBTUksa0JBQWtCQSxDQUFDSixtQkFDdkJHLHNCQUFzQixVQUFVLEVBQUVFLFFBQVEsUUFBUUwsOEJBQWMsQ0FBQztBQUVuRSxRQUFNTSxxQkFBcUJBLENBQUNDLFlBQzFCSixzQkFBc0IsVUFBVSxFQUFFRSxRQUFRLFdBQVcsR0FBR0UsUUFBUSxDQUFDO0FBRW5FLFFBQU1DLG9CQUFvQkEsQ0FBQ0QsWUFBaUJKLHNCQUFzQixVQUFVSSxPQUFPO0FBRW5GLFFBQU1FLGNBQWNiLE1BQU1NLHVCQUF1QlEsU0FBU0MsT0FBTztBQUNqRSxRQUFNQyxjQUFjWCxXQUFXUyxTQUFTRztBQUV4QyxTQUNFLG1DQUNHWDtBQUFBQSwyQkFBdUJZLFFBQVEsTUFBTSxLQUNwQyx1QkFBQyxTQUFJO0FBQUE7QUFBQSxNQUVILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsU0FGTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBR0E7QUFBQSxJQUVERixlQUFlVix1QkFBdUJZLFFBQVEsU0FBUyxLQUN0RDtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0M7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUE7QUFBQSxNQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUsyQjtBQUFBLE9BYi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FnQkE7QUFFSjtBQUFFZixHQXRDSUYsNkJBQTRDO0FBQUEsVUFDZEosV0FDZEQsVUFDb0NELFVBQVU7QUFBQTtBQUFBd0IsS0FIOURsQjtBQXdDTixlQUFlQTtBQUE0QixJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsInVzZU1hY2hpbmUiLCJ1c2VBY3RvciIsInVzZVBhcmFtcyIsIlRyYW5zYWN0aW9uRGV0YWlsIiwidHJhbnNhY3Rpb25EZXRhaWxNYWNoaW5lIiwiZmlyc3QiLCJUcmFuc2FjdGlvbkRldGFpbHNDb250YWluZXIiLCJhdXRoU2VydmljZSIsIl9zIiwidHJhbnNhY3Rpb25JZCIsImF1dGhTdGF0ZSIsInRyYW5zYWN0aW9uRGV0YWlsU3RhdGUiLCJzZW5kVHJhbnNhY3Rpb25EZXRhaWwiLCJ0cmFuc2FjdGlvbkxpa2UiLCJlbnRpdHkiLCJ0cmFuc2FjdGlvbkNvbW1lbnQiLCJwYXlsb2FkIiwidHJhbnNhY3Rpb25VcGRhdGUiLCJ0cmFuc2FjdGlvbiIsImNvbnRleHQiLCJyZXN1bHRzIiwiY3VycmVudFVzZXIiLCJ1c2VyIiwibWF0Y2hlcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVHJhbnNhY3Rpb25EZXRhaWxDb250YWluZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlTWFjaGluZSwgdXNlQWN0b3IgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VQYXJhbXMgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgVHJhbnNhY3Rpb25EZXRhaWwgZnJvbSBcIi4uL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25EZXRhaWxcIjtcclxuaW1wb3J0IHsgVHJhbnNhY3Rpb24gfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCB7IHRyYW5zYWN0aW9uRGV0YWlsTWFjaGluZSB9IGZyb20gXCIuLi9tYWNoaW5lcy90cmFuc2FjdGlvbkRldGFpbE1hY2hpbmVcIjtcclxuaW1wb3J0IHsgZmlyc3QgfSBmcm9tIFwibG9kYXNoL2ZwXCI7XHJcbmltcG9ydCB7IEludGVycHJldGVyIH0gZnJvbSBcInhzdGF0ZVwiO1xyXG5pbXBvcnQgeyBBdXRoTWFjaGluZUNvbnRleHQsIEF1dGhNYWNoaW5lRXZlbnRzIH0gZnJvbSBcIi4uL21hY2hpbmVzL2F1dGhNYWNoaW5lXCI7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIFByb3BzIHtcclxuICBhdXRoU2VydmljZTogSW50ZXJwcmV0ZXI8QXV0aE1hY2hpbmVDb250ZXh0LCBhbnksIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnk+O1xyXG59XHJcbmludGVyZmFjZSBQYXJhbXMge1xyXG4gIHRyYW5zYWN0aW9uSWQ6IHN0cmluZztcclxufVxyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25EZXRhaWxzQ29udGFpbmVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBhdXRoU2VydmljZSB9KSA9PiB7XHJcbiAgY29uc3QgeyB0cmFuc2FjdGlvbklkIH06IFBhcmFtcyA9IHVzZVBhcmFtcygpO1xyXG4gIGNvbnN0IFthdXRoU3RhdGVdID0gdXNlQWN0b3IoYXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IFt0cmFuc2FjdGlvbkRldGFpbFN0YXRlLCBzZW5kVHJhbnNhY3Rpb25EZXRhaWxdID0gdXNlTWFjaGluZSh0cmFuc2FjdGlvbkRldGFpbE1hY2hpbmUpO1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBzZW5kVHJhbnNhY3Rpb25EZXRhaWwoXCJGRVRDSFwiLCB7IHRyYW5zYWN0aW9uSWQgfSk7XHJcbiAgfSwgW3NlbmRUcmFuc2FjdGlvbkRldGFpbCwgdHJhbnNhY3Rpb25JZF0pO1xyXG5cclxuICBjb25zdCB0cmFuc2FjdGlvbkxpa2UgPSAodHJhbnNhY3Rpb25JZDogVHJhbnNhY3Rpb25bXCJpZFwiXSkgPT5cclxuICAgIHNlbmRUcmFuc2FjdGlvbkRldGFpbChcIkNSRUFURVwiLCB7IGVudGl0eTogXCJMSUtFXCIsIHRyYW5zYWN0aW9uSWQgfSk7XHJcblxyXG4gIGNvbnN0IHRyYW5zYWN0aW9uQ29tbWVudCA9IChwYXlsb2FkOiBhbnkpID0+XHJcbiAgICBzZW5kVHJhbnNhY3Rpb25EZXRhaWwoXCJDUkVBVEVcIiwgeyBlbnRpdHk6IFwiQ09NTUVOVFwiLCAuLi5wYXlsb2FkIH0pO1xyXG5cclxuICBjb25zdCB0cmFuc2FjdGlvblVwZGF0ZSA9IChwYXlsb2FkOiBhbnkpID0+IHNlbmRUcmFuc2FjdGlvbkRldGFpbChcIlVQREFURVwiLCBwYXlsb2FkKTtcclxuXHJcbiAgY29uc3QgdHJhbnNhY3Rpb24gPSBmaXJzdCh0cmFuc2FjdGlvbkRldGFpbFN0YXRlLmNvbnRleHQ/LnJlc3VsdHMpO1xyXG4gIGNvbnN0IGN1cnJlbnRVc2VyID0gYXV0aFN0YXRlPy5jb250ZXh0Py51c2VyO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAge3RyYW5zYWN0aW9uRGV0YWlsU3RhdGUubWF0Y2hlcyhcImlkbGVcIikgJiYgKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICBMb2FkaW5nLi4uXHJcbiAgICAgICAgICA8YnIgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgICAge2N1cnJlbnRVc2VyICYmIHRyYW5zYWN0aW9uRGV0YWlsU3RhdGUubWF0Y2hlcyhcInN1Y2Nlc3NcIikgJiYgKFxyXG4gICAgICAgIDxUcmFuc2FjdGlvbkRldGFpbFxyXG4gICAgICAgICAgdHJhbnNhY3Rpb249e3RyYW5zYWN0aW9ufVxyXG4gICAgICAgICAgdHJhbnNhY3Rpb25MaWtlPXt0cmFuc2FjdGlvbkxpa2V9XHJcbiAgICAgICAgICB0cmFuc2FjdGlvbkNvbW1lbnQ9e3RyYW5zYWN0aW9uQ29tbWVudH1cclxuICAgICAgICAgIHRyYW5zYWN0aW9uVXBkYXRlPXt0cmFuc2FjdGlvblVwZGF0ZX1cclxuICAgICAgICAgIGN1cnJlbnRVc2VyPXtjdXJyZW50VXNlcn1cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgPC8+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRyYW5zYWN0aW9uRGV0YWlsc0NvbnRhaW5lcjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29udGFpbmVycy9UcmFuc2FjdGlvbkRldGFpbENvbnRhaW5lci50c3gifQ==