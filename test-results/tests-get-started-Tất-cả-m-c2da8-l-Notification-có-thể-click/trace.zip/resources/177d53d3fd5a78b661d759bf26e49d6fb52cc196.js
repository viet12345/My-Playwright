import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionListAmountRangeFilter.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import {
  Grid,
  Popover,
  Typography,
  Slider,
  Chip,
  Button,
  useTheme,
  useMediaQuery,
  Drawer
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { ArrowDropDown as ArrowDropDownIcon } from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import {
  formatAmountRangeValues,
  amountRangeValueText,
  amountRangeValueTextLabel,
  padAmountWithZeros
} from "/src/utils/transactionUtils.ts";
import __vite__cjsImport7_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const first = __vite__cjsImport7_lodash_fp["first"]; const last = __vite__cjsImport7_lodash_fp["last"];
const TransactionListAmountRangeFilter = ({
  filterAmountRange,
  amountRangeFilters,
  resetAmountRange
}) => {
  _s();
  const theme = useTheme();
  const xsBreakpoint = useMediaQuery(theme.breakpoints.only("xs"));
  const initialAmountRange = [0, 100];
  const [amountRangeValue, setAmountRangeValue] = React.useState(initialAmountRange);
  const [amountRangeAnchorEl, setAmountRangeAnchorEl] = React.useState(null);
  const handleAmountRangeClick = (event) => {
    setAmountRangeAnchorEl(event.currentTarget);
  };
  const handleAmountRangeClose = () => {
    setAmountRangeAnchorEl(null);
  };
  const handleAmountRangeChange = (_event, amountRange) => {
    filterAmountRange({
      amountMin: padAmountWithZeros(first(amountRange)),
      amountMax: padAmountWithZeros(last(amountRange))
    });
    setAmountRangeValue(amountRange);
  };
  const amountRangeOpen = Boolean(amountRangeAnchorEl);
  const amountRangeId = amountRangeOpen ? "amount-range-popover" : void 0;
  const AmountRangeFilter = () => /* @__PURE__ */ jsxDEV(
    Grid,
    {
      "data-test": "transaction-list-filter-amount-range",
      container: true,
      direction: "column",
      justifyContent: "flex-start",
      alignItems: "flex-start",
      spacing: 1,
      sx: { width: "300px", margin: "30px" },
      children: [
        /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            direction: "row",
            justifyContent: "space-between",
            alignItems: "center",
            sx: { width: "100%" },
            children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, sx: { width: "225px" }, children: /* @__PURE__ */ jsxDEV(Typography, { color: "textSecondary", "data-test": "transaction-list-filter-amount-range-text", children: [
                "Amount Range: ",
                formatAmountRangeValues(amountRangeValue)
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
                lineNumber: 81,
                columnNumber: 13
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
                lineNumber: 80,
                columnNumber: 11
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
                Button,
                {
                  "data-test": "transaction-list-filter-amount-clear-button",
                  onClick: () => {
                    setAmountRangeValue(initialAmountRange);
                    resetAmountRange();
                  },
                  children: "Clear"
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
                  lineNumber: 86,
                  columnNumber: 13
                },
                this
              ) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
                lineNumber: 85,
                columnNumber: 11
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
            lineNumber: 73,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
          lineNumber: 72,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
          Slider,
          {
            "data-test": "transaction-list-filter-amount-range-slider",
            sx: { width: "200px" },
            value: amountRangeValue,
            min: 0,
            max: 100,
            onChange: handleAmountRangeChange,
            valueLabelDisplay: "auto",
            "aria-labelledby": "range-slider",
            getAriaValueText: amountRangeValueText,
            valueLabelFormat: amountRangeValueTextLabel
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
            lineNumber: 99,
            columnNumber: 9
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
          lineNumber: 98,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
      lineNumber: 63,
      columnNumber: 3
    },
    this
  );
  return /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV(
      Chip,
      {
        color: "primary",
        variant: "outlined",
        onClick: handleAmountRangeClick,
        "data-test": "transaction-list-filter-amount-range-button",
        label: `Amount: ${formatAmountRangeValues(amountRangeValue)}`,
        deleteIcon: /* @__PURE__ */ jsxDEV(ArrowDropDownIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
          lineNumber: 123,
          columnNumber: 21
        }, this),
        onDelete: handleAmountRangeClick
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
        lineNumber: 117,
        columnNumber: 7
      },
      this
    ),
    !xsBreakpoint && /* @__PURE__ */ jsxDEV(
      Popover,
      {
        id: amountRangeId,
        open: amountRangeOpen,
        anchorEl: amountRangeAnchorEl,
        onClose: handleAmountRangeClose,
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "left"
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "left"
        },
        children: /* @__PURE__ */ jsxDEV(AmountRangeFilter, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
          lineNumber: 141,
          columnNumber: 11
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
        lineNumber: 127,
        columnNumber: 7
      },
      this
    ),
    xsBreakpoint && /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        id: amountRangeId,
        open: amountRangeOpen,
        ModalProps: { onClose: handleAmountRangeClose },
        anchor: "bottom",
        "data-test": "amount-range-filter-drawer",
        children: [
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              "data-test": "amount-range-filter-drawer-close",
              onClick: () => handleAmountRangeClose(),
              children: "Close"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
              lineNumber: 152,
              columnNumber: 11
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(AmountRangeFilter, {}, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
            lineNumber: 158,
            columnNumber: 11
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
        lineNumber: 145,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx",
    lineNumber: 116,
    columnNumber: 5
  }, this);
};
_s(TransactionListAmountRangeFilter, "FsQFZ6nV0Ob42nGZ/rWYbLcvbTA=", false, function() {
  return [useTheme, useMediaQuery];
});
_c = TransactionListAmountRangeFilter;
export default TransactionListAmountRangeFilter;
var _c;
$RefreshReg$(_c, "TransactionListAmountRangeFilter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionListAmountRangeFilter.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0ZZOzJCQWhGWjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCO0FBQUEsRUFDRUE7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLGlCQUFpQkMseUJBQXlCO0FBRW5EO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FFSztBQUNQLFNBQVNDLE9BQU9DLFlBQVk7QUFRNUIsTUFBTUMsbUNBQW9GQSxDQUFDO0FBQUEsRUFDekZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsUUFBUWhCLFNBQVM7QUFDdkIsUUFBTWlCLGVBQWVoQixjQUFjZSxNQUFNRSxZQUFZQyxLQUFLLElBQUksQ0FBQztBQUUvRCxRQUFNQyxxQkFBcUIsQ0FBQyxHQUFHLEdBQUc7QUFDbEMsUUFBTSxDQUFDQyxrQkFBa0JDLG1CQUFtQixJQUFJQyxNQUFNQyxTQUFtQkosa0JBQWtCO0FBRTNGLFFBQU0sQ0FBQ0sscUJBQXFCQyxzQkFBc0IsSUFBSUgsTUFBTUMsU0FBZ0MsSUFBSTtBQUVoRyxRQUFNRyx5QkFBeUJBLENBQUNDLFVBQTRDO0FBQzFFRiwyQkFBdUJFLE1BQU1DLGFBQWE7QUFBQSxFQUM1QztBQUVBLFFBQU1DLHlCQUF5QkEsTUFBTTtBQUNuQ0osMkJBQXVCLElBQUk7QUFBQSxFQUM3QjtBQUVBLFFBQU1LLDBCQUEwQkEsQ0FBQ0MsUUFBYUMsZ0JBQW1DO0FBQy9FckIsc0JBQWtCO0FBQUEsTUFDaEJzQixXQUFXMUIsbUJBQW1CQyxNQUFNd0IsV0FBdUIsQ0FBVztBQUFBLE1BQ3RFRSxXQUFXM0IsbUJBQW1CRSxLQUFLdUIsV0FBdUIsQ0FBVztBQUFBLElBQ3ZFLENBQUM7QUFDRFgsd0JBQW9CVyxXQUF1QjtBQUFBLEVBQzdDO0FBRUEsUUFBTUcsa0JBQWtCQyxRQUFRWixtQkFBbUI7QUFDbkQsUUFBTWEsZ0JBQWdCRixrQkFBa0IseUJBQXlCRztBQUVqRSxRQUFNQyxvQkFBb0JBLE1BQ3hCO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxhQUFVO0FBQUEsTUFDVjtBQUFBLE1BQ0EsV0FBVTtBQUFBLE1BQ1YsZ0JBQWU7QUFBQSxNQUNmLFlBQVc7QUFBQSxNQUNYLFNBQVM7QUFBQSxNQUNULElBQUksRUFBRUMsT0FBTyxTQUFTQyxRQUFRLE9BQU87QUFBQSxNQUVyQztBQUFBLCtCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsZ0JBQWU7QUFBQSxZQUNmLFlBQVc7QUFBQSxZQUNYLElBQUksRUFBRUQsT0FBTyxPQUFPO0FBQUEsWUFFcEI7QUFBQSxxQ0FBQyxRQUFLLE1BQUksTUFBQyxJQUFJLEVBQUVBLE9BQU8sUUFBUSxHQUM5QixpQ0FBQyxjQUFXLE9BQU0saUJBQWdCLGFBQVUsNkNBQTRDO0FBQUE7QUFBQSxnQkFDdkVwQyx3QkFBd0JnQixnQkFBZ0I7QUFBQSxtQkFEekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGFBQVU7QUFBQSxrQkFDVixTQUFTLE1BQU07QUFDYkMsd0NBQW9CRixrQkFBa0I7QUFDdENOLHFDQUFpQjtBQUFBLGtCQUNuQjtBQUFBLGtCQUFFO0FBQUE7QUFBQSxnQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVUE7QUFBQTtBQUFBO0FBQUEsVUF0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBdUJBLEtBeEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUF5QkE7QUFBQSxRQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFVO0FBQUEsWUFDVixJQUFJLEVBQUUyQixPQUFPLFFBQVE7QUFBQSxZQUNyQixPQUFPcEI7QUFBQUEsWUFDUCxLQUFLO0FBQUEsWUFDTCxLQUFLO0FBQUEsWUFDTCxVQUFVVTtBQUFBQSxZQUNWLG1CQUFrQjtBQUFBLFlBQ2xCLG1CQUFnQjtBQUFBLFlBQ2hCLGtCQUFrQnpCO0FBQUFBLFlBQ2xCLGtCQUFrQkM7QUFBQUE7QUFBQUEsVUFWcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBVThDLEtBWGhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFhQTtBQUFBO0FBQUE7QUFBQSxJQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpREE7QUFHRixTQUNFLHVCQUFDLFNBQ0M7QUFBQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sU0FBUTtBQUFBLFFBQ1IsU0FBU29CO0FBQUFBLFFBQ1QsYUFBVTtBQUFBLFFBQ1YsT0FBTyxXQUFXdEIsd0JBQXdCZ0IsZ0JBQWdCLENBQUM7QUFBQSxRQUMzRCxZQUFZLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUM5QixVQUFVTTtBQUFBQTtBQUFBQSxNQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9tQztBQUFBLElBRWxDLENBQUNWLGdCQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFJcUI7QUFBQUEsUUFDSixNQUFNRjtBQUFBQSxRQUNOLFVBQVVYO0FBQUFBLFFBQ1YsU0FBU0s7QUFBQUEsUUFDVCxjQUFjO0FBQUEsVUFDWmEsVUFBVTtBQUFBLFVBQ1ZDLFlBQVk7QUFBQSxRQUNkO0FBQUEsUUFDQSxpQkFBaUI7QUFBQSxVQUNmRCxVQUFVO0FBQUEsVUFDVkMsWUFBWTtBQUFBLFFBQ2Q7QUFBQSxRQUVBLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQTtBQUFBLE1BZHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWVBO0FBQUEsSUFFRDNCLGdCQUNDO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFJcUI7QUFBQUEsUUFDSixNQUFNRjtBQUFBQSxRQUNOLFlBQVksRUFBRVMsU0FBU2YsdUJBQXVCO0FBQUEsUUFDOUMsUUFBTztBQUFBLFFBQ1AsYUFBVTtBQUFBLFFBRVY7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBVTtBQUFBLGNBQ1YsU0FBUyxNQUFNQSx1QkFBdUI7QUFBQSxjQUFFO0FBQUE7QUFBQSxZQUYxQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFLQTtBQUFBLFVBQ0EsdUJBQUMsdUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBa0I7QUFBQTtBQUFBO0FBQUEsTUFicEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBY0E7QUFBQSxPQTNDSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkNBO0FBRUo7QUFBRWYsR0FySUlKLGtDQUFpRjtBQUFBLFVBS3ZFWCxVQUNPQyxhQUFhO0FBQUE7QUFBQTZDLEtBTjlCbkM7QUF1SU4sZUFBZUE7QUFBaUMsSUFBQW1DO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJHcmlkIiwiUG9wb3ZlciIsIlR5cG9ncmFwaHkiLCJTbGlkZXIiLCJDaGlwIiwiQnV0dG9uIiwidXNlVGhlbWUiLCJ1c2VNZWRpYVF1ZXJ5IiwiRHJhd2VyIiwiQXJyb3dEcm9wRG93biIsIkFycm93RHJvcERvd25JY29uIiwiZm9ybWF0QW1vdW50UmFuZ2VWYWx1ZXMiLCJhbW91bnRSYW5nZVZhbHVlVGV4dCIsImFtb3VudFJhbmdlVmFsdWVUZXh0TGFiZWwiLCJwYWRBbW91bnRXaXRoWmVyb3MiLCJmaXJzdCIsImxhc3QiLCJUcmFuc2FjdGlvbkxpc3RBbW91bnRSYW5nZUZpbHRlciIsImZpbHRlckFtb3VudFJhbmdlIiwiYW1vdW50UmFuZ2VGaWx0ZXJzIiwicmVzZXRBbW91bnRSYW5nZSIsIl9zIiwidGhlbWUiLCJ4c0JyZWFrcG9pbnQiLCJicmVha3BvaW50cyIsIm9ubHkiLCJpbml0aWFsQW1vdW50UmFuZ2UiLCJhbW91bnRSYW5nZVZhbHVlIiwic2V0QW1vdW50UmFuZ2VWYWx1ZSIsIlJlYWN0IiwidXNlU3RhdGUiLCJhbW91bnRSYW5nZUFuY2hvckVsIiwic2V0QW1vdW50UmFuZ2VBbmNob3JFbCIsImhhbmRsZUFtb3VudFJhbmdlQ2xpY2siLCJldmVudCIsImN1cnJlbnRUYXJnZXQiLCJoYW5kbGVBbW91bnRSYW5nZUNsb3NlIiwiaGFuZGxlQW1vdW50UmFuZ2VDaGFuZ2UiLCJfZXZlbnQiLCJhbW91bnRSYW5nZSIsImFtb3VudE1pbiIsImFtb3VudE1heCIsImFtb3VudFJhbmdlT3BlbiIsIkJvb2xlYW4iLCJhbW91bnRSYW5nZUlkIiwidW5kZWZpbmVkIiwiQW1vdW50UmFuZ2VGaWx0ZXIiLCJ3aWR0aCIsIm1hcmdpbiIsInZlcnRpY2FsIiwiaG9yaXpvbnRhbCIsIm9uQ2xvc2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uTGlzdEFtb3VudFJhbmdlRmlsdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7XHJcbiAgR3JpZCxcclxuICBQb3BvdmVyLFxyXG4gIFR5cG9ncmFwaHksXHJcbiAgU2xpZGVyLFxyXG4gIENoaXAsXHJcbiAgQnV0dG9uLFxyXG4gIHVzZVRoZW1lLFxyXG4gIHVzZU1lZGlhUXVlcnksXHJcbiAgRHJhd2VyLFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IEFycm93RHJvcERvd24gYXMgQXJyb3dEcm9wRG93bkljb24gfSBmcm9tIFwiQG11aS9pY29ucy1tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvbkFtb3VudFJhbmdlUGF5bG9hZCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IHtcclxuICBmb3JtYXRBbW91bnRSYW5nZVZhbHVlcyxcclxuICBhbW91bnRSYW5nZVZhbHVlVGV4dCxcclxuICBhbW91bnRSYW5nZVZhbHVlVGV4dExhYmVsLFxyXG4gIHBhZEFtb3VudFdpdGhaZXJvcyxcclxuICAvL2hhc0Ftb3VudFF1ZXJ5RmllbGRzXHJcbn0gZnJvbSBcIi4uL3V0aWxzL3RyYW5zYWN0aW9uVXRpbHNcIjtcclxuaW1wb3J0IHsgZmlyc3QsIGxhc3QgfSBmcm9tIFwibG9kYXNoL2ZwXCI7XHJcblxyXG5leHBvcnQgdHlwZSBUcmFuc2FjdGlvbkxpc3RBbW91bnRSYW5nZUZpbHRlclByb3BzID0ge1xyXG4gIGZpbHRlckFtb3VudFJhbmdlOiBGdW5jdGlvbjtcclxuICBhbW91bnRSYW5nZUZpbHRlcnM6IFRyYW5zYWN0aW9uQW1vdW50UmFuZ2VQYXlsb2FkO1xyXG4gIHJlc2V0QW1vdW50UmFuZ2U6IEZ1bmN0aW9uO1xyXG59O1xyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25MaXN0QW1vdW50UmFuZ2VGaWx0ZXI6IFJlYWN0LkZDPFRyYW5zYWN0aW9uTGlzdEFtb3VudFJhbmdlRmlsdGVyUHJvcHM+ID0gKHtcclxuICBmaWx0ZXJBbW91bnRSYW5nZSxcclxuICBhbW91bnRSYW5nZUZpbHRlcnMsXHJcbiAgcmVzZXRBbW91bnRSYW5nZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IHRoZW1lID0gdXNlVGhlbWUoKTtcclxuICBjb25zdCB4c0JyZWFrcG9pbnQgPSB1c2VNZWRpYVF1ZXJ5KHRoZW1lLmJyZWFrcG9pbnRzLm9ubHkoXCJ4c1wiKSk7XHJcblxyXG4gIGNvbnN0IGluaXRpYWxBbW91bnRSYW5nZSA9IFswLCAxMDBdO1xyXG4gIGNvbnN0IFthbW91bnRSYW5nZVZhbHVlLCBzZXRBbW91bnRSYW5nZVZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlPG51bWJlcltdPihpbml0aWFsQW1vdW50UmFuZ2UpO1xyXG5cclxuICBjb25zdCBbYW1vdW50UmFuZ2VBbmNob3JFbCwgc2V0QW1vdW50UmFuZ2VBbmNob3JFbF0gPSBSZWFjdC51c2VTdGF0ZTxIVE1MRGl2RWxlbWVudCB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBoYW5kbGVBbW91bnRSYW5nZUNsaWNrID0gKGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50PEhUTUxEaXZFbGVtZW50PikgPT4ge1xyXG4gICAgc2V0QW1vdW50UmFuZ2VBbmNob3JFbChldmVudC5jdXJyZW50VGFyZ2V0KTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBbW91bnRSYW5nZUNsb3NlID0gKCkgPT4ge1xyXG4gICAgc2V0QW1vdW50UmFuZ2VBbmNob3JFbChudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVBbW91bnRSYW5nZUNoYW5nZSA9IChfZXZlbnQ6IGFueSwgYW1vdW50UmFuZ2U6IG51bWJlciB8IG51bWJlcltdKSA9PiB7XHJcbiAgICBmaWx0ZXJBbW91bnRSYW5nZSh7XHJcbiAgICAgIGFtb3VudE1pbjogcGFkQW1vdW50V2l0aFplcm9zKGZpcnN0KGFtb3VudFJhbmdlIGFzIG51bWJlcltdKSBhcyBudW1iZXIpLFxyXG4gICAgICBhbW91bnRNYXg6IHBhZEFtb3VudFdpdGhaZXJvcyhsYXN0KGFtb3VudFJhbmdlIGFzIG51bWJlcltdKSBhcyBudW1iZXIpLFxyXG4gICAgfSk7XHJcbiAgICBzZXRBbW91bnRSYW5nZVZhbHVlKGFtb3VudFJhbmdlIGFzIG51bWJlcltdKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBhbW91bnRSYW5nZU9wZW4gPSBCb29sZWFuKGFtb3VudFJhbmdlQW5jaG9yRWwpO1xyXG4gIGNvbnN0IGFtb3VudFJhbmdlSWQgPSBhbW91bnRSYW5nZU9wZW4gPyBcImFtb3VudC1yYW5nZS1wb3BvdmVyXCIgOiB1bmRlZmluZWQ7XHJcblxyXG4gIGNvbnN0IEFtb3VudFJhbmdlRmlsdGVyID0gKCkgPT4gKFxyXG4gICAgPEdyaWRcclxuICAgICAgZGF0YS10ZXN0PVwidHJhbnNhY3Rpb24tbGlzdC1maWx0ZXItYW1vdW50LXJhbmdlXCJcclxuICAgICAgY29udGFpbmVyXHJcbiAgICAgIGRpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiXHJcbiAgICAgIGFsaWduSXRlbXM9XCJmbGV4LXN0YXJ0XCJcclxuICAgICAgc3BhY2luZz17MX1cclxuICAgICAgc3g9e3sgd2lkdGg6IFwiMzAwcHhcIiwgbWFyZ2luOiBcIjMwcHhcIiB9fVxyXG4gICAgPlxyXG4gICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgIDxHcmlkXHJcbiAgICAgICAgICBjb250YWluZXJcclxuICAgICAgICAgIGRpcmVjdGlvbj1cInJvd1wiXHJcbiAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICBzeD17eyB3aWR0aDogXCIxMDAlXCIgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtIHN4PXt7IHdpZHRoOiBcIjIyNXB4XCIgfX0+XHJcbiAgICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbG9yPVwidGV4dFNlY29uZGFyeVwiIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWxpc3QtZmlsdGVyLWFtb3VudC1yYW5nZS10ZXh0XCI+XHJcbiAgICAgICAgICAgICAgQW1vdW50IFJhbmdlOiB7Zm9ybWF0QW1vdW50UmFuZ2VWYWx1ZXMoYW1vdW50UmFuZ2VWYWx1ZSl9XHJcbiAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saXN0LWZpbHRlci1hbW91bnQtY2xlYXItYnV0dG9uXCJcclxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBzZXRBbW91bnRSYW5nZVZhbHVlKGluaXRpYWxBbW91bnRSYW5nZSk7XHJcbiAgICAgICAgICAgICAgICByZXNldEFtb3VudFJhbmdlKCk7XHJcbiAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENsZWFyXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgPC9HcmlkPlxyXG4gICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgIDxTbGlkZXJcclxuICAgICAgICAgIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWxpc3QtZmlsdGVyLWFtb3VudC1yYW5nZS1zbGlkZXJcIlxyXG4gICAgICAgICAgc3g9e3sgd2lkdGg6IFwiMjAwcHhcIiB9fVxyXG4gICAgICAgICAgdmFsdWU9e2Ftb3VudFJhbmdlVmFsdWV9XHJcbiAgICAgICAgICBtaW49ezB9XHJcbiAgICAgICAgICBtYXg9ezEwMH1cclxuICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVBbW91bnRSYW5nZUNoYW5nZX1cclxuICAgICAgICAgIHZhbHVlTGFiZWxEaXNwbGF5PVwiYXV0b1wiXHJcbiAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJyYW5nZS1zbGlkZXJcIlxyXG4gICAgICAgICAgZ2V0QXJpYVZhbHVlVGV4dD17YW1vdW50UmFuZ2VWYWx1ZVRleHR9XHJcbiAgICAgICAgICB2YWx1ZUxhYmVsRm9ybWF0PXthbW91bnRSYW5nZVZhbHVlVGV4dExhYmVsfVxyXG4gICAgICAgIC8+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvR3JpZD5cclxuICApO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAgPENoaXBcclxuICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgb25DbGljaz17aGFuZGxlQW1vdW50UmFuZ2VDbGlja31cclxuICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saXN0LWZpbHRlci1hbW91bnQtcmFuZ2UtYnV0dG9uXCJcclxuICAgICAgICBsYWJlbD17YEFtb3VudDogJHtmb3JtYXRBbW91bnRSYW5nZVZhbHVlcyhhbW91bnRSYW5nZVZhbHVlKX1gfVxyXG4gICAgICAgIGRlbGV0ZUljb249ezxBcnJvd0Ryb3BEb3duSWNvbiAvPn1cclxuICAgICAgICBvbkRlbGV0ZT17aGFuZGxlQW1vdW50UmFuZ2VDbGlja31cclxuICAgICAgLz5cclxuICAgICAgeyF4c0JyZWFrcG9pbnQgJiYgKFxyXG4gICAgICAgIDxQb3BvdmVyXHJcbiAgICAgICAgICBpZD17YW1vdW50UmFuZ2VJZH1cclxuICAgICAgICAgIG9wZW49e2Ftb3VudFJhbmdlT3Blbn1cclxuICAgICAgICAgIGFuY2hvckVsPXthbW91bnRSYW5nZUFuY2hvckVsfVxyXG4gICAgICAgICAgb25DbG9zZT17aGFuZGxlQW1vdW50UmFuZ2VDbG9zZX1cclxuICAgICAgICAgIGFuY2hvck9yaWdpbj17e1xyXG4gICAgICAgICAgICB2ZXJ0aWNhbDogXCJib3R0b21cIixcclxuICAgICAgICAgICAgaG9yaXpvbnRhbDogXCJsZWZ0XCIsXHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgICAgdHJhbnNmb3JtT3JpZ2luPXt7XHJcbiAgICAgICAgICAgIHZlcnRpY2FsOiBcInRvcFwiLFxyXG4gICAgICAgICAgICBob3Jpem9udGFsOiBcImxlZnRcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEFtb3VudFJhbmdlRmlsdGVyIC8+XHJcbiAgICAgICAgPC9Qb3BvdmVyPlxyXG4gICAgICApfVxyXG4gICAgICB7eHNCcmVha3BvaW50ICYmIChcclxuICAgICAgICA8RHJhd2VyXHJcbiAgICAgICAgICBpZD17YW1vdW50UmFuZ2VJZH1cclxuICAgICAgICAgIG9wZW49e2Ftb3VudFJhbmdlT3Blbn1cclxuICAgICAgICAgIE1vZGFsUHJvcHM9e3sgb25DbG9zZTogaGFuZGxlQW1vdW50UmFuZ2VDbG9zZSB9fVxyXG4gICAgICAgICAgYW5jaG9yPVwiYm90dG9tXCJcclxuICAgICAgICAgIGRhdGEtdGVzdD1cImFtb3VudC1yYW5nZS1maWx0ZXItZHJhd2VyXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgIGRhdGEtdGVzdD1cImFtb3VudC1yYW5nZS1maWx0ZXItZHJhd2VyLWNsb3NlXCJcclxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlQW1vdW50UmFuZ2VDbG9zZSgpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICBDbG9zZVxyXG4gICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8QW1vdW50UmFuZ2VGaWx0ZXIgLz5cclxuICAgICAgICA8L0RyYXdlcj5cclxuICAgICAgKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvbkxpc3RBbW91bnRSYW5nZUZpbHRlcjtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvbkxpc3RBbW91bnRSYW5nZUZpbHRlci50c3gifQ==