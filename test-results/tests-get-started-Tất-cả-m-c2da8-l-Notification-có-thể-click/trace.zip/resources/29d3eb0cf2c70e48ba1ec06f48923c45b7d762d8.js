import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SignUpForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import { Button, Container, CssBaseline, TextField, Grid, Box, Typography } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object, ref } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
import RWALogo from "/src/components/SvgRwaLogo.tsx";
import Footer from "/src/components/Footer.tsx";
const PREFIX = "SignUpForm";
const classes = {
  paper: `${PREFIX}-paper`,
  logo: `${PREFIX}-logo`,
  form: `${PREFIX}-form`,
  submit: `${PREFIX}-submit`
};
const StyledContainer = styled(Container)(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.logo}`]: {
    color: theme.palette.primary.main
  },
  [`& .${classes.form}`]: {
    width: "100%",
    // Fix IE 11 issue.
    marginTop: theme.spacing(1)
  },
  [`& .${classes.submit}`]: {
    margin: theme.spacing(3, 0, 2)
  }
}));
const validationSchema = object({
  firstName: string().required("First Name is required"),
  lastName: string().required("Last Name is required"),
  username: string().required("Username is required"),
  password: string().min(4, "Password must contain at least 4 characters").required("Enter your password"),
  confirmPassword: string().required("Confirm your password").oneOf([ref("password")], "Password does not match")
});
const SignUpForm = ({ authService }) => {
  _s();
  const [, sendAuth] = useActor(authService);
  const initialValues = {
    firstName: "",
    lastName: "",
    username: "",
    password: "",
    confirmPassword: ""
  };
  const signUpPending = (payload) => sendAuth({ type: "SIGNUP", ...payload });
  return /* @__PURE__ */ jsxDEV(StyledContainer, { component: "main", maxWidth: "xs", children: [
    /* @__PURE__ */ jsxDEV(CssBaseline, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
      lineNumber: 76,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: classes.paper, children: [
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(RWALogo, { className: classes.logo }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
        lineNumber: 79,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
        lineNumber: 78,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h5", "data-test": "signup-title", children: "Sign Up" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
        lineNumber: 81,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Formik,
        {
          initialValues,
          validationSchema,
          onSubmit: async (values, { setSubmitting, setFieldValue }) => {
            setSubmitting(true);
            signUpPending(values);
          },
          children: ({ isValid, isSubmitting, dirty }) => /* @__PURE__ */ jsxDEV(Form, { className: classes.form, children: [
            /* @__PURE__ */ jsxDEV(Field, { name: "firstName", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                required: true,
                fullWidth: true,
                id: "firstName",
                label: "First Name",
                type: "text",
                autoFocus: true,
                "data-test": "signup-first-name",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 97,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 95,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { name: "lastName", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                required: true,
                fullWidth: true,
                id: "lastName",
                label: "Last Name",
                type: "text",
                "data-test": "signup-last-name",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 115,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 113,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { name: "username", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                required: true,
                fullWidth: true,
                id: "username",
                label: "Username",
                type: "text",
                "data-test": "signup-username",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 132,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 130,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { name: "password", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                required: true,
                fullWidth: true,
                label: "Password",
                type: "password",
                id: "password",
                "data-test": "signup-password",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 149,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 147,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { name: "confirmPassword", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                required: true,
                fullWidth: true,
                label: "Confirm Password",
                id: "confirmPassword",
                "data-test": "signup-confirmPassword",
                type: "password",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 166,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 164,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "submit",
                fullWidth: true,
                variant: "contained",
                color: "primary",
                className: classes.submit,
                "data-test": "signup-submit",
                disabled: !isValid || isSubmitting,
                children: "Sign Up"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
                lineNumber: 181,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Grid, { container: true, children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Link, { to: "/signin", children: "Have an account? Sign In" }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 194,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 193,
              columnNumber: 17
            }, this) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
              lineNumber: 192,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
            lineNumber: 94,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
          lineNumber: 84,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
      lineNumber: 77,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { mt: 8, children: /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
      lineNumber: 202,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
      lineNumber: 201,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx",
    lineNumber: 75,
    columnNumber: 5
  }, this);
};
_s(SignUpForm, "YY5LQLJhuoSlJhPDCCVm2ZnQaIM=", false, function() {
  return [useActor];
});
_c = SignUpForm;
export default SignUpForm;
var _c;
$RefreshReg$(_c, "SignUpForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignUpForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkVNOzJCQTNFTjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLGdCQUFnQjtBQUV6QixTQUFTQyxZQUFZO0FBQ3JCLFNBQVNDLFFBQVFDLFdBQVdDLGFBQWFDLFdBQVdDLE1BQU1DLEtBQUtDLGtCQUFrQjtBQUNqRixTQUFTQyxRQUFRQyxNQUFNQyxhQUF5QjtBQUNoRCxTQUFTQyxRQUFRQyxRQUFRQyxXQUFXO0FBRXBDLE9BQU9DLGFBQWE7QUFDcEIsT0FBT0MsWUFBWTtBQUluQixNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE9BQU8sR0FBR0YsTUFBTTtBQUFBLEVBQ2hCRyxNQUFNLEdBQUdILE1BQU07QUFBQSxFQUNmSSxNQUFNLEdBQUdKLE1BQU07QUFBQSxFQUNmSyxRQUFRLEdBQUdMLE1BQU07QUFDbkI7QUFFQSxNQUFNTSxrQkFBa0J4QixPQUFPSSxTQUFTLEVBQUUsQ0FBQyxFQUFFcUIsTUFBTSxPQUFPO0FBQUEsRUFDeEQsQ0FBQyxNQUFNTixRQUFRQyxLQUFLLEVBQUUsR0FBRztBQUFBLElBQ3ZCTSxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxJQUMxQkMsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsRUFDZDtBQUFBLEVBRUEsQ0FBQyxNQUFNWCxRQUFRRSxJQUFJLEVBQUUsR0FBRztBQUFBLElBQ3RCVSxPQUFPTixNQUFNTyxRQUFRQyxRQUFRQztBQUFBQSxFQUMvQjtBQUFBLEVBRUEsQ0FBQyxNQUFNZixRQUFRRyxJQUFJLEVBQUUsR0FBRztBQUFBLElBQ3RCYSxPQUFPO0FBQUE7QUFBQSxJQUNQVCxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUM1QjtBQUFBLEVBRUEsQ0FBQyxNQUFNUixRQUFRSSxNQUFNLEVBQUUsR0FBRztBQUFBLElBQ3hCYSxRQUFRWCxNQUFNRSxRQUFRLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDL0I7QUFDRixFQUFFO0FBRUYsTUFBTVUsbUJBQW1CdkIsT0FBTztBQUFBLEVBQzlCd0IsV0FBV3pCLE9BQU8sRUFBRTBCLFNBQVMsd0JBQXdCO0FBQUEsRUFDckRDLFVBQVUzQixPQUFPLEVBQUUwQixTQUFTLHVCQUF1QjtBQUFBLEVBQ25ERSxVQUFVNUIsT0FBTyxFQUFFMEIsU0FBUyxzQkFBc0I7QUFBQSxFQUNsREcsVUFBVTdCLE9BQU8sRUFDZDhCLElBQUksR0FBRyw2Q0FBNkMsRUFDcERKLFNBQVMscUJBQXFCO0FBQUEsRUFDakNLLGlCQUFpQi9CLE9BQU8sRUFDckIwQixTQUFTLHVCQUF1QixFQUNoQ00sTUFBTSxDQUFDOUIsSUFBSSxVQUFVLENBQUMsR0FBRyx5QkFBeUI7QUFDdkQsQ0FBQztBQU1ELE1BQU0rQixhQUE4QkEsQ0FBQyxFQUFFQyxZQUFZLE1BQU07QUFBQUMsS0FBQTtBQUN2RCxRQUFNLEdBQUdDLFFBQVEsSUFBSWhELFNBQVM4QyxXQUFXO0FBQ3pDLFFBQU1HLGdCQUE2RDtBQUFBLElBQ2pFWixXQUFXO0FBQUEsSUFDWEUsVUFBVTtBQUFBLElBQ1ZDLFVBQVU7QUFBQSxJQUNWQyxVQUFVO0FBQUEsSUFDVkUsaUJBQWlCO0FBQUEsRUFDbkI7QUFFQSxRQUFNTyxnQkFBZ0JBLENBQUNDLFlBQTJCSCxTQUFTLEVBQUVJLE1BQU0sVUFBVSxHQUFHRCxRQUFRLENBQUM7QUFFekYsU0FDRSx1QkFBQyxtQkFBZ0IsV0FBVSxRQUFPLFVBQVMsTUFDekM7QUFBQSwyQkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxJQUNaLHVCQUFDLFNBQUksV0FBV2pDLFFBQVFDLE9BQ3RCO0FBQUEsNkJBQUMsU0FDQyxpQ0FBQyxXQUFRLFdBQVdELFFBQVFFLFFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBaUMsS0FEbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssYUFBVSxnQkFBZSx1QkFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQTtBQUFBLFFBQUM7QUFBQTtBQUFBLFVBQ0M7QUFBQSxVQUNBO0FBQUEsVUFDQSxVQUFVLE9BQU9pQyxRQUFRLEVBQUVDLGVBQWVDLGNBQWMsTUFBTTtBQUM1REQsMEJBQWMsSUFBSTtBQUVsQkosMEJBQWNHLE1BQU07QUFBQSxVQUN0QjtBQUFBLFVBRUMsV0FBQyxFQUFFRyxTQUFTQyxjQUFjQyxNQUFNLE1BQy9CLHVCQUFDLFFBQUssV0FBV3hDLFFBQVFHLE1BQ3ZCO0FBQUEsbUNBQUMsU0FBTSxNQUFLLGFBQ1QsV0FBQyxFQUFFc0MsT0FBT0MsTUFBTSxFQUFFQyxPQUFPQyxPQUFPQyxjQUFjQyxRQUFRLEVBQWMsTUFDbkU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsUUFBTztBQUFBLGdCQUNQO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxJQUFHO0FBQUEsZ0JBQ0gsT0FBTTtBQUFBLGdCQUNOLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGFBQVU7QUFBQSxnQkFDVixRQUFRQSxXQUFXRixVQUFVQyxpQkFBaUJFLFFBQVFKLEtBQUs7QUFBQSxnQkFDM0QsWUFBWUcsV0FBV0YsVUFBVUMsZUFBZUYsUUFBUTtBQUFBLGdCQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxjQVpOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVlZLEtBZGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaUJBO0FBQUEsWUFDQSx1QkFBQyxTQUFNLE1BQUssWUFDVCxXQUFDLEVBQUVBLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFFBQU87QUFBQSxnQkFDUDtBQUFBLGdCQUNBO0FBQUEsZ0JBQ0EsSUFBRztBQUFBLGdCQUNILE9BQU07QUFBQSxnQkFDTixNQUFLO0FBQUEsZ0JBQ0wsYUFBVTtBQUFBLGdCQUNWLFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLGdCQUMzRCxZQUFZRyxXQUFXRixVQUFVQyxlQUFlRixRQUFRO0FBQUEsZ0JBQ3hELEdBQUlGO0FBQUFBO0FBQUFBLGNBWE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBV1ksS0FiaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFnQkE7QUFBQSxZQUNBLHVCQUFDLFNBQU0sTUFBSyxZQUNULFdBQUMsRUFBRUEsT0FBT0MsTUFBTSxFQUFFQyxPQUFPQyxPQUFPQyxjQUFjQyxRQUFRLEVBQWMsTUFDbkU7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUFRO0FBQUEsZ0JBQ1IsUUFBTztBQUFBLGdCQUNQO0FBQUEsZ0JBQ0E7QUFBQSxnQkFDQSxJQUFHO0FBQUEsZ0JBQ0gsT0FBTTtBQUFBLGdCQUNOLE1BQUs7QUFBQSxnQkFDTCxhQUFVO0FBQUEsZ0JBQ1YsUUFBUUEsV0FBV0YsVUFBVUMsaUJBQWlCRSxRQUFRSixLQUFLO0FBQUEsZ0JBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxnQkFDeEQsR0FBSUY7QUFBQUE7QUFBQUEsY0FYTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFXWSxLQWJoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWdCQTtBQUFBLFlBQ0EsdUJBQUMsU0FBTSxNQUFLLFlBQ1QsV0FBQyxFQUFFQSxPQUFPQyxNQUFNLEVBQUVDLE9BQU9DLE9BQU9DLGNBQWNDLFFBQVEsRUFBYyxNQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixRQUFPO0FBQUEsZ0JBQ1A7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLE9BQU07QUFBQSxnQkFDTixNQUFLO0FBQUEsZ0JBQ0wsSUFBRztBQUFBLGdCQUNILGFBQVU7QUFBQSxnQkFDVixRQUFRQSxXQUFXRixVQUFVQyxpQkFBaUJFLFFBQVFKLEtBQUs7QUFBQSxnQkFDM0QsWUFBWUcsV0FBV0YsVUFBVUMsZUFBZUYsUUFBUTtBQUFBLGdCQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxjQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFNLE1BQUssbUJBQ1QsV0FBQyxFQUFFQSxPQUFPQyxNQUFNLEVBQUVDLE9BQU9DLE9BQU9DLGNBQWNDLFFBQVEsRUFBYyxNQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixRQUFPO0FBQUEsZ0JBQ1A7QUFBQSxnQkFDQTtBQUFBLGdCQUNBLE9BQU07QUFBQSxnQkFDTixJQUFHO0FBQUEsZ0JBQ0gsYUFBVTtBQUFBLGdCQUNWLE1BQUs7QUFBQSxnQkFDTCxRQUFRQSxXQUFXRixVQUFVQyxpQkFBaUJFLFFBQVFKLEtBQUs7QUFBQSxnQkFDM0QsWUFBWUcsV0FBV0YsVUFBVUMsZUFBZUYsUUFBUTtBQUFBLGdCQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxjQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLFNBQVE7QUFBQSxnQkFDUixPQUFNO0FBQUEsZ0JBQ04sV0FBV3pDLFFBQVFJO0FBQUFBLGdCQUNuQixhQUFVO0FBQUEsZ0JBQ1YsVUFBVSxDQUFDa0MsV0FBV0M7QUFBQUEsZ0JBQWE7QUFBQTtBQUFBLGNBUHJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVVBO0FBQUEsWUFDQSx1QkFBQyxRQUFLLFdBQVMsTUFDYixpQ0FBQyxRQUFLLE1BQUksTUFDUixpQ0FBQyxRQUFLLElBQUcsV0FBVyx3Q0FBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0MsS0FEakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxlQXRHRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXVHQTtBQUFBO0FBQUEsUUFqSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BbUhBO0FBQUEsU0ExSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQTJIQTtBQUFBLElBQ0EsdUJBQUMsT0FBSSxJQUFJLEdBQ1AsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWhJRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBaUlBO0FBRUo7QUFBRVYsR0FoSklGLFlBQTJCO0FBQUEsVUFDVjdDLFFBQVE7QUFBQTtBQUFBa0UsS0FEekJyQjtBQWtKTixlQUFlQTtBQUFXLElBQUFxQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsic3R5bGVkIiwidXNlQWN0b3IiLCJMaW5rIiwiQnV0dG9uIiwiQ29udGFpbmVyIiwiQ3NzQmFzZWxpbmUiLCJUZXh0RmllbGQiLCJHcmlkIiwiQm94IiwiVHlwb2dyYXBoeSIsIkZvcm1payIsIkZvcm0iLCJGaWVsZCIsInN0cmluZyIsIm9iamVjdCIsInJlZiIsIlJXQUxvZ28iLCJGb290ZXIiLCJQUkVGSVgiLCJjbGFzc2VzIiwicGFwZXIiLCJsb2dvIiwiZm9ybSIsInN1Ym1pdCIsIlN0eWxlZENvbnRhaW5lciIsInRoZW1lIiwibWFyZ2luVG9wIiwic3BhY2luZyIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsImNvbG9yIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwid2lkdGgiLCJtYXJnaW4iLCJ2YWxpZGF0aW9uU2NoZW1hIiwiZmlyc3ROYW1lIiwicmVxdWlyZWQiLCJsYXN0TmFtZSIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJtaW4iLCJjb25maXJtUGFzc3dvcmQiLCJvbmVPZiIsIlNpZ25VcEZvcm0iLCJhdXRoU2VydmljZSIsIl9zIiwic2VuZEF1dGgiLCJpbml0aWFsVmFsdWVzIiwic2lnblVwUGVuZGluZyIsInBheWxvYWQiLCJ0eXBlIiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInNldEZpZWxkVmFsdWUiLCJpc1ZhbGlkIiwiaXNTdWJtaXR0aW5nIiwiZGlydHkiLCJmaWVsZCIsIm1ldGEiLCJlcnJvciIsInZhbHVlIiwiaW5pdGlhbFZhbHVlIiwidG91Y2hlZCIsIkJvb2xlYW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpZ25VcEZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IHVzZUFjdG9yIH0gZnJvbSBcIkB4c3RhdGUvcmVhY3RcIjtcclxuaW1wb3J0IHsgSW50ZXJwcmV0ZXIgfSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyBCdXR0b24sIENvbnRhaW5lciwgQ3NzQmFzZWxpbmUsIFRleHRGaWVsZCwgR3JpZCwgQm94LCBUeXBvZ3JhcGh5IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHsgRm9ybWlrLCBGb3JtLCBGaWVsZCwgRmllbGRQcm9wcyB9IGZyb20gXCJmb3JtaWtcIjtcclxuaW1wb3J0IHsgc3RyaW5nLCBvYmplY3QsIHJlZiB9IGZyb20gXCJ5dXBcIjtcclxuXHJcbmltcG9ydCBSV0FMb2dvIGZyb20gXCIuL1N2Z1J3YUxvZ29cIjtcclxuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9Gb290ZXJcIjtcclxuaW1wb3J0IHsgU2lnblVwUGF5bG9hZCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IHsgQXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZUV2ZW50cywgQXV0aE1hY2hpbmVTY2hlbWEgfSBmcm9tIFwiLi4vbWFjaGluZXMvYXV0aE1hY2hpbmVcIjtcclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiU2lnblVwRm9ybVwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwYXBlcjogYCR7UFJFRklYfS1wYXBlcmAsXHJcbiAgbG9nbzogYCR7UFJFRklYfS1sb2dvYCxcclxuICBmb3JtOiBgJHtQUkVGSVh9LWZvcm1gLFxyXG4gIHN1Ym1pdDogYCR7UFJFRklYfS1zdWJtaXRgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkQ29udGFpbmVyID0gc3R5bGVkKENvbnRhaW5lcikoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYgLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDgpLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5sb2dvfWBdOiB7XHJcbiAgICBjb2xvcjogdGhlbWUucGFsZXR0ZS5wcmltYXJ5Lm1haW4sXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuZm9ybX1gXToge1xyXG4gICAgd2lkdGg6IFwiMTAwJVwiLCAvLyBGaXggSUUgMTEgaXNzdWUuXHJcbiAgICBtYXJnaW5Ub3A6IHRoZW1lLnNwYWNpbmcoMSksXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMuc3VibWl0fWBdOiB7XHJcbiAgICBtYXJnaW46IHRoZW1lLnNwYWNpbmcoMywgMCwgMiksXHJcbiAgfSxcclxufSkpIGFzIHR5cGVvZiBDb250YWluZXI7XHJcblxyXG5jb25zdCB2YWxpZGF0aW9uU2NoZW1hID0gb2JqZWN0KHtcclxuICBmaXJzdE5hbWU6IHN0cmluZygpLnJlcXVpcmVkKFwiRmlyc3QgTmFtZSBpcyByZXF1aXJlZFwiKSxcclxuICBsYXN0TmFtZTogc3RyaW5nKCkucmVxdWlyZWQoXCJMYXN0IE5hbWUgaXMgcmVxdWlyZWRcIiksXHJcbiAgdXNlcm5hbWU6IHN0cmluZygpLnJlcXVpcmVkKFwiVXNlcm5hbWUgaXMgcmVxdWlyZWRcIiksXHJcbiAgcGFzc3dvcmQ6IHN0cmluZygpXHJcbiAgICAubWluKDQsIFwiUGFzc3dvcmQgbXVzdCBjb250YWluIGF0IGxlYXN0IDQgY2hhcmFjdGVyc1wiKVxyXG4gICAgLnJlcXVpcmVkKFwiRW50ZXIgeW91ciBwYXNzd29yZFwiKSxcclxuICBjb25maXJtUGFzc3dvcmQ6IHN0cmluZygpXHJcbiAgICAucmVxdWlyZWQoXCJDb25maXJtIHlvdXIgcGFzc3dvcmRcIilcclxuICAgIC5vbmVPZihbcmVmKFwicGFzc3dvcmRcIildLCBcIlBhc3N3b3JkIGRvZXMgbm90IG1hdGNoXCIpLFxyXG59KTtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHJvcHMge1xyXG4gIGF1dGhTZXJ2aWNlOiBJbnRlcnByZXRlcjxBdXRoTWFjaGluZUNvbnRleHQsIEF1dGhNYWNoaW5lU2NoZW1hLCBBdXRoTWFjaGluZUV2ZW50cywgYW55LCBhbnk+O1xyXG59XHJcblxyXG5jb25zdCBTaWduVXBGb3JtOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBhdXRoU2VydmljZSB9KSA9PiB7XHJcbiAgY29uc3QgWywgc2VuZEF1dGhdID0gdXNlQWN0b3IoYXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IGluaXRpYWxWYWx1ZXM6IFNpZ25VcFBheWxvYWQgJiB7IGNvbmZpcm1QYXNzd29yZDogc3RyaW5nIH0gPSB7XHJcbiAgICBmaXJzdE5hbWU6IFwiXCIsXHJcbiAgICBsYXN0TmFtZTogXCJcIixcclxuICAgIHVzZXJuYW1lOiBcIlwiLFxyXG4gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICBjb25maXJtUGFzc3dvcmQ6IFwiXCIsXHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgc2lnblVwUGVuZGluZyA9IChwYXlsb2FkOiBTaWduVXBQYXlsb2FkKSA9PiBzZW5kQXV0aCh7IHR5cGU6IFwiU0lHTlVQXCIsIC4uLnBheWxvYWQgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkQ29udGFpbmVyIGNvbXBvbmVudD1cIm1haW5cIiBtYXhXaWR0aD1cInhzXCI+XHJcbiAgICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5wYXBlcn0+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxSV0FMb2dvIGNsYXNzTmFtZT17Y2xhc3Nlcy5sb2dvfSAvPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgxXCIgdmFyaWFudD1cImg1XCIgZGF0YS10ZXN0PVwic2lnbnVwLXRpdGxlXCI+XHJcbiAgICAgICAgICBTaWduIFVwXHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDxGb3JtaWtcclxuICAgICAgICAgIGluaXRpYWxWYWx1ZXM9e2luaXRpYWxWYWx1ZXN9XHJcbiAgICAgICAgICB2YWxpZGF0aW9uU2NoZW1hPXt2YWxpZGF0aW9uU2NoZW1hfVxyXG4gICAgICAgICAgb25TdWJtaXQ9e2FzeW5jICh2YWx1ZXMsIHsgc2V0U3VibWl0dGluZywgc2V0RmllbGRWYWx1ZSB9KSA9PiB7XHJcbiAgICAgICAgICAgIHNldFN1Ym1pdHRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgICAgICBzaWduVXBQZW5kaW5nKHZhbHVlcyk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgID5cclxuICAgICAgICAgIHsoeyBpc1ZhbGlkLCBpc1N1Ym1pdHRpbmcsIGRpcnR5IH0pID0+IChcclxuICAgICAgICAgICAgPEZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19PlxyXG4gICAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwiZmlyc3ROYW1lXCI+XHJcbiAgICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGE6IHsgZXJyb3IsIHZhbHVlLCBpbml0aWFsVmFsdWUsIHRvdWNoZWQgfSB9OiBGaWVsZFByb3BzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbj1cIm5vcm1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICBpZD1cImZpcnN0TmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJGaXJzdCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lnbnVwLWZpcnN0LW5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwibGFzdE5hbWVcIj5cclxuICAgICAgICAgICAgICAgIHsoeyBmaWVsZCwgbWV0YTogeyBlcnJvciwgdmFsdWUsIGluaXRpYWxWYWx1ZSwgdG91Y2hlZCB9IH06IEZpZWxkUHJvcHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luPVwibm9ybWFsXCJcclxuICAgICAgICAgICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwibGFzdE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiTGFzdCBOYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lnbnVwLWxhc3QtbmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I9eyh0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUpICYmIEJvb2xlYW4oZXJyb3IpfVxyXG4gICAgICAgICAgICAgICAgICAgIGhlbHBlclRleHQ9e3RvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSA/IGVycm9yIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICAgICAgPEZpZWxkIG5hbWU9XCJ1c2VybmFtZVwiPlxyXG4gICAgICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW49XCJub3JtYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgaWQ9XCJ1c2VybmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJVc2VybmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRhdGEtdGVzdD1cInNpZ251cC11c2VybmFtZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZXJyb3I9eyh0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUpICYmIEJvb2xlYW4oZXJyb3IpfVxyXG4gICAgICAgICAgICAgICAgICAgIGhlbHBlclRleHQ9e3RvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSA/IGVycm9yIDogXCJcIn1cclxuICAgICAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICAgICAgPEZpZWxkIG5hbWU9XCJwYXNzd29yZFwiPlxyXG4gICAgICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIm91dGxpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW49XCJub3JtYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJzaWdudXAtcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwiY29uZmlybVBhc3N3b3JkXCI+XHJcbiAgICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGE6IHsgZXJyb3IsIHZhbHVlLCBpbml0aWFsVmFsdWUsIHRvdWNoZWQgfSB9OiBGaWVsZFByb3BzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbj1cIm5vcm1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIkNvbmZpcm0gUGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiY29uZmlybVBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJzaWdudXAtY29uZmlybVBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPXsodG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlKSAmJiBCb29sZWFuKGVycm9yKX1cclxuICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuc3VibWl0fVxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lnbnVwLXN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17IWlzVmFsaWQgfHwgaXNTdWJtaXR0aW5nfVxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIFNpZ24gVXBcclxuICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICA8R3JpZCBjb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9zaWduaW5cIj57XCJIYXZlIGFuIGFjY291bnQ/IFNpZ24gSW5cIn08L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8L0Zvcm0+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvRm9ybWlrPlxyXG4gICAgICA8L2Rpdj5cclxuICAgICAgPEJveCBtdD17OH0+XHJcbiAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICA8L0JveD5cclxuICAgIDwvU3R5bGVkQ29udGFpbmVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTaWduVXBGb3JtO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1NpZ25VcEZvcm0udHN4In0=