import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NavBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import clsx from "/node_modules/.vite/deps/clsx.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import {
  AppBar,
  Toolbar,
  Typography,
  IconButton,
  Badge,
  Button,
  useTheme,
  useMediaQuery,
  Link
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import {
  Menu as MenuIcon,
  Notifications as NotificationsIcon,
  AttachMoney as AttachMoneyIcon
} from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import { Link as RouterLink, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import TransactionNavTabs from "/src/components/TransactionNavTabs.tsx";
import RWALogo from "/src/components/SvgRwaLogo.tsx";
import RWALogoIcon from "/src/components/SvgRwaIconLogo.tsx";
const drawerWidth = 240;
const PREFIX = "NavBar";
const classes = {
  toolbar: `${PREFIX}-toolbar`,
  appBar: `${PREFIX}-appBar`,
  appBarShift: `${PREFIX}-appBarShift`,
  menuButtonHidden: `${PREFIX}-menuButtonHidden`,
  title: `${PREFIX}-title`,
  logo: `${PREFIX}-logo`,
  newTransactionButton: `${PREFIX}-newTransactionButton`,
  customBadge: `${PREFIX}-customBadge`
};
const StyledAppBar = styled(AppBar)(({ theme }) => ({
  [`& .${classes.toolbar}`]: {
    paddingRight: 24
    // keep right padding when drawer closed
  },
  [`&.${classes.appBar}`]: {
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
  },
  [`&.${classes.appBarShift}`]: {
    marginLeft: drawerWidth,
    width: `calc(100% - ${drawerWidth}px)`,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.enteringScreen
    })
  },
  [`& .${classes.menuButtonHidden}`]: {
    display: "none"
  },
  [`& .${classes.title}`]: {
    flexGrow: 1,
    textAlign: "center"
  },
  [`& .${classes.logo}`]: {
    color: "white",
    verticalAlign: "bottom"
  },
  [`& .${classes.newTransactionButton}`]: {
    fontSize: 16,
    backgroundColor: "#00C853",
    paddingTop: 5,
    paddingBottom: 5,
    paddingRight: 20,
    fontWeight: "bold",
    "&:hover": {
      backgroundColor: "#4CAF50",
      borderColor: "#00C853",
      boxShadow: "none"
    }
  },
  [`& .${classes.customBadge}`]: {
    backgroundColor: "red",
    color: "white"
  }
}));
_c = StyledAppBar;
const NavBar = ({ drawerOpen, toggleDrawer, notificationsService }) => {
  _s();
  const match = useLocation();
  const theme = useTheme();
  const [notificationsState] = useActor(notificationsService);
  const allNotifications = notificationsState?.context?.results;
  const xsBreakpoint = useMediaQuery(theme.breakpoints.only("xs"));
  return /* @__PURE__ */ jsxDEV(
    StyledAppBar,
    {
      position: "absolute",
      className: clsx(classes.appBar, drawerOpen && classes.appBarShift),
      children: [
        /* @__PURE__ */ jsxDEV(Toolbar, { className: classes.toolbar, children: [
          /* @__PURE__ */ jsxDEV(
            IconButton,
            {
              "data-test": "sidenav-toggle",
              edge: "start",
              color: "inherit",
              "aria-label": "open drawer",
              onClick: () => toggleDrawer(),
              size: "large",
              children: /* @__PURE__ */ jsxDEV(MenuIcon, { "data-test": "drawer-icon" }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                lineNumber: 140,
                columnNumber: 11
              }, this)
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
              lineNumber: 132,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Typography,
            {
              component: "h1",
              variant: "h6",
              color: "inherit",
              noWrap: true,
              className: classes.title,
              "data-test": "app-name-logo",
              children: /* @__PURE__ */ jsxDEV(
                Link,
                {
                  to: "/",
                  style: { color: "#fff", textDecoration: "none" },
                  component: RouterLink,
                  underline: "hover",
                  children: xsBreakpoint ? /* @__PURE__ */ jsxDEV(RWALogoIcon, { className: classes.logo }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                    lineNumber: 157,
                    columnNumber: 13
                  }, this) : /* @__PURE__ */ jsxDEV(RWALogo, { className: classes.logo }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                    lineNumber: 159,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                  lineNumber: 150,
                  columnNumber: 11
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
              lineNumber: 142,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            Button,
            {
              className: classes.newTransactionButton,
              variant: "contained",
              color: "inherit",
              component: RouterLink,
              to: "/transaction/new",
              "data-test": "nav-top-new-transaction",
              children: [
                /* @__PURE__ */ jsxDEV(AttachMoneyIcon, {}, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                  lineNumber: 171,
                  columnNumber: 11
                }, this),
                " New"
              ]
            },
            void 0,
            true,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
              lineNumber: 163,
              columnNumber: 9
            },
            this
          ),
          /* @__PURE__ */ jsxDEV(
            IconButton,
            {
              color: "inherit",
              component: RouterLink,
              to: "/notifications",
              "data-test": "nav-top-notifications-link",
              size: "large",
              children: /* @__PURE__ */ jsxDEV(
                Badge,
                {
                  badgeContent: allNotifications ? allNotifications.length : void 0,
                  "data-test": "nav-top-notifications-count",
                  classes: { badge: classes.customBadge },
                  children: /* @__PURE__ */ jsxDEV(NotificationsIcon, {}, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                    lineNumber: 185,
                    columnNumber: 13
                  }, this)
                },
                void 0,
                false,
                {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
                  lineNumber: 180,
                  columnNumber: 11
                },
                this
              )
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
              lineNumber: 173,
              columnNumber: 9
            },
            this
          )
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
          lineNumber: 131,
          columnNumber: 7
        }, this),
        (match.pathname === "/" || RegExp("/(?:public|contacts|personal)").test(match.pathname)) && /* @__PURE__ */ jsxDEV(TransactionNavTabs, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
          lineNumber: 190,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx",
      lineNumber: 127,
      columnNumber: 5
    },
    this
  );
};
_s(NavBar, "AuTvNDar/niBAstLkZZs+LxRGWg=", false, function() {
  return [useLocation, useTheme, useActor, useMediaQuery];
});
_c2 = NavBar;
export default NavBar;
var _c, _c2;
$RefreshReg$(_c, "StyledAppBar");
$RefreshReg$(_c2, "NavBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/NavBar.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMklVOzJCQTNJVjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLE9BQU9DLFVBQVU7QUFRakIsU0FBU0MsZ0JBQWdCO0FBQ3pCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQO0FBQUEsRUFDRUMsUUFBUUM7QUFBQUEsRUFDUkMsaUJBQWlCQztBQUFBQSxFQUNqQkMsZUFBZUM7QUFBQUEsT0FDVjtBQUNQLFNBQVNOLFFBQVFPLFlBQVlDLG1CQUFtQjtBQUdoRCxPQUFPQyx3QkFBd0I7QUFDL0IsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxpQkFBaUI7QUFFeEIsTUFBTUMsY0FBYztBQUVwQixNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLFNBQVMsR0FBR0YsTUFBTTtBQUFBLEVBQ2xCRyxRQUFRLEdBQUdILE1BQU07QUFBQSxFQUNqQkksYUFBYSxHQUFHSixNQUFNO0FBQUEsRUFDdEJLLGtCQUFrQixHQUFHTCxNQUFNO0FBQUEsRUFDM0JNLE9BQU8sR0FBR04sTUFBTTtBQUFBLEVBQ2hCTyxNQUFNLEdBQUdQLE1BQU07QUFBQSxFQUNmUSxzQkFBc0IsR0FBR1IsTUFBTTtBQUFBLEVBQy9CUyxhQUFhLEdBQUdULE1BQU07QUFDeEI7QUFFQSxNQUFNVSxlQUFlbEMsT0FBT0csTUFBTSxFQUFFLENBQUMsRUFBRWdDLE1BQU0sT0FBTztBQUFBLEVBQ2xELENBQUMsTUFBTVYsUUFBUUMsT0FBTyxFQUFFLEdBQUc7QUFBQSxJQUN6QlUsY0FBYztBQUFBO0FBQUEsRUFDaEI7QUFBQSxFQUVBLENBQUMsS0FBS1gsUUFBUUUsTUFBTSxFQUFFLEdBQUc7QUFBQSxJQUN2QlUsWUFBWUYsTUFBTUcsWUFBWUMsT0FBTyxDQUFDLFNBQVMsUUFBUSxHQUFHO0FBQUEsTUFDeERDLFFBQVFMLE1BQU1HLFlBQVlFLE9BQU9DO0FBQUFBLE1BQ2pDQyxVQUFVUCxNQUFNRyxZQUFZSSxTQUFTQztBQUFBQSxJQUN2QyxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsQ0FBQyxLQUFLbEIsUUFBUUcsV0FBVyxFQUFFLEdBQUc7QUFBQSxJQUM1QmdCLFlBQVlyQjtBQUFBQSxJQUNac0IsT0FBTyxlQUFldEIsV0FBVztBQUFBLElBQ2pDYyxZQUFZRixNQUFNRyxZQUFZQyxPQUFPLENBQUMsU0FBUyxRQUFRLEdBQUc7QUFBQSxNQUN4REMsUUFBUUwsTUFBTUcsWUFBWUUsT0FBT0M7QUFBQUEsTUFDakNDLFVBQVVQLE1BQU1HLFlBQVlJLFNBQVNJO0FBQUFBLElBQ3ZDLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxDQUFDLE1BQU1yQixRQUFRSSxnQkFBZ0IsRUFBRSxHQUFHO0FBQUEsSUFDbENrQixTQUFTO0FBQUEsRUFDWDtBQUFBLEVBRUEsQ0FBQyxNQUFNdEIsUUFBUUssS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN2QmtCLFVBQVU7QUFBQSxJQUNWQyxXQUFXO0FBQUEsRUFDYjtBQUFBLEVBRUEsQ0FBQyxNQUFNeEIsUUFBUU0sSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUN0Qm1CLE9BQU87QUFBQSxJQUNQQyxlQUFlO0FBQUEsRUFDakI7QUFBQSxFQUVBLENBQUMsTUFBTTFCLFFBQVFPLG9CQUFvQixFQUFFLEdBQUc7QUFBQSxJQUN0Q29CLFVBQVU7QUFBQSxJQUNWQyxpQkFBaUI7QUFBQSxJQUNqQkMsWUFBWTtBQUFBLElBQ1pDLGVBQWU7QUFBQSxJQUNmbkIsY0FBYztBQUFBLElBQ2RvQixZQUFZO0FBQUEsSUFDWixXQUFXO0FBQUEsTUFDVEgsaUJBQWlCO0FBQUEsTUFDakJJLGFBQWE7QUFBQSxNQUNiQyxXQUFXO0FBQUEsSUFDYjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLENBQUMsTUFBTWpDLFFBQVFRLFdBQVcsRUFBRSxHQUFHO0FBQUEsSUFDN0JvQixpQkFBaUI7QUFBQSxJQUNqQkgsT0FBTztBQUFBLEVBQ1Q7QUFDRixFQUFFO0FBQUVTLEtBckRFekI7QUFtRU4sTUFBTTBCLFNBQWdDQSxDQUFDLEVBQUVDLFlBQVlDLGNBQWNDLHFCQUFxQixNQUFNO0FBQUFDLEtBQUE7QUFDNUYsUUFBTUMsUUFBUTlDLFlBQVk7QUFFMUIsUUFBTWdCLFFBQVExQixTQUFTO0FBQ3ZCLFFBQU0sQ0FBQ3lELGtCQUFrQixJQUFJaEUsU0FBUzZELG9CQUFvQjtBQUUxRCxRQUFNSSxtQkFBbUJELG9CQUFvQkUsU0FBU0M7QUFDdEQsUUFBTUMsZUFBZTVELGNBQWN5QixNQUFNb0MsWUFBWUMsS0FBSyxJQUFJLENBQUM7QUFFL0QsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsVUFBUztBQUFBLE1BQ1QsV0FBV3ZFLEtBQUt3QixRQUFRRSxRQUFRa0MsY0FBY3BDLFFBQVFHLFdBQVc7QUFBQSxNQUVqRTtBQUFBLCtCQUFDLFdBQVEsV0FBV0gsUUFBUUMsU0FDMUI7QUFBQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBVTtBQUFBLGNBQ1YsTUFBSztBQUFBLGNBQ0wsT0FBTTtBQUFBLGNBQ04sY0FBVztBQUFBLGNBQ1gsU0FBUyxNQUFNb0MsYUFBYTtBQUFBLGNBQzVCLE1BQUs7QUFBQSxjQUVMLGlDQUFDLFlBQVMsYUFBVSxpQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBaUM7QUFBQTtBQUFBLFlBUm5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVNBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBVTtBQUFBLGNBQ1YsU0FBUTtBQUFBLGNBQ1IsT0FBTTtBQUFBLGNBQ047QUFBQSxjQUNBLFdBQVdyQyxRQUFRSztBQUFBQSxjQUNuQixhQUFVO0FBQUEsY0FFVjtBQUFBLGdCQUFDO0FBQUE7QUFBQSxrQkFDQyxJQUFHO0FBQUEsa0JBQ0gsT0FBTyxFQUFFb0IsT0FBTyxRQUFRdUIsZ0JBQWdCLE9BQU87QUFBQSxrQkFDL0MsV0FBV3ZEO0FBQUFBLGtCQUNYLFdBQVU7QUFBQSxrQkFFVG9ELHlCQUNDLHVCQUFDLGVBQVksV0FBVzdDLFFBQVFNLFFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXFDLElBRXJDLHVCQUFDLFdBQVEsV0FBV04sUUFBUU0sUUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBaUM7QUFBQTtBQUFBLGdCQVRyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FXQTtBQUFBO0FBQUEsWUFuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBb0JBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsV0FBV04sUUFBUU87QUFBQUEsY0FDbkIsU0FBUTtBQUFBLGNBQ1IsT0FBTTtBQUFBLGNBQ04sV0FBV2Q7QUFBQUEsY0FDWCxJQUFHO0FBQUEsY0FDSCxhQUFVO0FBQUEsY0FFVjtBQUFBLHVDQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQWdCO0FBQUEsZ0JBQUc7QUFBQTtBQUFBO0FBQUEsWUFSckI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBU0E7QUFBQSxVQUNBO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxPQUFNO0FBQUEsY0FDTixXQUFXQTtBQUFBQSxjQUNYLElBQUc7QUFBQSxjQUNILGFBQVU7QUFBQSxjQUNWLE1BQUs7QUFBQSxjQUVMO0FBQUEsZ0JBQUM7QUFBQTtBQUFBLGtCQUNDLGNBQWNpRCxtQkFBbUJBLGlCQUFpQk8sU0FBU0M7QUFBQUEsa0JBQzNELGFBQVU7QUFBQSxrQkFDVixTQUFTLEVBQUVDLE9BQU9uRCxRQUFRUSxZQUFZO0FBQUEsa0JBRXRDLGlDQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQWtCO0FBQUE7QUFBQSxnQkFMcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBTUE7QUFBQTtBQUFBLFlBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBY0E7QUFBQSxhQXhERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBeURBO0FBQUEsU0FDRWdDLE1BQU1ZLGFBQWEsT0FBT0MsT0FBTywrQkFBK0IsRUFBRUMsS0FBS2QsTUFBTVksUUFBUSxNQUNyRix1QkFBQyx3QkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CO0FBQUE7QUFBQTtBQUFBLElBL0R2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFpRUE7QUFFSjtBQUFFYixHQTdFSUosUUFBNkI7QUFBQSxVQUNuQnpDLGFBRUFWLFVBQ2VQLFVBR1JRLGFBQWE7QUFBQTtBQUFBc0UsTUFQOUJwQjtBQStFTixlQUFlQTtBQUFPLElBQUFELElBQUFxQjtBQUFBQyxhQUFBdEIsSUFBQTtBQUFBc0IsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlZCIsImNsc3giLCJ1c2VBY3RvciIsIkFwcEJhciIsIlRvb2xiYXIiLCJUeXBvZ3JhcGh5IiwiSWNvbkJ1dHRvbiIsIkJhZGdlIiwiQnV0dG9uIiwidXNlVGhlbWUiLCJ1c2VNZWRpYVF1ZXJ5IiwiTGluayIsIk1lbnUiLCJNZW51SWNvbiIsIk5vdGlmaWNhdGlvbnMiLCJOb3RpZmljYXRpb25zSWNvbiIsIkF0dGFjaE1vbmV5IiwiQXR0YWNoTW9uZXlJY29uIiwiUm91dGVyTGluayIsInVzZUxvY2F0aW9uIiwiVHJhbnNhY3Rpb25OYXZUYWJzIiwiUldBTG9nbyIsIlJXQUxvZ29JY29uIiwiZHJhd2VyV2lkdGgiLCJQUkVGSVgiLCJjbGFzc2VzIiwidG9vbGJhciIsImFwcEJhciIsImFwcEJhclNoaWZ0IiwibWVudUJ1dHRvbkhpZGRlbiIsInRpdGxlIiwibG9nbyIsIm5ld1RyYW5zYWN0aW9uQnV0dG9uIiwiY3VzdG9tQmFkZ2UiLCJTdHlsZWRBcHBCYXIiLCJ0aGVtZSIsInBhZGRpbmdSaWdodCIsInRyYW5zaXRpb24iLCJ0cmFuc2l0aW9ucyIsImNyZWF0ZSIsImVhc2luZyIsInNoYXJwIiwiZHVyYXRpb24iLCJsZWF2aW5nU2NyZWVuIiwibWFyZ2luTGVmdCIsIndpZHRoIiwiZW50ZXJpbmdTY3JlZW4iLCJkaXNwbGF5IiwiZmxleEdyb3ciLCJ0ZXh0QWxpZ24iLCJjb2xvciIsInZlcnRpY2FsQWxpZ24iLCJmb250U2l6ZSIsImJhY2tncm91bmRDb2xvciIsInBhZGRpbmdUb3AiLCJwYWRkaW5nQm90dG9tIiwiZm9udFdlaWdodCIsImJvcmRlckNvbG9yIiwiYm94U2hhZG93IiwiX2MiLCJOYXZCYXIiLCJkcmF3ZXJPcGVuIiwidG9nZ2xlRHJhd2VyIiwibm90aWZpY2F0aW9uc1NlcnZpY2UiLCJfcyIsIm1hdGNoIiwibm90aWZpY2F0aW9uc1N0YXRlIiwiYWxsTm90aWZpY2F0aW9ucyIsImNvbnRleHQiLCJyZXN1bHRzIiwieHNCcmVha3BvaW50IiwiYnJlYWtwb2ludHMiLCJvbmx5IiwidGV4dERlY29yYXRpb24iLCJsZW5ndGgiLCJ1bmRlZmluZWQiLCJiYWRnZSIsInBhdGhuYW1lIiwiUmVnRXhwIiwidGVzdCIsIl9jMiIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk5hdkJhci50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IGNsc3ggZnJvbSBcImNsc3hcIjtcclxuaW1wb3J0IHtcclxuICBCYXNlQWN0aW9uT2JqZWN0LFxyXG4gIEludGVycHJldGVyLFxyXG4gIFJlc29sdmVUeXBlZ2VuTWV0YSxcclxuICBTZXJ2aWNlTWFwLFxyXG4gIFR5cGVnZW5EaXNhYmxlZCxcclxufSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IHVzZUFjdG9yIH0gZnJvbSBcIkB4c3RhdGUvcmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBBcHBCYXIsXHJcbiAgVG9vbGJhcixcclxuICBUeXBvZ3JhcGh5LFxyXG4gIEljb25CdXR0b24sXHJcbiAgQmFkZ2UsXHJcbiAgQnV0dG9uLFxyXG4gIHVzZVRoZW1lLFxyXG4gIHVzZU1lZGlhUXVlcnksXHJcbiAgTGluayxcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQge1xyXG4gIE1lbnUgYXMgTWVudUljb24sXHJcbiAgTm90aWZpY2F0aW9ucyBhcyBOb3RpZmljYXRpb25zSWNvbixcclxuICBBdHRhY2hNb25leSBhcyBBdHRhY2hNb25leUljb24sXHJcbn0gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHsgTGluayBhcyBSb3V0ZXJMaW5rLCB1c2VMb2NhdGlvbiB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5pbXBvcnQgeyBEYXRhQ29udGV4dCwgRGF0YUV2ZW50cywgRGF0YVNjaGVtYSB9IGZyb20gXCIuLi9tYWNoaW5lcy9kYXRhTWFjaGluZVwiO1xyXG5pbXBvcnQgVHJhbnNhY3Rpb25OYXZUYWJzIGZyb20gXCIuL1RyYW5zYWN0aW9uTmF2VGFic1wiO1xyXG5pbXBvcnQgUldBTG9nbyBmcm9tIFwiLi9TdmdSd2FMb2dvXCI7XHJcbmltcG9ydCBSV0FMb2dvSWNvbiBmcm9tIFwiLi9TdmdSd2FJY29uTG9nb1wiO1xyXG5cclxuY29uc3QgZHJhd2VyV2lkdGggPSAyNDA7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIk5hdkJhclwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICB0b29sYmFyOiBgJHtQUkVGSVh9LXRvb2xiYXJgLFxyXG4gIGFwcEJhcjogYCR7UFJFRklYfS1hcHBCYXJgLFxyXG4gIGFwcEJhclNoaWZ0OiBgJHtQUkVGSVh9LWFwcEJhclNoaWZ0YCxcclxuICBtZW51QnV0dG9uSGlkZGVuOiBgJHtQUkVGSVh9LW1lbnVCdXR0b25IaWRkZW5gLFxyXG4gIHRpdGxlOiBgJHtQUkVGSVh9LXRpdGxlYCxcclxuICBsb2dvOiBgJHtQUkVGSVh9LWxvZ29gLFxyXG4gIG5ld1RyYW5zYWN0aW9uQnV0dG9uOiBgJHtQUkVGSVh9LW5ld1RyYW5zYWN0aW9uQnV0dG9uYCxcclxuICBjdXN0b21CYWRnZTogYCR7UFJFRklYfS1jdXN0b21CYWRnZWAsXHJcbn07XHJcblxyXG5jb25zdCBTdHlsZWRBcHBCYXIgPSBzdHlsZWQoQXBwQmFyKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJiAuJHtjbGFzc2VzLnRvb2xiYXJ9YF06IHtcclxuICAgIHBhZGRpbmdSaWdodDogMjQsIC8vIGtlZXAgcmlnaHQgcGFkZGluZyB3aGVuIGRyYXdlciBjbG9zZWRcclxuICB9LFxyXG5cclxuICBbYCYuJHtjbGFzc2VzLmFwcEJhcn1gXToge1xyXG4gICAgdHJhbnNpdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuY3JlYXRlKFtcIndpZHRoXCIsIFwibWFyZ2luXCJdLCB7XHJcbiAgICAgIGVhc2luZzogdGhlbWUudHJhbnNpdGlvbnMuZWFzaW5nLnNoYXJwLFxyXG4gICAgICBkdXJhdGlvbjogdGhlbWUudHJhbnNpdGlvbnMuZHVyYXRpb24ubGVhdmluZ1NjcmVlbixcclxuICAgIH0pLFxyXG4gIH0sXHJcblxyXG4gIFtgJi4ke2NsYXNzZXMuYXBwQmFyU2hpZnR9YF06IHtcclxuICAgIG1hcmdpbkxlZnQ6IGRyYXdlcldpZHRoLFxyXG4gICAgd2lkdGg6IGBjYWxjKDEwMCUgLSAke2RyYXdlcldpZHRofXB4KWAsXHJcbiAgICB0cmFuc2l0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5jcmVhdGUoW1wid2lkdGhcIiwgXCJtYXJnaW5cIl0sIHtcclxuICAgICAgZWFzaW5nOiB0aGVtZS50cmFuc2l0aW9ucy5lYXNpbmcuc2hhcnAsXHJcbiAgICAgIGR1cmF0aW9uOiB0aGVtZS50cmFuc2l0aW9ucy5kdXJhdGlvbi5lbnRlcmluZ1NjcmVlbixcclxuICAgIH0pLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLm1lbnVCdXR0b25IaWRkZW59YF06IHtcclxuICAgIGRpc3BsYXk6IFwibm9uZVwiLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnRpdGxlfWBdOiB7XHJcbiAgICBmbGV4R3JvdzogMSxcclxuICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5sb2dvfWBdOiB7XHJcbiAgICBjb2xvcjogXCJ3aGl0ZVwiLFxyXG4gICAgdmVydGljYWxBbGlnbjogXCJib3R0b21cIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5uZXdUcmFuc2FjdGlvbkJ1dHRvbn1gXToge1xyXG4gICAgZm9udFNpemU6IDE2LFxyXG4gICAgYmFja2dyb3VuZENvbG9yOiBcIiMwMEM4NTNcIixcclxuICAgIHBhZGRpbmdUb3A6IDUsXHJcbiAgICBwYWRkaW5nQm90dG9tOiA1LFxyXG4gICAgcGFkZGluZ1JpZ2h0OiAyMCxcclxuICAgIGZvbnRXZWlnaHQ6IFwiYm9sZFwiLFxyXG4gICAgXCImOmhvdmVyXCI6IHtcclxuICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiM0Q0FGNTBcIixcclxuICAgICAgYm9yZGVyQ29sb3I6IFwiIzAwQzg1M1wiLFxyXG4gICAgICBib3hTaGFkb3c6IFwibm9uZVwiLFxyXG4gICAgfSxcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5jdXN0b21CYWRnZX1gXToge1xyXG4gICAgYmFja2dyb3VuZENvbG9yOiBcInJlZFwiLFxyXG4gICAgY29sb3I6IFwid2hpdGVcIixcclxuICB9LFxyXG59KSk7XHJcblxyXG5pbnRlcmZhY2UgTmF2QmFyUHJvcHMge1xyXG4gIGRyYXdlck9wZW46IGJvb2xlYW47XHJcbiAgdG9nZ2xlRHJhd2VyOiBGdW5jdGlvbjtcclxuICBub3RpZmljYXRpb25zU2VydmljZTogSW50ZXJwcmV0ZXI8XHJcbiAgICBEYXRhQ29udGV4dCxcclxuICAgIERhdGFTY2hlbWEsXHJcbiAgICBEYXRhRXZlbnRzLFxyXG4gICAgYW55LFxyXG4gICAgUmVzb2x2ZVR5cGVnZW5NZXRhPFR5cGVnZW5EaXNhYmxlZCwgRGF0YUV2ZW50cywgQmFzZUFjdGlvbk9iamVjdCwgU2VydmljZU1hcD5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBOYXZCYXI6IFJlYWN0LkZDPE5hdkJhclByb3BzPiA9ICh7IGRyYXdlck9wZW4sIHRvZ2dsZURyYXdlciwgbm90aWZpY2F0aW9uc1NlcnZpY2UgfSkgPT4ge1xyXG4gIGNvbnN0IG1hdGNoID0gdXNlTG9jYXRpb24oKTtcclxuXHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpO1xyXG4gIGNvbnN0IFtub3RpZmljYXRpb25zU3RhdGVdID0gdXNlQWN0b3Iobm90aWZpY2F0aW9uc1NlcnZpY2UpO1xyXG5cclxuICBjb25zdCBhbGxOb3RpZmljYXRpb25zID0gbm90aWZpY2F0aW9uc1N0YXRlPy5jb250ZXh0Py5yZXN1bHRzO1xyXG4gIGNvbnN0IHhzQnJlYWtwb2ludCA9IHVzZU1lZGlhUXVlcnkodGhlbWUuYnJlYWtwb2ludHMub25seShcInhzXCIpKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRBcHBCYXJcclxuICAgICAgcG9zaXRpb249XCJhYnNvbHV0ZVwiXHJcbiAgICAgIGNsYXNzTmFtZT17Y2xzeChjbGFzc2VzLmFwcEJhciwgZHJhd2VyT3BlbiAmJiBjbGFzc2VzLmFwcEJhclNoaWZ0KX1cclxuICAgID5cclxuICAgICAgPFRvb2xiYXIgY2xhc3NOYW1lPXtjbGFzc2VzLnRvb2xiYXJ9PlxyXG4gICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICBkYXRhLXRlc3Q9XCJzaWRlbmF2LXRvZ2dsZVwiXHJcbiAgICAgICAgICBlZGdlPVwic3RhcnRcIlxyXG4gICAgICAgICAgY29sb3I9XCJpbmhlcml0XCJcclxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJvcGVuIGRyYXdlclwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGVEcmF3ZXIoKX1cclxuICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPE1lbnVJY29uIGRhdGEtdGVzdD1cImRyYXdlci1pY29uXCIgLz5cclxuICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgPFR5cG9ncmFwaHlcclxuICAgICAgICAgIGNvbXBvbmVudD1cImgxXCJcclxuICAgICAgICAgIHZhcmlhbnQ9XCJoNlwiXHJcbiAgICAgICAgICBjb2xvcj1cImluaGVyaXRcIlxyXG4gICAgICAgICAgbm9XcmFwXHJcbiAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9XHJcbiAgICAgICAgICBkYXRhLXRlc3Q9XCJhcHAtbmFtZS1sb2dvXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICB0bz1cIi9cIlxyXG4gICAgICAgICAgICBzdHlsZT17eyBjb2xvcjogXCIjZmZmXCIsIHRleHREZWNvcmF0aW9uOiBcIm5vbmVcIiB9fVxyXG4gICAgICAgICAgICBjb21wb25lbnQ9e1JvdXRlckxpbmt9XHJcbiAgICAgICAgICAgIHVuZGVybGluZT1cImhvdmVyXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAge3hzQnJlYWtwb2ludCA/IChcclxuICAgICAgICAgICAgICA8UldBTG9nb0ljb24gY2xhc3NOYW1lPXtjbGFzc2VzLmxvZ299IC8+XHJcbiAgICAgICAgICAgICkgOiAoXHJcbiAgICAgICAgICAgICAgPFJXQUxvZ28gY2xhc3NOYW1lPXtjbGFzc2VzLmxvZ299IC8+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDxCdXR0b25cclxuICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5uZXdUcmFuc2FjdGlvbkJ1dHRvbn1cclxuICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgY29sb3I9XCJpbmhlcml0XCJcclxuICAgICAgICAgIGNvbXBvbmVudD17Um91dGVyTGlua31cclxuICAgICAgICAgIHRvPVwiL3RyYW5zYWN0aW9uL25ld1wiXHJcbiAgICAgICAgICBkYXRhLXRlc3Q9XCJuYXYtdG9wLW5ldy10cmFuc2FjdGlvblwiXHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgPEF0dGFjaE1vbmV5SWNvbiAvPiBOZXdcclxuICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8SWNvbkJ1dHRvblxyXG4gICAgICAgICAgY29sb3I9XCJpbmhlcml0XCJcclxuICAgICAgICAgIGNvbXBvbmVudD17Um91dGVyTGlua31cclxuICAgICAgICAgIHRvPVwiL25vdGlmaWNhdGlvbnNcIlxyXG4gICAgICAgICAgZGF0YS10ZXN0PVwibmF2LXRvcC1ub3RpZmljYXRpb25zLWxpbmtcIlxyXG4gICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICA+XHJcbiAgICAgICAgICA8QmFkZ2VcclxuICAgICAgICAgICAgYmFkZ2VDb250ZW50PXthbGxOb3RpZmljYXRpb25zID8gYWxsTm90aWZpY2F0aW9ucy5sZW5ndGggOiB1bmRlZmluZWR9XHJcbiAgICAgICAgICAgIGRhdGEtdGVzdD1cIm5hdi10b3Atbm90aWZpY2F0aW9ucy1jb3VudFwiXHJcbiAgICAgICAgICAgIGNsYXNzZXM9e3sgYmFkZ2U6IGNsYXNzZXMuY3VzdG9tQmFkZ2UgfX1cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPE5vdGlmaWNhdGlvbnNJY29uIC8+XHJcbiAgICAgICAgICA8L0JhZGdlPlxyXG4gICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgPC9Ub29sYmFyPlxyXG4gICAgICB7KG1hdGNoLnBhdGhuYW1lID09PSBcIi9cIiB8fCBSZWdFeHAoXCIvKD86cHVibGljfGNvbnRhY3RzfHBlcnNvbmFsKVwiKS50ZXN0KG1hdGNoLnBhdGhuYW1lKSkgJiYgKFxyXG4gICAgICAgIDxUcmFuc2FjdGlvbk5hdlRhYnMgLz5cclxuICAgICAgKX1cclxuICAgIDwvU3R5bGVkQXBwQmFyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBOYXZCYXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvTmF2QmFyLnRzeCJ9