import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BankAccountForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { TextField, Button, Grid } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
import { useHistory } from "/node_modules/.vite/deps/react-router.js?v=6af76b79";
const validationSchema = object({
  bankName: string().min(5, "Must contain at least 5 characters").required("Enter a bank name"),
  routingNumber: string().length(9, "Must contain a valid routing number").required("Enter a valid bank routing number"),
  accountNumber: string().min(9, "Must contain at least 9 digits").max(12, "Must contain no more than 12 digits").required("Enter a valid bank account number")
});
const PREFIX = "BankAccountForm";
const classes = {
  paper: `${PREFIX}-paper`,
  form: `${PREFIX}-form`,
  submit: `${PREFIX}-submit`
};
const StyledFormik = styled(Formik)(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.form}`]: {
    width: "100%",
    // Fix IE 11 issue.
    marginTop: theme.spacing(1)
  },
  [`& .${classes.submit}`]: {
    margin: theme.spacing(3, 0, 2)
  }
}));
_c = StyledFormik;
const BankAccountForm = ({
  userId,
  createBankAccount,
  onboarding
}) => {
  _s();
  const history = useHistory();
  const initialValues = {
    userId,
    bankName: "",
    accountNumber: "",
    routingNumber: ""
  };
  return /* @__PURE__ */ jsxDEV(
    StyledFormik,
    {
      initialValues,
      validationSchema,
      onSubmit: (values, { setSubmitting }) => {
        setSubmitting(true);
        createBankAccount({ ...values, userId });
        if (!onboarding) {
          history.push("/bankaccounts");
        }
      },
      children: ({ isValid, isSubmitting }) => /* @__PURE__ */ jsxDEV(Form, { className: classes.form, "data-test": "bankaccount-form", children: [
        /* @__PURE__ */ jsxDEV(Field, { name: "bankName", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "bankaccount-bankName-input",
            type: "text",
            placeholder: "Bank Name",
            "data-test": "bankaccount-bankName-input",
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
            lineNumber: 84,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
          lineNumber: 82,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { name: "routingNumber", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "bankaccount-routingNumber-input",
            type: "text",
            placeholder: "Routing Number",
            "data-test": "bankaccount-routingNumber-input",
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
            lineNumber: 101,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
          lineNumber: 99,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Field, { name: "accountNumber", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
          TextField,
          {
            variant: "outlined",
            margin: "dense",
            fullWidth: true,
            required: true,
            id: "bankaccount-accountNumber-input",
            type: "text",
            placeholder: "Account Number",
            "data-test": "bankaccount-accountNumber-input",
            error: (touched || value !== initialValue) && Boolean(error),
            helperText: touched || value !== initialValue ? error : "",
            ...field
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
            lineNumber: 118,
            columnNumber: 11
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
          lineNumber: 116,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            spacing: 2,
            direction: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "submit",
                fullWidth: true,
                variant: "contained",
                color: "primary",
                className: classes.submit,
                "data-test": "bankaccount-submit",
                disabled: !isValid || isSubmitting,
                children: "Save"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
                lineNumber: 141,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
              lineNumber: 140,
              columnNumber: 13
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
            lineNumber: 133,
            columnNumber: 11
          },
          this
        )
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
        lineNumber: 81,
        columnNumber: 7
      }, this)
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx",
      lineNumber: 67,
      columnNumber: 5
    },
    this
  );
};
_s(BankAccountForm, "9cZfZ04734qoCGIctmKX7+sX6eU=", false, function() {
  return [useHistory];
});
_c2 = BankAccountForm;
export default BankAccountForm;
var _c, _c2;
$RefreshReg$(_c, "StyledFormik");
$RefreshReg$(_c2, "BankAccountForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/BankAccountForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUZjOzJCQW5GZDtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLFdBQVdDLFFBQVFDLFlBQVk7QUFDeEMsU0FBU0MsUUFBUUMsTUFBTUMsYUFBeUI7QUFDaEQsU0FBU0MsUUFBUUMsY0FBYztBQUUvQixTQUFTQyxrQkFBa0I7QUFFM0IsTUFBTUMsbUJBQW1CRixPQUFPO0FBQUEsRUFDOUJHLFVBQVVKLE9BQU8sRUFBRUssSUFBSSxHQUFHLG9DQUFvQyxFQUFFQyxTQUFTLG1CQUFtQjtBQUFBLEVBQzVGQyxlQUFlUCxPQUFPLEVBQ25CUSxPQUFPLEdBQUcscUNBQXFDLEVBQy9DRixTQUFTLG1DQUFtQztBQUFBLEVBQy9DRyxlQUFlVCxPQUFPLEVBQ25CSyxJQUFJLEdBQUcsZ0NBQWdDLEVBQ3ZDSyxJQUFJLElBQUkscUNBQXFDLEVBQzdDSixTQUFTLG1DQUFtQztBQUNqRCxDQUFDO0FBRUQsTUFBTUssU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFBQSxFQUNoQkcsTUFBTSxHQUFHSCxNQUFNO0FBQUEsRUFDZkksUUFBUSxHQUFHSixNQUFNO0FBQ25CO0FBRUEsTUFBTUssZUFBZXZCLE9BQU9JLE1BQU0sRUFBRSxDQUFDLEVBQUVvQixNQUFNLE9BQU87QUFBQSxFQUNsRCxDQUFDLE1BQU1MLFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdkJLLFdBQVdELE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQzFCQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLFlBQVk7QUFBQSxFQUNkO0FBQUEsRUFFQSxDQUFDLE1BQU1WLFFBQVFFLElBQUksRUFBRSxHQUFHO0FBQUEsSUFDdEJTLE9BQU87QUFBQTtBQUFBLElBQ1BMLFdBQVdELE1BQU1FLFFBQVEsQ0FBQztBQUFBLEVBQzVCO0FBQUEsRUFFQSxDQUFDLE1BQU1QLFFBQVFHLE1BQU0sRUFBRSxHQUFHO0FBQUEsSUFDeEJTLFFBQVFQLE1BQU1FLFFBQVEsR0FBRyxHQUFHLENBQUM7QUFBQSxFQUMvQjtBQUNGLEVBQUU7QUFBRU0sS0FoQkVUO0FBd0JOLE1BQU1VLGtCQUFrREEsQ0FBQztBQUFBLEVBQ3ZEQztBQUFBQSxFQUNBQztBQUFBQSxFQUNBQztBQUNGLE1BQU07QUFBQUMsS0FBQTtBQUNKLFFBQU1DLFVBQVU3QixXQUFXO0FBRTNCLFFBQU04QixnQkFBb0M7QUFBQSxJQUN4Q0w7QUFBQUEsSUFDQXZCLFVBQVU7QUFBQSxJQUNWSyxlQUFlO0FBQUEsSUFDZkYsZUFBZTtBQUFBLEVBQ2pCO0FBRUEsU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0M7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFVLENBQUMwQixRQUFRLEVBQUVDLGNBQWMsTUFBTTtBQUN2Q0Esc0JBQWMsSUFBSTtBQUVsQk4sMEJBQWtCLEVBQUUsR0FBR0ssUUFBUU4sT0FBTyxDQUFDO0FBRXZDLFlBQUksQ0FBQ0UsWUFBWTtBQUNmRSxrQkFBUUksS0FBSyxlQUFlO0FBQUEsUUFDOUI7QUFBQSxNQUNGO0FBQUEsTUFFQyxXQUFDLEVBQUVDLFNBQVNDLGFBQWEsTUFDeEIsdUJBQUMsUUFBSyxXQUFXekIsUUFBUUUsTUFBTSxhQUFVLG9CQUN2QztBQUFBLCtCQUFDLFNBQU0sTUFBSyxZQUNULFdBQUMsRUFBRXdCLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixRQUFPO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLGFBQVc7QUFBQSxZQUNYLFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLFlBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxZQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sTUFBSyxpQkFDVCxXQUFDLEVBQUVBLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixRQUFPO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLGFBQVc7QUFBQSxZQUNYLFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLFlBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxZQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBLHVCQUFDLFNBQU0sTUFBSyxpQkFDVCxXQUFDLEVBQUVBLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxTQUFRO0FBQUEsWUFDUixRQUFPO0FBQUEsWUFDUDtBQUFBLFlBQ0E7QUFBQSxZQUNBLElBQUk7QUFBQSxZQUNKLE1BQUs7QUFBQSxZQUNMLGFBQVk7QUFBQSxZQUNaLGFBQVc7QUFBQSxZQUNYLFFBQVFBLFdBQVdGLFVBQVVDLGlCQUFpQkUsUUFBUUosS0FBSztBQUFBLFlBQzNELFlBQVlHLFdBQVdGLFVBQVVDLGVBQWVGLFFBQVE7QUFBQSxZQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxVQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFnQkE7QUFBQSxRQUNBO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQztBQUFBLFlBQ0EsU0FBUztBQUFBLFlBQ1QsV0FBVTtBQUFBLFlBQ1YsZ0JBQWU7QUFBQSxZQUNmLFlBQVc7QUFBQSxZQUVYLGlDQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsU0FBUTtBQUFBLGdCQUNSLE9BQU07QUFBQSxnQkFDTixXQUFXMUIsUUFBUUc7QUFBQUEsZ0JBQ25CLGFBQVU7QUFBQSxnQkFDVixVQUFVLENBQUNxQixXQUFXQztBQUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FQckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUEsS0FYRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVlBO0FBQUE7QUFBQSxVQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFvQkE7QUFBQSxXQXhFRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBeUVBO0FBQUE7QUFBQSxJQXZGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUF5RkE7QUFFSjtBQUFFUCxHQTFHSUosaUJBQStDO0FBQUEsVUFLbkN4QixVQUFVO0FBQUE7QUFBQTJDLE1BTHRCbkI7QUE0R04sZUFBZUE7QUFBZ0IsSUFBQUQsSUFBQW9CO0FBQUFDLGFBQUFyQixJQUFBO0FBQUFxQixhQUFBRCxLQUFBIiwibmFtZXMiOlsic3R5bGVkIiwiVGV4dEZpZWxkIiwiQnV0dG9uIiwiR3JpZCIsIkZvcm1payIsIkZvcm0iLCJGaWVsZCIsInN0cmluZyIsIm9iamVjdCIsInVzZUhpc3RvcnkiLCJ2YWxpZGF0aW9uU2NoZW1hIiwiYmFua05hbWUiLCJtaW4iLCJyZXF1aXJlZCIsInJvdXRpbmdOdW1iZXIiLCJsZW5ndGgiLCJhY2NvdW50TnVtYmVyIiwibWF4IiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwiZm9ybSIsInN1Ym1pdCIsIlN0eWxlZEZvcm1payIsInRoZW1lIiwibWFyZ2luVG9wIiwic3BhY2luZyIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiYWxpZ25JdGVtcyIsIndpZHRoIiwibWFyZ2luIiwiX2MiLCJCYW5rQWNjb3VudEZvcm0iLCJ1c2VySWQiLCJjcmVhdGVCYW5rQWNjb3VudCIsIm9uYm9hcmRpbmciLCJfcyIsImhpc3RvcnkiLCJpbml0aWFsVmFsdWVzIiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsInB1c2giLCJpc1ZhbGlkIiwiaXNTdWJtaXR0aW5nIiwiZmllbGQiLCJtZXRhIiwiZXJyb3IiLCJ2YWx1ZSIsImluaXRpYWxWYWx1ZSIsInRvdWNoZWQiLCJCb29sZWFuIiwiX2MyIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQmFua0FjY291bnRGb3JtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBUZXh0RmllbGQsIEJ1dHRvbiwgR3JpZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IEZvcm1paywgRm9ybSwgRmllbGQsIEZpZWxkUHJvcHMgfSBmcm9tIFwiZm9ybWlrXCI7XHJcbmltcG9ydCB7IHN0cmluZywgb2JqZWN0IH0gZnJvbSBcInl1cFwiO1xyXG5pbXBvcnQgeyBCYW5rQWNjb3VudFBheWxvYWQsIFVzZXIgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCB7IHVzZUhpc3RvcnkgfSBmcm9tIFwicmVhY3Qtcm91dGVyXCI7XHJcblxyXG5jb25zdCB2YWxpZGF0aW9uU2NoZW1hID0gb2JqZWN0KHtcclxuICBiYW5rTmFtZTogc3RyaW5nKCkubWluKDUsIFwiTXVzdCBjb250YWluIGF0IGxlYXN0IDUgY2hhcmFjdGVyc1wiKS5yZXF1aXJlZChcIkVudGVyIGEgYmFuayBuYW1lXCIpLFxyXG4gIHJvdXRpbmdOdW1iZXI6IHN0cmluZygpXHJcbiAgICAubGVuZ3RoKDksIFwiTXVzdCBjb250YWluIGEgdmFsaWQgcm91dGluZyBudW1iZXJcIilcclxuICAgIC5yZXF1aXJlZChcIkVudGVyIGEgdmFsaWQgYmFuayByb3V0aW5nIG51bWJlclwiKSxcclxuICBhY2NvdW50TnVtYmVyOiBzdHJpbmcoKVxyXG4gICAgLm1pbig5LCBcIk11c3QgY29udGFpbiBhdCBsZWFzdCA5IGRpZ2l0c1wiKVxyXG4gICAgLm1heCgxMiwgXCJNdXN0IGNvbnRhaW4gbm8gbW9yZSB0aGFuIDEyIGRpZ2l0c1wiKVxyXG4gICAgLnJlcXVpcmVkKFwiRW50ZXIgYSB2YWxpZCBiYW5rIGFjY291bnQgbnVtYmVyXCIpLFxyXG59KTtcclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiQmFua0FjY291bnRGb3JtXCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHBhcGVyOiBgJHtQUkVGSVh9LXBhcGVyYCxcclxuICBmb3JtOiBgJHtQUkVGSVh9LWZvcm1gLFxyXG4gIHN1Ym1pdDogYCR7UFJFRklYfS1zdWJtaXRgLFxyXG59O1xyXG5cclxuY29uc3QgU3R5bGVkRm9ybWlrID0gc3R5bGVkKEZvcm1paykoKHsgdGhlbWUgfSkgPT4gKHtcclxuICBbYCYgLiR7Y2xhc3Nlcy5wYXBlcn1gXToge1xyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDgpLFxyXG4gICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxyXG4gICAgYWxpZ25JdGVtczogXCJjZW50ZXJcIixcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5mb3JtfWBdOiB7XHJcbiAgICB3aWR0aDogXCIxMDAlXCIsIC8vIEZpeCBJRSAxMSBpc3N1ZS5cclxuICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZygxKSxcclxuICB9LFxyXG5cclxuICBbYCYgLiR7Y2xhc3Nlcy5zdWJtaXR9YF06IHtcclxuICAgIG1hcmdpbjogdGhlbWUuc3BhY2luZygzLCAwLCAyKSxcclxuICB9LFxyXG59KSk7XHJcblxyXG5leHBvcnQgaW50ZXJmYWNlIEJhbmtBY2NvdW50Rm9ybVByb3BzIHtcclxuICB1c2VySWQ6IFVzZXJbXCJpZFwiXTtcclxuICBjcmVhdGVCYW5rQWNjb3VudDogRnVuY3Rpb247XHJcbiAgb25ib2FyZGluZz86IGJvb2xlYW47XHJcbn1cclxuXHJcbmNvbnN0IEJhbmtBY2NvdW50Rm9ybTogUmVhY3QuRkM8QmFua0FjY291bnRGb3JtUHJvcHM+ID0gKHtcclxuICB1c2VySWQsXHJcbiAgY3JlYXRlQmFua0FjY291bnQsXHJcbiAgb25ib2FyZGluZyxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VIaXN0b3J5KCk7XHJcblxyXG4gIGNvbnN0IGluaXRpYWxWYWx1ZXM6IEJhbmtBY2NvdW50UGF5bG9hZCA9IHtcclxuICAgIHVzZXJJZCxcclxuICAgIGJhbmtOYW1lOiBcIlwiLFxyXG4gICAgYWNjb3VudE51bWJlcjogXCJcIixcclxuICAgIHJvdXRpbmdOdW1iZXI6IFwiXCIsXHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxTdHlsZWRGb3JtaWtcclxuICAgICAgaW5pdGlhbFZhbHVlcz17aW5pdGlhbFZhbHVlc31cclxuICAgICAgdmFsaWRhdGlvblNjaGVtYT17dmFsaWRhdGlvblNjaGVtYX1cclxuICAgICAgb25TdWJtaXQ9eyh2YWx1ZXMsIHsgc2V0U3VibWl0dGluZyB9KSA9PiB7XHJcbiAgICAgICAgc2V0U3VibWl0dGluZyh0cnVlKTtcclxuXHJcbiAgICAgICAgY3JlYXRlQmFua0FjY291bnQoeyAuLi52YWx1ZXMsIHVzZXJJZCB9KTtcclxuXHJcbiAgICAgICAgaWYgKCFvbmJvYXJkaW5nKSB7XHJcbiAgICAgICAgICBoaXN0b3J5LnB1c2goXCIvYmFua2FjY291bnRzXCIpO1xyXG4gICAgICAgIH1cclxuICAgICAgfX1cclxuICAgID5cclxuICAgICAgeyh7IGlzVmFsaWQsIGlzU3VibWl0dGluZyB9KSA9PiAoXHJcbiAgICAgICAgPEZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19IGRhdGEtdGVzdD1cImJhbmthY2NvdW50LWZvcm1cIj5cclxuICAgICAgICAgIDxGaWVsZCBuYW1lPVwiYmFua05hbWVcIj5cclxuICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBpZD17XCJiYW5rYWNjb3VudC1iYW5rTmFtZS1pbnB1dFwifVxyXG4gICAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCYW5rIE5hbWVcIlxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PXtcImJhbmthY2NvdW50LWJhbmtOYW1lLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICBlcnJvcj17KHRvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSkgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICA8RmllbGQgbmFtZT1cInJvdXRpbmdOdW1iZXJcIj5cclxuICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBpZD17XCJiYW5rYWNjb3VudC1yb3V0aW5nTnVtYmVyLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJvdXRpbmcgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdD17XCJiYW5rYWNjb3VudC1yb3V0aW5nTnVtYmVyLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICBlcnJvcj17KHRvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSkgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICA8RmllbGQgbmFtZT1cImFjY291bnROdW1iZXJcIj5cclxuICAgICAgICAgICAgeyh7IGZpZWxkLCBtZXRhOiB7IGVycm9yLCB2YWx1ZSwgaW5pdGlhbFZhbHVlLCB0b3VjaGVkIH0gfTogRmllbGRQcm9wcykgPT4gKFxyXG4gICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBtYXJnaW49XCJkZW5zZVwiXHJcbiAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAgICAgICBpZD17XCJiYW5rYWNjb3VudC1hY2NvdW50TnVtYmVyLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkFjY291bnQgTnVtYmVyXCJcclxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdD17XCJiYW5rYWNjb3VudC1hY2NvdW50TnVtYmVyLWlucHV0XCJ9XHJcbiAgICAgICAgICAgICAgICBlcnJvcj17KHRvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSkgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXt0b3VjaGVkIHx8IHZhbHVlICE9PSBpbml0aWFsVmFsdWUgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICB7Li4uZmllbGR9XHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgIDwvRmllbGQ+XHJcbiAgICAgICAgICA8R3JpZFxyXG4gICAgICAgICAgICBjb250YWluZXJcclxuICAgICAgICAgICAgc3BhY2luZz17Mn1cclxuICAgICAgICAgICAgZGlyZWN0aW9uPVwicm93XCJcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJmbGV4LXN0YXJ0XCJcclxuICAgICAgICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgIHR5cGU9XCJzdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuc3VibWl0fVxyXG4gICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwiYmFua2FjY291bnQtc3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGRpc2FibGVkPXshaXNWYWxpZCB8fCBpc1N1Ym1pdHRpbmd9XHJcbiAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgU2F2ZVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9Gb3JtPlxyXG4gICAgICApfVxyXG4gICAgPC9TdHlsZWRGb3JtaWs+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEJhbmtBY2NvdW50Rm9ybTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9CYW5rQWNjb3VudEZvcm0udHN4In0=