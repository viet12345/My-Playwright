import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/EmptyList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Box, Typography, Grid, colors } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const { grey } = colors;
const EmptyList = ({
  entity,
  children
}) => {
  return /* @__PURE__ */ jsxDEV(
    Box,
    {
      display: "flex",
      height: 600,
      "min-height": 600,
      alignItems: "center",
      justifyContent: "center",
      border: 1,
      borderColor: grey[200],
      children: /* @__PURE__ */ jsxDEV(
        Grid,
        {
          container: true,
          direction: "column",
          justifyContent: "center",
          alignItems: "center",
          style: { height: "100%", width: "100%" },
          spacing: 2,
          children: [
            /* @__PURE__ */ jsxDEV(Grid, { item: true, "data-test": "empty-list-header", children: /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: [
              "No ",
              entity
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
              lineNumber: 29,
              columnNumber: 11
            }, this) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
              lineNumber: 28,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
              Box,
              {
                "data-test": "empty-list-children",
                display: "flex",
                width: 300,
                alignItems: "center",
                justifyContent: "center",
                children
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
                lineNumber: 34,
                columnNumber: 11
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
              lineNumber: 33,
              columnNumber: 9
            }, this)
          ]
        },
        void 0,
        true,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
          lineNumber: 20,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx",
      lineNumber: 11,
      columnNumber: 5
    },
    this
  );
};
_c = EmptyList;
export default EmptyList;
var _c;
$RefreshReg$(_c, "EmptyList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/EmptyList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJVO0FBNUJWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsS0FBS0MsWUFBWUMsTUFBTUMsY0FBYztBQUU5QyxNQUFNLEVBQUVDLEtBQUssSUFBSUQ7QUFFakIsTUFBTUUsWUFBc0VBLENBQUM7QUFBQSxFQUMzRUM7QUFBQUEsRUFDQUM7QUFDRixNQUFNO0FBQ0osU0FDRTtBQUFBLElBQUM7QUFBQTtBQUFBLE1BQ0MsU0FBUTtBQUFBLE1BQ1IsUUFBUTtBQUFBLE1BQ1IsY0FBWTtBQUFBLE1BQ1osWUFBVztBQUFBLE1BQ1gsZ0JBQWU7QUFBQSxNQUNmLFFBQVE7QUFBQSxNQUNSLGFBQWFILEtBQUssR0FBRztBQUFBLE1BRXJCO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0EsV0FBVTtBQUFBLFVBQ1YsZ0JBQWU7QUFBQSxVQUNmLFlBQVc7QUFBQSxVQUNYLE9BQU8sRUFBRUksUUFBUSxRQUFRQyxPQUFPLE9BQU87QUFBQSxVQUN2QyxTQUFTO0FBQUEsVUFFVDtBQUFBLG1DQUFDLFFBQUssTUFBSSxNQUFDLGFBQVUscUJBQ25CLGlDQUFDLGNBQVcsV0FBVSxNQUFLLFNBQVEsTUFBSyxPQUFNLFdBQVUsY0FBWSxNQUFDO0FBQUE7QUFBQSxjQUMvREg7QUFBQUEsaUJBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSUE7QUFBQSxZQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsYUFBVTtBQUFBLGdCQUNWLFNBQVE7QUFBQSxnQkFDUixPQUFPO0FBQUEsZ0JBQ1AsWUFBVztBQUFBLGdCQUNYLGdCQUFlO0FBQUEsZ0JBRWRDO0FBQUFBO0FBQUFBLGNBUEg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBUUEsS0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVVBO0FBQUE7QUFBQTtBQUFBLFFBdkJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQXdCQTtBQUFBO0FBQUEsSUFqQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBa0NBO0FBRUo7QUFBRUcsS0F6Q0lMO0FBMkNOLGVBQWVBO0FBQVUsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiQm94IiwiVHlwb2dyYXBoeSIsIkdyaWQiLCJjb2xvcnMiLCJncmV5IiwiRW1wdHlMaXN0IiwiZW50aXR5IiwiY2hpbGRyZW4iLCJoZWlnaHQiLCJ3aWR0aCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRW1wdHlMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IEJveCwgVHlwb2dyYXBoeSwgR3JpZCwgY29sb3JzIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuXHJcbmNvbnN0IHsgZ3JleSB9ID0gY29sb3JzO1xyXG5cclxuY29uc3QgRW1wdHlMaXN0OiBSZWFjdC5GQzx7IGVudGl0eTogc3RyaW5nOyBjaGlsZHJlbj86IFJlYWN0LlJlYWN0Tm9kZSB9PiA9ICh7XHJcbiAgZW50aXR5LFxyXG4gIGNoaWxkcmVuLFxyXG59KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxCb3hcclxuICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICBoZWlnaHQ9ezYwMH1cclxuICAgICAgbWluLWhlaWdodD17NjAwfVxyXG4gICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICBib3JkZXI9ezF9XHJcbiAgICAgIGJvcmRlckNvbG9yPXtncmV5WzIwMF19XHJcbiAgICA+XHJcbiAgICAgIDxHcmlkXHJcbiAgICAgICAgY29udGFpbmVyXHJcbiAgICAgICAgZGlyZWN0aW9uPVwiY29sdW1uXCJcclxuICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgc3R5bGU9e3sgaGVpZ2h0OiBcIjEwMCVcIiwgd2lkdGg6IFwiMTAwJVwiIH19XHJcbiAgICAgICAgc3BhY2luZz17Mn1cclxuICAgICAgPlxyXG4gICAgICAgIDxHcmlkIGl0ZW0gZGF0YS10ZXN0PVwiZW1wdHktbGlzdC1oZWFkZXJcIj5cclxuICAgICAgICAgIDxUeXBvZ3JhcGh5IGNvbXBvbmVudD1cImgyXCIgdmFyaWFudD1cImg2XCIgY29sb3I9XCJwcmltYXJ5XCIgZ3V0dGVyQm90dG9tPlxyXG4gICAgICAgICAgICBObyB7ZW50aXR5fVxyXG4gICAgICAgICAgPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICBkYXRhLXRlc3Q9XCJlbXB0eS1saXN0LWNoaWxkcmVuXCJcclxuICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICB3aWR0aD17MzAwfVxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvR3JpZD5cclxuICAgIDwvQm94PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBFbXB0eUxpc3Q7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvRW1wdHlMaXN0LnRzeCJ9