import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionDateRangeFilter.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const React = __vite__cjsImport3_react.__esModule ? __vite__cjsImport3_react.default : __vite__cjsImport3_react;
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { format as formatDate } from "/node_modules/.vite/deps/date-fns.js?v=6af76b79";
import { Popover, Chip, useTheme, Drawer, Button, useMediaQuery, colors } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { ArrowDropDown as ArrowDropDownIcon, Cancel as CancelIcon } from "/node_modules/.vite/deps/@mui_icons-material.js?v=6af76b79";
import InfiniteCalendar, { Calendar, withRange } from "/node_modules/.vite/deps/react-infinite-calendar.js?v=6af76b79";
import "/node_modules/react-infinite-calendar/styles.css";
import { hasDateQueryFields } from "/src/utils/transactionUtils.ts";
const PREFIX = "TransactionListDateRangeFilter";
const classes = {
  popover: `${PREFIX}-popover`
};
const Root = styled("div")(({ theme }) => ({
  [`& .${classes.popover}`]: {
    [theme.breakpoints.down("md")]: {
      top: 0,
      left: 0,
      right: 0,
      bottom: 0
    }
  }
}));
_c = Root;
const { indigo } = colors;
const CalendarWithRange = withRange(Calendar);
_c2 = CalendarWithRange;
const TransactionListDateRangeFilter = ({
  filterDateRange,
  dateRangeFilters,
  resetDateRange
}) => {
  _s();
  const theme = useTheme();
  const xsBreakpoint = useMediaQuery(theme.breakpoints.only("xs"));
  const queryHasDateFields = dateRangeFilters && hasDateQueryFields(dateRangeFilters);
  const [dateRangeAnchorEl, setDateRangeAnchorEl] = React.useState(null);
  const onCalendarSelect = (e) => {
    if (e.eventType === 3) {
      filterDateRange({
        dateRangeStart: new Date(e.start.setUTCHours(0, 0, 0, 0)).toISOString(),
        dateRangeEnd: new Date(e.end.setUTCHours(23, 59, 59, 999)).toISOString()
      });
      setDateRangeAnchorEl(null);
    }
  };
  const handleDateRangeClick = (event) => {
    setDateRangeAnchorEl(event.currentTarget);
  };
  const handleDateRangeClose = () => {
    setDateRangeAnchorEl(null);
  };
  const dateRangeOpen = Boolean(dateRangeAnchorEl);
  const dateRangeId = dateRangeOpen ? "date-range-popover" : void 0;
  const formatButtonDate = (date) => {
    return formatDate(new Date(date), "MMM, d yyyy");
  };
  const dateRangeLabel = (dateRangeFields) => {
    const { dateRangeStart, dateRangeEnd } = dateRangeFields;
    return `${formatButtonDate(dateRangeStart)} - ${formatButtonDate(dateRangeEnd)}`;
  };
  return /* @__PURE__ */ jsxDEV(Root, { children: [
    !queryHasDateFields && /* @__PURE__ */ jsxDEV(
      Chip,
      {
        color: "primary",
        variant: "outlined",
        onClick: handleDateRangeClick,
        "data-test": "transaction-list-filter-date-range-button",
        label: "Date: ALL",
        deleteIcon: /* @__PURE__ */ jsxDEV(ArrowDropDownIcon, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
          lineNumber: 88,
          columnNumber: 21
        }, this),
        onDelete: handleDateRangeClick
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
        lineNumber: 82,
        columnNumber: 7
      },
      this
    ),
    queryHasDateFields && /* @__PURE__ */ jsxDEV(
      Chip,
      {
        color: "primary",
        variant: "outlined",
        onClick: handleDateRangeClick,
        "data-test": "transaction-list-filter-date-range-button",
        label: `Date: ${dateRangeLabel(dateRangeFilters)}`,
        deleteIcon: /* @__PURE__ */ jsxDEV(CancelIcon, { "data-test": "transaction-list-filter-date-clear-button" }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
          lineNumber: 99,
          columnNumber: 21
        }, this),
        onDelete: () => {
          resetDateRange();
        }
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
        lineNumber: 93,
        columnNumber: 7
      },
      this
    ),
    !xsBreakpoint && /* @__PURE__ */ jsxDEV(
      Popover,
      {
        id: dateRangeId,
        open: dateRangeOpen,
        anchorEl: dateRangeAnchorEl,
        onClose: handleDateRangeClose,
        anchorOrigin: {
          vertical: "bottom",
          horizontal: "left"
        },
        transformOrigin: {
          vertical: "top",
          horizontal: "left"
        },
        className: classes.popover,
        children: /* @__PURE__ */ jsxDEV(
          InfiniteCalendar,
          {
            "data-test": "transaction-list-filter-date-range",
            width: xsBreakpoint ? window.innerWidth : 350,
            height: xsBreakpoint ? window.innerHeight : 300,
            rowHeight: 50,
            Component: CalendarWithRange,
            selected: false,
            onSelect: onCalendarSelect,
            locale: {
              headerFormat: "MMM Do"
            },
            theme: {
              accentColor: indigo["400"],
              headerColor: indigo["500"],
              weekdayColor: indigo["300"],
              selectionColor: indigo["300"],
              floatingNav: {
                background: indigo["400"],
                color: "#FFF",
                chevron: "#FFA726"
              }
            }
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
            lineNumber: 121,
            columnNumber: 11
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
        lineNumber: 106,
        columnNumber: 7
      },
      this
    ),
    xsBreakpoint && /* @__PURE__ */ jsxDEV(
      Drawer,
      {
        id: dateRangeId,
        open: dateRangeOpen,
        ModalProps: { onClose: handleDateRangeClose },
        anchor: "bottom",
        "data-test": "date-range-filter-drawer",
        children: [
          /* @__PURE__ */ jsxDEV(Button, { "data-test": "date-range-filter-drawer-close", onClick: () => handleDateRangeClose(), children: "Close" }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
            lineNumber: 154,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(
            InfiniteCalendar,
            {
              "data-test": "transaction-list-filter-date-range",
              width: window.innerWidth,
              height: window.innerHeight - 185,
              rowHeight: 50,
              Component: CalendarWithRange,
              selected: false,
              onSelect: onCalendarSelect,
              locale: {
                headerFormat: "MMM Do"
              },
              theme: {
                accentColor: indigo["400"],
                headerColor: indigo["500"],
                weekdayColor: indigo["300"],
                selectionColor: indigo["300"],
                floatingNav: {
                  background: indigo["400"],
                  color: "#FFF",
                  chevron: "#FFA726"
                }
              }
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
              lineNumber: 157,
              columnNumber: 11
            },
            this
          )
        ]
      },
      void 0,
      true,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
        lineNumber: 147,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx",
    lineNumber: 80,
    columnNumber: 5
  }, this);
};
_s(TransactionListDateRangeFilter, "dB/xP/dAbgkcXVJokxT0j+7d9mU=", false, function() {
  return [useTheme, useMediaQuery];
});
_c3 = TransactionListDateRangeFilter;
export default TransactionListDateRangeFilter;
var _c, _c2, _c3;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "CalendarWithRange");
$RefreshReg$(_c3, "TransactionListDateRangeFilter");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionDateRangeFilter.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUZzQjsyQkF2RnRCO0FBQWtCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0EsY0FBYztBQUN2QixTQUFTQyxVQUFVQyxrQkFBa0I7QUFDckMsU0FBU0MsU0FBU0MsTUFBTUMsVUFBVUMsUUFBUUMsUUFBUUMsZUFBZUMsY0FBYztBQUMvRSxTQUFTQyxpQkFBaUJDLG1CQUFtQkMsVUFBVUMsa0JBQWtCO0FBQ3pFLE9BQU9DLG9CQUFvQkMsVUFBVUMsaUJBQWlCO0FBRXRELE9BQU87QUFFUCxTQUFTQywwQkFBMEI7QUFFbkMsTUFBTUMsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxTQUFTLEdBQUdGLE1BQU07QUFDcEI7QUFFQSxNQUFNRyxPQUFPckIsT0FBTyxLQUFLLEVBQUUsQ0FBQyxFQUFFc0IsTUFBTSxPQUFPO0FBQUEsRUFDekMsQ0FBQyxNQUFNSCxRQUFRQyxPQUFPLEVBQUUsR0FBRztBQUFBLElBQ3pCLENBQUNFLE1BQU1DLFlBQVlDLEtBQUssSUFBSSxDQUFDLEdBQUc7QUFBQSxNQUM5QkMsS0FBSztBQUFBLE1BQ0xDLE1BQU07QUFBQSxNQUNOQyxPQUFPO0FBQUEsTUFDUEMsUUFBUTtBQUFBLElBQ1Y7QUFBQSxFQUNGO0FBQ0YsRUFBRTtBQUFFQyxLQVRFUjtBQVdOLE1BQU0sRUFBRVMsT0FBTyxJQUFJckI7QUFDbkIsTUFBTXNCLG9CQUFvQmYsVUFBVUQsUUFBUTtBQUFFaUIsTUFBeENEO0FBUU4sTUFBTUUsaUNBQWdGQSxDQUFDO0FBQUEsRUFDckZDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTWYsUUFBUWpCLFNBQVM7QUFDdkIsUUFBTWlDLGVBQWU5QixjQUFjYyxNQUFNQyxZQUFZZ0IsS0FBSyxJQUFJLENBQUM7QUFDL0QsUUFBTUMscUJBQXFCTCxvQkFBb0JsQixtQkFBbUJrQixnQkFBZ0I7QUFFbEYsUUFBTSxDQUFDTSxtQkFBbUJDLG9CQUFvQixJQUFJQyxNQUFNQyxTQUFnQyxJQUFJO0FBRTVGLFFBQU1DLG1CQUFtQkEsQ0FBQ0MsTUFBbUQ7QUFDM0UsUUFBSUEsRUFBRUMsY0FBYyxHQUFHO0FBQ3JCYixzQkFBZ0I7QUFBQSxRQUNkYyxnQkFBZ0IsSUFBSUMsS0FBS0gsRUFBRUksTUFBTUMsWUFBWSxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUMsRUFBRUMsWUFBWTtBQUFBLFFBQ3RFQyxjQUFjLElBQUlKLEtBQUtILEVBQUVRLElBQUlILFlBQVksSUFBSSxJQUFJLElBQUksR0FBRyxDQUFDLEVBQUVDLFlBQVk7QUFBQSxNQUN6RSxDQUFDO0FBQ0RWLDJCQUFxQixJQUFJO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBRUEsUUFBTWEsdUJBQXVCQSxDQUFDQyxVQUE0QztBQUN4RWQseUJBQXFCYyxNQUFNQyxhQUFhO0FBQUEsRUFDMUM7QUFFQSxRQUFNQyx1QkFBdUJBLE1BQU07QUFDakNoQix5QkFBcUIsSUFBSTtBQUFBLEVBQzNCO0FBRUEsUUFBTWlCLGdCQUFnQkMsUUFBUW5CLGlCQUFpQjtBQUMvQyxRQUFNb0IsY0FBY0YsZ0JBQWdCLHVCQUF1Qkc7QUFFM0QsUUFBTUMsbUJBQW1CQSxDQUFDQyxTQUFpQjtBQUN6QyxXQUFPOUQsV0FBVyxJQUFJK0MsS0FBS2UsSUFBSSxHQUFHLGFBQWE7QUFBQSxFQUNqRDtBQUVBLFFBQU1DLGlCQUFpQkEsQ0FBQ0Msb0JBQWlEO0FBQ3ZFLFVBQU0sRUFBRWxCLGdCQUFnQkssYUFBYSxJQUFJYTtBQUN6QyxXQUFPLEdBQUdILGlCQUFpQmYsY0FBZSxDQUFDLE1BQU1lLGlCQUFpQlYsWUFBYSxDQUFDO0FBQUEsRUFDbEY7QUFFQSxTQUNFLHVCQUFDLFFBQ0U7QUFBQSxLQUFDYixzQkFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sU0FBUTtBQUFBLFFBQ1IsU0FBU2U7QUFBQUEsUUFDVCxhQUFVO0FBQUEsUUFDVixPQUFPO0FBQUEsUUFDUCxZQUFZLHVCQUFDLHVCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBa0I7QUFBQSxRQUM5QixVQUFVQTtBQUFBQTtBQUFBQSxNQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQU9pQztBQUFBLElBR2xDZixzQkFDQztBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsT0FBTTtBQUFBLFFBQ04sU0FBUTtBQUFBLFFBQ1IsU0FBU2U7QUFBQUEsUUFDVCxhQUFVO0FBQUEsUUFDVixPQUFPLFNBQVNVLGVBQWU5QixnQkFBZ0IsQ0FBQztBQUFBLFFBQ2hELFlBQVksdUJBQUMsY0FBVyxhQUFVLCtDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlFO0FBQUEsUUFDN0UsVUFBVSxNQUFNO0FBQ2RDLHlCQUFlO0FBQUEsUUFDakI7QUFBQTtBQUFBLE1BVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBU0k7QUFBQSxJQUdMLENBQUNFLGdCQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxJQUFJdUI7QUFBQUEsUUFDSixNQUFNRjtBQUFBQSxRQUNOLFVBQVVsQjtBQUFBQSxRQUNWLFNBQVNpQjtBQUFBQSxRQUNULGNBQWM7QUFBQSxVQUNaUyxVQUFVO0FBQUEsVUFDVkMsWUFBWTtBQUFBLFFBQ2Q7QUFBQSxRQUNBLGlCQUFpQjtBQUFBLFVBQ2ZELFVBQVU7QUFBQSxVQUNWQyxZQUFZO0FBQUEsUUFDZDtBQUFBLFFBQ0EsV0FBV2pELFFBQVFDO0FBQUFBLFFBRW5CO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxhQUFVO0FBQUEsWUFDVixPQUFPa0IsZUFBZStCLE9BQU9DLGFBQWE7QUFBQSxZQUMxQyxRQUFRaEMsZUFBZStCLE9BQU9FLGNBQWM7QUFBQSxZQUM1QyxXQUFXO0FBQUEsWUFDWCxXQUFXeEM7QUFBQUEsWUFDWCxVQUFVO0FBQUEsWUFDVixVQUFVYztBQUFBQSxZQUNWLFFBQVE7QUFBQSxjQUNOMkIsY0FBYztBQUFBLFlBQ2hCO0FBQUEsWUFDQSxPQUFPO0FBQUEsY0FDTEMsYUFBYTNDLE9BQU8sS0FBSztBQUFBLGNBQ3pCNEMsYUFBYTVDLE9BQU8sS0FBSztBQUFBLGNBQ3pCNkMsY0FBYzdDLE9BQU8sS0FBSztBQUFBLGNBQzFCOEMsZ0JBQWdCOUMsT0FBTyxLQUFLO0FBQUEsY0FDNUIrQyxhQUFhO0FBQUEsZ0JBQ1hDLFlBQVloRCxPQUFPLEtBQUs7QUFBQSxnQkFDeEJpRCxPQUFPO0FBQUEsZ0JBQ1BDLFNBQVM7QUFBQSxjQUNYO0FBQUEsWUFDRjtBQUFBO0FBQUEsVUFyQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBcUJJO0FBQUE7QUFBQSxNQXBDTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFzQ0E7QUFBQSxJQUVEMUMsZ0JBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLElBQUl1QjtBQUFBQSxRQUNKLE1BQU1GO0FBQUFBLFFBQ04sWUFBWSxFQUFFc0IsU0FBU3ZCLHFCQUFxQjtBQUFBLFFBQzVDLFFBQU87QUFBQSxRQUNQLGFBQVU7QUFBQSxRQUVWO0FBQUEsaUNBQUMsVUFBTyxhQUFVLGtDQUFpQyxTQUFTLE1BQU1BLHFCQUFxQixHQUFHLHFCQUExRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsVUFDQTtBQUFBLFlBQUM7QUFBQTtBQUFBLGNBQ0MsYUFBVTtBQUFBLGNBQ1YsT0FBT1csT0FBT0M7QUFBQUEsY0FDZCxRQUFRRCxPQUFPRSxjQUFjO0FBQUEsY0FDN0IsV0FBVztBQUFBLGNBQ1gsV0FBV3hDO0FBQUFBLGNBQ1gsVUFBVTtBQUFBLGNBQ1YsVUFBVWM7QUFBQUEsY0FDVixRQUFRO0FBQUEsZ0JBQ04yQixjQUFjO0FBQUEsY0FDaEI7QUFBQSxjQUNBLE9BQU87QUFBQSxnQkFDTEMsYUFBYTNDLE9BQU8sS0FBSztBQUFBLGdCQUN6QjRDLGFBQWE1QyxPQUFPLEtBQUs7QUFBQSxnQkFDekI2QyxjQUFjN0MsT0FBTyxLQUFLO0FBQUEsZ0JBQzFCOEMsZ0JBQWdCOUMsT0FBTyxLQUFLO0FBQUEsZ0JBQzVCK0MsYUFBYTtBQUFBLGtCQUNYQyxZQUFZaEQsT0FBTyxLQUFLO0FBQUEsa0JBQ3hCaUQsT0FBTztBQUFBLGtCQUNQQyxTQUFTO0FBQUEsZ0JBQ1g7QUFBQSxjQUNGO0FBQUE7QUFBQSxZQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFxQkk7QUFBQTtBQUFBO0FBQUEsTUEvQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBaUNBO0FBQUEsT0FwR0o7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXNHQTtBQUVKO0FBQUUzQyxHQWxKSUosZ0NBQTZFO0FBQUEsVUFLbkU1QixVQUNPRyxhQUFhO0FBQUE7QUFBQTBFLE1BTjlCakQ7QUFvSk4sZUFBZUE7QUFBK0IsSUFBQUosSUFBQUcsS0FBQWtEO0FBQUFDLGFBQUF0RCxJQUFBO0FBQUFzRCxhQUFBbkQsS0FBQTtBQUFBbUQsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlZCIsImZvcm1hdCIsImZvcm1hdERhdGUiLCJQb3BvdmVyIiwiQ2hpcCIsInVzZVRoZW1lIiwiRHJhd2VyIiwiQnV0dG9uIiwidXNlTWVkaWFRdWVyeSIsImNvbG9ycyIsIkFycm93RHJvcERvd24iLCJBcnJvd0Ryb3BEb3duSWNvbiIsIkNhbmNlbCIsIkNhbmNlbEljb24iLCJJbmZpbml0ZUNhbGVuZGFyIiwiQ2FsZW5kYXIiLCJ3aXRoUmFuZ2UiLCJoYXNEYXRlUXVlcnlGaWVsZHMiLCJQUkVGSVgiLCJjbGFzc2VzIiwicG9wb3ZlciIsIlJvb3QiLCJ0aGVtZSIsImJyZWFrcG9pbnRzIiwiZG93biIsInRvcCIsImxlZnQiLCJyaWdodCIsImJvdHRvbSIsIl9jIiwiaW5kaWdvIiwiQ2FsZW5kYXJXaXRoUmFuZ2UiLCJfYzIiLCJUcmFuc2FjdGlvbkxpc3REYXRlUmFuZ2VGaWx0ZXIiLCJmaWx0ZXJEYXRlUmFuZ2UiLCJkYXRlUmFuZ2VGaWx0ZXJzIiwicmVzZXREYXRlUmFuZ2UiLCJfcyIsInhzQnJlYWtwb2ludCIsIm9ubHkiLCJxdWVyeUhhc0RhdGVGaWVsZHMiLCJkYXRlUmFuZ2VBbmNob3JFbCIsInNldERhdGVSYW5nZUFuY2hvckVsIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsIm9uQ2FsZW5kYXJTZWxlY3QiLCJlIiwiZXZlbnRUeXBlIiwiZGF0ZVJhbmdlU3RhcnQiLCJEYXRlIiwic3RhcnQiLCJzZXRVVENIb3VycyIsInRvSVNPU3RyaW5nIiwiZGF0ZVJhbmdlRW5kIiwiZW5kIiwiaGFuZGxlRGF0ZVJhbmdlQ2xpY2siLCJldmVudCIsImN1cnJlbnRUYXJnZXQiLCJoYW5kbGVEYXRlUmFuZ2VDbG9zZSIsImRhdGVSYW5nZU9wZW4iLCJCb29sZWFuIiwiZGF0ZVJhbmdlSWQiLCJ1bmRlZmluZWQiLCJmb3JtYXRCdXR0b25EYXRlIiwiZGF0ZSIsImRhdGVSYW5nZUxhYmVsIiwiZGF0ZVJhbmdlRmllbGRzIiwidmVydGljYWwiLCJob3Jpem9udGFsIiwid2luZG93IiwiaW5uZXJXaWR0aCIsImlubmVySGVpZ2h0IiwiaGVhZGVyRm9ybWF0IiwiYWNjZW50Q29sb3IiLCJoZWFkZXJDb2xvciIsIndlZWtkYXlDb2xvciIsInNlbGVjdGlvbkNvbG9yIiwiZmxvYXRpbmdOYXYiLCJiYWNrZ3JvdW5kIiwiY29sb3IiLCJjaGV2cm9uIiwib25DbG9zZSIsIl9jMyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlRyYW5zYWN0aW9uRGF0ZVJhbmdlRmlsdGVyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHN0eWxlZCB9IGZyb20gXCJAbXVpL21hdGVyaWFsL3N0eWxlc1wiO1xyXG5pbXBvcnQgeyBmb3JtYXQgYXMgZm9ybWF0RGF0ZSB9IGZyb20gXCJkYXRlLWZuc1wiO1xyXG5pbXBvcnQgeyBQb3BvdmVyLCBDaGlwLCB1c2VUaGVtZSwgRHJhd2VyLCBCdXR0b24sIHVzZU1lZGlhUXVlcnksIGNvbG9ycyB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7IEFycm93RHJvcERvd24gYXMgQXJyb3dEcm9wRG93bkljb24sIENhbmNlbCBhcyBDYW5jZWxJY29uIH0gZnJvbSBcIkBtdWkvaWNvbnMtbWF0ZXJpYWxcIjtcclxuaW1wb3J0IEluZmluaXRlQ2FsZW5kYXIsIHsgQ2FsZW5kYXIsIHdpdGhSYW5nZSB9IGZyb20gXCJyZWFjdC1pbmZpbml0ZS1jYWxlbmRhclwiO1xyXG5cclxuaW1wb3J0IFwicmVhY3QtaW5maW5pdGUtY2FsZW5kYXIvc3R5bGVzLmNzc1wiO1xyXG5pbXBvcnQgeyBUcmFuc2FjdGlvbkRhdGVSYW5nZVBheWxvYWQgfSBmcm9tIFwiLi4vbW9kZWxzXCI7XHJcbmltcG9ydCB7IGhhc0RhdGVRdWVyeUZpZWxkcyB9IGZyb20gXCIuLi91dGlscy90cmFuc2FjdGlvblV0aWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uTGlzdERhdGVSYW5nZUZpbHRlclwiO1xyXG5cclxuY29uc3QgY2xhc3NlcyA9IHtcclxuICBwb3BvdmVyOiBgJHtQUkVGSVh9LXBvcG92ZXJgLFxyXG59O1xyXG5cclxuY29uc3QgUm9vdCA9IHN0eWxlZChcImRpdlwiKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJiAuJHtjbGFzc2VzLnBvcG92ZXJ9YF06IHtcclxuICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKFwibWRcIildOiB7XHJcbiAgICAgIHRvcDogMCxcclxuICAgICAgbGVmdDogMCxcclxuICAgICAgcmlnaHQ6IDAsXHJcbiAgICAgIGJvdHRvbTogMCxcclxuICAgIH0sXHJcbiAgfSxcclxufSkpO1xyXG5cclxuY29uc3QgeyBpbmRpZ28gfSA9IGNvbG9ycztcclxuY29uc3QgQ2FsZW5kYXJXaXRoUmFuZ2UgPSB3aXRoUmFuZ2UoQ2FsZW5kYXIpO1xyXG5cclxuZXhwb3J0IHR5cGUgVHJhbnNhY3Rpb25MaXN0RGF0ZVJhbmdlRmlsdGVyUHJvcHMgPSB7XHJcbiAgZmlsdGVyRGF0ZVJhbmdlOiBGdW5jdGlvbjtcclxuICBkYXRlUmFuZ2VGaWx0ZXJzOiBUcmFuc2FjdGlvbkRhdGVSYW5nZVBheWxvYWQ7XHJcbiAgcmVzZXREYXRlUmFuZ2U6IEZ1bmN0aW9uO1xyXG59O1xyXG5cclxuY29uc3QgVHJhbnNhY3Rpb25MaXN0RGF0ZVJhbmdlRmlsdGVyOiBSZWFjdC5GQzxUcmFuc2FjdGlvbkxpc3REYXRlUmFuZ2VGaWx0ZXJQcm9wcz4gPSAoe1xyXG4gIGZpbHRlckRhdGVSYW5nZSxcclxuICBkYXRlUmFuZ2VGaWx0ZXJzLFxyXG4gIHJlc2V0RGF0ZVJhbmdlLFxyXG59KSA9PiB7XHJcbiAgY29uc3QgdGhlbWUgPSB1c2VUaGVtZSgpO1xyXG4gIGNvbnN0IHhzQnJlYWtwb2ludCA9IHVzZU1lZGlhUXVlcnkodGhlbWUuYnJlYWtwb2ludHMub25seShcInhzXCIpKTtcclxuICBjb25zdCBxdWVyeUhhc0RhdGVGaWVsZHMgPSBkYXRlUmFuZ2VGaWx0ZXJzICYmIGhhc0RhdGVRdWVyeUZpZWxkcyhkYXRlUmFuZ2VGaWx0ZXJzKTtcclxuXHJcbiAgY29uc3QgW2RhdGVSYW5nZUFuY2hvckVsLCBzZXREYXRlUmFuZ2VBbmNob3JFbF0gPSBSZWFjdC51c2VTdGF0ZTxIVE1MRGl2RWxlbWVudCB8IG51bGw+KG51bGwpO1xyXG5cclxuICBjb25zdCBvbkNhbGVuZGFyU2VsZWN0ID0gKGU6IHsgZXZlbnRUeXBlOiBudW1iZXI7IHN0YXJ0OiBhbnk7IGVuZDogYW55IH0pID0+IHtcclxuICAgIGlmIChlLmV2ZW50VHlwZSA9PT0gMykge1xyXG4gICAgICBmaWx0ZXJEYXRlUmFuZ2Uoe1xyXG4gICAgICAgIGRhdGVSYW5nZVN0YXJ0OiBuZXcgRGF0ZShlLnN0YXJ0LnNldFVUQ0hvdXJzKDAsIDAsIDAsIDApKS50b0lTT1N0cmluZygpLFxyXG4gICAgICAgIGRhdGVSYW5nZUVuZDogbmV3IERhdGUoZS5lbmQuc2V0VVRDSG91cnMoMjMsIDU5LCA1OSwgOTk5KSkudG9JU09TdHJpbmcoKSxcclxuICAgICAgfSk7XHJcbiAgICAgIHNldERhdGVSYW5nZUFuY2hvckVsKG51bGwpO1xyXG4gICAgfVxyXG4gIH07XHJcblxyXG4gIGNvbnN0IGhhbmRsZURhdGVSYW5nZUNsaWNrID0gKGV2ZW50OiBSZWFjdC5Nb3VzZUV2ZW50PEhUTUxEaXZFbGVtZW50PikgPT4ge1xyXG4gICAgc2V0RGF0ZVJhbmdlQW5jaG9yRWwoZXZlbnQuY3VycmVudFRhcmdldCk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3QgaGFuZGxlRGF0ZVJhbmdlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICBzZXREYXRlUmFuZ2VBbmNob3JFbChudWxsKTtcclxuICB9O1xyXG5cclxuICBjb25zdCBkYXRlUmFuZ2VPcGVuID0gQm9vbGVhbihkYXRlUmFuZ2VBbmNob3JFbCk7XHJcbiAgY29uc3QgZGF0ZVJhbmdlSWQgPSBkYXRlUmFuZ2VPcGVuID8gXCJkYXRlLXJhbmdlLXBvcG92ZXJcIiA6IHVuZGVmaW5lZDtcclxuXHJcbiAgY29uc3QgZm9ybWF0QnV0dG9uRGF0ZSA9IChkYXRlOiBzdHJpbmcpID0+IHtcclxuICAgIHJldHVybiBmb3JtYXREYXRlKG5ldyBEYXRlKGRhdGUpLCBcIk1NTSwgZCB5eXl5XCIpO1xyXG4gIH07XHJcblxyXG4gIGNvbnN0IGRhdGVSYW5nZUxhYmVsID0gKGRhdGVSYW5nZUZpZWxkczogVHJhbnNhY3Rpb25EYXRlUmFuZ2VQYXlsb2FkKSA9PiB7XHJcbiAgICBjb25zdCB7IGRhdGVSYW5nZVN0YXJ0LCBkYXRlUmFuZ2VFbmQgfSA9IGRhdGVSYW5nZUZpZWxkcztcclxuICAgIHJldHVybiBgJHtmb3JtYXRCdXR0b25EYXRlKGRhdGVSYW5nZVN0YXJ0ISl9IC0gJHtmb3JtYXRCdXR0b25EYXRlKGRhdGVSYW5nZUVuZCEpfWA7XHJcbiAgfTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxSb290PlxyXG4gICAgICB7IXF1ZXJ5SGFzRGF0ZUZpZWxkcyAmJiAoXHJcbiAgICAgICAgPENoaXBcclxuICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlRGF0ZVJhbmdlQ2xpY2t9XHJcbiAgICAgICAgICBkYXRhLXRlc3Q9XCJ0cmFuc2FjdGlvbi1saXN0LWZpbHRlci1kYXRlLXJhbmdlLWJ1dHRvblwiXHJcbiAgICAgICAgICBsYWJlbD17XCJEYXRlOiBBTExcIn1cclxuICAgICAgICAgIGRlbGV0ZUljb249ezxBcnJvd0Ryb3BEb3duSWNvbiAvPn1cclxuICAgICAgICAgIG9uRGVsZXRlPXtoYW5kbGVEYXRlUmFuZ2VDbGlja31cclxuICAgICAgICAvPlxyXG4gICAgICApfVxyXG4gICAgICB7cXVlcnlIYXNEYXRlRmllbGRzICYmIChcclxuICAgICAgICA8Q2hpcFxyXG4gICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICBvbkNsaWNrPXtoYW5kbGVEYXRlUmFuZ2VDbGlja31cclxuICAgICAgICAgIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWxpc3QtZmlsdGVyLWRhdGUtcmFuZ2UtYnV0dG9uXCJcclxuICAgICAgICAgIGxhYmVsPXtgRGF0ZTogJHtkYXRlUmFuZ2VMYWJlbChkYXRlUmFuZ2VGaWx0ZXJzKX1gfVxyXG4gICAgICAgICAgZGVsZXRlSWNvbj17PENhbmNlbEljb24gZGF0YS10ZXN0PVwidHJhbnNhY3Rpb24tbGlzdC1maWx0ZXItZGF0ZS1jbGVhci1idXR0b25cIiAvPn1cclxuICAgICAgICAgIG9uRGVsZXRlPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHJlc2V0RGF0ZVJhbmdlKCk7XHJcbiAgICAgICAgICB9fVxyXG4gICAgICAgIC8+XHJcbiAgICAgICl9XHJcbiAgICAgIHsheHNCcmVha3BvaW50ICYmIChcclxuICAgICAgICA8UG9wb3ZlclxyXG4gICAgICAgICAgaWQ9e2RhdGVSYW5nZUlkfVxyXG4gICAgICAgICAgb3Blbj17ZGF0ZVJhbmdlT3Blbn1cclxuICAgICAgICAgIGFuY2hvckVsPXtkYXRlUmFuZ2VBbmNob3JFbH1cclxuICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZURhdGVSYW5nZUNsb3NlfVxyXG4gICAgICAgICAgYW5jaG9yT3JpZ2luPXt7XHJcbiAgICAgICAgICAgIHZlcnRpY2FsOiBcImJvdHRvbVwiLFxyXG4gICAgICAgICAgICBob3Jpem9udGFsOiBcImxlZnRcIixcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgICB0cmFuc2Zvcm1PcmlnaW49e3tcclxuICAgICAgICAgICAgdmVydGljYWw6IFwidG9wXCIsXHJcbiAgICAgICAgICAgIGhvcml6b250YWw6IFwibGVmdFwiLFxyXG4gICAgICAgICAgfX1cclxuICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5wb3BvdmVyfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxJbmZpbml0ZUNhbGVuZGFyXHJcbiAgICAgICAgICAgIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWxpc3QtZmlsdGVyLWRhdGUtcmFuZ2VcIlxyXG4gICAgICAgICAgICB3aWR0aD17eHNCcmVha3BvaW50ID8gd2luZG93LmlubmVyV2lkdGggOiAzNTB9XHJcbiAgICAgICAgICAgIGhlaWdodD17eHNCcmVha3BvaW50ID8gd2luZG93LmlubmVySGVpZ2h0IDogMzAwfVxyXG4gICAgICAgICAgICByb3dIZWlnaHQ9ezUwfVxyXG4gICAgICAgICAgICBDb21wb25lbnQ9e0NhbGVuZGFyV2l0aFJhbmdlfVxyXG4gICAgICAgICAgICBzZWxlY3RlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgIG9uU2VsZWN0PXtvbkNhbGVuZGFyU2VsZWN0fVxyXG4gICAgICAgICAgICBsb2NhbGU9e3tcclxuICAgICAgICAgICAgICBoZWFkZXJGb3JtYXQ6IFwiTU1NIERvXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHRoZW1lPXt7XHJcbiAgICAgICAgICAgICAgYWNjZW50Q29sb3I6IGluZGlnb1tcIjQwMFwiXSxcclxuICAgICAgICAgICAgICBoZWFkZXJDb2xvcjogaW5kaWdvW1wiNTAwXCJdLFxyXG4gICAgICAgICAgICAgIHdlZWtkYXlDb2xvcjogaW5kaWdvW1wiMzAwXCJdLFxyXG4gICAgICAgICAgICAgIHNlbGVjdGlvbkNvbG9yOiBpbmRpZ29bXCIzMDBcIl0sXHJcbiAgICAgICAgICAgICAgZmxvYXRpbmdOYXY6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGluZGlnb1tcIjQwMFwiXSxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNGRkZcIixcclxuICAgICAgICAgICAgICAgIGNoZXZyb246IFwiI0ZGQTcyNlwiLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvUG9wb3Zlcj5cclxuICAgICAgKX1cclxuICAgICAge3hzQnJlYWtwb2ludCAmJiAoXHJcbiAgICAgICAgPERyYXdlclxyXG4gICAgICAgICAgaWQ9e2RhdGVSYW5nZUlkfVxyXG4gICAgICAgICAgb3Blbj17ZGF0ZVJhbmdlT3Blbn1cclxuICAgICAgICAgIE1vZGFsUHJvcHM9e3sgb25DbG9zZTogaGFuZGxlRGF0ZVJhbmdlQ2xvc2UgfX1cclxuICAgICAgICAgIGFuY2hvcj1cImJvdHRvbVwiXHJcbiAgICAgICAgICBkYXRhLXRlc3Q9XCJkYXRlLXJhbmdlLWZpbHRlci1kcmF3ZXJcIlxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxCdXR0b24gZGF0YS10ZXN0PVwiZGF0ZS1yYW5nZS1maWx0ZXItZHJhd2VyLWNsb3NlXCIgb25DbGljaz17KCkgPT4gaGFuZGxlRGF0ZVJhbmdlQ2xvc2UoKX0+XHJcbiAgICAgICAgICAgIENsb3NlXHJcbiAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDxJbmZpbml0ZUNhbGVuZGFyXHJcbiAgICAgICAgICAgIGRhdGEtdGVzdD1cInRyYW5zYWN0aW9uLWxpc3QtZmlsdGVyLWRhdGUtcmFuZ2VcIlxyXG4gICAgICAgICAgICB3aWR0aD17d2luZG93LmlubmVyV2lkdGh9XHJcbiAgICAgICAgICAgIGhlaWdodD17d2luZG93LmlubmVySGVpZ2h0IC0gMTg1fVxyXG4gICAgICAgICAgICByb3dIZWlnaHQ9ezUwfVxyXG4gICAgICAgICAgICBDb21wb25lbnQ9e0NhbGVuZGFyV2l0aFJhbmdlfVxyXG4gICAgICAgICAgICBzZWxlY3RlZD17ZmFsc2V9XHJcbiAgICAgICAgICAgIG9uU2VsZWN0PXtvbkNhbGVuZGFyU2VsZWN0fVxyXG4gICAgICAgICAgICBsb2NhbGU9e3tcclxuICAgICAgICAgICAgICBoZWFkZXJGb3JtYXQ6IFwiTU1NIERvXCIsXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgIHRoZW1lPXt7XHJcbiAgICAgICAgICAgICAgYWNjZW50Q29sb3I6IGluZGlnb1tcIjQwMFwiXSxcclxuICAgICAgICAgICAgICBoZWFkZXJDb2xvcjogaW5kaWdvW1wiNTAwXCJdLFxyXG4gICAgICAgICAgICAgIHdlZWtkYXlDb2xvcjogaW5kaWdvW1wiMzAwXCJdLFxyXG4gICAgICAgICAgICAgIHNlbGVjdGlvbkNvbG9yOiBpbmRpZ29bXCIzMDBcIl0sXHJcbiAgICAgICAgICAgICAgZmxvYXRpbmdOYXY6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IGluZGlnb1tcIjQwMFwiXSxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNGRkZcIixcclxuICAgICAgICAgICAgICAgIGNoZXZyb246IFwiI0ZGQTcyNlwiLFxyXG4gICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgIDwvRHJhd2VyPlxyXG4gICAgICApfVxyXG4gICAgPC9Sb290PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvbkxpc3REYXRlUmFuZ2VGaWx0ZXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvVHJhbnNhY3Rpb25EYXRlUmFuZ2VGaWx0ZXIudHN4In0=