import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserListItem.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { ListItem, ListItemText, ListItemAvatar, Avatar, Grid } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const UserListItem = ({ user, setReceiver, index }) => {
  return /* @__PURE__ */ jsxDEV(ListItem, { "data-test": `user-list-item-${user.id}`, onClick: () => setReceiver(user), children: [
    /* @__PURE__ */ jsxDEV(ListItemAvatar, { children: /* @__PURE__ */ jsxDEV(Avatar, { src: user.avatar }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
      lineNumber: 16,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(
      ListItemText,
      {
        primary: `${user.firstName} ${user.lastName}`,
        secondary: /* @__PURE__ */ jsxDEV("span", { children: /* @__PURE__ */ jsxDEV(
          Grid,
          {
            component: "span",
            container: true,
            direction: "row",
            justifyContent: "flex-start",
            alignItems: "flex-start",
            spacing: 1,
            children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, component: "span", children: [
                /* @__PURE__ */ jsxDEV("b", { children: "U: " }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                  lineNumber: 31,
                  columnNumber: 17
                }, this),
                user.username
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                lineNumber: 30,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, component: "span", children: "•" }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                lineNumber: 34,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, component: "span", children: [
                /* @__PURE__ */ jsxDEV("b", { children: "E: " }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                  lineNumber: 38,
                  columnNumber: 17
                }, this),
                user.email
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                lineNumber: 37,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, component: "span", children: "•" }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                lineNumber: 41,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, component: "span", children: [
                /* @__PURE__ */ jsxDEV("b", { children: "P: " }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                  lineNumber: 45,
                  columnNumber: 17
                }, this),
                user.phoneNumber
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
                lineNumber: 44,
                columnNumber: 15
              }, this)
            ]
          },
          void 0,
          true,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
            lineNumber: 22,
            columnNumber: 13
          },
          this
        ) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
          lineNumber: 21,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
        lineNumber: 18,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
};
_c = UserListItem;
export default UserListItem;
var _c;
$RefreshReg$(_c, "UserListItem");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UserListItem.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZVE7QUFmUixPQUFPQSxvQkFBa0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNDLFVBQVVDLGNBQWNDLGdCQUFnQkMsUUFBUUMsWUFBWTtBQVVyRSxNQUFNQyxlQUE0Q0EsQ0FBQyxFQUFFQyxNQUFNQyxhQUFhQyxNQUFNLE1BQU07QUFDbEYsU0FDRSx1QkFBQyxZQUFTLGFBQVcsa0JBQWtCRixLQUFLRyxFQUFFLElBQUksU0FBUyxNQUFNRixZQUFZRCxJQUFJLEdBQy9FO0FBQUEsMkJBQUMsa0JBQ0MsaUNBQUMsVUFBTyxLQUFLQSxLQUFLSSxVQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXlCLEtBRDNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLElBQ0E7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDLFNBQVMsR0FBR0osS0FBS0ssU0FBUyxJQUFJTCxLQUFLTSxRQUFRO0FBQUEsUUFDM0MsV0FDRSx1QkFBQyxVQUNDO0FBQUEsVUFBQztBQUFBO0FBQUEsWUFDQyxXQUFXO0FBQUEsWUFDWDtBQUFBLFlBQ0EsV0FBVTtBQUFBLFlBQ1YsZ0JBQWU7QUFBQSxZQUNmLFlBQVc7QUFBQSxZQUNYLFNBQVM7QUFBQSxZQUVUO0FBQUEscUNBQUMsUUFBSyxNQUFJLE1BQUMsV0FBVyxRQUNwQjtBQUFBLHVDQUFDLE9BQUUsbUJBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBTTtBQUFBLGdCQUNMTixLQUFLTztBQUFBQSxtQkFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUdBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLE1BQUksTUFBQyxXQUFXLFFBQVEsaUJBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSSxNQUFDLFdBQVcsUUFDcEI7QUFBQSx1Q0FBQyxPQUFFLG1CQUFIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBQU07QUFBQSxnQkFDTFAsS0FBS1E7QUFBQUEsbUJBRlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFHQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQUMsV0FBVyxRQUFRLGlCQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUVBO0FBQUEsY0FDQSx1QkFBQyxRQUFLLE1BQUksTUFBQyxXQUFXLFFBQ3BCO0FBQUEsdUNBQUMsT0FBRSxtQkFBSDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUFNO0FBQUEsZ0JBQ0xSLEtBQUtTO0FBQUFBLG1CQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBR0E7QUFBQTtBQUFBO0FBQUEsVUF6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBMEJBLEtBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUE0QkE7QUFBQTtBQUFBLE1BL0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWdDRztBQUFBLE9BcENMO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFFQyxLQTFDSVg7QUE0Q04sZUFBZUE7QUFBYSxJQUFBVztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJMaXN0SXRlbSIsIkxpc3RJdGVtVGV4dCIsIkxpc3RJdGVtQXZhdGFyIiwiQXZhdGFyIiwiR3JpZCIsIlVzZXJMaXN0SXRlbSIsInVzZXIiLCJzZXRSZWNlaXZlciIsImluZGV4IiwiaWQiLCJhdmF0YXIiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsInVzZXJuYW1lIiwiZW1haWwiLCJwaG9uZU51bWJlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlckxpc3RJdGVtLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpc3RJdGVtLCBMaXN0SXRlbVRleHQsIExpc3RJdGVtQXZhdGFyLCBBdmF0YXIsIEdyaWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVXNlckxpc3RJdGVtUHJvcHMge1xyXG4gIHVzZXI6IFVzZXI7XHJcbiAgc2V0UmVjZWl2ZXI6IEZ1bmN0aW9uO1xyXG4gIGluZGV4OiBOdW1iZXI7XHJcbn1cclxuXHJcbmNvbnN0IFVzZXJMaXN0SXRlbTogUmVhY3QuRkM8VXNlckxpc3RJdGVtUHJvcHM+ID0gKHsgdXNlciwgc2V0UmVjZWl2ZXIsIGluZGV4IH0pID0+IHtcclxuICByZXR1cm4gKFxyXG4gICAgPExpc3RJdGVtIGRhdGEtdGVzdD17YHVzZXItbGlzdC1pdGVtLSR7dXNlci5pZH1gfSBvbkNsaWNrPXsoKSA9PiBzZXRSZWNlaXZlcih1c2VyKX0+XHJcbiAgICAgIDxMaXN0SXRlbUF2YXRhcj5cclxuICAgICAgICA8QXZhdGFyIHNyYz17dXNlci5hdmF0YXJ9IC8+XHJcbiAgICAgIDwvTGlzdEl0ZW1BdmF0YXI+XHJcbiAgICAgIDxMaXN0SXRlbVRleHRcclxuICAgICAgICBwcmltYXJ5PXtgJHt1c2VyLmZpcnN0TmFtZX0gJHt1c2VyLmxhc3ROYW1lfWB9XHJcbiAgICAgICAgc2Vjb25kYXJ5PXtcclxuICAgICAgICAgIDxzcGFuPlxyXG4gICAgICAgICAgICA8R3JpZFxyXG4gICAgICAgICAgICAgIGNvbXBvbmVudD17XCJzcGFuXCJ9XHJcbiAgICAgICAgICAgICAgY29udGFpbmVyXHJcbiAgICAgICAgICAgICAgZGlyZWN0aW9uPVwicm93XCJcclxuICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJmbGV4LXN0YXJ0XCJcclxuICAgICAgICAgICAgICBzcGFjaW5nPXsxfVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgPEdyaWQgaXRlbSBjb21wb25lbnQ9e1wic3BhblwifT5cclxuICAgICAgICAgICAgICAgIDxiPlU6IDwvYj5cclxuICAgICAgICAgICAgICAgIHt1c2VyLnVzZXJuYW1lfVxyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICA8R3JpZCBpdGVtIGNvbXBvbmVudD17XCJzcGFuXCJ9PlxyXG4gICAgICAgICAgICAgICAgJmJ1bGw7XHJcbiAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgIDxHcmlkIGl0ZW0gY29tcG9uZW50PXtcInNwYW5cIn0+XHJcbiAgICAgICAgICAgICAgICA8Yj5FOiA8L2I+XHJcbiAgICAgICAgICAgICAgICB7dXNlci5lbWFpbH1cclxuICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgPEdyaWQgaXRlbSBjb21wb25lbnQ9e1wic3BhblwifT5cclxuICAgICAgICAgICAgICAgICZidWxsO1xyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICA8R3JpZCBpdGVtIGNvbXBvbmVudD17XCJzcGFuXCJ9PlxyXG4gICAgICAgICAgICAgICAgPGI+UDogPC9iPlxyXG4gICAgICAgICAgICAgICAge3VzZXIucGhvbmVOdW1iZXJ9XHJcbiAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG4gICAgPC9MaXN0SXRlbT5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVXNlckxpc3RJdGVtO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb21wb25lbnRzL1VzZXJMaXN0SXRlbS50c3gifQ==