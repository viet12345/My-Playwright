import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport0_lodash_fp["isEmpty"]; const omit = __vite__cjsImport0_lodash_fp["omit"];
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
export const publicTransactionsMachine = dataMachine("publicTransactions").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.get(`http://localhost:${backendPort}/transactions/public`, {
        params: !isEmpty(payload) ? payload : void 0
      });
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInB1YmxpY1RyYW5zYWN0aW9uc01hY2hpbmUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgaXNFbXB0eSwgb21pdCB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IHsgZGF0YU1hY2hpbmUgfSBmcm9tIFwiLi9kYXRhTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBodHRwQ2xpZW50IH0gZnJvbSBcIi4uL3V0aWxzL2FzeW5jVXRpbHNcIjtcclxuaW1wb3J0IHsgYmFja2VuZFBvcnQgfSBmcm9tIFwiLi4vdXRpbHMvcG9ydFV0aWxzXCI7XHJcblxyXG5leHBvcnQgY29uc3QgcHVibGljVHJhbnNhY3Rpb25zTWFjaGluZSA9IGRhdGFNYWNoaW5lKFwicHVibGljVHJhbnNhY3Rpb25zXCIpLndpdGhDb25maWcoe1xyXG4gIHNlcnZpY2VzOiB7XHJcbiAgICBmZXRjaERhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQuZ2V0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L3RyYW5zYWN0aW9ucy9wdWJsaWNgLCB7XHJcbiAgICAgICAgcGFyYW1zOiAhaXNFbXB0eShwYXlsb2FkKSA/IHBheWxvYWQgOiB1bmRlZmluZWQsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgfSxcclxuICB9LFxyXG59KTtcclxuIl0sIm1hcHBpbmdzIjoiQUFBQSxTQUFTLFNBQVMsWUFBWTtBQUM5QixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUVyQixhQUFNLDRCQUE0QixZQUFZLG9CQUFvQixFQUFFLFdBQVc7QUFBQSxFQUNwRixVQUFVO0FBQUEsSUFDUixXQUFXLE9BQU8sS0FBSyxVQUFlO0FBQ3BDLFlBQU0sVUFBVSxLQUFLLFFBQVEsS0FBSztBQUNsQyxZQUFNLE9BQU8sTUFBTSxXQUFXLElBQUksb0JBQW9CLFdBQVcsd0JBQXdCO0FBQUEsUUFDdkYsUUFBUSxDQUFDLFFBQVEsT0FBTyxJQUFJLFVBQVU7QUFBQSxNQUN4QyxDQUFDO0FBQ0QsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUFBLEVBQ0Y7QUFDRixDQUFDOyIsIm5hbWVzIjpbXX0=