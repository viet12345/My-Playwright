import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UsersList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UsersList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { List } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import UserListItem from "/src/components/UserListItem.tsx";
const UsersList = ({ users, setReceiver }) => {
  return /* @__PURE__ */ jsxDEV(List, { "data-test": "users-list", children: users && users.map(
    (user, index) => /* @__PURE__ */ jsxDEV(UserListItem, { user, setReceiver, index }, user.id, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UsersList.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this)
  ) }, void 0, false, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UsersList.tsx",
    lineNumber: 14,
    columnNumber: 5
  }, this);
};
_c = UsersList;
export default UsersList;
var _c;
$RefreshReg$(_c, "UsersList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UsersList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/UsersList.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JVO0FBaEJWLE9BQU9BLG9CQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDekIsU0FBU0MsWUFBWTtBQUVyQixPQUFPQyxrQkFBa0I7QUFRekIsTUFBTUMsWUFBc0NBLENBQUMsRUFBRUMsT0FBT0MsWUFBWSxNQUFNO0FBQ3RFLFNBQ0UsdUJBQUMsUUFBSyxhQUFVLGNBQ2JELG1CQUNDQSxNQUFNRTtBQUFBQSxJQUFJLENBQUNDLE1BQVlDLFVBQ3JCLHVCQUFDLGdCQUEyQixNQUFZLGFBQTBCLFNBQS9DRCxLQUFLRSxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStFO0FBQUEsRUFDaEYsS0FKTDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFFQyxLQVRJUDtBQVdOLGVBQWVBO0FBQVUsSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlJlYWN0IiwiTGlzdCIsIlVzZXJMaXN0SXRlbSIsIlVzZXJzTGlzdCIsInVzZXJzIiwic2V0UmVjZWl2ZXIiLCJtYXAiLCJ1c2VyIiwiaW5kZXgiLCJpZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlcnNMaXN0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IExpc3QgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuaW1wb3J0IFVzZXJMaXN0SXRlbSBmcm9tIFwiLi9Vc2VyTGlzdEl0ZW1cIjtcclxuaW1wb3J0IHsgVXNlciB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgVXNlcnNMaXN0UHJvcHMge1xyXG4gIHVzZXJzOiBVc2VyW107XHJcbiAgc2V0UmVjZWl2ZXI6IEZ1bmN0aW9uO1xyXG59XHJcblxyXG5jb25zdCBVc2Vyc0xpc3Q6IFJlYWN0LkZDPFVzZXJzTGlzdFByb3BzPiA9ICh7IHVzZXJzLCBzZXRSZWNlaXZlciB9KSA9PiB7XHJcbiAgcmV0dXJuIChcclxuICAgIDxMaXN0IGRhdGEtdGVzdD1cInVzZXJzLWxpc3RcIj5cclxuICAgICAge3VzZXJzICYmXHJcbiAgICAgICAgdXNlcnMubWFwKCh1c2VyOiBVc2VyLCBpbmRleDogbnVtYmVyKSA9PiAoXHJcbiAgICAgICAgICA8VXNlckxpc3RJdGVtIGtleT17dXNlci5pZH0gdXNlcj17dXNlcn0gc2V0UmVjZWl2ZXI9e3NldFJlY2VpdmVyfSBpbmRleD17aW5kZXh9IC8+XHJcbiAgICAgICAgKSl9XHJcbiAgICA8L0xpc3Q+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJzTGlzdDtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9Vc2Vyc0xpc3QudHN4In0=