import {
  createLocation,
  createMemoryHistory,
  createPath,
  invariant,
  locationsAreEqual
} from "/node_modules/.vite/deps/chunk-ICEXKG2N.js?v=6af76b79";
import {
  tiny_warning_esm_default
} from "/node_modules/.vite/deps/chunk-DGAH7IWJ.js?v=6af76b79";
import {
  _inheritsLoose
} from "/node_modules/.vite/deps/chunk-HZOIS4LS.js?v=6af76b79";
import {
  require_hoist_non_react_statics_cjs
} from "/node_modules/.vite/deps/chunk-LXNNWNNO.js?v=6af76b79";
import {
  _objectWithoutPropertiesLoose
} from "/node_modules/.vite/deps/chunk-SRCT3FTM.js?v=6af76b79";
import {
  _extends,
  init_extends
} from "/node_modules/.vite/deps/chunk-64QIVKMX.js?v=6af76b79";
import {
  require_prop_types
} from "/node_modules/.vite/deps/chunk-6IJE4OMF.js?v=6af76b79";
import {
  require_react_is
} from "/node_modules/.vite/deps/chunk-AAY5IJNO.js?v=6af76b79";
import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZGRSIX2Q.js?v=6af76b79";
import {
  __commonJS,
  __toESM
} from "/node_modules/.vite/deps/chunk-ROME4SDB.js?v=6af76b79";

// node_modules/react-router/node_modules/isarray/index.js
var require_isarray = __commonJS({
  "node_modules/react-router/node_modules/isarray/index.js"(exports, module) {
    module.exports = Array.isArray || function(arr) {
      return Object.prototype.toString.call(arr) == "[object Array]";
    };
  }
});

// node_modules/react-router/node_modules/path-to-regexp/index.js
var require_path_to_regexp = __commonJS({
  "node_modules/react-router/node_modules/path-to-regexp/index.js"(exports, module) {
    var isarray = require_isarray();
    module.exports = pathToRegexp2;
    module.exports.parse = parse;
    module.exports.compile = compile;
    module.exports.tokensToFunction = tokensToFunction;
    module.exports.tokensToRegExp = tokensToRegExp;
    var PATH_REGEXP = new RegExp([
      // Match escaped characters that would otherwise appear in future matches.
      // This allows the user to escape special characters that won't transform.
      "(\\\\.)",
      // Match Express-style parameters and un-named parameters with a prefix
      // and optional suffixes. Matches appear as:
      //
      // "/:test(\\d+)?" => ["/", "test", "\d+", undefined, "?", undefined]
      // "/route(\\d+)"  => [undefined, undefined, undefined, "\d+", undefined, undefined]
      // "/*"            => ["/", undefined, undefined, undefined, undefined, "*"]
      "([\\/.])?(?:(?:\\:(\\w+)(?:\\(((?:\\\\.|[^\\\\()])+)\\))?|\\(((?:\\\\.|[^\\\\()])+)\\))([+*?])?|(\\*))"
    ].join("|"), "g");
    function parse(str, options) {
      var tokens = [];
      var key = 0;
      var index = 0;
      var path = "";
      var defaultDelimiter = options && options.delimiter || "/";
      var res;
      while ((res = PATH_REGEXP.exec(str)) != null) {
        var m = res[0];
        var escaped = res[1];
        var offset = res.index;
        path += str.slice(index, offset);
        index = offset + m.length;
        if (escaped) {
          path += escaped[1];
          continue;
        }
        var next = str[index];
        var prefix = res[2];
        var name = res[3];
        var capture = res[4];
        var group = res[5];
        var modifier = res[6];
        var asterisk = res[7];
        if (path) {
          tokens.push(path);
          path = "";
        }
        var partial = prefix != null && next != null && next !== prefix;
        var repeat = modifier === "+" || modifier === "*";
        var optional = modifier === "?" || modifier === "*";
        var delimiter = prefix || defaultDelimiter;
        var pattern = capture || group;
        var prevText = prefix || (typeof tokens[tokens.length - 1] === "string" ? tokens[tokens.length - 1] : "");
        tokens.push({
          name: name || key++,
          prefix: prefix || "",
          delimiter,
          optional,
          repeat,
          partial,
          asterisk: !!asterisk,
          pattern: pattern ? escapeGroup(pattern) : asterisk ? ".*" : restrictBacktrack(delimiter, prevText)
        });
      }
      if (index < str.length) {
        path += str.substr(index);
      }
      if (path) {
        tokens.push(path);
      }
      return tokens;
    }
    function restrictBacktrack(delimiter, prevText) {
      if (!prevText || prevText.indexOf(delimiter) > -1) {
        return "[^" + escapeString(delimiter) + "]+?";
      }
      return escapeString(prevText) + "|(?:(?!" + escapeString(prevText) + ")[^" + escapeString(delimiter) + "])+?";
    }
    function compile(str, options) {
      return tokensToFunction(parse(str, options), options);
    }
    function encodeURIComponentPretty(str) {
      return encodeURI(str).replace(/[\/?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
      });
    }
    function encodeAsterisk(str) {
      return encodeURI(str).replace(/[?#]/g, function(c) {
        return "%" + c.charCodeAt(0).toString(16).toUpperCase();
      });
    }
    function tokensToFunction(tokens, options) {
      var matches = new Array(tokens.length);
      for (var i = 0; i < tokens.length; i++) {
        if (typeof tokens[i] === "object") {
          matches[i] = new RegExp("^(?:" + tokens[i].pattern + ")$", flags(options));
        }
      }
      return function(obj, opts) {
        var path = "";
        var data = obj || {};
        var options2 = opts || {};
        var encode = options2.pretty ? encodeURIComponentPretty : encodeURIComponent;
        for (var i2 = 0; i2 < tokens.length; i2++) {
          var token = tokens[i2];
          if (typeof token === "string") {
            path += token;
            continue;
          }
          var value = data[token.name];
          var segment;
          if (value == null) {
            if (token.optional) {
              if (token.partial) {
                path += token.prefix;
              }
              continue;
            } else {
              throw new TypeError('Expected "' + token.name + '" to be defined');
            }
          }
          if (isarray(value)) {
            if (!token.repeat) {
              throw new TypeError('Expected "' + token.name + '" to not repeat, but received `' + JSON.stringify(value) + "`");
            }
            if (value.length === 0) {
              if (token.optional) {
                continue;
              } else {
                throw new TypeError('Expected "' + token.name + '" to not be empty');
              }
            }
            for (var j = 0; j < value.length; j++) {
              segment = encode(value[j]);
              if (!matches[i2].test(segment)) {
                throw new TypeError('Expected all "' + token.name + '" to match "' + token.pattern + '", but received `' + JSON.stringify(segment) + "`");
              }
              path += (j === 0 ? token.prefix : token.delimiter) + segment;
            }
            continue;
          }
          segment = token.asterisk ? encodeAsterisk(value) : encode(value);
          if (!matches[i2].test(segment)) {
            throw new TypeError('Expected "' + token.name + '" to match "' + token.pattern + '", but received "' + segment + '"');
          }
          path += token.prefix + segment;
        }
        return path;
      };
    }
    function escapeString(str) {
      return str.replace(/([.+*?=^!:${}()[\]|\/\\])/g, "\\$1");
    }
    function escapeGroup(group) {
      return group.replace(/([=!:$\/()])/g, "\\$1");
    }
    function attachKeys(re, keys) {
      re.keys = keys;
      return re;
    }
    function flags(options) {
      return options && options.sensitive ? "" : "i";
    }
    function regexpToRegexp(path, keys) {
      var groups = path.source.match(/\((?!\?)/g);
      if (groups) {
        for (var i = 0; i < groups.length; i++) {
          keys.push({
            name: i,
            prefix: null,
            delimiter: null,
            optional: false,
            repeat: false,
            partial: false,
            asterisk: false,
            pattern: null
          });
        }
      }
      return attachKeys(path, keys);
    }
    function arrayToRegexp(path, keys, options) {
      var parts = [];
      for (var i = 0; i < path.length; i++) {
        parts.push(pathToRegexp2(path[i], keys, options).source);
      }
      var regexp = new RegExp("(?:" + parts.join("|") + ")", flags(options));
      return attachKeys(regexp, keys);
    }
    function stringToRegexp(path, keys, options) {
      return tokensToRegExp(parse(path, options), keys, options);
    }
    function tokensToRegExp(tokens, keys, options) {
      if (!isarray(keys)) {
        options = /** @type {!Object} */
        keys || options;
        keys = [];
      }
      options = options || {};
      var strict = options.strict;
      var end = options.end !== false;
      var route = "";
      for (var i = 0; i < tokens.length; i++) {
        var token = tokens[i];
        if (typeof token === "string") {
          route += escapeString(token);
        } else {
          var prefix = escapeString(token.prefix);
          var capture = "(?:" + token.pattern + ")";
          keys.push(token);
          if (token.repeat) {
            capture += "(?:" + prefix + capture + ")*";
          }
          if (token.optional) {
            if (!token.partial) {
              capture = "(?:" + prefix + "(" + capture + "))?";
            } else {
              capture = prefix + "(" + capture + ")?";
            }
          } else {
            capture = prefix + "(" + capture + ")";
          }
          route += capture;
        }
      }
      var delimiter = escapeString(options.delimiter || "/");
      var endsWithDelimiter = route.slice(-delimiter.length) === delimiter;
      if (!strict) {
        route = (endsWithDelimiter ? route.slice(0, -delimiter.length) : route) + "(?:" + delimiter + "(?=$))?";
      }
      if (end) {
        route += "$";
      } else {
        route += strict && endsWithDelimiter ? "" : "(?=" + delimiter + "|$)";
      }
      return attachKeys(new RegExp("^" + route, flags(options)), keys);
    }
    function pathToRegexp2(path, keys, options) {
      if (!isarray(keys)) {
        options = /** @type {!Object} */
        keys || options;
        keys = [];
      }
      options = options || {};
      if (path instanceof RegExp) {
        return regexpToRegexp(
          path,
          /** @type {!Array} */
          keys
        );
      }
      if (isarray(path)) {
        return arrayToRegexp(
          /** @type {!Array} */
          path,
          /** @type {!Array} */
          keys,
          options
        );
      }
      return stringToRegexp(
        /** @type {string} */
        path,
        /** @type {!Array} */
        keys,
        options
      );
    }
  }
});

// node_modules/react-router/esm/react-router.js
var import_react = __toESM(require_react());
var import_prop_types = __toESM(require_prop_types());
init_extends();
var import_path_to_regexp = __toESM(require_path_to_regexp());
var import_react_is = __toESM(require_react_is());
var import_hoist_non_react_statics = __toESM(require_hoist_non_react_statics_cjs());
var MAX_SIGNED_31_BIT_INT = 1073741823;
var commonjsGlobal = typeof globalThis !== "undefined" ? (
  // eslint-disable-next-line no-undef
  globalThis
) : typeof window !== "undefined" ? window : typeof global !== "undefined" ? global : {};
function getUniqueId() {
  var key = "__global_unique_id__";
  return commonjsGlobal[key] = (commonjsGlobal[key] || 0) + 1;
}
function objectIs(x, y) {
  if (x === y) {
    return x !== 0 || 1 / x === 1 / y;
  } else {
    return x !== x && y !== y;
  }
}
function createEventEmitter(value) {
  var handlers = [];
  return {
    on: function on(handler) {
      handlers.push(handler);
    },
    off: function off(handler) {
      handlers = handlers.filter(function(h) {
        return h !== handler;
      });
    },
    get: function get() {
      return value;
    },
    set: function set(newValue, changedBits) {
      value = newValue;
      handlers.forEach(function(handler) {
        return handler(value, changedBits);
      });
    }
  };
}
function onlyChild(children) {
  return Array.isArray(children) ? children[0] : children;
}
function createReactContext(defaultValue, calculateChangedBits) {
  var _Provider$childContex, _Consumer$contextType;
  var contextProp = "__create-react-context-" + getUniqueId() + "__";
  var Provider = function(_React$Component) {
    _inheritsLoose(Provider2, _React$Component);
    function Provider2() {
      var _this;
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
      _this.emitter = createEventEmitter(_this.props.value);
      return _this;
    }
    var _proto = Provider2.prototype;
    _proto.getChildContext = function getChildContext() {
      var _ref;
      return _ref = {}, _ref[contextProp] = this.emitter, _ref;
    };
    _proto.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
      if (this.props.value !== nextProps.value) {
        var oldValue = this.props.value;
        var newValue = nextProps.value;
        var changedBits;
        if (objectIs(oldValue, newValue)) {
          changedBits = 0;
        } else {
          changedBits = typeof calculateChangedBits === "function" ? calculateChangedBits(oldValue, newValue) : MAX_SIGNED_31_BIT_INT;
          if (true) {
            true ? tiny_warning_esm_default((changedBits & MAX_SIGNED_31_BIT_INT) === changedBits, "calculateChangedBits: Expected the return value to be a 31-bit integer. Instead received: " + changedBits) : void 0;
          }
          changedBits |= 0;
          if (changedBits !== 0) {
            this.emitter.set(nextProps.value, changedBits);
          }
        }
      }
    };
    _proto.render = function render() {
      return this.props.children;
    };
    return Provider2;
  }(import_react.default.Component);
  Provider.childContextTypes = (_Provider$childContex = {}, _Provider$childContex[contextProp] = import_prop_types.default.object.isRequired, _Provider$childContex);
  var Consumer = function(_React$Component2) {
    _inheritsLoose(Consumer2, _React$Component2);
    function Consumer2() {
      var _this2;
      for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
        args[_key2] = arguments[_key2];
      }
      _this2 = _React$Component2.call.apply(_React$Component2, [this].concat(args)) || this;
      _this2.observedBits = void 0;
      _this2.state = {
        value: _this2.getValue()
      };
      _this2.onUpdate = function(newValue, changedBits) {
        var observedBits = _this2.observedBits | 0;
        if ((observedBits & changedBits) !== 0) {
          _this2.setState({
            value: _this2.getValue()
          });
        }
      };
      return _this2;
    }
    var _proto2 = Consumer2.prototype;
    _proto2.componentWillReceiveProps = function componentWillReceiveProps(nextProps) {
      var observedBits = nextProps.observedBits;
      this.observedBits = observedBits === void 0 || observedBits === null ? MAX_SIGNED_31_BIT_INT : observedBits;
    };
    _proto2.componentDidMount = function componentDidMount() {
      if (this.context[contextProp]) {
        this.context[contextProp].on(this.onUpdate);
      }
      var observedBits = this.props.observedBits;
      this.observedBits = observedBits === void 0 || observedBits === null ? MAX_SIGNED_31_BIT_INT : observedBits;
    };
    _proto2.componentWillUnmount = function componentWillUnmount() {
      if (this.context[contextProp]) {
        this.context[contextProp].off(this.onUpdate);
      }
    };
    _proto2.getValue = function getValue() {
      if (this.context[contextProp]) {
        return this.context[contextProp].get();
      } else {
        return defaultValue;
      }
    };
    _proto2.render = function render() {
      return onlyChild(this.props.children)(this.state.value);
    };
    return Consumer2;
  }(import_react.default.Component);
  Consumer.contextTypes = (_Consumer$contextType = {}, _Consumer$contextType[contextProp] = import_prop_types.default.object, _Consumer$contextType);
  return {
    Provider,
    Consumer
  };
}
var createContext = import_react.default.createContext || createReactContext;
var createNamedContext = function createNamedContext2(name) {
  var context2 = createContext();
  context2.displayName = name;
  return context2;
};
var historyContext = createNamedContext("Router-History");
var context = createNamedContext("Router");
var Router = function(_React$Component) {
  _inheritsLoose(Router2, _React$Component);
  Router2.computeRootMatch = function computeRootMatch(pathname) {
    return {
      path: "/",
      url: "/",
      params: {},
      isExact: pathname === "/"
    };
  };
  function Router2(props) {
    var _this;
    _this = _React$Component.call(this, props) || this;
    _this.state = {
      location: props.history.location
    };
    _this._isMounted = false;
    _this._pendingLocation = null;
    if (!props.staticContext) {
      _this.unlisten = props.history.listen(function(location) {
        _this._pendingLocation = location;
      });
    }
    return _this;
  }
  var _proto = Router2.prototype;
  _proto.componentDidMount = function componentDidMount() {
    var _this2 = this;
    this._isMounted = true;
    if (this.unlisten) {
      this.unlisten();
    }
    if (!this.props.staticContext) {
      this.unlisten = this.props.history.listen(function(location) {
        if (_this2._isMounted) {
          _this2.setState({
            location
          });
        }
      });
    }
    if (this._pendingLocation) {
      this.setState({
        location: this._pendingLocation
      });
    }
  };
  _proto.componentWillUnmount = function componentWillUnmount() {
    if (this.unlisten) {
      this.unlisten();
      this._isMounted = false;
      this._pendingLocation = null;
    }
  };
  _proto.render = function render() {
    return import_react.default.createElement(context.Provider, {
      value: {
        history: this.props.history,
        location: this.state.location,
        match: Router2.computeRootMatch(this.state.location.pathname),
        staticContext: this.props.staticContext
      }
    }, import_react.default.createElement(historyContext.Provider, {
      children: this.props.children || null,
      value: this.props.history
    }));
  };
  return Router2;
}(import_react.default.Component);
if (true) {
  Router.propTypes = {
    children: import_prop_types.default.node,
    history: import_prop_types.default.object.isRequired,
    staticContext: import_prop_types.default.object
  };
  Router.prototype.componentDidUpdate = function(prevProps) {
    true ? tiny_warning_esm_default(prevProps.history === this.props.history, "You cannot change <Router history>") : void 0;
  };
}
var MemoryRouter = function(_React$Component) {
  _inheritsLoose(MemoryRouter2, _React$Component);
  function MemoryRouter2() {
    var _this;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
    _this.history = createMemoryHistory(_this.props);
    return _this;
  }
  var _proto = MemoryRouter2.prototype;
  _proto.render = function render() {
    return import_react.default.createElement(Router, {
      history: this.history,
      children: this.props.children
    });
  };
  return MemoryRouter2;
}(import_react.default.Component);
if (true) {
  MemoryRouter.propTypes = {
    initialEntries: import_prop_types.default.array,
    initialIndex: import_prop_types.default.number,
    getUserConfirmation: import_prop_types.default.func,
    keyLength: import_prop_types.default.number,
    children: import_prop_types.default.node
  };
  MemoryRouter.prototype.componentDidMount = function() {
    true ? tiny_warning_esm_default(!this.props.history, "<MemoryRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { MemoryRouter as Router }`.") : void 0;
  };
}
var Lifecycle = function(_React$Component) {
  _inheritsLoose(Lifecycle2, _React$Component);
  function Lifecycle2() {
    return _React$Component.apply(this, arguments) || this;
  }
  var _proto = Lifecycle2.prototype;
  _proto.componentDidMount = function componentDidMount() {
    if (this.props.onMount)
      this.props.onMount.call(this, this);
  };
  _proto.componentDidUpdate = function componentDidUpdate(prevProps) {
    if (this.props.onUpdate)
      this.props.onUpdate.call(this, this, prevProps);
  };
  _proto.componentWillUnmount = function componentWillUnmount() {
    if (this.props.onUnmount)
      this.props.onUnmount.call(this, this);
  };
  _proto.render = function render() {
    return null;
  };
  return Lifecycle2;
}(import_react.default.Component);
function Prompt(_ref) {
  var message = _ref.message, _ref$when = _ref.when, when = _ref$when === void 0 ? true : _ref$when;
  return import_react.default.createElement(context.Consumer, null, function(context2) {
    !context2 ? true ? invariant(false, "You should not use <Prompt> outside a <Router>") : invariant(false) : void 0;
    if (!when || context2.staticContext)
      return null;
    var method = context2.history.block;
    return import_react.default.createElement(Lifecycle, {
      onMount: function onMount(self) {
        self.release = method(message);
      },
      onUpdate: function onUpdate(self, prevProps) {
        if (prevProps.message !== message) {
          self.release();
          self.release = method(message);
        }
      },
      onUnmount: function onUnmount(self) {
        self.release();
      },
      message
    });
  });
}
if (true) {
  messageType = import_prop_types.default.oneOfType([import_prop_types.default.func, import_prop_types.default.string]);
  Prompt.propTypes = {
    when: import_prop_types.default.bool,
    message: messageType.isRequired
  };
}
var messageType;
var cache = {};
var cacheLimit = 1e4;
var cacheCount = 0;
function compilePath(path) {
  if (cache[path])
    return cache[path];
  var generator = import_path_to_regexp.default.compile(path);
  if (cacheCount < cacheLimit) {
    cache[path] = generator;
    cacheCount++;
  }
  return generator;
}
function generatePath(path, params) {
  if (path === void 0) {
    path = "/";
  }
  if (params === void 0) {
    params = {};
  }
  return path === "/" ? path : compilePath(path)(params, {
    pretty: true
  });
}
function Redirect(_ref) {
  var computedMatch = _ref.computedMatch, to = _ref.to, _ref$push = _ref.push, push = _ref$push === void 0 ? false : _ref$push;
  return import_react.default.createElement(context.Consumer, null, function(context2) {
    !context2 ? true ? invariant(false, "You should not use <Redirect> outside a <Router>") : invariant(false) : void 0;
    var history = context2.history, staticContext = context2.staticContext;
    var method = push ? history.push : history.replace;
    var location = createLocation(computedMatch ? typeof to === "string" ? generatePath(to, computedMatch.params) : _extends({}, to, {
      pathname: generatePath(to.pathname, computedMatch.params)
    }) : to);
    if (staticContext) {
      method(location);
      return null;
    }
    return import_react.default.createElement(Lifecycle, {
      onMount: function onMount() {
        method(location);
      },
      onUpdate: function onUpdate(self, prevProps) {
        var prevLocation = createLocation(prevProps.to);
        if (!locationsAreEqual(prevLocation, _extends({}, location, {
          key: prevLocation.key
        }))) {
          method(location);
        }
      },
      to
    });
  });
}
if (true) {
  Redirect.propTypes = {
    push: import_prop_types.default.bool,
    from: import_prop_types.default.string,
    to: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.object]).isRequired
  };
}
var cache$1 = {};
var cacheLimit$1 = 1e4;
var cacheCount$1 = 0;
function compilePath$1(path, options) {
  var cacheKey = "" + options.end + options.strict + options.sensitive;
  var pathCache = cache$1[cacheKey] || (cache$1[cacheKey] = {});
  if (pathCache[path])
    return pathCache[path];
  var keys = [];
  var regexp = (0, import_path_to_regexp.default)(path, keys, options);
  var result = {
    regexp,
    keys
  };
  if (cacheCount$1 < cacheLimit$1) {
    pathCache[path] = result;
    cacheCount$1++;
  }
  return result;
}
function matchPath(pathname, options) {
  if (options === void 0) {
    options = {};
  }
  if (typeof options === "string" || Array.isArray(options)) {
    options = {
      path: options
    };
  }
  var _options = options, path = _options.path, _options$exact = _options.exact, exact = _options$exact === void 0 ? false : _options$exact, _options$strict = _options.strict, strict = _options$strict === void 0 ? false : _options$strict, _options$sensitive = _options.sensitive, sensitive = _options$sensitive === void 0 ? false : _options$sensitive;
  var paths = [].concat(path);
  return paths.reduce(function(matched, path2) {
    if (!path2 && path2 !== "")
      return null;
    if (matched)
      return matched;
    var _compilePath = compilePath$1(path2, {
      end: exact,
      strict,
      sensitive
    }), regexp = _compilePath.regexp, keys = _compilePath.keys;
    var match = regexp.exec(pathname);
    if (!match)
      return null;
    var url = match[0], values = match.slice(1);
    var isExact = pathname === url;
    if (exact && !isExact)
      return null;
    return {
      path: path2,
      // the path used to match
      url: path2 === "/" && url === "" ? "/" : url,
      // the matched portion of the URL
      isExact,
      // whether or not we matched exactly
      params: keys.reduce(function(memo, key, index) {
        memo[key.name] = values[index];
        return memo;
      }, {})
    };
  }, null);
}
function isEmptyChildren(children) {
  return import_react.default.Children.count(children) === 0;
}
function evalChildrenDev(children, props, path) {
  var value = children(props);
  true ? tiny_warning_esm_default(value !== void 0, "You returned `undefined` from the `children` function of " + ("<Route" + (path ? ' path="' + path + '"' : "") + ">, but you ") + "should have returned a React element or `null`") : void 0;
  return value || null;
}
var Route = function(_React$Component) {
  _inheritsLoose(Route2, _React$Component);
  function Route2() {
    return _React$Component.apply(this, arguments) || this;
  }
  var _proto = Route2.prototype;
  _proto.render = function render() {
    var _this = this;
    return import_react.default.createElement(context.Consumer, null, function(context$1) {
      !context$1 ? true ? invariant(false, "You should not use <Route> outside a <Router>") : invariant(false) : void 0;
      var location = _this.props.location || context$1.location;
      var match = _this.props.computedMatch ? _this.props.computedMatch : _this.props.path ? matchPath(location.pathname, _this.props) : context$1.match;
      var props = _extends({}, context$1, {
        location,
        match
      });
      var _this$props = _this.props, children = _this$props.children, component = _this$props.component, render2 = _this$props.render;
      if (Array.isArray(children) && isEmptyChildren(children)) {
        children = null;
      }
      return import_react.default.createElement(context.Provider, {
        value: props
      }, props.match ? children ? typeof children === "function" ? true ? evalChildrenDev(children, props, _this.props.path) : children(props) : children : component ? import_react.default.createElement(component, props) : render2 ? render2(props) : null : typeof children === "function" ? true ? evalChildrenDev(children, props, _this.props.path) : children(props) : null);
    });
  };
  return Route2;
}(import_react.default.Component);
if (true) {
  Route.propTypes = {
    children: import_prop_types.default.oneOfType([import_prop_types.default.func, import_prop_types.default.node]),
    component: function component(props, propName) {
      if (props[propName] && !(0, import_react_is.isValidElementType)(props[propName])) {
        return new Error("Invalid prop 'component' supplied to 'Route': the prop is not a valid React component");
      }
    },
    exact: import_prop_types.default.bool,
    location: import_prop_types.default.object,
    path: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.arrayOf(import_prop_types.default.string)]),
    render: import_prop_types.default.func,
    sensitive: import_prop_types.default.bool,
    strict: import_prop_types.default.bool
  };
  Route.prototype.componentDidMount = function() {
    true ? tiny_warning_esm_default(!(this.props.children && !isEmptyChildren(this.props.children) && this.props.component), "You should not use <Route component> and <Route children> in the same route; <Route component> will be ignored") : void 0;
    true ? tiny_warning_esm_default(!(this.props.children && !isEmptyChildren(this.props.children) && this.props.render), "You should not use <Route render> and <Route children> in the same route; <Route render> will be ignored") : void 0;
    true ? tiny_warning_esm_default(!(this.props.component && this.props.render), "You should not use <Route component> and <Route render> in the same route; <Route render> will be ignored") : void 0;
  };
  Route.prototype.componentDidUpdate = function(prevProps) {
    true ? tiny_warning_esm_default(!(this.props.location && !prevProps.location), '<Route> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.') : void 0;
    true ? tiny_warning_esm_default(!(!this.props.location && prevProps.location), '<Route> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.') : void 0;
  };
}
function addLeadingSlash(path) {
  return path.charAt(0) === "/" ? path : "/" + path;
}
function addBasename(basename, location) {
  if (!basename)
    return location;
  return _extends({}, location, {
    pathname: addLeadingSlash(basename) + location.pathname
  });
}
function stripBasename(basename, location) {
  if (!basename)
    return location;
  var base = addLeadingSlash(basename);
  if (location.pathname.indexOf(base) !== 0)
    return location;
  return _extends({}, location, {
    pathname: location.pathname.substr(base.length)
  });
}
function createURL(location) {
  return typeof location === "string" ? location : createPath(location);
}
function staticHandler(methodName) {
  return function() {
    true ? invariant(false, "You cannot %s with <StaticRouter>", methodName) : invariant(false);
  };
}
function noop() {
}
var StaticRouter = function(_React$Component) {
  _inheritsLoose(StaticRouter2, _React$Component);
  function StaticRouter2() {
    var _this;
    for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }
    _this = _React$Component.call.apply(_React$Component, [this].concat(args)) || this;
    _this.handlePush = function(location) {
      return _this.navigateTo(location, "PUSH");
    };
    _this.handleReplace = function(location) {
      return _this.navigateTo(location, "REPLACE");
    };
    _this.handleListen = function() {
      return noop;
    };
    _this.handleBlock = function() {
      return noop;
    };
    return _this;
  }
  var _proto = StaticRouter2.prototype;
  _proto.navigateTo = function navigateTo(location, action) {
    var _this$props = this.props, _this$props$basename = _this$props.basename, basename = _this$props$basename === void 0 ? "" : _this$props$basename, _this$props$context = _this$props.context, context2 = _this$props$context === void 0 ? {} : _this$props$context;
    context2.action = action;
    context2.location = addBasename(basename, createLocation(location));
    context2.url = createURL(context2.location);
  };
  _proto.render = function render() {
    var _this$props2 = this.props, _this$props2$basename = _this$props2.basename, basename = _this$props2$basename === void 0 ? "" : _this$props2$basename, _this$props2$context = _this$props2.context, context2 = _this$props2$context === void 0 ? {} : _this$props2$context, _this$props2$location = _this$props2.location, location = _this$props2$location === void 0 ? "/" : _this$props2$location, rest = _objectWithoutPropertiesLoose(_this$props2, ["basename", "context", "location"]);
    var history = {
      createHref: function createHref(path) {
        return addLeadingSlash(basename + createURL(path));
      },
      action: "POP",
      location: stripBasename(basename, createLocation(location)),
      push: this.handlePush,
      replace: this.handleReplace,
      go: staticHandler("go"),
      goBack: staticHandler("goBack"),
      goForward: staticHandler("goForward"),
      listen: this.handleListen,
      block: this.handleBlock
    };
    return import_react.default.createElement(Router, _extends({}, rest, {
      history,
      staticContext: context2
    }));
  };
  return StaticRouter2;
}(import_react.default.Component);
if (true) {
  StaticRouter.propTypes = {
    basename: import_prop_types.default.string,
    context: import_prop_types.default.object,
    location: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.object])
  };
  StaticRouter.prototype.componentDidMount = function() {
    true ? tiny_warning_esm_default(!this.props.history, "<StaticRouter> ignores the history prop. To use a custom history, use `import { Router }` instead of `import { StaticRouter as Router }`.") : void 0;
  };
}
var Switch = function(_React$Component) {
  _inheritsLoose(Switch2, _React$Component);
  function Switch2() {
    return _React$Component.apply(this, arguments) || this;
  }
  var _proto = Switch2.prototype;
  _proto.render = function render() {
    var _this = this;
    return import_react.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? true ? invariant(false, "You should not use <Switch> outside a <Router>") : invariant(false) : void 0;
      var location = _this.props.location || context2.location;
      var element, match;
      import_react.default.Children.forEach(_this.props.children, function(child) {
        if (match == null && import_react.default.isValidElement(child)) {
          element = child;
          var path = child.props.path || child.props.from;
          match = path ? matchPath(location.pathname, _extends({}, child.props, {
            path
          })) : context2.match;
        }
      });
      return match ? import_react.default.cloneElement(element, {
        location,
        computedMatch: match
      }) : null;
    });
  };
  return Switch2;
}(import_react.default.Component);
if (true) {
  Switch.propTypes = {
    children: import_prop_types.default.node,
    location: import_prop_types.default.object
  };
  Switch.prototype.componentDidUpdate = function(prevProps) {
    true ? tiny_warning_esm_default(!(this.props.location && !prevProps.location), '<Switch> elements should not change from uncontrolled to controlled (or vice versa). You initially used no "location" prop and then provided one on a subsequent render.') : void 0;
    true ? tiny_warning_esm_default(!(!this.props.location && prevProps.location), '<Switch> elements should not change from controlled to uncontrolled (or vice versa). You provided a "location" prop initially but omitted it on a subsequent render.') : void 0;
  };
}
function withRouter(Component) {
  var displayName = "withRouter(" + (Component.displayName || Component.name) + ")";
  var C = function C2(props) {
    var wrappedComponentRef = props.wrappedComponentRef, remainingProps = _objectWithoutPropertiesLoose(props, ["wrappedComponentRef"]);
    return import_react.default.createElement(context.Consumer, null, function(context2) {
      !context2 ? true ? invariant(false, "You should not use <" + displayName + " /> outside a <Router>") : invariant(false) : void 0;
      return import_react.default.createElement(Component, _extends({}, remainingProps, context2, {
        ref: wrappedComponentRef
      }));
    });
  };
  C.displayName = displayName;
  C.WrappedComponent = Component;
  if (true) {
    C.propTypes = {
      wrappedComponentRef: import_prop_types.default.oneOfType([import_prop_types.default.string, import_prop_types.default.func, import_prop_types.default.object])
    };
  }
  return (0, import_hoist_non_react_statics.default)(C, Component);
}
var useContext = import_react.default.useContext;
function useHistory() {
  if (true) {
    !(typeof useContext === "function") ? true ? invariant(false, "You must use React >= 16.8 in order to use useHistory()") : invariant(false) : void 0;
  }
  return useContext(historyContext);
}
function useLocation() {
  if (true) {
    !(typeof useContext === "function") ? true ? invariant(false, "You must use React >= 16.8 in order to use useLocation()") : invariant(false) : void 0;
  }
  return useContext(context).location;
}
function useParams() {
  if (true) {
    !(typeof useContext === "function") ? true ? invariant(false, "You must use React >= 16.8 in order to use useParams()") : invariant(false) : void 0;
  }
  var match = useContext(context).match;
  return match ? match.params : {};
}
function useRouteMatch(path) {
  if (true) {
    !(typeof useContext === "function") ? true ? invariant(false, "You must use React >= 16.8 in order to use useRouteMatch()") : invariant(false) : void 0;
  }
  var location = useLocation();
  var match = useContext(context).match;
  return path ? matchPath(location.pathname, path) : match;
}
if (true) {
  if (typeof window !== "undefined") {
    global$1 = window;
    key = "__react_router_build__";
    buildNames = {
      cjs: "CommonJS",
      esm: "ES modules",
      umd: "UMD"
    };
    if (global$1[key] && global$1[key] !== "esm") {
      initialBuildName = buildNames[global$1[key]];
      secondaryBuildName = buildNames["esm"];
      throw new Error("You are loading the " + secondaryBuildName + " build of React Router " + ("on a page that is already running the " + initialBuildName + " ") + "build, so things won't work right.");
    }
    global$1[key] = "esm";
  }
}
var global$1;
var key;
var buildNames;
var initialBuildName;
var secondaryBuildName;

export {
  historyContext,
  context,
  Router,
  MemoryRouter,
  Prompt,
  generatePath,
  Redirect,
  matchPath,
  Route,
  StaticRouter,
  Switch,
  withRouter,
  useHistory,
  useLocation,
  useParams,
  useRouteMatch
};
//# sourceMappingURL=chunk-IC4WRPTG.js.map
