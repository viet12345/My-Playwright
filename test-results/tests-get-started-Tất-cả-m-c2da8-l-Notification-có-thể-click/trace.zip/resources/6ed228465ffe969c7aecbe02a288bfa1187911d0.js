import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SvgRwaIconLogo.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgRwaIconLogo.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
function SvgRwaIconLogo(props) {
  return /* @__PURE__ */ jsxDEV(
    "svg",
    {
      width: "47px",
      height: "47px",
      viewBox: "0 0 47 47",
      xmlns: "http://www.w3.org/2000/svg",
      ...props,
      children: /* @__PURE__ */ jsxDEV(
        "path",
        {
          d: "M42.073 12.133c-.802-.357-1.713-.51-2.682-.473l-9.832.384c-.901.112-1.527.94-1.385 1.831.14.874.966 1.477 1.845 1.346l9.514-.357c.555-.02.957.068 1.237.192.42.186.603.409.717.777.116.37.12.936-.174 1.662l-3.843 9.51c-.782 1.937-3.782 4.168-6 4.251l-8.053.301c-.901.112-1.527.94-1.385 1.832.14.874.966 1.477 1.845 1.346l7.735-.274c3.881-.145 7.486-2.851 8.857-6.244l3.842-9.51c.514-1.273.635-2.6.258-3.806-.374-1.203-1.293-2.234-2.496-2.768zM23.68 13.33a1.66 1.66 0 00-.93-.147l-7.688.173c-3.859.094-7.416 2.67-8.74 5.945l-3.707 9.177c-.662 1.638-.61 3.417.344 4.798.951 1.383 2.715 2.145 4.644 2.099l9.772-.253c.894-.098 1.507-.894 1.355-1.76-.15-.849-.979-1.443-1.852-1.327l-9.456.23c-1.103.026-1.556-.293-1.806-.655-.25-.362-.38-.987-.002-1.92l3.708-9.178c.754-1.866 3.714-3.993 5.921-4.046l8.005-.195c.894-.098 1.507-.894 1.355-1.76a1.63 1.63 0 00-.921-1.181h-.002zm2.52 2.093c-.811-.315-1.718.071-2.027.862l-.186.462c-1.183.164-2.3.756-3.06 1.753-1.54 2.018-1.095 4.956.985 6.505.714.531.858 1.476.33 2.167-.53.692-1.488.815-2.202.285l-.635-.47c-.691-.527-1.675-.412-2.202.255-.537.682-.416 1.642.328 2.197l.635.47v.001c.13.096.264.186.402.269-.26.76.117 1.609.888 1.933.82.344 1.755-.037 2.07-.844l.185-.457c1.184-.163 2.3-.76 3.062-1.758 1.54-2.017 1.094-4.955-.986-6.504-.714-.531-.858-1.475-.33-2.167.53-.691 1.489-.816 2.203-.286l.634.47c.692.527 1.677.412 2.204-.255.537-.681.388-1.675-.33-2.197l-.632-.47c-.13-.097-.27-.175-.408-.257.275-.78-.127-1.652-.927-1.964z",
          fill: "currentColor",
          fillRule: "evenodd"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgRwaIconLogo.tsx",
          lineNumber: 12,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgRwaIconLogo.tsx",
      lineNumber: 5,
      columnNumber: 5
    },
    this
  );
}
_c = SvgRwaIconLogo;
export default SvgRwaIconLogo;
var _c;
$RefreshReg$(_c, "SvgRwaIconLogo");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgRwaIconLogo.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SvgRwaIconLogo.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV007QUFYTixPQUFPLG9CQUFnQjtBQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFOUIsU0FBU0EsZUFBZUMsT0FBWTtBQUNsQyxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxPQUFNO0FBQUEsTUFDTixRQUFPO0FBQUEsTUFDUCxTQUFRO0FBQUEsTUFDUixPQUFNO0FBQUEsTUFDTixHQUFJQTtBQUFBQSxNQUVKO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxHQUFFO0FBQUEsVUFDRixNQUFLO0FBQUEsVUFDTCxVQUFTO0FBQUE7QUFBQSxRQUhYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUdvQjtBQUFBO0FBQUEsSUFWdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUE7QUFFSjtBQUFDQyxLQWhCUUY7QUFrQlQsZUFBZUE7QUFBZSxJQUFBRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiU3ZnUndhSWNvbkxvZ28iLCJwcm9wcyIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU3ZnUndhSWNvbkxvZ28udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAqIGFzIFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuZnVuY3Rpb24gU3ZnUndhSWNvbkxvZ28ocHJvcHM6IGFueSkge1xyXG4gIHJldHVybiAoXHJcbiAgICA8c3ZnXHJcbiAgICAgIHdpZHRoPVwiNDdweFwiXHJcbiAgICAgIGhlaWdodD1cIjQ3cHhcIlxyXG4gICAgICB2aWV3Qm94PVwiMCAwIDQ3IDQ3XCJcclxuICAgICAgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiXHJcbiAgICAgIHsuLi5wcm9wc31cclxuICAgID5cclxuICAgICAgPHBhdGhcclxuICAgICAgICBkPVwiTTQyLjA3MyAxMi4xMzNjLS44MDItLjM1Ny0xLjcxMy0uNTEtMi42ODItLjQ3M2wtOS44MzIuMzg0Yy0uOTAxLjExMi0xLjUyNy45NC0xLjM4NSAxLjgzMS4xNC44NzQuOTY2IDEuNDc3IDEuODQ1IDEuMzQ2bDkuNTE0LS4zNTdjLjU1NS0uMDIuOTU3LjA2OCAxLjIzNy4xOTIuNDIuMTg2LjYwMy40MDkuNzE3Ljc3Ny4xMTYuMzcuMTIuOTM2LS4xNzQgMS42NjJsLTMuODQzIDkuNTFjLS43ODIgMS45MzctMy43ODIgNC4xNjgtNiA0LjI1MWwtOC4wNTMuMzAxYy0uOTAxLjExMi0xLjUyNy45NC0xLjM4NSAxLjgzMi4xNC44NzQuOTY2IDEuNDc3IDEuODQ1IDEuMzQ2bDcuNzM1LS4yNzRjMy44ODEtLjE0NSA3LjQ4Ni0yLjg1MSA4Ljg1Ny02LjI0NGwzLjg0Mi05LjUxYy41MTQtMS4yNzMuNjM1LTIuNi4yNTgtMy44MDYtLjM3NC0xLjIwMy0xLjI5My0yLjIzNC0yLjQ5Ni0yLjc2OHpNMjMuNjggMTMuMzNhMS42NiAxLjY2IDAgMDAtLjkzLS4xNDdsLTcuNjg4LjE3M2MtMy44NTkuMDk0LTcuNDE2IDIuNjctOC43NCA1Ljk0NWwtMy43MDcgOS4xNzdjLS42NjIgMS42MzgtLjYxIDMuNDE3LjM0NCA0Ljc5OC45NTEgMS4zODMgMi43MTUgMi4xNDUgNC42NDQgMi4wOTlsOS43NzItLjI1M2MuODk0LS4wOTggMS41MDctLjg5NCAxLjM1NS0xLjc2LS4xNS0uODQ5LS45NzktMS40NDMtMS44NTItMS4zMjdsLTkuNDU2LjIzYy0xLjEwMy4wMjYtMS41NTYtLjI5My0xLjgwNi0uNjU1LS4yNS0uMzYyLS4zOC0uOTg3LS4wMDItMS45MmwzLjcwOC05LjE3OGMuNzU0LTEuODY2IDMuNzE0LTMuOTkzIDUuOTIxLTQuMDQ2bDguMDA1LS4xOTVjLjg5NC0uMDk4IDEuNTA3LS44OTQgMS4zNTUtMS43NmExLjYzIDEuNjMgMCAwMC0uOTIxLTEuMTgxaC0uMDAyem0yLjUyIDIuMDkzYy0uODExLS4zMTUtMS43MTguMDcxLTIuMDI3Ljg2MmwtLjE4Ni40NjJjLTEuMTgzLjE2NC0yLjMuNzU2LTMuMDYgMS43NTMtMS41NCAyLjAxOC0xLjA5NSA0Ljk1Ni45ODUgNi41MDUuNzE0LjUzMS44NTggMS40NzYuMzMgMi4xNjctLjUzLjY5Mi0xLjQ4OC44MTUtMi4yMDIuMjg1bC0uNjM1LS40N2MtLjY5MS0uNTI3LTEuNjc1LS40MTItMi4yMDIuMjU1LS41MzcuNjgyLS40MTYgMS42NDIuMzI4IDIuMTk3bC42MzUuNDd2LjAwMWMuMTMuMDk2LjI2NC4xODYuNDAyLjI2OS0uMjYuNzYuMTE3IDEuNjA5Ljg4OCAxLjkzMy44Mi4zNDQgMS43NTUtLjAzNyAyLjA3LS44NDRsLjE4NS0uNDU3YzEuMTg0LS4xNjMgMi4zLS43NiAzLjA2Mi0xLjc1OCAxLjU0LTIuMDE3IDEuMDk0LTQuOTU1LS45ODYtNi41MDQtLjcxNC0uNTMxLS44NTgtMS40NzUtLjMzLTIuMTY3LjUzLS42OTEgMS40ODktLjgxNiAyLjIwMy0uMjg2bC42MzQuNDdjLjY5Mi41MjcgMS42NzcuNDEyIDIuMjA0LS4yNTUuNTM3LS42ODEuMzg4LTEuNjc1LS4zMy0yLjE5N2wtLjYzMi0uNDdjLS4xMy0uMDk3LS4yNy0uMTc1LS40MDgtLjI1Ny4yNzUtLjc4LS4xMjctMS42NTItLjkyNy0xLjk2NHpcIlxyXG4gICAgICAgIGZpbGw9XCJjdXJyZW50Q29sb3JcIlxyXG4gICAgICAgIGZpbGxSdWxlPVwiZXZlbm9kZFwiXHJcbiAgICAgIC8+XHJcbiAgICA8L3N2Zz5cclxuICApO1xyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTdmdSd2FJY29uTG9nbztcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9TdmdSd2FJY29uTG9nby50c3gifQ==