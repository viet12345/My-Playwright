import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Switch, Route, Redirect } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import { useActor, useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { CssBaseline } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { snackbarMachine } from "/src/machines/snackbarMachine.ts";
import { notificationsMachine } from "/src/machines/notificationsMachine.ts";
import { authService } from "/src/machines/authMachine.ts";
import AlertBar from "/src/components/AlertBar.tsx";
import SignInForm from "/src/components/SignInForm.tsx";
import SignUpForm from "/src/components/SignUpForm.tsx";
import { bankAccountsMachine } from "/src/machines/bankAccountsMachine.ts";
import PrivateRoutesContainer from "/src/containers/PrivateRoutesContainer.tsx";
const PREFIX = "App";
const classes = {
  root: `${PREFIX}-root`
};
const Root = styled("div")(({ theme }) => ({
  [`&.${classes.root}`]: {
    display: "flex"
  }
}));
_c = Root;
if (window.Cypress) {
  window.authService = authService;
}
const App = () => {
  _s();
  const [authState] = useActor(authService);
  const [, , notificationsService] = useMachine(notificationsMachine);
  const [, , snackbarService] = useMachine(snackbarMachine);
  const [, , bankAccountsService] = useMachine(bankAccountsMachine);
  const isLoggedIn = authState.matches("authorized") || authState.matches("refreshing") || authState.matches("updating");
  return /* @__PURE__ */ jsxDEV(Root, { className: classes.root, children: [
    /* @__PURE__ */ jsxDEV(CssBaseline, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
      lineNumber: 50,
      columnNumber: 7
    }, this),
    isLoggedIn && /* @__PURE__ */ jsxDEV(
      PrivateRoutesContainer,
      {
        isLoggedIn,
        notificationsService,
        authService,
        snackbarService,
        bankAccountsService
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 53,
        columnNumber: 7
      },
      this
    ),
    authState.matches("unauthorized") && /* @__PURE__ */ jsxDEV(Switch, { children: [
      /* @__PURE__ */ jsxDEV(Route, { exact: true, path: "/signup", children: /* @__PURE__ */ jsxDEV(SignUpForm, { authService }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 64,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 63,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { exact: true, path: "/signin", children: /* @__PURE__ */ jsxDEV(SignInForm, { authService }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 67,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 66,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Route, { path: "/*", children: /* @__PURE__ */ jsxDEV(
        Redirect,
        {
          to: {
            pathname: "/signin"
          }
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
          lineNumber: 70,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
        lineNumber: 69,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
      lineNumber: 62,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(AlertBar, { snackbarService }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
      lineNumber: 78,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx",
    lineNumber: 49,
    columnNumber: 5
  }, this);
};
_s(App, "5aL7SgwMO4IYGu3lbnqzlfix+sY=", false, function() {
  return [useActor, useMachine, useMachine, useMachine];
});
_c2 = App;
export default App;
var _c, _c2;
$RefreshReg$(_c, "Root");
$RefreshReg$(_c2, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/App.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaURNOzJCQWpETjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBQ3ZCLFNBQVNDLFFBQVFDLE9BQU9DLGdCQUFnQjtBQUN4QyxTQUFTQyxVQUFVQyxrQkFBa0I7QUFDckMsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLHVCQUF1QjtBQUNoQyxTQUFTQyw0QkFBNEI7QUFDckMsU0FBU0MsbUJBQW1CO0FBQzVCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLGdCQUFnQjtBQUN2QixTQUFTQywyQkFBMkI7QUFDcEMsT0FBT0MsNEJBQTRCO0FBRW5DLE1BQU1DLFNBQVM7QUFFZixNQUFNQyxVQUFVO0FBQUEsRUFDZEMsTUFBTSxHQUFHRixNQUFNO0FBQ2pCO0FBRUEsTUFBTUcsT0FBT2xCLE9BQU8sS0FBSyxFQUFFLENBQUMsRUFBRW1CLE1BQU0sT0FBTztBQUFBLEVBQ3pDLENBQUMsS0FBS0gsUUFBUUMsSUFBSSxFQUFFLEdBQUc7QUFBQSxJQUNyQkcsU0FBUztBQUFBLEVBQ1g7QUFDRixFQUFFO0FBRUZDLEtBTk1IO0FBT04sSUFBSUksT0FBT0MsU0FBUztBQUdsQkQsU0FBT2IsY0FBY0E7QUFDdkI7QUFFQSxNQUFNZSxNQUFnQkEsTUFBTTtBQUFBQyxLQUFBO0FBQzFCLFFBQU0sQ0FBQ0MsU0FBUyxJQUFJdEIsU0FBU0ssV0FBVztBQUN4QyxRQUFNLEtBQUtrQixvQkFBb0IsSUFBSXRCLFdBQVdHLG9CQUFvQjtBQUVsRSxRQUFNLEtBQUtvQixlQUFlLElBQUl2QixXQUFXRSxlQUFlO0FBRXhELFFBQU0sS0FBS3NCLG1CQUFtQixJQUFJeEIsV0FBV1EsbUJBQW1CO0FBRWhFLFFBQU1pQixhQUNKSixVQUFVSyxRQUFRLFlBQVksS0FDOUJMLFVBQVVLLFFBQVEsWUFBWSxLQUM5QkwsVUFBVUssUUFBUSxVQUFVO0FBRTlCLFNBQ0UsdUJBQUMsUUFBSyxXQUFXZixRQUFRQyxNQUN2QjtBQUFBLDJCQUFDLGlCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBWTtBQUFBLElBRVhhLGNBQ0M7QUFBQSxNQUFDO0FBQUE7QUFBQSxRQUNDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBO0FBQUEsTUFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFLMkM7QUFBQSxJQUc1Q0osVUFBVUssUUFBUSxjQUFjLEtBQy9CLHVCQUFDLFVBQ0M7QUFBQSw2QkFBQyxTQUFNLE9BQUssTUFBQyxNQUFLLFdBQ2hCLGlDQUFDLGNBQVcsZUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDLEtBRHZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsU0FBTSxPQUFLLE1BQUMsTUFBSyxXQUNoQixpQ0FBQyxjQUFXLGVBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBLHVCQUFDLFNBQU0sTUFBSyxNQUNWO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxJQUFJO0FBQUEsWUFDRkMsVUFBVTtBQUFBLFVBQ1o7QUFBQTtBQUFBLFFBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR0ksS0FKTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUE7QUFBQSxTQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FjQTtBQUFBLElBRUYsdUJBQUMsWUFBUyxtQkFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTJDO0FBQUEsT0E3QjdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4QkE7QUFFSjtBQUFFUCxHQTlDSUQsS0FBYTtBQUFBLFVBQ0dwQixVQUNlQyxZQUVMQSxZQUVJQSxVQUFVO0FBQUE7QUFBQTRCLE1BTnhDVDtBQWdETixlQUFlQTtBQUFJLElBQUFILElBQUFZO0FBQUFDLGFBQUFiLElBQUE7QUFBQWEsYUFBQUQsS0FBQSIsIm5hbWVzIjpbInN0eWxlZCIsIlN3aXRjaCIsIlJvdXRlIiwiUmVkaXJlY3QiLCJ1c2VBY3RvciIsInVzZU1hY2hpbmUiLCJDc3NCYXNlbGluZSIsInNuYWNrYmFyTWFjaGluZSIsIm5vdGlmaWNhdGlvbnNNYWNoaW5lIiwiYXV0aFNlcnZpY2UiLCJBbGVydEJhciIsIlNpZ25JbkZvcm0iLCJTaWduVXBGb3JtIiwiYmFua0FjY291bnRzTWFjaGluZSIsIlByaXZhdGVSb3V0ZXNDb250YWluZXIiLCJQUkVGSVgiLCJjbGFzc2VzIiwicm9vdCIsIlJvb3QiLCJ0aGVtZSIsImRpc3BsYXkiLCJfYyIsIndpbmRvdyIsIkN5cHJlc3MiLCJBcHAiLCJfcyIsImF1dGhTdGF0ZSIsIm5vdGlmaWNhdGlvbnNTZXJ2aWNlIiwic25hY2tiYXJTZXJ2aWNlIiwiYmFua0FjY291bnRzU2VydmljZSIsImlzTG9nZ2VkSW4iLCJtYXRjaGVzIiwicGF0aG5hbWUiLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IFN3aXRjaCwgUm91dGUsIFJlZGlyZWN0IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlQWN0b3IsIHVzZU1hY2hpbmUgfSBmcm9tIFwiQHhzdGF0ZS9yZWFjdFwiO1xyXG5pbXBvcnQgeyBDc3NCYXNlbGluZSB9IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcblxyXG5pbXBvcnQgeyBzbmFja2Jhck1hY2hpbmUgfSBmcm9tIFwiLi4vbWFjaGluZXMvc25hY2tiYXJNYWNoaW5lXCI7XHJcbmltcG9ydCB7IG5vdGlmaWNhdGlvbnNNYWNoaW5lIH0gZnJvbSBcIi4uL21hY2hpbmVzL25vdGlmaWNhdGlvbnNNYWNoaW5lXCI7XHJcbmltcG9ydCB7IGF1dGhTZXJ2aWNlIH0gZnJvbSBcIi4uL21hY2hpbmVzL2F1dGhNYWNoaW5lXCI7XHJcbmltcG9ydCBBbGVydEJhciBmcm9tIFwiLi4vY29tcG9uZW50cy9BbGVydEJhclwiO1xyXG5pbXBvcnQgU2lnbkluRm9ybSBmcm9tIFwiLi4vY29tcG9uZW50cy9TaWduSW5Gb3JtXCI7XHJcbmltcG9ydCBTaWduVXBGb3JtIGZyb20gXCIuLi9jb21wb25lbnRzL1NpZ25VcEZvcm1cIjtcclxuaW1wb3J0IHsgYmFua0FjY291bnRzTWFjaGluZSB9IGZyb20gXCIuLi9tYWNoaW5lcy9iYW5rQWNjb3VudHNNYWNoaW5lXCI7XHJcbmltcG9ydCBQcml2YXRlUm91dGVzQ29udGFpbmVyIGZyb20gXCIuL1ByaXZhdGVSb3V0ZXNDb250YWluZXJcIjtcclxuXHJcbmNvbnN0IFBSRUZJWCA9IFwiQXBwXCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHJvb3Q6IGAke1BSRUZJWH0tcm9vdGAsXHJcbn07XHJcblxyXG5jb25zdCBSb290ID0gc3R5bGVkKFwiZGl2XCIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmLiR7Y2xhc3Nlcy5yb290fWBdOiB7XHJcbiAgICBkaXNwbGF5OiBcImZsZXhcIixcclxuICB9LFxyXG59KSk7XHJcblxyXG4vLyBAdHMtaWdub3JlXHJcbmlmICh3aW5kb3cuQ3lwcmVzcykge1xyXG4gIC8vIEV4cG9zZSBhdXRoU2VydmljZSBvbiB3aW5kb3cgZm9yIEN5cHJlc3NcclxuICAvLyBAdHMtaWdub3JlXHJcbiAgd2luZG93LmF1dGhTZXJ2aWNlID0gYXV0aFNlcnZpY2U7XHJcbn1cclxuXHJcbmNvbnN0IEFwcDogUmVhY3QuRkMgPSAoKSA9PiB7XHJcbiAgY29uc3QgW2F1dGhTdGF0ZV0gPSB1c2VBY3RvcihhdXRoU2VydmljZSk7XHJcbiAgY29uc3QgWywgLCBub3RpZmljYXRpb25zU2VydmljZV0gPSB1c2VNYWNoaW5lKG5vdGlmaWNhdGlvbnNNYWNoaW5lKTtcclxuXHJcbiAgY29uc3QgWywgLCBzbmFja2JhclNlcnZpY2VdID0gdXNlTWFjaGluZShzbmFja2Jhck1hY2hpbmUpO1xyXG5cclxuICBjb25zdCBbLCAsIGJhbmtBY2NvdW50c1NlcnZpY2VdID0gdXNlTWFjaGluZShiYW5rQWNjb3VudHNNYWNoaW5lKTtcclxuXHJcbiAgY29uc3QgaXNMb2dnZWRJbiA9XHJcbiAgICBhdXRoU3RhdGUubWF0Y2hlcyhcImF1dGhvcml6ZWRcIikgfHxcclxuICAgIGF1dGhTdGF0ZS5tYXRjaGVzKFwicmVmcmVzaGluZ1wiKSB8fFxyXG4gICAgYXV0aFN0YXRlLm1hdGNoZXMoXCJ1cGRhdGluZ1wiKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxSb290IGNsYXNzTmFtZT17Y2xhc3Nlcy5yb290fT5cclxuICAgICAgPENzc0Jhc2VsaW5lIC8+XHJcblxyXG4gICAgICB7aXNMb2dnZWRJbiAmJiAoXHJcbiAgICAgICAgPFByaXZhdGVSb3V0ZXNDb250YWluZXJcclxuICAgICAgICAgIGlzTG9nZ2VkSW49e2lzTG9nZ2VkSW59XHJcbiAgICAgICAgICBub3RpZmljYXRpb25zU2VydmljZT17bm90aWZpY2F0aW9uc1NlcnZpY2V9XHJcbiAgICAgICAgICBhdXRoU2VydmljZT17YXV0aFNlcnZpY2V9XHJcbiAgICAgICAgICBzbmFja2JhclNlcnZpY2U9e3NuYWNrYmFyU2VydmljZX1cclxuICAgICAgICAgIGJhbmtBY2NvdW50c1NlcnZpY2U9e2JhbmtBY2NvdW50c1NlcnZpY2V9XHJcbiAgICAgICAgLz5cclxuICAgICAgKX1cclxuICAgICAge2F1dGhTdGF0ZS5tYXRjaGVzKFwidW5hdXRob3JpemVkXCIpICYmIChcclxuICAgICAgICA8U3dpdGNoPlxyXG4gICAgICAgICAgPFJvdXRlIGV4YWN0IHBhdGg9XCIvc2lnbnVwXCI+XHJcbiAgICAgICAgICAgIDxTaWduVXBGb3JtIGF1dGhTZXJ2aWNlPXthdXRoU2VydmljZX0gLz5cclxuICAgICAgICAgIDwvUm91dGU+XHJcbiAgICAgICAgICA8Um91dGUgZXhhY3QgcGF0aD1cIi9zaWduaW5cIj5cclxuICAgICAgICAgICAgPFNpZ25JbkZvcm0gYXV0aFNlcnZpY2U9e2F1dGhTZXJ2aWNlfSAvPlxyXG4gICAgICAgICAgPC9Sb3V0ZT5cclxuICAgICAgICAgIDxSb3V0ZSBwYXRoPVwiLypcIj5cclxuICAgICAgICAgICAgPFJlZGlyZWN0XHJcbiAgICAgICAgICAgICAgdG89e3tcclxuICAgICAgICAgICAgICAgIHBhdGhuYW1lOiBcIi9zaWduaW5cIixcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAvPlxyXG4gICAgICAgICAgPC9Sb3V0ZT5cclxuICAgICAgICA8L1N3aXRjaD5cclxuICAgICAgKX1cclxuICAgICAgPEFsZXJ0QmFyIHNuYWNrYmFyU2VydmljZT17c25hY2tiYXJTZXJ2aWNlfSAvPlxyXG4gICAgPC9Sb290PlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBcHA7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbnRhaW5lcnMvQXBwLnRzeCJ9