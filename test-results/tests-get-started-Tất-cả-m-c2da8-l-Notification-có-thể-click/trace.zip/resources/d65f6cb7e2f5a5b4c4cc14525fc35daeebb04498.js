import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AlertBar.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/AlertBar.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Snackbar } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Alert } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const AlertBar = ({ snackbarService }) => {
  _s();
  const [snackbarState] = useActor(snackbarService);
  return /* @__PURE__ */ jsxDEV(
    Snackbar,
    {
      anchorOrigin: { vertical: "bottom", horizontal: "left" },
      open: snackbarState?.matches("visible"),
      autoHideDuration: 3e3,
      children: /* @__PURE__ */ jsxDEV(
        Alert,
        {
          "data-test": `alert-bar-${snackbarState?.context.severity}`,
          elevation: 6,
          variant: "filled",
          severity: snackbarState?.context.severity,
          children: snackbarState?.context.message
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/AlertBar.tsx",
          lineNumber: 33,
          columnNumber: 7
        },
        this
      )
    },
    void 0,
    false,
    {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/AlertBar.tsx",
      lineNumber: 28,
      columnNumber: 5
    },
    this
  );
};
_s(AlertBar, "EhDkAbvUhcXqe3cChqYfD9cldJc=", false, function() {
  return [useActor];
});
_c = AlertBar;
export default AlertBar;
var _c;
$RefreshReg$(_c, "AlertBar");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/AlertBar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/AlertBar.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NNOzJCQWhDTjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxnQkFBZ0I7QUFTekIsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLGFBQWE7QUFZdEIsTUFBTUMsV0FBNEJBLENBQUMsRUFBRUMsZ0JBQWdCLE1BQU07QUFBQUMsS0FBQTtBQUN6RCxRQUFNLENBQUNDLGFBQWEsSUFBSUwsU0FBU0csZUFBZTtBQUVoRCxTQUNFO0FBQUEsSUFBQztBQUFBO0FBQUEsTUFDQyxjQUFjLEVBQUVHLFVBQVUsVUFBVUMsWUFBWSxPQUFPO0FBQUEsTUFDdkQsTUFBTUYsZUFBZUcsUUFBUSxTQUFTO0FBQUEsTUFDdEMsa0JBQWtCO0FBQUEsTUFFbEI7QUFBQSxRQUFDO0FBQUE7QUFBQSxVQUNDLGFBQVcsYUFBYUgsZUFBZUksUUFBUUMsUUFBUTtBQUFBLFVBQ3ZELFdBQVc7QUFBQSxVQUNYLFNBQVE7QUFBQSxVQUNSLFVBQVVMLGVBQWVJLFFBQVFDO0FBQUFBLFVBRWhDTCx5QkFBZUksUUFBUUU7QUFBQUE7QUFBQUEsUUFOMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BT0E7QUFBQTtBQUFBLElBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBYUE7QUFFSjtBQUFFUCxHQW5CSUYsVUFBeUI7QUFBQSxVQUNMRixRQUFRO0FBQUE7QUFBQVksS0FENUJWO0FBcUJOLGVBQWVBO0FBQVMsSUFBQVU7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNuYWNrYmFyIiwidXNlQWN0b3IiLCJBbGVydCIsIkFsZXJ0QmFyIiwic25hY2tiYXJTZXJ2aWNlIiwiX3MiLCJzbmFja2JhclN0YXRlIiwidmVydGljYWwiLCJob3Jpem9udGFsIiwibWF0Y2hlcyIsImNvbnRleHQiLCJzZXZlcml0eSIsIm1lc3NhZ2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFsZXJ0QmFyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IFNuYWNrYmFyIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuaW1wb3J0IHtcclxuICBCYXNlQWN0aW9uT2JqZWN0LFxyXG4gIEludGVycHJldGVyLFxyXG4gIFJlc29sdmVUeXBlZ2VuTWV0YSxcclxuICBTZXJ2aWNlTWFwLFxyXG4gIFR5cGVnZW5EaXNhYmxlZCxcclxufSBmcm9tIFwieHN0YXRlXCI7XHJcbmltcG9ydCB7IFNuYWNrYmFyQ29udGV4dCwgU25hY2tiYXJTY2hlbWEsIFNuYWNrYmFyRXZlbnRzIH0gZnJvbSBcIi4uL21hY2hpbmVzL3NuYWNrYmFyTWFjaGluZVwiO1xyXG5pbXBvcnQgeyB1c2VBY3RvciB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWxcIjtcclxuXHJcbmludGVyZmFjZSBQcm9wcyB7XHJcbiAgc25hY2tiYXJTZXJ2aWNlOiBJbnRlcnByZXRlcjxcclxuICAgIFNuYWNrYmFyQ29udGV4dCxcclxuICAgIFNuYWNrYmFyU2NoZW1hLFxyXG4gICAgU25hY2tiYXJFdmVudHMsXHJcbiAgICBhbnksXHJcbiAgICBSZXNvbHZlVHlwZWdlbk1ldGE8VHlwZWdlbkRpc2FibGVkLCBTbmFja2JhckV2ZW50cywgQmFzZUFjdGlvbk9iamVjdCwgU2VydmljZU1hcD5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBBbGVydEJhcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgc25hY2tiYXJTZXJ2aWNlIH0pID0+IHtcclxuICBjb25zdCBbc25hY2tiYXJTdGF0ZV0gPSB1c2VBY3RvcihzbmFja2JhclNlcnZpY2UpO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPFNuYWNrYmFyXHJcbiAgICAgIGFuY2hvck9yaWdpbj17eyB2ZXJ0aWNhbDogXCJib3R0b21cIiwgaG9yaXpvbnRhbDogXCJsZWZ0XCIgfX1cclxuICAgICAgb3Blbj17c25hY2tiYXJTdGF0ZT8ubWF0Y2hlcyhcInZpc2libGVcIil9XHJcbiAgICAgIGF1dG9IaWRlRHVyYXRpb249ezMwMDB9XHJcbiAgICA+XHJcbiAgICAgIDxBbGVydFxyXG4gICAgICAgIGRhdGEtdGVzdD17YGFsZXJ0LWJhci0ke3NuYWNrYmFyU3RhdGU/LmNvbnRleHQuc2V2ZXJpdHl9YH1cclxuICAgICAgICBlbGV2YXRpb249ezZ9XHJcbiAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgc2V2ZXJpdHk9e3NuYWNrYmFyU3RhdGU/LmNvbnRleHQuc2V2ZXJpdHl9XHJcbiAgICAgID5cclxuICAgICAgICB7c25hY2tiYXJTdGF0ZT8uY29udGV4dC5tZXNzYWdlfVxyXG4gICAgICA8L0FsZXJ0PlxyXG4gICAgPC9TbmFja2Jhcj5cclxuICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQWxlcnRCYXI7XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvQWxlcnRCYXIudHN4In0=