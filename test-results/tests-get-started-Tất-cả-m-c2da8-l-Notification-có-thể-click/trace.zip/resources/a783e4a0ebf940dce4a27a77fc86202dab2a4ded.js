import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TransactionCreateStepThree.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { Link as RouterLink, useHistory } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import { Paper, Typography, Grid, Avatar, Box, Button } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { formatAmount } from "/src/utils/transactionUtils.ts";
const PREFIX = "TransactionCreateStepThree";
const classes = {
  paper: `${PREFIX}-paper`
};
const StyledPaper = styled(Paper)(({ theme }) => ({
  [`&.${classes.paper}`]: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  }
}));
_c = StyledPaper;
const TransactionCreateStepThree = ({
  createTransactionService
}) => {
  _s();
  const history = useHistory();
  const [createTransactionState, sendCreateTransaction] = useActor(createTransactionService);
  const receiver = createTransactionState?.context?.receiver;
  const transactionDetails = createTransactionState?.context?.transactionDetails;
  return /* @__PURE__ */ jsxDEV(StyledPaper, { className: classes.paper, elevation: 0, children: [
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        display: "flex",
        justifyContent: "center",
        width: "95%",
        "min-height": 200,
        height: 200,
        style: { paddingTop: "5%" },
        children: /* @__PURE__ */ jsxDEV(
          Grid,
          {
            container: true,
            direction: "row",
            justifyContent: "space-around",
            alignItems: "center",
            spacing: 4,
            children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "column", justifyContent: "flex-start", alignItems: "center", children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Avatar, { src: receiver.avatar }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
                lineNumber: 79,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
                lineNumber: 78,
                columnNumber: 15
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: [
                receiver.firstName,
                " ",
                receiver.lastName
              ] }, void 0, true, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
                lineNumber: 82,
                columnNumber: 17
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
                lineNumber: 81,
                columnNumber: 15
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
              lineNumber: 77,
              columnNumber: 13
            }, this) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
              lineNumber: 76,
              columnNumber: 11
            }, this)
          },
          void 0,
          false,
          {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
            lineNumber: 69,
            columnNumber: 9
          },
          this
        )
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
        lineNumber: 61,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        display: "flex",
        justifyContent: "center",
        width: "100%",
        height: "100",
        style: { paddingBottom: "5%" },
        children: /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", justifyContent: "center", alignItems: "center", children: /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Typography, { component: "h2", variant: "h6", color: "primary", gutterBottom: true, children: [
          transactionDetails?.transactionType === "payment" ? "Paid " : "Requested ",
          transactionDetails?.amount && formatAmount(parseInt(transactionDetails.amount, 10) * 100),
          " ",
          "for ",
          transactionDetails?.description
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
          lineNumber: 99,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
          lineNumber: 98,
          columnNumber: 11
        }, this) }, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
          lineNumber: 97,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
        lineNumber: 90,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV(
      Box,
      {
        display: "flex",
        justifyContent: "center",
        width: "100%",
        height: "100",
        style: { paddingBottom: "5%" },
        children: /* @__PURE__ */ jsxDEV(Grid, { container: true, direction: "row", justifyContent: "space-around", alignItems: "center", children: [
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "contained",
              size: "small",
              component: RouterLink,
              to: "/",
              "data-test": "new-transaction-return-to-transactions",
              children: "Return To Transactions"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
              lineNumber: 117,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
            lineNumber: 116,
            columnNumber: 11
          }, this),
          /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
            Button,
            {
              variant: "contained",
              size: "small",
              onClick: () => {
                sendCreateTransaction("RESET");
                history.push("/transaction/new");
              },
              "data-test": "new-transaction-create-another-transaction",
              children: "Create Another Transaction"
            },
            void 0,
            false,
            {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
              lineNumber: 128,
              columnNumber: 13
            },
            this
          ) }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
            lineNumber: 127,
            columnNumber: 11
          }, this)
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
          lineNumber: 115,
          columnNumber: 9
        }, this)
      },
      void 0,
      false,
      {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
        lineNumber: 108,
        columnNumber: 7
      },
      this
    )
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx",
    lineNumber: 60,
    columnNumber: 5
  }, this);
};
_s(TransactionCreateStepThree, "C52zo2AOMOxfzjiIxZeKCMLqcIc=", false, function() {
  return [useHistory, useActor];
});
_c2 = TransactionCreateStepThree;
export default TransactionCreateStepThree;
var _c, _c2;
$RefreshReg$(_c, "StyledPaper");
$RefreshReg$(_c2, "TransactionCreateStepThree");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/TransactionCreateStepThree.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBOEVnQjsyQkE5RWhCO0FBQWtCLE1BQU87QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ3pCLFNBQVNBLGNBQWM7QUFDdkIsU0FBU0MsUUFBUUMsWUFBWUMsa0JBQWtCO0FBQy9DLFNBQVNDLE9BQU9DLFlBQVlDLE1BQU1DLFFBQVFDLEtBQUtDLGNBQWM7QUFhN0QsU0FBU0MsZ0JBQWdCO0FBQ3pCLFNBQVNDLG9CQUFvQjtBQUU3QixNQUFNQyxTQUFTO0FBRWYsTUFBTUMsVUFBVTtBQUFBLEVBQ2RDLE9BQU8sR0FBR0YsTUFBTTtBQUNsQjtBQUVBLE1BQU1HLGNBQWNmLE9BQU9JLEtBQUssRUFBRSxDQUFDLEVBQUVZLE1BQU0sT0FBTztBQUFBLEVBQ2hELENBQUMsS0FBS0gsUUFBUUMsS0FBSyxFQUFFLEdBQUc7QUFBQSxJQUN0QkcsU0FBUztBQUFBLElBQ1RDLGVBQWU7QUFBQSxJQUNmQyxZQUFZO0FBQUEsRUFDZDtBQUNGLEVBQUU7QUFBRUMsS0FORUw7QUF1Qk4sTUFBTU0sNkJBQXdFQSxDQUFDO0FBQUEsRUFDN0VDO0FBQ0YsTUFBTTtBQUFBQyxLQUFBO0FBQ0osUUFBTUMsVUFBVXJCLFdBQVc7QUFFM0IsUUFBTSxDQUFDc0Isd0JBQXdCQyxxQkFBcUIsSUFBSWhCLFNBQVNZLHdCQUF3QjtBQUV6RixRQUFNSyxXQUFXRix3QkFBd0JHLFNBQVNEO0FBQ2xELFFBQU1FLHFCQUFxQkosd0JBQXdCRyxTQUFTQztBQUU1RCxTQUNFLHVCQUFDLGVBQVksV0FBV2hCLFFBQVFDLE9BQU8sV0FBVyxHQUNoRDtBQUFBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixnQkFBZTtBQUFBLFFBQ2YsT0FBTTtBQUFBLFFBQ04sY0FBWTtBQUFBLFFBQ1osUUFBUTtBQUFBLFFBQ1IsT0FBTyxFQUFFZ0IsWUFBWSxLQUFLO0FBQUEsUUFFMUI7QUFBQSxVQUFDO0FBQUE7QUFBQSxZQUNDO0FBQUEsWUFDQSxXQUFVO0FBQUEsWUFDVixnQkFBZTtBQUFBLFlBQ2YsWUFBVztBQUFBLFlBQ1gsU0FBUztBQUFBLFlBRVQsaUNBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsUUFBSyxXQUFTLE1BQUMsV0FBVSxVQUFTLGdCQUFlLGNBQWEsWUFBVyxVQUN4RTtBQUFBLHFDQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLFVBQU8sS0FBS0gsU0FBU0ksVUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBNkIsS0FEL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQTtBQUFBLGNBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1IsaUNBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxNQUFLLE9BQU0sV0FBVSxjQUFZLE1BQ2pFSjtBQUFBQSx5QkFBU0s7QUFBQUEsZ0JBQVU7QUFBQSxnQkFBRUwsU0FBU007QUFBQUEsbUJBRGpDO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUlBO0FBQUEsaUJBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFTQSxLQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBV0E7QUFBQTtBQUFBLFVBbEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQW1CQTtBQUFBO0FBQUEsTUEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBNEJBO0FBQUEsSUFDQTtBQUFBLE1BQUM7QUFBQTtBQUFBLFFBQ0MsU0FBUTtBQUFBLFFBQ1IsZ0JBQWU7QUFBQSxRQUNmLE9BQU07QUFBQSxRQUNOLFFBQU87QUFBQSxRQUNQLE9BQU8sRUFBRUMsZUFBZSxLQUFLO0FBQUEsUUFFN0IsaUNBQUMsUUFBSyxXQUFTLE1BQUMsV0FBVSxPQUFNLGdCQUFlLFVBQVMsWUFBVyxVQUNqRSxpQ0FBQyxRQUFLLE1BQUksTUFDUixpQ0FBQyxjQUFXLFdBQVUsTUFBSyxTQUFRLE1BQUssT0FBTSxXQUFVLGNBQVksTUFDakVMO0FBQUFBLDhCQUFvQk0sb0JBQW9CLFlBQVksVUFBVTtBQUFBLFVBQzlETixvQkFBb0JPLFVBQ25CekIsYUFBYTBCLFNBQVNSLG1CQUFtQk8sUUFBUSxFQUFFLElBQUksR0FBRztBQUFBLFVBQUc7QUFBQSxVQUFJO0FBQUEsVUFDOURQLG9CQUFvQlM7QUFBQUEsYUFKM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBLEtBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVNBO0FBQUE7QUFBQSxNQWhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFpQkE7QUFBQSxJQUNBO0FBQUEsTUFBQztBQUFBO0FBQUEsUUFDQyxTQUFRO0FBQUEsUUFDUixnQkFBZTtBQUFBLFFBQ2YsT0FBTTtBQUFBLFFBQ04sUUFBTztBQUFBLFFBQ1AsT0FBTyxFQUFFSixlQUFlLEtBQUs7QUFBQSxRQUU3QixpQ0FBQyxRQUFLLFdBQVMsTUFBQyxXQUFVLE9BQU0sZ0JBQWUsZ0JBQWUsWUFBVyxVQUN2RTtBQUFBLGlDQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsWUFBQztBQUFBO0FBQUEsY0FDQyxTQUFRO0FBQUEsY0FDUixNQUFLO0FBQUEsY0FDTCxXQUFXaEM7QUFBQUEsY0FDWCxJQUFHO0FBQUEsY0FDSCxhQUFVO0FBQUEsY0FBd0M7QUFBQTtBQUFBLFlBTHBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFVQTtBQUFBLFVBQ0EsdUJBQUMsUUFBSyxNQUFJLE1BQ1I7QUFBQSxZQUFDO0FBQUE7QUFBQSxjQUNDLFNBQVE7QUFBQSxjQUNSLE1BQUs7QUFBQSxjQUVMLFNBQVMsTUFBTTtBQUNid0Isc0NBQXNCLE9BQU87QUFDN0JGLHdCQUFRZSxLQUFLLGtCQUFrQjtBQUFBLGNBQ2pDO0FBQUEsY0FDQSxhQUFVO0FBQUEsY0FBNEM7QUFBQTtBQUFBLFlBUnhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxVQVdBLEtBWkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFhQTtBQUFBLGFBekJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUEwQkE7QUFBQTtBQUFBLE1BakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQWtDQTtBQUFBLE9BbEZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FtRkE7QUFFSjtBQUFFaEIsR0FoR0lGLDRCQUFxRTtBQUFBLFVBR3pEbEIsWUFFd0NPLFFBQVE7QUFBQTtBQUFBOEIsTUFMNURuQjtBQWtHTixlQUFlQTtBQUEyQixJQUFBRCxJQUFBb0I7QUFBQUMsYUFBQXJCLElBQUE7QUFBQXFCLGFBQUFELEtBQUEiLCJuYW1lcyI6WyJzdHlsZWQiLCJMaW5rIiwiUm91dGVyTGluayIsInVzZUhpc3RvcnkiLCJQYXBlciIsIlR5cG9ncmFwaHkiLCJHcmlkIiwiQXZhdGFyIiwiQm94IiwiQnV0dG9uIiwidXNlQWN0b3IiLCJmb3JtYXRBbW91bnQiLCJQUkVGSVgiLCJjbGFzc2VzIiwicGFwZXIiLCJTdHlsZWRQYXBlciIsInRoZW1lIiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJhbGlnbkl0ZW1zIiwiX2MiLCJUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZSIsImNyZWF0ZVRyYW5zYWN0aW9uU2VydmljZSIsIl9zIiwiaGlzdG9yeSIsImNyZWF0ZVRyYW5zYWN0aW9uU3RhdGUiLCJzZW5kQ3JlYXRlVHJhbnNhY3Rpb24iLCJyZWNlaXZlciIsImNvbnRleHQiLCJ0cmFuc2FjdGlvbkRldGFpbHMiLCJwYWRkaW5nVG9wIiwiYXZhdGFyIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJwYWRkaW5nQm90dG9tIiwidHJhbnNhY3Rpb25UeXBlIiwiYW1vdW50IiwicGFyc2VJbnQiLCJkZXNjcmlwdGlvbiIsInB1c2giLCJfYzIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZS50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyBzdHlsZWQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbC9zdHlsZXNcIjtcclxuaW1wb3J0IHsgTGluayBhcyBSb3V0ZXJMaW5rLCB1c2VIaXN0b3J5IH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgUGFwZXIsIFR5cG9ncmFwaHksIEdyaWQsIEF2YXRhciwgQm94LCBCdXR0b24gfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQge1xyXG4gIEJhc2VBY3Rpb25PYmplY3QsXHJcbiAgSW50ZXJwcmV0ZXIsXHJcbiAgUmVzb2x2ZVR5cGVnZW5NZXRhLFxyXG4gIFNlcnZpY2VNYXAsXHJcbiAgVHlwZWdlbkRpc2FibGVkLFxyXG59IGZyb20gXCJ4c3RhdGVcIjtcclxuaW1wb3J0IHtcclxuICBDcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVDb250ZXh0LFxyXG4gIENyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZUV2ZW50cyxcclxuICBDcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVTY2hlbWEsXHJcbn0gZnJvbSBcIi4uL21hY2hpbmVzL2NyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZVwiO1xyXG5pbXBvcnQgeyB1c2VBY3RvciB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7IGZvcm1hdEFtb3VudCB9IGZyb20gXCIuLi91dGlscy90cmFuc2FjdGlvblV0aWxzXCI7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlRyYW5zYWN0aW9uQ3JlYXRlU3RlcFRocmVlXCI7XHJcblxyXG5jb25zdCBjbGFzc2VzID0ge1xyXG4gIHBhcGVyOiBgJHtQUkVGSVh9LXBhcGVyYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZFBhcGVyID0gc3R5bGVkKFBhcGVyKSgoeyB0aGVtZSB9KSA9PiAoe1xyXG4gIFtgJi4ke2NsYXNzZXMucGFwZXJ9YF06IHtcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgfSxcclxufSkpO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZVByb3BzIHtcclxuICBjcmVhdGVUcmFuc2FjdGlvblNlcnZpY2U6IEludGVycHJldGVyPFxyXG4gICAgQ3JlYXRlVHJhbnNhY3Rpb25NYWNoaW5lQ29udGV4dCxcclxuICAgIENyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZVNjaGVtYSxcclxuICAgIENyZWF0ZVRyYW5zYWN0aW9uTWFjaGluZUV2ZW50cyxcclxuICAgIGFueSxcclxuICAgIFJlc29sdmVUeXBlZ2VuTWV0YTxcclxuICAgICAgVHlwZWdlbkRpc2FibGVkLFxyXG4gICAgICBDcmVhdGVUcmFuc2FjdGlvbk1hY2hpbmVFdmVudHMsXHJcbiAgICAgIEJhc2VBY3Rpb25PYmplY3QsXHJcbiAgICAgIFNlcnZpY2VNYXBcclxuICAgID5cclxuICA+O1xyXG59XHJcblxyXG5jb25zdCBUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZTogUmVhY3QuRkM8VHJhbnNhY3Rpb25DcmVhdGVTdGVwVGhyZWVQcm9wcz4gPSAoe1xyXG4gIGNyZWF0ZVRyYW5zYWN0aW9uU2VydmljZSxcclxufSkgPT4ge1xyXG4gIGNvbnN0IGhpc3RvcnkgPSB1c2VIaXN0b3J5KCk7XHJcblxyXG4gIGNvbnN0IFtjcmVhdGVUcmFuc2FjdGlvblN0YXRlLCBzZW5kQ3JlYXRlVHJhbnNhY3Rpb25dID0gdXNlQWN0b3IoY3JlYXRlVHJhbnNhY3Rpb25TZXJ2aWNlKTtcclxuXHJcbiAgY29uc3QgcmVjZWl2ZXIgPSBjcmVhdGVUcmFuc2FjdGlvblN0YXRlPy5jb250ZXh0Py5yZWNlaXZlcjtcclxuICBjb25zdCB0cmFuc2FjdGlvbkRldGFpbHMgPSBjcmVhdGVUcmFuc2FjdGlvblN0YXRlPy5jb250ZXh0Py50cmFuc2FjdGlvbkRldGFpbHM7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkUGFwZXIgY2xhc3NOYW1lPXtjbGFzc2VzLnBhcGVyfSBlbGV2YXRpb249ezB9PlxyXG4gICAgICA8Qm94XHJcbiAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICB3aWR0aD1cIjk1JVwiXHJcbiAgICAgICAgbWluLWhlaWdodD17MjAwfVxyXG4gICAgICAgIGhlaWdodD17MjAwfVxyXG4gICAgICAgIHN0eWxlPXt7IHBhZGRpbmdUb3A6IFwiNSVcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPEdyaWRcclxuICAgICAgICAgIGNvbnRhaW5lclxyXG4gICAgICAgICAgZGlyZWN0aW9uPVwicm93XCJcclxuICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYXJvdW5kXCJcclxuICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgc3BhY2luZz17NH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICA8R3JpZCBjb250YWluZXIgZGlyZWN0aW9uPVwiY29sdW1uXCIganVzdGlmeUNvbnRlbnQ9XCJmbGV4LXN0YXJ0XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgICAgICA8QXZhdGFyIHNyYz17cmVjZWl2ZXIuYXZhdGFyfSAvPlxyXG4gICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgY29tcG9uZW50PVwiaDJcIiB2YXJpYW50PVwiaDZcIiBjb2xvcj1cInByaW1hcnlcIiBndXR0ZXJCb3R0b20+XHJcbiAgICAgICAgICAgICAgICAgIHtyZWNlaXZlci5maXJzdE5hbWV9IHtyZWNlaXZlci5sYXN0TmFtZX1cclxuICAgICAgICAgICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8L0dyaWQ+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgICA8Qm94XHJcbiAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICB3aWR0aD1cIjEwMCVcIlxyXG4gICAgICAgIGhlaWdodD1cIjEwMFwiXHJcbiAgICAgICAgc3R5bGU9e3sgcGFkZGluZ0JvdHRvbTogXCI1JVwiIH19XHJcbiAgICAgID5cclxuICAgICAgICA8R3JpZCBjb250YWluZXIgZGlyZWN0aW9uPVwicm93XCIganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMlwiIHZhcmlhbnQ9XCJoNlwiIGNvbG9yPVwicHJpbWFyeVwiIGd1dHRlckJvdHRvbT5cclxuICAgICAgICAgICAgICB7dHJhbnNhY3Rpb25EZXRhaWxzPy50cmFuc2FjdGlvblR5cGUgPT09IFwicGF5bWVudFwiID8gXCJQYWlkIFwiIDogXCJSZXF1ZXN0ZWQgXCJ9XHJcbiAgICAgICAgICAgICAge3RyYW5zYWN0aW9uRGV0YWlscz8uYW1vdW50ICYmXHJcbiAgICAgICAgICAgICAgICBmb3JtYXRBbW91bnQocGFyc2VJbnQodHJhbnNhY3Rpb25EZXRhaWxzLmFtb3VudCwgMTApICogMTAwKX17XCIgXCJ9XHJcbiAgICAgICAgICAgICAgZm9yIHt0cmFuc2FjdGlvbkRldGFpbHM/LmRlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9HcmlkPlxyXG4gICAgICA8L0JveD5cclxuICAgICAgPEJveFxyXG4gICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgd2lkdGg9XCIxMDAlXCJcclxuICAgICAgICBoZWlnaHQ9XCIxMDBcIlxyXG4gICAgICAgIHN0eWxlPXt7IHBhZGRpbmdCb3R0b206IFwiNSVcIiB9fVxyXG4gICAgICA+XHJcbiAgICAgICAgPEdyaWQgY29udGFpbmVyIGRpcmVjdGlvbj1cInJvd1wiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYXJvdW5kXCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgIHNpemU9XCJzbWFsbFwiXHJcbiAgICAgICAgICAgICAgY29tcG9uZW50PXtSb3V0ZXJMaW5rfVxyXG4gICAgICAgICAgICAgIHRvPVwiL1wiXHJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0PVwibmV3LXRyYW5zYWN0aW9uLXJldHVybi10by10cmFuc2FjdGlvbnNcIlxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgUmV0dXJuIFRvIFRyYW5zYWN0aW9uc1xyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICBzaXplPVwic21hbGxcIlxyXG4gICAgICAgICAgICAgIC8qIGlzdGFuYnVsIGlnbm9yZSBuZXh0ICovXHJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc2VuZENyZWF0ZVRyYW5zYWN0aW9uKFwiUkVTRVRcIik7XHJcbiAgICAgICAgICAgICAgICBoaXN0b3J5LnB1c2goXCIvdHJhbnNhY3Rpb24vbmV3XCIpO1xyXG4gICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0PVwibmV3LXRyYW5zYWN0aW9uLWNyZWF0ZS1hbm90aGVyLXRyYW5zYWN0aW9uXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENyZWF0ZSBBbm90aGVyIFRyYW5zYWN0aW9uXHJcbiAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgPC9Cb3g+XHJcbiAgICA8L1N0eWxlZFBhcGVyPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBUcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZTtcclxuIl0sImZpbGUiOiJDOi9Vc2Vycy9BUy1MMzQvRGVza3RvcC9UeXBlU2NyaXB0L2N5cHJlc3MtcmVhbHdvcmxkLWFwcC9zcmMvY29tcG9uZW50cy9UcmFuc2FjdGlvbkNyZWF0ZVN0ZXBUaHJlZS50c3gifQ==