import __vite__cjsImport0_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const omit = __vite__cjsImport0_lodash_fp["omit"];
import gql from "/node_modules/.vite/deps/graphql-tag.js?v=6af76b79";
import { dataMachine } from "/src/machines/dataMachine.ts";
import { httpClient } from "/src/utils/asyncUtils.ts";
import { backendPort } from "/src/utils/portUtils.ts";
const listBankAccountQuery = gql`
  query ListBankAccount {
    listBankAccount {
      id
      uuid
      userId
      bankName
      accountNumber
      routingNumber
      isDeleted
      createdAt
      modifiedAt
    }
  }
`;
const deleteBankAccountMutation = gql`
  mutation DeleteBankAccount($id: ID!) {
    deleteBankAccount(id: $id)
  }
`;
const createBankAccountMutation = gql`
  mutation CreateBankAccount($bankName: String!, $accountNumber: String!, $routingNumber: String!) {
    createBankAccount(
      bankName: $bankName
      accountNumber: $accountNumber
      routingNumber: $routingNumber
    ) {
      id
      uuid
      userId
      bankName
      accountNumber
      routingNumber
      isDeleted
      createdAt
    }
  }
`;
export const bankAccountsMachine = dataMachine("bankAccounts").withConfig({
  services: {
    fetchData: async (ctx, event) => {
      const resp = await httpClient.post(`http://localhost:${backendPort}/graphql`, {
        operationName: "ListBankAccount",
        query: listBankAccountQuery.loc?.source.body
      });
      return { results: resp.data.data.listBankAccount, pageData: {} };
    },
    deleteData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.post(`http://localhost:${backendPort}/graphql`, {
        operationName: "DeleteBankAccount",
        query: deleteBankAccountMutation.loc?.source.body,
        variables: payload
      });
      return resp.data;
    },
    createData: async (ctx, event) => {
      const payload = omit("type", event);
      const resp = await httpClient.post(`http://localhost:${backendPort}/graphql`, {
        operationName: "CreateBankAccount",
        query: createBankAccountMutation.loc?.source.body,
        variables: payload
      });
      return resp.data;
    }
  }
});

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImJhbmtBY2NvdW50c01hY2hpbmUudHMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgb21pdCB9IGZyb20gXCJsb2Rhc2gvZnBcIjtcclxuaW1wb3J0IGdxbCBmcm9tIFwiZ3JhcGhxbC10YWdcIjtcclxuaW1wb3J0IHsgZGF0YU1hY2hpbmUgfSBmcm9tIFwiLi9kYXRhTWFjaGluZVwiO1xyXG5pbXBvcnQgeyBodHRwQ2xpZW50IH0gZnJvbSBcIi4uL3V0aWxzL2FzeW5jVXRpbHNcIjtcclxuaW1wb3J0IHsgYmFja2VuZFBvcnQgfSBmcm9tIFwiLi4vdXRpbHMvcG9ydFV0aWxzXCI7XHJcblxyXG5jb25zdCBsaXN0QmFua0FjY291bnRRdWVyeSA9IGdxbGBcclxuICBxdWVyeSBMaXN0QmFua0FjY291bnQge1xyXG4gICAgbGlzdEJhbmtBY2NvdW50IHtcclxuICAgICAgaWRcclxuICAgICAgdXVpZFxyXG4gICAgICB1c2VySWRcclxuICAgICAgYmFua05hbWVcclxuICAgICAgYWNjb3VudE51bWJlclxyXG4gICAgICByb3V0aW5nTnVtYmVyXHJcbiAgICAgIGlzRGVsZXRlZFxyXG4gICAgICBjcmVhdGVkQXRcclxuICAgICAgbW9kaWZpZWRBdFxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmNvbnN0IGRlbGV0ZUJhbmtBY2NvdW50TXV0YXRpb24gPSBncWxgXHJcbiAgbXV0YXRpb24gRGVsZXRlQmFua0FjY291bnQoJGlkOiBJRCEpIHtcclxuICAgIGRlbGV0ZUJhbmtBY2NvdW50KGlkOiAkaWQpXHJcbiAgfVxyXG5gO1xyXG5cclxuY29uc3QgY3JlYXRlQmFua0FjY291bnRNdXRhdGlvbiA9IGdxbGBcclxuICBtdXRhdGlvbiBDcmVhdGVCYW5rQWNjb3VudCgkYmFua05hbWU6IFN0cmluZyEsICRhY2NvdW50TnVtYmVyOiBTdHJpbmchLCAkcm91dGluZ051bWJlcjogU3RyaW5nISkge1xyXG4gICAgY3JlYXRlQmFua0FjY291bnQoXHJcbiAgICAgIGJhbmtOYW1lOiAkYmFua05hbWVcclxuICAgICAgYWNjb3VudE51bWJlcjogJGFjY291bnROdW1iZXJcclxuICAgICAgcm91dGluZ051bWJlcjogJHJvdXRpbmdOdW1iZXJcclxuICAgICkge1xyXG4gICAgICBpZFxyXG4gICAgICB1dWlkXHJcbiAgICAgIHVzZXJJZFxyXG4gICAgICBiYW5rTmFtZVxyXG4gICAgICBhY2NvdW50TnVtYmVyXHJcbiAgICAgIHJvdXRpbmdOdW1iZXJcclxuICAgICAgaXNEZWxldGVkXHJcbiAgICAgIGNyZWF0ZWRBdFxyXG4gICAgfVxyXG4gIH1cclxuYDtcclxuXHJcbmV4cG9ydCBjb25zdCBiYW5rQWNjb3VudHNNYWNoaW5lID0gZGF0YU1hY2hpbmUoXCJiYW5rQWNjb3VudHNcIikud2l0aENvbmZpZyh7XHJcbiAgc2VydmljZXM6IHtcclxuICAgIGZldGNoRGF0YTogYXN5bmMgKGN0eCwgZXZlbnQ6IGFueSkgPT4ge1xyXG4gICAgICBjb25zdCByZXNwID0gYXdhaXQgaHR0cENsaWVudC5wb3N0KGBodHRwOi8vbG9jYWxob3N0OiR7YmFja2VuZFBvcnR9L2dyYXBocWxgLCB7XHJcbiAgICAgICAgb3BlcmF0aW9uTmFtZTogXCJMaXN0QmFua0FjY291bnRcIixcclxuICAgICAgICBxdWVyeTogbGlzdEJhbmtBY2NvdW50UXVlcnkubG9jPy5zb3VyY2UuYm9keSxcclxuICAgICAgfSk7XHJcbiAgICAgIC8vIEB0cy1pZ25vcmVcclxuICAgICAgcmV0dXJuIHsgcmVzdWx0czogcmVzcC5kYXRhLmRhdGEubGlzdEJhbmtBY2NvdW50LCBwYWdlRGF0YToge30gfTtcclxuICAgIH0sXHJcbiAgICBkZWxldGVEYXRhOiBhc3luYyAoY3R4LCBldmVudDogYW55KSA9PiB7XHJcbiAgICAgIGNvbnN0IHBheWxvYWQgPSBvbWl0KFwidHlwZVwiLCBldmVudCk7XHJcbiAgICAgIGNvbnN0IHJlc3AgPSBhd2FpdCBodHRwQ2xpZW50LnBvc3QoYGh0dHA6Ly9sb2NhbGhvc3Q6JHtiYWNrZW5kUG9ydH0vZ3JhcGhxbGAsIHtcclxuICAgICAgICBvcGVyYXRpb25OYW1lOiBcIkRlbGV0ZUJhbmtBY2NvdW50XCIsXHJcbiAgICAgICAgcXVlcnk6IGRlbGV0ZUJhbmtBY2NvdW50TXV0YXRpb24ubG9jPy5zb3VyY2UuYm9keSxcclxuICAgICAgICB2YXJpYWJsZXM6IHBheWxvYWQsXHJcbiAgICAgIH0pO1xyXG4gICAgICByZXR1cm4gcmVzcC5kYXRhO1xyXG4gICAgfSxcclxuICAgIGNyZWF0ZURhdGE6IGFzeW5jIChjdHgsIGV2ZW50OiBhbnkpID0+IHtcclxuICAgICAgY29uc3QgcGF5bG9hZCA9IG9taXQoXCJ0eXBlXCIsIGV2ZW50KTtcclxuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGh0dHBDbGllbnQucG9zdChgaHR0cDovL2xvY2FsaG9zdDoke2JhY2tlbmRQb3J0fS9ncmFwaHFsYCwge1xyXG4gICAgICAgIG9wZXJhdGlvbk5hbWU6IFwiQ3JlYXRlQmFua0FjY291bnRcIixcclxuICAgICAgICBxdWVyeTogY3JlYXRlQmFua0FjY291bnRNdXRhdGlvbi5sb2M/LnNvdXJjZS5ib2R5LFxyXG4gICAgICAgIHZhcmlhYmxlczogcGF5bG9hZCxcclxuICAgICAgfSk7XHJcbiAgICAgIHJldHVybiByZXNwLmRhdGE7XHJcbiAgICB9LFxyXG4gIH0sXHJcbn0pO1xyXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsWUFBWTtBQUNyQixPQUFPLFNBQVM7QUFDaEIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxtQkFBbUI7QUFFNUIsTUFBTSx1QkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBZ0I3QixNQUFNLDRCQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTWxDLE1BQU0sNEJBQTRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQW1CM0IsYUFBTSxzQkFBc0IsWUFBWSxjQUFjLEVBQUUsV0FBVztBQUFBLEVBQ3hFLFVBQVU7QUFBQSxJQUNSLFdBQVcsT0FBTyxLQUFLLFVBQWU7QUFDcEMsWUFBTSxPQUFPLE1BQU0sV0FBVyxLQUFLLG9CQUFvQixXQUFXLFlBQVk7QUFBQSxRQUM1RSxlQUFlO0FBQUEsUUFDZixPQUFPLHFCQUFxQixLQUFLLE9BQU87QUFBQSxNQUMxQyxDQUFDO0FBRUQsYUFBTyxFQUFFLFNBQVMsS0FBSyxLQUFLLEtBQUssaUJBQWlCLFVBQVUsQ0FBQyxFQUFFO0FBQUEsSUFDakU7QUFBQSxJQUNBLFlBQVksT0FBTyxLQUFLLFVBQWU7QUFDckMsWUFBTSxVQUFVLEtBQUssUUFBUSxLQUFLO0FBQ2xDLFlBQU0sT0FBTyxNQUFNLFdBQVcsS0FBSyxvQkFBb0IsV0FBVyxZQUFZO0FBQUEsUUFDNUUsZUFBZTtBQUFBLFFBQ2YsT0FBTywwQkFBMEIsS0FBSyxPQUFPO0FBQUEsUUFDN0MsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFBQSxJQUNBLFlBQVksT0FBTyxLQUFLLFVBQWU7QUFDckMsWUFBTSxVQUFVLEtBQUssUUFBUSxLQUFLO0FBQ2xDLFlBQU0sT0FBTyxNQUFNLFdBQVcsS0FBSyxvQkFBb0IsV0FBVyxZQUFZO0FBQUEsUUFDNUUsZUFBZTtBQUFBLFFBQ2YsT0FBTywwQkFBMEIsS0FBSyxPQUFPO0FBQUEsUUFDN0MsV0FBVztBQUFBLE1BQ2IsQ0FBQztBQUNELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFBQSxFQUNGO0FBQ0YsQ0FBQzsiLCJuYW1lcyI6W119