import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/containers/UserOnboardingContainer.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=6af76b79"; const useEffect = __vite__cjsImport3_react["useEffect"];
import {
  Button,
  Box,
  useTheme,
  useMediaQuery,
  Grid,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import __vite__cjsImport5_lodash_fp from "/node_modules/.vite/deps/lodash_fp.js?v=6af76b79"; const isEmpty = __vite__cjsImport5_lodash_fp["isEmpty"];
import { useActor, useMachine } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { userOnboardingMachine } from "/src/machines/userOnboardingMachine.ts";
import BankAccountForm from "/src/components/BankAccountForm.tsx";
import NavigatorIllustration from "/src/components/SvgUndrawNavigatorA479.tsx";
import PersonalFinance from "/src/components/SvgUndrawPersonalFinanceTqcd.tsx";
const UserOnboardingContainer = ({ authService, bankAccountsService }) => {
  _s();
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("md"));
  const [bankAccountsState, sendBankAccounts] = useActor(bankAccountsService);
  const [authState, sendAuth] = useActor(authService);
  const [userOnboardingState, sendUserOnboarding] = useMachine(userOnboardingMachine);
  const currentUser = authState?.context?.user;
  useEffect(() => {
    sendBankAccounts("FETCH");
  }, [sendBankAccounts]);
  const noBankAccounts = bankAccountsState?.matches("success.withoutData") && isEmpty(bankAccountsState?.context?.results);
  const dialogIsOpen = userOnboardingState.matches("stepTwo") && !noBankAccounts || userOnboardingState.matches("stepThree") && !noBankAccounts || !userOnboardingState.matches("done") && noBankAccounts || false;
  const nextStep = () => sendUserOnboarding("NEXT");
  const createBankAccountWithNextStep = (payload) => {
    sendBankAccounts({ type: "CREATE", ...payload });
    nextStep();
  };
  return /* @__PURE__ */ jsxDEV(Dialog, { "data-test": "user-onboarding-dialog", fullScreen, open: dialogIsOpen, children: [
    /* @__PURE__ */ jsxDEV(DialogTitle, { "data-test": "user-onboarding-dialog-title", children: [
      userOnboardingState.matches("stepOne") && "Get Started with Real World App",
      userOnboardingState.matches("stepTwo") && "Create Bank Account",
      userOnboardingState.matches("stepThree") && "Finished"
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
      lineNumber: 74,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogContent, { "data-test": "user-onboarding-dialog-content", children: /* @__PURE__ */ jsxDEV(Box, { display: "flex", alignItems: "center", justifyContent: "center", children: [
      userOnboardingState.matches("stepOne") && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(NavigatorIllustration, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 83,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 84,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(DialogContentText, { style: { paddingLeft: 20 }, children: [
          "Real World App requires a Bank Account to perform transactions.",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
            lineNumber: 87,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
            lineNumber: 88,
            columnNumber: 17
          }, this),
          "Click ",
          /* @__PURE__ */ jsxDEV("b", { children: "Next" }, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
            lineNumber: 89,
            columnNumber: 23
          }, this),
          " to begin setup of your Bank Account."
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 85,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
        lineNumber: 82,
        columnNumber: 11
      }, this),
      userOnboardingState.matches("stepTwo") && /* @__PURE__ */ jsxDEV(
        BankAccountForm,
        {
          userId: currentUser?.id,
          createBankAccount: createBankAccountWithNextStep,
          onboarding: true
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 94,
          columnNumber: 11
        },
        this
      ),
      userOnboardingState.matches("stepThree") && /* @__PURE__ */ jsxDEV(Fragment, { children: [
        /* @__PURE__ */ jsxDEV(PersonalFinance, {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 102,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 103,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV(DialogContentText, { style: { paddingLeft: 20 }, children: [
          "You're all set!",
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
            lineNumber: 106,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
            lineNumber: 107,
            columnNumber: 17
          }, this),
          "We're excited to have you aboard the Real World App!"
        ] }, void 0, true, {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 104,
          columnNumber: 15
        }, this)
      ] }, void 0, true, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
        lineNumber: 101,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
      lineNumber: 80,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
      lineNumber: 79,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(DialogActions, { children: /* @__PURE__ */ jsxDEV(Grid, { container: true, justifyContent: "space-between", children: [
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(
        Button,
        {
          style: { paddingRight: "80%" },
          onClick: (
            /* istanbul ignore next */
            () => sendAuth("LOGOUT")
          ),
          color: "secondary",
          "data-test": "user-onboarding-logout",
          children: "Logout"
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
          lineNumber: 117,
          columnNumber: 13
        },
        this
      ) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
        lineNumber: 116,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV(Grid, { item: true, children: !userOnboardingState.matches("stepTwo") && /* @__PURE__ */ jsxDEV(Button, { onClick: () => nextStep(), color: "primary", "data-test": "user-onboarding-next", children: userOnboardingState.matches("stepThree") ? "Done" : "Next" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
        lineNumber: 128,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
        lineNumber: 126,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
      lineNumber: 115,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
      lineNumber: 114,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx",
    lineNumber: 73,
    columnNumber: 5
  }, this);
};
_s(UserOnboardingContainer, "bimEe/mjCJ2cHllBnfhWImyk4Pw=", false, function() {
  return [useTheme, useMediaQuery, useActor, useActor, useMachine];
});
_c = UserOnboardingContainer;
export default UserOnboardingContainer;
var _c;
$RefreshReg$(_c, "UserOnboardingContainer");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/containers/UserOnboardingContainer.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUVNLFNBUU0sVUFSTjsyQkF6RU47QUFBZ0JBLE1BQVMsY0FBZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN4QztBQUFBLEVBQ0VDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLEVBQ0FDO0FBQUFBLE9BQ0s7QUFRUCxTQUFTQyxlQUFlO0FBQ3hCLFNBQVNDLFVBQVVDLGtCQUFrQjtBQUVyQyxTQUFTQyw2QkFBNkI7QUFDdEMsT0FBT0MscUJBQXFCO0FBRzVCLE9BQU9DLDJCQUEyQjtBQUNsQyxPQUFPQyxxQkFBcUI7QUFhNUIsTUFBTUMsMEJBQTJDQSxDQUFDLEVBQUVDLGFBQWFDLG9CQUFvQixNQUFNO0FBQUFDLEtBQUE7QUFDekYsUUFBTUMsUUFBUW5CLFNBQVM7QUFDdkIsUUFBTW9CLGFBQWFuQixjQUFja0IsTUFBTUUsWUFBWUMsS0FBSyxJQUFJLENBQUM7QUFDN0QsUUFBTSxDQUFDQyxtQkFBbUJDLGdCQUFnQixJQUFJZixTQUFTUSxtQkFBbUI7QUFDMUUsUUFBTSxDQUFDUSxXQUFXQyxRQUFRLElBQUlqQixTQUFTTyxXQUFXO0FBQ2xELFFBQU0sQ0FBQ1cscUJBQXFCQyxrQkFBa0IsSUFBSWxCLFdBQVdDLHFCQUFxQjtBQUVsRixRQUFNa0IsY0FBY0osV0FBV0ssU0FBU0M7QUFFeENsQyxZQUFVLE1BQU07QUFDZDJCLHFCQUFpQixPQUFPO0FBQUEsRUFDMUIsR0FBRyxDQUFDQSxnQkFBZ0IsQ0FBQztBQUVyQixRQUFNUSxpQkFDSlQsbUJBQW1CVSxRQUFRLHFCQUFxQixLQUNoRHpCLFFBQVFlLG1CQUFtQk8sU0FBU0ksT0FBTztBQUU3QyxRQUFNQyxlQUNIUixvQkFBb0JNLFFBQVEsU0FBUyxLQUFLLENBQUNELGtCQUMzQ0wsb0JBQW9CTSxRQUFRLFdBQVcsS0FBSyxDQUFDRCxrQkFDN0MsQ0FBQ0wsb0JBQW9CTSxRQUFRLE1BQU0sS0FBS0Qsa0JBQ3pDO0FBRUYsUUFBTUksV0FBV0EsTUFBTVIsbUJBQW1CLE1BQU07QUFFaEQsUUFBTVMsZ0NBQWdDQSxDQUFDQyxZQUFpQjtBQUN0RGQscUJBQWlCLEVBQUVlLE1BQU0sVUFBVSxHQUFHRCxRQUFRLENBQUM7QUFDL0NGLGFBQVM7QUFBQSxFQUNYO0FBRUEsU0FDRSx1QkFBQyxVQUFPLGFBQVUsMEJBQXlCLFlBQXdCLE1BQU1ELGNBQ3ZFO0FBQUEsMkJBQUMsZUFBWSxhQUFVLGdDQUNwQlI7QUFBQUEsMEJBQW9CTSxRQUFRLFNBQVMsS0FBSztBQUFBLE1BQzFDTixvQkFBb0JNLFFBQVEsU0FBUyxLQUFLO0FBQUEsTUFDMUNOLG9CQUFvQk0sUUFBUSxXQUFXLEtBQUs7QUFBQSxTQUgvQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUNBLHVCQUFDLGlCQUFjLGFBQVUsa0NBQ3ZCLGlDQUFDLE9BQUksU0FBUSxRQUFPLFlBQVcsVUFBUyxnQkFBZSxVQUNwRE47QUFBQUEsMEJBQW9CTSxRQUFRLFNBQVMsS0FDcEMsbUNBQ0U7QUFBQSwrQkFBQywyQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXNCO0FBQUEsUUFDdEIsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQUc7QUFBQSxRQUNILHVCQUFDLHFCQUFrQixPQUFPLEVBQUVPLGFBQWEsR0FBRyxHQUFHO0FBQUE7QUFBQSxVQUU3Qyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQUc7QUFBQSxVQUNILHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQUc7QUFBQSxVQUNBLHVCQUFDLE9BQUUsb0JBQUg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBTztBQUFBLFVBQUk7QUFBQSxhQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS0E7QUFBQSxXQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFTQTtBQUFBLE1BRURiLG9CQUFvQk0sUUFBUSxTQUFTLEtBQ3BDO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxRQUFRSixhQUFhWTtBQUFBQSxVQUNyQixtQkFBbUJKO0FBQUFBLFVBQ25CLFlBQVU7QUFBQTtBQUFBLFFBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BR1k7QUFBQSxNQUdiVixvQkFBb0JNLFFBQVEsV0FBVyxLQUN0QyxtQ0FDRTtBQUFBLCtCQUFDLHFCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0I7QUFBQSxRQUNoQix1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBRztBQUFBLFFBQ0gsdUJBQUMscUJBQWtCLE9BQU8sRUFBRU8sYUFBYSxHQUFHLEdBQUc7QUFBQTtBQUFBLFVBRTdDLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFBRztBQUFBLFVBQ0gsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFHO0FBQUEsVUFBRztBQUFBLGFBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0NBLEtBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxJQUNBLHVCQUFDLGlCQUNDLGlDQUFDLFFBQUssV0FBUyxNQUFDLGdCQUFlLGlCQUM3QjtBQUFBLDZCQUFDLFFBQUssTUFBSSxNQUNSO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQyxPQUFPLEVBQUVFLGNBQWMsTUFBTTtBQUFBLFVBQzdCO0FBQUE7QUFBQSxZQUFvQyxNQUFNaEIsU0FBUyxRQUFRO0FBQUE7QUFBQSxVQUMzRCxPQUFNO0FBQUEsVUFDTixhQUFVO0FBQUEsVUFBd0I7QUFBQTtBQUFBLFFBSnBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQU9BLEtBUkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVNBO0FBQUEsTUFDQSx1QkFBQyxRQUFLLE1BQUksTUFDUCxXQUFDQyxvQkFBb0JNLFFBQVEsU0FBUyxLQUNyQyx1QkFBQyxVQUFPLFNBQVMsTUFBTUcsU0FBUyxHQUFHLE9BQU0sV0FBVSxhQUFVLHdCQUMxRFQsOEJBQW9CTSxRQUFRLFdBQVcsSUFBSSxTQUFTLFVBRHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxLQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQTtBQUFBLFNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLE9BN0RGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E4REE7QUFFSjtBQUFFZixHQS9GSUgseUJBQXdDO0FBQUEsVUFDOUJmLFVBQ0tDLGVBQzJCUSxVQUNoQkEsVUFDb0JDLFVBQVU7QUFBQTtBQUFBaUMsS0FMeEQ1QjtBQWlHTixlQUFlQTtBQUF3QixJQUFBNEI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUVmZmVjdCIsIkJ1dHRvbiIsIkJveCIsInVzZVRoZW1lIiwidXNlTWVkaWFRdWVyeSIsIkdyaWQiLCJEaWFsb2ciLCJEaWFsb2dBY3Rpb25zIiwiRGlhbG9nQ29udGVudCIsIkRpYWxvZ0NvbnRlbnRUZXh0IiwiRGlhbG9nVGl0bGUiLCJpc0VtcHR5IiwidXNlQWN0b3IiLCJ1c2VNYWNoaW5lIiwidXNlck9uYm9hcmRpbmdNYWNoaW5lIiwiQmFua0FjY291bnRGb3JtIiwiTmF2aWdhdG9ySWxsdXN0cmF0aW9uIiwiUGVyc29uYWxGaW5hbmNlIiwiVXNlck9uYm9hcmRpbmdDb250YWluZXIiLCJhdXRoU2VydmljZSIsImJhbmtBY2NvdW50c1NlcnZpY2UiLCJfcyIsInRoZW1lIiwiZnVsbFNjcmVlbiIsImJyZWFrcG9pbnRzIiwiZG93biIsImJhbmtBY2NvdW50c1N0YXRlIiwic2VuZEJhbmtBY2NvdW50cyIsImF1dGhTdGF0ZSIsInNlbmRBdXRoIiwidXNlck9uYm9hcmRpbmdTdGF0ZSIsInNlbmRVc2VyT25ib2FyZGluZyIsImN1cnJlbnRVc2VyIiwiY29udGV4dCIsInVzZXIiLCJub0JhbmtBY2NvdW50cyIsIm1hdGNoZXMiLCJyZXN1bHRzIiwiZGlhbG9nSXNPcGVuIiwibmV4dFN0ZXAiLCJjcmVhdGVCYW5rQWNjb3VudFdpdGhOZXh0U3RlcCIsInBheWxvYWQiLCJ0eXBlIiwicGFkZGluZ0xlZnQiLCJpZCIsInBhZGRpbmdSaWdodCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlck9uYm9hcmRpbmdDb250YWluZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHtcclxuICBCdXR0b24sXHJcbiAgQm94LFxyXG4gIHVzZVRoZW1lLFxyXG4gIHVzZU1lZGlhUXVlcnksXHJcbiAgR3JpZCxcclxuICBEaWFsb2csXHJcbiAgRGlhbG9nQWN0aW9ucyxcclxuICBEaWFsb2dDb250ZW50LFxyXG4gIERpYWxvZ0NvbnRlbnRUZXh0LFxyXG4gIERpYWxvZ1RpdGxlLFxyXG59IGZyb20gXCJAbXVpL21hdGVyaWFsXCI7XHJcbmltcG9ydCB7XHJcbiAgQmFzZUFjdGlvbk9iamVjdCxcclxuICBJbnRlcnByZXRlcixcclxuICBSZXNvbHZlVHlwZWdlbk1ldGEsXHJcbiAgU2VydmljZU1hcCxcclxuICBUeXBlZ2VuRGlzYWJsZWQsXHJcbn0gZnJvbSBcInhzdGF0ZVwiO1xyXG5pbXBvcnQgeyBpc0VtcHR5IH0gZnJvbSBcImxvZGFzaC9mcFwiO1xyXG5pbXBvcnQgeyB1c2VBY3RvciwgdXNlTWFjaGluZSB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcblxyXG5pbXBvcnQgeyB1c2VyT25ib2FyZGluZ01hY2hpbmUgfSBmcm9tIFwiLi4vbWFjaGluZXMvdXNlck9uYm9hcmRpbmdNYWNoaW5lXCI7XHJcbmltcG9ydCBCYW5rQWNjb3VudEZvcm0gZnJvbSBcIi4uL2NvbXBvbmVudHMvQmFua0FjY291bnRGb3JtXCI7XHJcbmltcG9ydCB7IERhdGFDb250ZXh0LCBEYXRhRXZlbnRzLCBEYXRhU2NoZW1hIH0gZnJvbSBcIi4uL21hY2hpbmVzL2RhdGFNYWNoaW5lXCI7XHJcbmltcG9ydCB7IEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVFdmVudHMsIEF1dGhNYWNoaW5lU2NoZW1hIH0gZnJvbSBcIi4uL21hY2hpbmVzL2F1dGhNYWNoaW5lXCI7XHJcbmltcG9ydCBOYXZpZ2F0b3JJbGx1c3RyYXRpb24gZnJvbSBcIi4uL2NvbXBvbmVudHMvU3ZnVW5kcmF3TmF2aWdhdG9yQTQ3OVwiO1xyXG5pbXBvcnQgUGVyc29uYWxGaW5hbmNlIGZyb20gXCIuLi9jb21wb25lbnRzL1N2Z1VuZHJhd1BlcnNvbmFsRmluYW5jZVRxY2RcIjtcclxuXHJcbmV4cG9ydCBpbnRlcmZhY2UgUHJvcHMge1xyXG4gIGF1dGhTZXJ2aWNlOiBJbnRlcnByZXRlcjxBdXRoTWFjaGluZUNvbnRleHQsIEF1dGhNYWNoaW5lU2NoZW1hLCBBdXRoTWFjaGluZUV2ZW50cywgYW55LCBhbnk+O1xyXG4gIGJhbmtBY2NvdW50c1NlcnZpY2U6IEludGVycHJldGVyPFxyXG4gICAgRGF0YUNvbnRleHQsXHJcbiAgICBEYXRhU2NoZW1hLFxyXG4gICAgRGF0YUV2ZW50cyxcclxuICAgIGFueSxcclxuICAgIFJlc29sdmVUeXBlZ2VuTWV0YTxUeXBlZ2VuRGlzYWJsZWQsIERhdGFFdmVudHMsIEJhc2VBY3Rpb25PYmplY3QsIFNlcnZpY2VNYXA+XHJcbiAgPjtcclxufVxyXG5cclxuY29uc3QgVXNlck9uYm9hcmRpbmdDb250YWluZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGF1dGhTZXJ2aWNlLCBiYW5rQWNjb3VudHNTZXJ2aWNlIH0pID0+IHtcclxuICBjb25zdCB0aGVtZSA9IHVzZVRoZW1lKCk7XHJcbiAgY29uc3QgZnVsbFNjcmVlbiA9IHVzZU1lZGlhUXVlcnkodGhlbWUuYnJlYWtwb2ludHMuZG93bihcIm1kXCIpKTtcclxuICBjb25zdCBbYmFua0FjY291bnRzU3RhdGUsIHNlbmRCYW5rQWNjb3VudHNdID0gdXNlQWN0b3IoYmFua0FjY291bnRzU2VydmljZSk7XHJcbiAgY29uc3QgW2F1dGhTdGF0ZSwgc2VuZEF1dGhdID0gdXNlQWN0b3IoYXV0aFNlcnZpY2UpO1xyXG4gIGNvbnN0IFt1c2VyT25ib2FyZGluZ1N0YXRlLCBzZW5kVXNlck9uYm9hcmRpbmddID0gdXNlTWFjaGluZSh1c2VyT25ib2FyZGluZ01hY2hpbmUpO1xyXG5cclxuICBjb25zdCBjdXJyZW50VXNlciA9IGF1dGhTdGF0ZT8uY29udGV4dD8udXNlcjtcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHNlbmRCYW5rQWNjb3VudHMoXCJGRVRDSFwiKTtcclxuICB9LCBbc2VuZEJhbmtBY2NvdW50c10pO1xyXG5cclxuICBjb25zdCBub0JhbmtBY2NvdW50cyA9XHJcbiAgICBiYW5rQWNjb3VudHNTdGF0ZT8ubWF0Y2hlcyhcInN1Y2Nlc3Mud2l0aG91dERhdGFcIikgJiZcclxuICAgIGlzRW1wdHkoYmFua0FjY291bnRzU3RhdGU/LmNvbnRleHQ/LnJlc3VsdHMpO1xyXG5cclxuICBjb25zdCBkaWFsb2dJc09wZW4gPVxyXG4gICAgKHVzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBUd29cIikgJiYgIW5vQmFua0FjY291bnRzKSB8fFxyXG4gICAgKHVzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBUaHJlZVwiKSAmJiAhbm9CYW5rQWNjb3VudHMpIHx8XHJcbiAgICAoIXVzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcImRvbmVcIikgJiYgbm9CYW5rQWNjb3VudHMpIHx8XHJcbiAgICBmYWxzZTtcclxuXHJcbiAgY29uc3QgbmV4dFN0ZXAgPSAoKSA9PiBzZW5kVXNlck9uYm9hcmRpbmcoXCJORVhUXCIpO1xyXG5cclxuICBjb25zdCBjcmVhdGVCYW5rQWNjb3VudFdpdGhOZXh0U3RlcCA9IChwYXlsb2FkOiBhbnkpID0+IHtcclxuICAgIHNlbmRCYW5rQWNjb3VudHMoeyB0eXBlOiBcIkNSRUFURVwiLCAuLi5wYXlsb2FkIH0pO1xyXG4gICAgbmV4dFN0ZXAoKTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPERpYWxvZyBkYXRhLXRlc3Q9XCJ1c2VyLW9uYm9hcmRpbmctZGlhbG9nXCIgZnVsbFNjcmVlbj17ZnVsbFNjcmVlbn0gb3Blbj17ZGlhbG9nSXNPcGVufT5cclxuICAgICAgPERpYWxvZ1RpdGxlIGRhdGEtdGVzdD1cInVzZXItb25ib2FyZGluZy1kaWFsb2ctdGl0bGVcIj5cclxuICAgICAgICB7dXNlck9uYm9hcmRpbmdTdGF0ZS5tYXRjaGVzKFwic3RlcE9uZVwiKSAmJiBcIkdldCBTdGFydGVkIHdpdGggUmVhbCBXb3JsZCBBcHBcIn1cclxuICAgICAgICB7dXNlck9uYm9hcmRpbmdTdGF0ZS5tYXRjaGVzKFwic3RlcFR3b1wiKSAmJiBcIkNyZWF0ZSBCYW5rIEFjY291bnRcIn1cclxuICAgICAgICB7dXNlck9uYm9hcmRpbmdTdGF0ZS5tYXRjaGVzKFwic3RlcFRocmVlXCIpICYmIFwiRmluaXNoZWRcIn1cclxuICAgICAgPC9EaWFsb2dUaXRsZT5cclxuICAgICAgPERpYWxvZ0NvbnRlbnQgZGF0YS10ZXN0PVwidXNlci1vbmJvYXJkaW5nLWRpYWxvZy1jb250ZW50XCI+XHJcbiAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiPlxyXG4gICAgICAgICAge3VzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBPbmVcIikgJiYgKFxyXG4gICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgIDxOYXZpZ2F0b3JJbGx1c3RyYXRpb24gLz5cclxuICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICA8RGlhbG9nQ29udGVudFRleHQgc3R5bGU9e3sgcGFkZGluZ0xlZnQ6IDIwIH19PlxyXG4gICAgICAgICAgICAgICAgUmVhbCBXb3JsZCBBcHAgcmVxdWlyZXMgYSBCYW5rIEFjY291bnQgdG8gcGVyZm9ybSB0cmFuc2FjdGlvbnMuXHJcbiAgICAgICAgICAgICAgICA8YnIgLz5cclxuICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgQ2xpY2sgPGI+TmV4dDwvYj4gdG8gYmVnaW4gc2V0dXAgb2YgeW91ciBCYW5rIEFjY291bnQuXHJcbiAgICAgICAgICAgICAgPC9EaWFsb2dDb250ZW50VGV4dD5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3VzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBUd29cIikgJiYgKFxyXG4gICAgICAgICAgICA8QmFua0FjY291bnRGb3JtXHJcbiAgICAgICAgICAgICAgdXNlcklkPXtjdXJyZW50VXNlcj8uaWQhfVxyXG4gICAgICAgICAgICAgIGNyZWF0ZUJhbmtBY2NvdW50PXtjcmVhdGVCYW5rQWNjb3VudFdpdGhOZXh0U3RlcH1cclxuICAgICAgICAgICAgICBvbmJvYXJkaW5nXHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgICAge3VzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBUaHJlZVwiKSAmJiAoXHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgPFBlcnNvbmFsRmluYW5jZSAvPlxyXG4gICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgIDxEaWFsb2dDb250ZW50VGV4dCBzdHlsZT17eyBwYWRkaW5nTGVmdDogMjAgfX0+XHJcbiAgICAgICAgICAgICAgICBZb3UncmUgYWxsIHNldCFcclxuICAgICAgICAgICAgICAgIDxiciAvPlxyXG4gICAgICAgICAgICAgICAgPGJyIC8+XHJcbiAgICAgICAgICAgICAgICBXZSdyZSBleGNpdGVkIHRvIGhhdmUgeW91IGFib2FyZCB0aGUgUmVhbCBXb3JsZCBBcHAhXHJcbiAgICAgICAgICAgICAgPC9EaWFsb2dDb250ZW50VGV4dD5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgIDxEaWFsb2dBY3Rpb25zPlxyXG4gICAgICAgIDxHcmlkIGNvbnRhaW5lciBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIj5cclxuICAgICAgICAgIDxHcmlkIGl0ZW0+XHJcbiAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICBzdHlsZT17eyBwYWRkaW5nUmlnaHQ6IFwiODAlXCIgfX1cclxuICAgICAgICAgICAgICBvbkNsaWNrPXsvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqLyAoKSA9PiBzZW5kQXV0aChcIkxPR09VVFwiKX1cclxuICAgICAgICAgICAgICBjb2xvcj1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgZGF0YS10ZXN0PVwidXNlci1vbmJvYXJkaW5nLWxvZ291dFwiXHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICBMb2dvdXRcclxuICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICA8R3JpZCBpdGVtPlxyXG4gICAgICAgICAgICB7IXVzZXJPbmJvYXJkaW5nU3RhdGUubWF0Y2hlcyhcInN0ZXBUd29cIikgJiYgKFxyXG4gICAgICAgICAgICAgIDxCdXR0b24gb25DbGljaz17KCkgPT4gbmV4dFN0ZXAoKX0gY29sb3I9XCJwcmltYXJ5XCIgZGF0YS10ZXN0PVwidXNlci1vbmJvYXJkaW5nLW5leHRcIj5cclxuICAgICAgICAgICAgICAgIHt1c2VyT25ib2FyZGluZ1N0YXRlLm1hdGNoZXMoXCJzdGVwVGhyZWVcIikgPyBcIkRvbmVcIiA6IFwiTmV4dFwifVxyXG4gICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvR3JpZD5cclxuICAgICAgPC9EaWFsb2dBY3Rpb25zPlxyXG4gICAgPC9EaWFsb2c+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFVzZXJPbmJvYXJkaW5nQ29udGFpbmVyO1xyXG4iXSwiZmlsZSI6IkM6L1VzZXJzL0FTLUwzNC9EZXNrdG9wL1R5cGVTY3JpcHQvY3lwcmVzcy1yZWFsd29ybGQtYXBwL3NyYy9jb250YWluZXJzL1VzZXJPbmJvYXJkaW5nQ29udGFpbmVyLnRzeCJ9