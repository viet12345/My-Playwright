import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/SignInForm.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=6af76b79"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { styled } from "/node_modules/.vite/deps/@mui_material_styles.js?v=6af76b79";
import { useActor } from "/node_modules/.vite/deps/@xstate_react.js?v=6af76b79";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=6af76b79";
import {
  Button,
  CssBaseline,
  TextField,
  FormControlLabel,
  Checkbox,
  Grid,
  Box,
  Typography,
  Container
} from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
import { Formik, Form, Field } from "/node_modules/.vite/deps/formik.js?v=6af76b79";
import { string, object } from "/node_modules/.vite/deps/yup.js?v=6af76b79";
import RWALogo from "/src/components/SvgRwaLogo.tsx";
import Footer from "/src/components/Footer.tsx";
import { Alert } from "/node_modules/.vite/deps/@mui_material.js?v=6af76b79";
const validationSchema = object({
  username: string().required("Username is required"),
  password: string().min(4, "Password must contain at least 4 characters").required("Enter your password")
});
const PREFIX = "SignInForm";
const classes = {
  paper: `${PREFIX}-paper`,
  logo: `${PREFIX}-logo`,
  form: `${PREFIX}-form`,
  submit: `${PREFIX}-submit`,
  alertMessage: `${PREFIX}-alertMessage`
};
const StyledContainer = styled(Container)(({ theme }) => ({
  [`& .${classes.paper}`]: {
    marginTop: theme.spacing(8),
    display: "flex",
    flexDirection: "column",
    alignItems: "center"
  },
  [`& .${classes.logo}`]: {
    color: theme.palette.primary.main
  },
  [`& .${classes.form}`]: {
    width: "100%",
    // Fix IE 11 issue.
    marginTop: theme.spacing(1)
  },
  [`& .${classes.submit}`]: {
    margin: theme.spacing(3, 0, 2)
  },
  [`& .${classes.alertMessage}`]: {
    marginBottom: theme.spacing(2)
  }
}));
const SignInForm = ({ authService }) => {
  _s();
  const [authState, sendAuth] = useActor(authService);
  const initialValues = {
    username: "",
    password: "",
    remember: void 0
  };
  const signInPending = (payload) => sendAuth({ type: "LOGIN", ...payload });
  return /* @__PURE__ */ jsxDEV(StyledContainer, { component: "main", maxWidth: "xs", children: [
    /* @__PURE__ */ jsxDEV(CssBaseline, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: classes.paper, children: [
      authState.context?.message && /* @__PURE__ */ jsxDEV(Alert, { "data-test": "signin-error", severity: "error", className: classes.alertMessage, children: authState.context.message }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
        lineNumber: 88,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV(RWALogo, { className: classes.logo }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
        lineNumber: 93,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
        lineNumber: 92,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Typography, { component: "h1", variant: "h5", children: "Sign in" }, void 0, false, {
        fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
        lineNumber: 95,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(
        Formik,
        {
          initialValues,
          validationSchema,
          onSubmit: async (values, { setSubmitting }) => {
            setSubmitting(true);
            signInPending(values);
          },
          children: ({ isValid, isSubmitting }) => /* @__PURE__ */ jsxDEV(Form, { className: classes.form, children: [
            /* @__PURE__ */ jsxDEV(Field, { name: "username", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                fullWidth: true,
                id: "username",
                label: "Username",
                type: "text",
                autoFocus: true,
                "data-test": "signin-username",
                error: (touched || value !== initialValue) && Boolean(error),
                helperText: touched || value !== initialValue ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 111,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
              lineNumber: 109,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(Field, { name: "password", children: ({ field, meta: { error, value, initialValue, touched } }) => /* @__PURE__ */ jsxDEV(
              TextField,
              {
                variant: "outlined",
                margin: "normal",
                fullWidth: true,
                label: "Password",
                type: "password",
                id: "password",
                "data-test": "signin-password",
                error: touched && value !== initialValue && Boolean(error),
                helperText: touched && value !== initialValue && touched ? error : "",
                ...field
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 128,
                columnNumber: 15
              },
              this
            ) }, void 0, false, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
              lineNumber: 126,
              columnNumber: 15
            }, this),
            /* @__PURE__ */ jsxDEV(
              FormControlLabel,
              {
                control: /* @__PURE__ */ jsxDEV(Field, { name: "remember", children: ({ field }) => {
                  return /* @__PURE__ */ jsxDEV(Checkbox, { color: "primary", "data-test": "signin-remember-me", ...field }, void 0, false, {
                    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                    lineNumber: 146,
                    columnNumber: 26
                  }, this);
                } }, void 0, false, {
                  fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                  lineNumber: 144,
                  columnNumber: 15
                }, this),
                label: "Remember me"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 142,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              Button,
              {
                type: "submit",
                fullWidth: true,
                variant: "contained",
                color: "primary",
                className: classes.submit,
                "data-test": "signin-submit",
                disabled: !isValid || isSubmitting,
                children: "Sign In"
              },
              void 0,
              false,
              {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 152,
                columnNumber: 15
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(Grid, { container: true, children: [
              /* @__PURE__ */ jsxDEV(Grid, { item: true, xs: true }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 164,
                columnNumber: 17
              }, this),
              /* @__PURE__ */ jsxDEV(Grid, { item: true, children: /* @__PURE__ */ jsxDEV(Link, { "data-test": "signup", to: "/signup", children: "Don't have an account? Sign Up" }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 168,
                columnNumber: 19
              }, this) }, void 0, false, {
                fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
                lineNumber: 167,
                columnNumber: 17
              }, this)
            ] }, void 0, true, {
              fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
              lineNumber: 163,
              columnNumber: 15
            }, this)
          ] }, void 0, true, {
            fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
            lineNumber: 108,
            columnNumber: 11
          }, this)
        },
        void 0,
        false,
        {
          fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
          lineNumber: 98,
          columnNumber: 9
        },
        this
      )
    ] }, void 0, true, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
      lineNumber: 86,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Box, { mt: 8, children: /* @__PURE__ */ jsxDEV(Footer, {}, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
      lineNumber: 178,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
      lineNumber: 177,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx",
    lineNumber: 84,
    columnNumber: 5
  }, this);
};
_s(SignInForm, "pUJtIQi1VqUJ66yHLq7JmkgZGZg=", false, function() {
  return [useActor];
});
_c = SignInForm;
export default SignInForm;
var _c;
$RefreshReg$(_c, "SignInForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
}
if (import.meta.hot && !inWebWorker) {
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/AS-L34/Desktop/TypeScript/cypress-realworld-app/src/components/SignInForm.tsx", currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZNOzJCQXBGTjtBQUFrQixNQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUN6QixTQUFTQSxjQUFjO0FBRXZCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxZQUFZO0FBQ3JCO0FBQUEsRUFDRUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsRUFDQUM7QUFBQUEsT0FDSztBQUNQLFNBQVNDLFFBQVFDLE1BQU1DLGFBQXlCO0FBQ2hELFNBQVNDLFFBQVFDLGNBQWM7QUFFL0IsT0FBT0MsYUFBYTtBQUNwQixPQUFPQyxZQUFZO0FBR25CLFNBQVNDLGFBQWE7QUFFdEIsTUFBTUMsbUJBQW1CSixPQUFPO0FBQUEsRUFDOUJLLFVBQVVOLE9BQU8sRUFBRU8sU0FBUyxzQkFBc0I7QUFBQSxFQUNsREMsVUFBVVIsT0FBTyxFQUNkUyxJQUFJLEdBQUcsNkNBQTZDLEVBQ3BERixTQUFTLHFCQUFxQjtBQUNuQyxDQUFDO0FBRUQsTUFBTUcsU0FBUztBQUVmLE1BQU1DLFVBQVU7QUFBQSxFQUNkQyxPQUFPLEdBQUdGLE1BQU07QUFBQSxFQUNoQkcsTUFBTSxHQUFHSCxNQUFNO0FBQUEsRUFDZkksTUFBTSxHQUFHSixNQUFNO0FBQUEsRUFDZkssUUFBUSxHQUFHTCxNQUFNO0FBQUEsRUFDakJNLGNBQWMsR0FBR04sTUFBTTtBQUN6QjtBQUVBLE1BQU1PLGtCQUFrQmhDLE9BQU9XLFNBQVMsRUFBRSxDQUFDLEVBQUVzQixNQUFNLE9BQU87QUFBQSxFQUN4RCxDQUFDLE1BQU1QLFFBQVFDLEtBQUssRUFBRSxHQUFHO0FBQUEsSUFDdkJPLFdBQVdELE1BQU1FLFFBQVEsQ0FBQztBQUFBLElBQzFCQyxTQUFTO0FBQUEsSUFDVEMsZUFBZTtBQUFBLElBQ2ZDLFlBQVk7QUFBQSxFQUNkO0FBQUEsRUFFQSxDQUFDLE1BQU1aLFFBQVFFLElBQUksRUFBRSxHQUFHO0FBQUEsSUFDdEJXLE9BQU9OLE1BQU1PLFFBQVFDLFFBQVFDO0FBQUFBLEVBQy9CO0FBQUEsRUFFQSxDQUFDLE1BQU1oQixRQUFRRyxJQUFJLEVBQUUsR0FBRztBQUFBLElBQ3RCYyxPQUFPO0FBQUE7QUFBQSxJQUNQVCxXQUFXRCxNQUFNRSxRQUFRLENBQUM7QUFBQSxFQUM1QjtBQUFBLEVBRUEsQ0FBQyxNQUFNVCxRQUFRSSxNQUFNLEVBQUUsR0FBRztBQUFBLElBQ3hCYyxRQUFRWCxNQUFNRSxRQUFRLEdBQUcsR0FBRyxDQUFDO0FBQUEsRUFDL0I7QUFBQSxFQUVBLENBQUMsTUFBTVQsUUFBUUssWUFBWSxFQUFFLEdBQUc7QUFBQSxJQUM5QmMsY0FBY1osTUFBTUUsUUFBUSxDQUFDO0FBQUEsRUFDL0I7QUFDRixFQUFFO0FBTUYsTUFBTVcsYUFBOEJBLENBQUMsRUFBRUMsWUFBWSxNQUFNO0FBQUFDLEtBQUE7QUFDdkQsUUFBTSxDQUFDQyxXQUFXQyxRQUFRLElBQUlqRCxTQUFTOEMsV0FBVztBQUNsRCxRQUFNSSxnQkFBK0I7QUFBQSxJQUNuQzlCLFVBQVU7QUFBQSxJQUNWRSxVQUFVO0FBQUEsSUFDVjZCLFVBQVVDO0FBQUFBLEVBQ1o7QUFFQSxRQUFNQyxnQkFBZ0JBLENBQUNDLFlBQTJCTCxTQUFTLEVBQUVNLE1BQU0sU0FBUyxHQUFHRCxRQUFRLENBQUM7QUFFeEYsU0FDRSx1QkFBQyxtQkFBZ0IsV0FBVSxRQUFPLFVBQVMsTUFDekM7QUFBQSwyQkFBQyxpQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVk7QUFBQSxJQUNaLHVCQUFDLFNBQUksV0FBVzdCLFFBQVFDLE9BQ3JCc0I7QUFBQUEsZ0JBQVVRLFNBQVNDLFdBQ2xCLHVCQUFDLFNBQU0sYUFBVSxnQkFBZSxVQUFTLFNBQVEsV0FBV2hDLFFBQVFLLGNBQ2pFa0Isb0JBQVVRLFFBQVFDLFdBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYsdUJBQUMsU0FDQyxpQ0FBQyxXQUFRLFdBQVdoQyxRQUFRRSxRQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlDLEtBRG5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsY0FBVyxXQUFVLE1BQUssU0FBUSxNQUFLLHVCQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNBO0FBQUEsUUFBQztBQUFBO0FBQUEsVUFDQztBQUFBLFVBQ0E7QUFBQSxVQUNBLFVBQVUsT0FBTytCLFFBQVEsRUFBRUMsY0FBYyxNQUFNO0FBQzdDQSwwQkFBYyxJQUFJO0FBRWxCTiwwQkFBY0ssTUFBTTtBQUFBLFVBQ3RCO0FBQUEsVUFFQyxXQUFDLEVBQUVFLFNBQVNDLGFBQWEsTUFDeEIsdUJBQUMsUUFBSyxXQUFXcEMsUUFBUUcsTUFDdkI7QUFBQSxtQ0FBQyxTQUFNLE1BQUssWUFDVCxXQUFDLEVBQUVrQyxPQUFPQyxNQUFNLEVBQUVDLE9BQU9DLE9BQU9DLGNBQWNDLFFBQVEsRUFBYyxNQUNuRTtBQUFBLGNBQUM7QUFBQTtBQUFBLGdCQUNDLFNBQVE7QUFBQSxnQkFDUixRQUFPO0FBQUEsZ0JBQ1A7QUFBQSxnQkFDQSxJQUFHO0FBQUEsZ0JBQ0gsT0FBTTtBQUFBLGdCQUNOLE1BQUs7QUFBQSxnQkFDTDtBQUFBLGdCQUNBLGFBQVU7QUFBQSxnQkFDVixRQUFRQSxXQUFXRixVQUFVQyxpQkFBaUJFLFFBQVFKLEtBQUs7QUFBQSxnQkFDM0QsWUFBWUcsV0FBV0YsVUFBVUMsZUFBZUYsUUFBUTtBQUFBLGdCQUN4RCxHQUFJRjtBQUFBQTtBQUFBQSxjQVhOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVdZLEtBYmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBZ0JBO0FBQUEsWUFDQSx1QkFBQyxTQUFNLE1BQUssWUFDVCxXQUFDLEVBQUVBLE9BQU9DLE1BQU0sRUFBRUMsT0FBT0MsT0FBT0MsY0FBY0MsUUFBUSxFQUFjLE1BQ25FO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsU0FBUTtBQUFBLGdCQUNSLFFBQU87QUFBQSxnQkFDUDtBQUFBLGdCQUNBLE9BQU07QUFBQSxnQkFDTixNQUFLO0FBQUEsZ0JBQ0wsSUFBRztBQUFBLGdCQUNILGFBQVU7QUFBQSxnQkFDVixPQUFPQSxXQUFXRixVQUFVQyxnQkFBZ0JFLFFBQVFKLEtBQUs7QUFBQSxnQkFDekQsWUFBWUcsV0FBV0YsVUFBVUMsZ0JBQWdCQyxVQUFVSCxRQUFRO0FBQUEsZ0JBQ25FLEdBQUlGO0FBQUFBO0FBQUFBLGNBVk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVVksS0FaaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFlQTtBQUFBLFlBQ0E7QUFBQSxjQUFDO0FBQUE7QUFBQSxnQkFDQyxTQUNFLHVCQUFDLFNBQU0sTUFBTSxZQUNWLFdBQUMsRUFBRUEsTUFBa0IsTUFBTTtBQUMxQix5QkFBTyx1QkFBQyxZQUFTLE9BQU0sV0FBVSxhQUFVLHNCQUFxQixHQUFJQSxTQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUFtRTtBQUFBLGdCQUM1RSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSUE7QUFBQSxnQkFFRixPQUFNO0FBQUE7QUFBQSxjQVJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVFxQjtBQUFBLFlBRXJCO0FBQUEsY0FBQztBQUFBO0FBQUEsZ0JBQ0MsTUFBSztBQUFBLGdCQUNMO0FBQUEsZ0JBQ0EsU0FBUTtBQUFBLGdCQUNSLE9BQU07QUFBQSxnQkFDTixXQUFXckMsUUFBUUk7QUFBQUEsZ0JBQ25CLGFBQVU7QUFBQSxnQkFDVixVQUFVLENBQUMrQixXQUFXQztBQUFBQSxnQkFBYTtBQUFBO0FBQUEsY0FQckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBVUE7QUFBQSxZQUNBLHVCQUFDLFFBQUssV0FBUyxNQUNiO0FBQUEscUNBQUMsUUFBSyxNQUFJLE1BQUMsSUFBRSxRQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRUE7QUFBQSxjQUNBLHVCQUFDLFFBQUssTUFBSSxNQUNSLGlDQUFDLFFBQUssYUFBVSxVQUFTLElBQUcsV0FDekIsOENBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSUE7QUFBQSxpQkFSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVNBO0FBQUEsZUFoRUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFpRUE7QUFBQTtBQUFBLFFBM0VKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxNQTZFQTtBQUFBLFNBekZGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0EwRkE7QUFBQSxJQUNBLHVCQUFDLE9BQUksSUFBSSxHQUNQLGlDQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPLEtBRFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0EvRkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdHQTtBQUVKO0FBQUVkLEdBN0dJRixZQUEyQjtBQUFBLFVBQ0Q3QyxRQUFRO0FBQUE7QUFBQXFFLEtBRGxDeEI7QUErR04sZUFBZUE7QUFBVyxJQUFBd0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInN0eWxlZCIsInVzZUFjdG9yIiwiTGluayIsIkJ1dHRvbiIsIkNzc0Jhc2VsaW5lIiwiVGV4dEZpZWxkIiwiRm9ybUNvbnRyb2xMYWJlbCIsIkNoZWNrYm94IiwiR3JpZCIsIkJveCIsIlR5cG9ncmFwaHkiLCJDb250YWluZXIiLCJGb3JtaWsiLCJGb3JtIiwiRmllbGQiLCJzdHJpbmciLCJvYmplY3QiLCJSV0FMb2dvIiwiRm9vdGVyIiwiQWxlcnQiLCJ2YWxpZGF0aW9uU2NoZW1hIiwidXNlcm5hbWUiLCJyZXF1aXJlZCIsInBhc3N3b3JkIiwibWluIiwiUFJFRklYIiwiY2xhc3NlcyIsInBhcGVyIiwibG9nbyIsImZvcm0iLCJzdWJtaXQiLCJhbGVydE1lc3NhZ2UiLCJTdHlsZWRDb250YWluZXIiLCJ0aGVtZSIsIm1hcmdpblRvcCIsInNwYWNpbmciLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImFsaWduSXRlbXMiLCJjb2xvciIsInBhbGV0dGUiLCJwcmltYXJ5IiwibWFpbiIsIndpZHRoIiwibWFyZ2luIiwibWFyZ2luQm90dG9tIiwiU2lnbkluRm9ybSIsImF1dGhTZXJ2aWNlIiwiX3MiLCJhdXRoU3RhdGUiLCJzZW5kQXV0aCIsImluaXRpYWxWYWx1ZXMiLCJyZW1lbWJlciIsInVuZGVmaW5lZCIsInNpZ25JblBlbmRpbmciLCJwYXlsb2FkIiwidHlwZSIsImNvbnRleHQiLCJtZXNzYWdlIiwidmFsdWVzIiwic2V0U3VibWl0dGluZyIsImlzVmFsaWQiLCJpc1N1Ym1pdHRpbmciLCJmaWVsZCIsIm1ldGEiLCJlcnJvciIsInZhbHVlIiwiaW5pdGlhbFZhbHVlIiwidG91Y2hlZCIsIkJvb2xlYW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpZ25JbkZvcm0udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgc3R5bGVkIH0gZnJvbSBcIkBtdWkvbWF0ZXJpYWwvc3R5bGVzXCI7XHJcbmltcG9ydCB7IEludGVycHJldGVyIH0gZnJvbSBcInhzdGF0ZVwiO1xyXG5pbXBvcnQgeyB1c2VBY3RvciB9IGZyb20gXCJAeHN0YXRlL3JlYWN0XCI7XHJcbmltcG9ydCB7IExpbmsgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQge1xyXG4gIEJ1dHRvbixcclxuICBDc3NCYXNlbGluZSxcclxuICBUZXh0RmllbGQsXHJcbiAgRm9ybUNvbnRyb2xMYWJlbCxcclxuICBDaGVja2JveCxcclxuICBHcmlkLFxyXG4gIEJveCxcclxuICBUeXBvZ3JhcGh5LFxyXG4gIENvbnRhaW5lcixcclxufSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5pbXBvcnQgeyBGb3JtaWssIEZvcm0sIEZpZWxkLCBGaWVsZFByb3BzIH0gZnJvbSBcImZvcm1pa1wiO1xyXG5pbXBvcnQgeyBzdHJpbmcsIG9iamVjdCB9IGZyb20gXCJ5dXBcIjtcclxuXHJcbmltcG9ydCBSV0FMb2dvIGZyb20gXCIuL1N2Z1J3YUxvZ29cIjtcclxuaW1wb3J0IEZvb3RlciBmcm9tIFwiLi9Gb290ZXJcIjtcclxuaW1wb3J0IHsgU2lnbkluUGF5bG9hZCB9IGZyb20gXCIuLi9tb2RlbHNcIjtcclxuaW1wb3J0IHsgQXV0aE1hY2hpbmVDb250ZXh0LCBBdXRoTWFjaGluZUV2ZW50cywgQXV0aE1hY2hpbmVTY2hlbWEgfSBmcm9tIFwiLi4vbWFjaGluZXMvYXV0aE1hY2hpbmVcIjtcclxuaW1wb3J0IHsgQWxlcnQgfSBmcm9tIFwiQG11aS9tYXRlcmlhbFwiO1xyXG5cclxuY29uc3QgdmFsaWRhdGlvblNjaGVtYSA9IG9iamVjdCh7XHJcbiAgdXNlcm5hbWU6IHN0cmluZygpLnJlcXVpcmVkKFwiVXNlcm5hbWUgaXMgcmVxdWlyZWRcIiksXHJcbiAgcGFzc3dvcmQ6IHN0cmluZygpXHJcbiAgICAubWluKDQsIFwiUGFzc3dvcmQgbXVzdCBjb250YWluIGF0IGxlYXN0IDQgY2hhcmFjdGVyc1wiKVxyXG4gICAgLnJlcXVpcmVkKFwiRW50ZXIgeW91ciBwYXNzd29yZFwiKSxcclxufSk7XHJcblxyXG5jb25zdCBQUkVGSVggPSBcIlNpZ25JbkZvcm1cIjtcclxuXHJcbmNvbnN0IGNsYXNzZXMgPSB7XHJcbiAgcGFwZXI6IGAke1BSRUZJWH0tcGFwZXJgLFxyXG4gIGxvZ286IGAke1BSRUZJWH0tbG9nb2AsXHJcbiAgZm9ybTogYCR7UFJFRklYfS1mb3JtYCxcclxuICBzdWJtaXQ6IGAke1BSRUZJWH0tc3VibWl0YCxcclxuICBhbGVydE1lc3NhZ2U6IGAke1BSRUZJWH0tYWxlcnRNZXNzYWdlYCxcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZENvbnRhaW5lciA9IHN0eWxlZChDb250YWluZXIpKCh7IHRoZW1lIH0pID0+ICh7XHJcbiAgW2AmIC4ke2NsYXNzZXMucGFwZXJ9YF06IHtcclxuICAgIG1hcmdpblRvcDogdGhlbWUuc3BhY2luZyg4KSxcclxuICAgIGRpc3BsYXk6IFwiZmxleFwiLFxyXG4gICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcclxuICAgIGFsaWduSXRlbXM6IFwiY2VudGVyXCIsXHJcbiAgfSxcclxuXHJcbiAgW2AmIC4ke2NsYXNzZXMubG9nb31gXToge1xyXG4gICAgY29sb3I6IHRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmZvcm19YF06IHtcclxuICAgIHdpZHRoOiBcIjEwMCVcIiwgLy8gRml4IElFIDExIGlzc3VlLlxyXG4gICAgbWFyZ2luVG9wOiB0aGVtZS5zcGFjaW5nKDEpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLnN1Ym1pdH1gXToge1xyXG4gICAgbWFyZ2luOiB0aGVtZS5zcGFjaW5nKDMsIDAsIDIpLFxyXG4gIH0sXHJcblxyXG4gIFtgJiAuJHtjbGFzc2VzLmFsZXJ0TWVzc2FnZX1gXToge1xyXG4gICAgbWFyZ2luQm90dG9tOiB0aGVtZS5zcGFjaW5nKDIpLFxyXG4gIH0sXHJcbn0pKSBhcyB0eXBlb2YgQ29udGFpbmVyO1xyXG5cclxuZXhwb3J0IGludGVyZmFjZSBQcm9wcyB7XHJcbiAgYXV0aFNlcnZpY2U6IEludGVycHJldGVyPEF1dGhNYWNoaW5lQ29udGV4dCwgQXV0aE1hY2hpbmVTY2hlbWEsIEF1dGhNYWNoaW5lRXZlbnRzLCBhbnksIGFueT47XHJcbn1cclxuXHJcbmNvbnN0IFNpZ25JbkZvcm06IFJlYWN0LkZDPFByb3BzPiA9ICh7IGF1dGhTZXJ2aWNlIH0pID0+IHtcclxuICBjb25zdCBbYXV0aFN0YXRlLCBzZW5kQXV0aF0gPSB1c2VBY3RvcihhdXRoU2VydmljZSk7XHJcbiAgY29uc3QgaW5pdGlhbFZhbHVlczogU2lnbkluUGF5bG9hZCA9IHtcclxuICAgIHVzZXJuYW1lOiBcIlwiLFxyXG4gICAgcGFzc3dvcmQ6IFwiXCIsXHJcbiAgICByZW1lbWJlcjogdW5kZWZpbmVkLFxyXG4gIH07XHJcblxyXG4gIGNvbnN0IHNpZ25JblBlbmRpbmcgPSAocGF5bG9hZDogU2lnbkluUGF5bG9hZCkgPT4gc2VuZEF1dGgoeyB0eXBlOiBcIkxPR0lOXCIsIC4uLnBheWxvYWQgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8U3R5bGVkQ29udGFpbmVyIGNvbXBvbmVudD1cIm1haW5cIiBtYXhXaWR0aD1cInhzXCI+XHJcbiAgICAgIDxDc3NCYXNlbGluZSAvPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT17Y2xhc3Nlcy5wYXBlcn0+XHJcbiAgICAgICAge2F1dGhTdGF0ZS5jb250ZXh0Py5tZXNzYWdlICYmIChcclxuICAgICAgICAgIDxBbGVydCBkYXRhLXRlc3Q9XCJzaWduaW4tZXJyb3JcIiBzZXZlcml0eT1cImVycm9yXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmFsZXJ0TWVzc2FnZX0+XHJcbiAgICAgICAgICAgIHthdXRoU3RhdGUuY29udGV4dC5tZXNzYWdlfVxyXG4gICAgICAgICAgPC9BbGVydD5cclxuICAgICAgICApfVxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8UldBTG9nbyBjbGFzc05hbWU9e2NsYXNzZXMubG9nb30gLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8VHlwb2dyYXBoeSBjb21wb25lbnQ9XCJoMVwiIHZhcmlhbnQ9XCJoNVwiPlxyXG4gICAgICAgICAgU2lnbiBpblxyXG4gICAgICAgIDwvVHlwb2dyYXBoeT5cclxuICAgICAgICA8Rm9ybWlrXHJcbiAgICAgICAgICBpbml0aWFsVmFsdWVzPXtpbml0aWFsVmFsdWVzfVxyXG4gICAgICAgICAgdmFsaWRhdGlvblNjaGVtYT17dmFsaWRhdGlvblNjaGVtYX1cclxuICAgICAgICAgIG9uU3VibWl0PXthc3luYyAodmFsdWVzLCB7IHNldFN1Ym1pdHRpbmcgfSkgPT4ge1xyXG4gICAgICAgICAgICBzZXRTdWJtaXR0aW5nKHRydWUpO1xyXG5cclxuICAgICAgICAgICAgc2lnbkluUGVuZGluZyh2YWx1ZXMpO1xyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7KHsgaXNWYWxpZCwgaXNTdWJtaXR0aW5nIH0pID0+IChcclxuICAgICAgICAgICAgPEZvcm0gY2xhc3NOYW1lPXtjbGFzc2VzLmZvcm19PlxyXG4gICAgICAgICAgICAgIDxGaWVsZCBuYW1lPVwidXNlcm5hbWVcIj5cclxuICAgICAgICAgICAgICAgIHsoeyBmaWVsZCwgbWV0YTogeyBlcnJvciwgdmFsdWUsIGluaXRpYWxWYWx1ZSwgdG91Y2hlZCB9IH06IEZpZWxkUHJvcHMpID0+IChcclxuICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJvdXRsaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luPVwibm9ybWFsXCJcclxuICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBsYWJlbD1cIlVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYXV0b0ZvY3VzXHJcbiAgICAgICAgICAgICAgICAgICAgZGF0YS10ZXN0PVwic2lnbmluLXVzZXJuYW1lXCJcclxuICAgICAgICAgICAgICAgICAgICBlcnJvcj17KHRvdWNoZWQgfHwgdmFsdWUgIT09IGluaXRpYWxWYWx1ZSkgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17dG91Y2hlZCB8fCB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlID8gZXJyb3IgOiBcIlwifVxyXG4gICAgICAgICAgICAgICAgICAgIHsuLi5maWVsZH1cclxuICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9GaWVsZD5cclxuICAgICAgICAgICAgICA8RmllbGQgbmFtZT1cInBhc3N3b3JkXCI+XHJcbiAgICAgICAgICAgICAgICB7KHsgZmllbGQsIG1ldGE6IHsgZXJyb3IsIHZhbHVlLCBpbml0aWFsVmFsdWUsIHRvdWNoZWQgfSB9OiBGaWVsZFByb3BzKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgIDxUZXh0RmllbGRcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwib3V0bGluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1hcmdpbj1cIm5vcm1hbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJQYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICBkYXRhLXRlc3Q9XCJzaWduaW4tcGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGVycm9yPXt0b3VjaGVkICYmIHZhbHVlICE9PSBpbml0aWFsVmFsdWUgJiYgQm9vbGVhbihlcnJvcil9XHJcbiAgICAgICAgICAgICAgICAgICAgaGVscGVyVGV4dD17dG91Y2hlZCAmJiB2YWx1ZSAhPT0gaW5pdGlhbFZhbHVlICYmIHRvdWNoZWQgPyBlcnJvciA6IFwiXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgey4uLmZpZWxkfVxyXG4gICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgIDxGb3JtQ29udHJvbExhYmVsXHJcbiAgICAgICAgICAgICAgICBjb250cm9sPXtcclxuICAgICAgICAgICAgICAgICAgPEZpZWxkIG5hbWU9e1wicmVtZW1iZXJcIn0+XHJcbiAgICAgICAgICAgICAgICAgICAgeyh7IGZpZWxkIH06IEZpZWxkUHJvcHMpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA8Q2hlY2tib3ggY29sb3I9XCJwcmltYXJ5XCIgZGF0YS10ZXN0PVwic2lnbmluLXJlbWVtYmVyLW1lXCIgey4uLmZpZWxkfSAvPjtcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICA8L0ZpZWxkPlxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgbGFiZWw9XCJSZW1lbWJlciBtZVwiXHJcbiAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICB0eXBlPVwic3VibWl0XCJcclxuICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnN1Ym1pdH1cclxuICAgICAgICAgICAgICAgIGRhdGEtdGVzdD1cInNpZ25pbi1zdWJtaXRcIlxyXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9eyFpc1ZhbGlkIHx8IGlzU3VibWl0dGluZ31cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICBTaWduIEluXHJcbiAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz5cclxuICAgICAgICAgICAgICAgICAgey8qPExpbmsgdG89XCIvZm9yZ290cGFzc3dvcmRcIj5Gb3Jnb3QgcGFzc3dvcmQ/PC9MaW5rPiovfVxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbT5cclxuICAgICAgICAgICAgICAgICAgPExpbmsgZGF0YS10ZXN0PVwic2lnbnVwXCIgdG89XCIvc2lnbnVwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAge1wiRG9uJ3QgaGF2ZSBhbiBhY2NvdW50PyBTaWduIFVwXCJ9XHJcbiAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDwvRm9ybT5cclxuICAgICAgICAgICl9XHJcbiAgICAgICAgPC9Gb3JtaWs+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgICA8Qm94IG10PXs4fT5cclxuICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgIDwvQm94PlxyXG4gICAgPC9TdHlsZWRDb250YWluZXI+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFNpZ25JbkZvcm07XHJcbiJdLCJmaWxlIjoiQzovVXNlcnMvQVMtTDM0L0Rlc2t0b3AvVHlwZVNjcmlwdC9jeXByZXNzLXJlYWx3b3JsZC1hcHAvc3JjL2NvbXBvbmVudHMvU2lnbkluRm9ybS50c3gifQ==